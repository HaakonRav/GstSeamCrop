#include "types/MocaTypes.h"
#include <iostream>

#ifdef HAVE_CAMERA
#ifdef HAVE_LIBFLTK

#include "gui/CameraWindow.h"
#include "filter/CvtColorSpace.h"
#include "types/MocaException.h"


class TestWindow : public CameraWindow
{
public:
  TestWindow(Rect dim, std::string title, bool color)
    : CameraWindow(dim, title, Rect(0, 0, dim.w, dim.h), CameraReader::SPEED_400,
                   color ? CameraReader::MODE_RAW8 : CameraReader::MODE_MONO8), color(color)
  {
    colorImage = boost::shared_ptr<Image8U>(new Image8U(image->width(), image->height(), 3));
  }

protected:
  void doStuff()
  {
    reader->getImage(*image);
    if (color)
      {
        CvtColorSpace::convert(*image, *colorImage, COLOR_BayerGB, COLOR_BGR);
        showImage(colorImage);
      }
    else
      showImage(image);
  }

  boost::shared_ptr<Image8U> colorImage;
  bool color;
};


int main(int argc, char **argv)
{
  if(argc<3)
  {
    std::cout << "usage: " << argv[0] << " width height [color]" << std::endl;
    return 1;
  }
  
  bool color = argc>3;

  try
  {
    TestWindow wnd(Rect(256, 256, atoi(argv[1]), atoi(argv[2])), std::string("Camera Image Viewer"), color);
    wnd.mainLoop();
  }
  catch(MocaException& e)
  {
    std::cerr << diagnostic_information(e);
  }
  
  return 0;
}

#else // HAVE_LIBFLTK

int main(int argc, char** argv)
{
  std::cout << "this example requires FLTK." << std::endl;
  return 0;
}


#endif // HAVE_LIBFLTK
#else // HAVE_CAMERA

int main(int argc, char** argv)
{
  std::cout << "this example requires a supported camera." << std::endl;
  return 0;
}


#endif // HAVE_CAMERA


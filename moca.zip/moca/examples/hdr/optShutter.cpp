#include "feature/Histogram.h"
#include "feature/OptimalShutter.h"
#include "filter/CvtColorSpace.h"
#include "filter/HDRStitching.h"
#include "filter/ToneMapping.h"
#include "io/HDRExposureIO.h"
#include "io/HDRImageIO.h"
#include "io/IO.h"
#include "io/DC1394Reader_Triggered.h"
#include "tools/Drawing.h"
#include "tools/Timing.h"
#include "types/Color.h"
#include "types/MocaException.h"
#include "types/Image32F.h"

#include <fstream>
#include <boost/archive/text_iarchive.hpp>
#include <boost/serialization/vector.hpp>
#include <boost/shared_ptr.hpp>



#ifdef HAVE_LIBDC1394

class OptShutter
{
public:
  OptShutter()
    : hist(0, 1, 10), numVideos(6), maxFrames(10),
      reqCov(0.15), minUseFactor(0.01), filePrefix("schmorf")
  {
  }

  // fills expSets with the saved exposure set sequence
  // resizes hdrVideo appropriately
  void loadHDRVideo(std::string path)
  {
    /*
    std::vector<std::vector<VectorI> > gTruth;
    std::cout << "Loading ground truth... ";
    std::ifstream fs(std::string(path + "/gtruth.txt").c_str());
    boost::archive::text_iarchive archive(fs);
    archive >> gTruth;
    std::cout << "done" << std::endl;
    */

    boost::shared_ptr<HDRExposureIO> reader = HDRExposureIO::createReader(path);
    expSets.clear();
    expSets.resize(reader->getNumExposures());
    std::cout << "Loading " << std::min((uint32)expSets.size(), maxFrames) << " exposure sets: ";
    for (uint32 i=0; i<expSets.size() && i<maxFrames; ++i)
      {
        std::cout << i << "  "; std::cout.flush();
        reader->getNext(expSets[i]);
      }
    std::cout << std::endl;
    reader->close();

    // load reference HDR frames
    std::cout << "Loading reference HDR frames: ";
    reference.clear();
    reference.reserve(expSets.size());
    for (uint32 i=0; i<expSets.size() && i<maxFrames; ++i)
      {
        std::cout << i << " ";
        std::stringstream name;
        name << path << "/hdr" << i << ".rgbe";
        boost::shared_ptr<Image32F> img(HDRImageIO::loadHDRImage(name.str(), false));
        reference.push_back(*img);
      }
    std::cout << std::endl;

    // resize hdrVideo
    assert(expSets.size() > 0 && expSets[0].size() > 0);
    boost::shared_ptr<Image8U> expImg = expSets[0][0].image;
    Image32F prototype(expImg->width(), expImg->height(), expImg->channels());
    hdrVideo.clear();
    hdrVideo.resize(expSets.size(), prototype);
  }

  // full==true: stitch using all exposures. false: only use the shutters in shutters
  void stitchHDRFrame(uint32 index, bool full=true)
  {
    assert(index < hdrVideo.size() && index < expSets.size());
    std::cout << "HDR stitching exposure set " << index << std::endl;

    std::vector<Exposure> expSet;
    if (full)
      expSet = expSets[index];
    else
      expSet = OptimalShutter::selectExposures(expSets[index], shutters);

    for (uint32 j=0; j<expSet.size(); ++j)
      {
        Exposure& e = expSet[j];
        CvtColorSpace::convert(*e.image, *e.image, COLOR_BGR, COLOR_Yxy);
        //e.topLeft = gTruth[index][j];
        //std::cout << "shutter " << j << ": " << e.shutter << std::endl;
      }
    HDRStitching::weighted(expSet, hdrVideo[index]);
    toneMapAndSave(index);
  }

  void toneMapAndSave(uint32 index)
  {
    Image32F& image = hdrVideo[index];
    Image8U ldrImg(image.width(), image.height(), image.channels());
    ToneMapping::histNorm(image, ldrImg);
    CvtColorSpace::convert(ldrImg, ldrImg, COLOR_Yxy, COLOR_BGR);
    std::stringstream ss;
    ss << filePrefix << index << ".png";
    //IO::saveImage(ss.str(), ldrImg);
    // create/save reference HDR frames
    /*
    std::stringstream name;
    name << filePrefix << "hdr" << index << ".rgbe";
    HDRImageIO::saveHDRImage(name.str(), hdrVideo[index], false);
    */
  }

  // each bin has average value of 1
  void createHist(uint32 bins, uint32 index = 0)
  {
    Image32F& image = reference[index];
    float min, max, avg;
    ToneMapping::minMaxAvg(image, min, max, avg);
    min = log(min); max = log(max);

    hist = Histogram(min, max, bins);
    float step = 1/(float)(image.width() * image.height());
    ToneMapping::logHisto(image, hist, step);
    std::cout << "histogram boundaries: (" << min << ", " << max << ")" << std::endl;

    std::vector<double> array(hist.size());
    for (uint32 i=0; i<hist.size(); ++i)
      array[i] = hist.bin(i);
    //arrayToImage(array, 800, filePrefix+"hist.png");
  }

  void arrayToImage(std::vector<double> const& array, uint32 imgWidth, std::string fileName)
  {
    Image8U histImg(imgWidth, imgWidth/4*3, 1);
    Drawing::arrayToImage(histImg, array);
    IO::saveImage(fileName, histImg);
  }

  void createWeightMask() // call after creating the histogram
  {
    weighting = OptimalShutter::createWeightMask(hist);
    
    std::cout << "weighting / hist: " << weighting.size() << "/" << hist.size() << std::endl;
    //arrayToImage(weighting, 800, filePrefix+"mask.png");
  }

  void findBestShutters(uint32 numExps = -1)
  {
    shutters = OptimalShutter::findBestShutters(hist, weighting, numExps);
    drawShutters();
  }

  void findEquiShutters(uint32 numExps)
  {
    shutters = OptimalShutter::findEquiShutters(numExps, hist);
    std::cout << "determined equidistant shutters: ";
    for (uint32 i=0; i<shutters.size(); ++i)
      std::cout << shutters[i] << " ";
    std::cout << std::endl;
    drawShutters();
  }

  // draw exposure coverage into an image
  void drawShutters()
  {
    assert(weighting.size() > 0);
    std::vector<double> coverage;
    coverage.resize(hist.size(), 0);
    for (uint32 i=0; i<shutters.size(); ++i)
      {
        // log radiance value to which pixel value 1 gets mapped
        double rad = log(1.0 / shutters[i]);
        int32 bin = (rad-hist.getMinVal()) / (hist.getMaxVal()-hist.getMinVal()) * hist.size() + 0.5;
        int32 start = std::max(bin, 0);
        int32 end = std::min((int32)hist.size(), (int32)weighting.size()+bin);
        for (int32 j=start; j<end; ++j)
          coverage[j] += weighting[j-bin];
      }
    //arrayToImage(coverage, 800, filePrefix+"cov.png");
  }

  // Computes the SNR of hdrVideo. Each frame must be an HDR image of the _same_ scene
  double computePSNR()
  {
    assert(hdrVideo.size() > 0);
    uint32 width = hdrVideo[0].width(), height = hdrVideo[0].height();
    uint32 size = std::min((uint32)hdrVideo.size(), maxFrames);
    double avgPSNR = 0;

    for (uint32 index=0; index<size; ++index)
      {
        float max = -INFINITY;
        double mse = 0; // mean squared error
        for (uint32 y=0; y<height; ++y)
          for (uint32 x=0; x<width; ++x)
            {
              max = std::max(reference[index](x, y), max);
              double diff = hdrVideo[index](x, y) - reference[index](x, y);
              mse += diff * diff;
            }
        mse /= width*height;
        avgPSNR += 20 * log10(max/sqrt(mse));
      }
    avgPSNR /= size;
    return avgPSNR;
  }
  
  double computeSNR()
  {
    assert(hdrVideo.size() > 0);
    uint32 width = hdrVideo[0].width(), height = hdrVideo[0].height();
    uint32 size = std::min((uint32)hdrVideo.size(), maxFrames);
    double avgSNR = 0;
    int32 excluded = 0;

    for (uint32 y=0; y<height; ++y)
      for (uint32 x=0; x<width; ++x)
        {
          double pixMean = 0;
          for (uint32 index=0; index<size; ++index)
            pixMean += hdrVideo[index](x, y); // brightness channel onry
          pixMean /= size;
          double pixVar = 0;
          for (uint32 index=0; index<size; ++index)
            {
              double diff = hdrVideo[index](x, y) - pixMean;
              pixVar += diff * diff;
            }
          pixVar /= size;
          if (pixVar != 0)
            avgSNR += pixMean / sqrt(pixVar);
          else
            ++excluded;
        }
    avgSNR /= width*height - excluded; // if (excluded == w*h) all pixels were identical -> infinite SNR
    return avgSNR;
  }

public:
  std::vector<std::vector<Exposure> > expSets;
  std::vector<Image32F> hdrVideo;
  std::vector<Image32F> reference; // same as hdrVideo, but stitched using _all_ exposures
  Histogram hist;
  std::vector<double> weighting;
  std::vector<double> shutters;

  // some constants
  uint32 numVideos; // number of videos to be processed for evaluation
  uint32 maxFrames; // number of frames to be loaded from disk (>0 to save time)
  double reqCov; // minimum coverage for each bin of the histogram
  double minUseFactor; // minimum usefulness for an extra shutter speed (use > maxUse*minUseFactor)
  std::string filePrefix; // prefix for filenames when saving images
};


// Captures [numSets] exposure sets from the camera. Scene should be static
// The spacing between the exposures is a factor of [shutFact] (but at least 1.0)
// The [numSets] exposures are saved to disk
void captureTestSet(double shutFact, std::string path, uint32 numSets)
{
  DC1394Reader_Triggered reader(CameraReader::SPEED_800, CameraReader::MODE_RAW8, 0);
  reader.start();
  CameraFeaturePtr shut = reader.getFeature(CameraFeature::FEATURE_Shutter);
  uint32 minShut = shut->getMin(), maxShut = shut->getMax();
  boost::shared_ptr<HDRExposureIO> expWriter(HDRExposureIO::createWriter(path));
  Image8U tempImg(640, 480, 1);
  std::vector<std::vector<Exposure> > expSets(numSets);

  for (uint32 rep=0; rep<numSets; ++rep)
    {
      std::cout << "Set #" << rep << std::endl;
      for (double shut=minShut; shut<=maxShut;)
        {
          uint32 intShut = (uint32)(shut+0.5);
          reader.captureImage(Rect(0, 0, 640, 480), intShut);
          Exposure exp;
          exp.image = boost::shared_ptr<Image8U>(new Image8U(640, 480, 3));
          exp.topLeft = Vector2D::create(0, 0);
          exp.shutter = intShut;
          reader.getImage(tempImg);
          CvtColorSpace::convert(tempImg, *(exp.image), COLOR_BayerGB, COLOR_BGR);
          std::cout << intShut << " " << std::flush;
          expSets[rep].push_back(exp);

          if (shut * (shutFact-1) < 1)
            shut += 1;
          else
            shut *= shutFact;
        }
      std::cout << std::endl;
    }

  std::cout << "Saving... ";
  for (uint32 rep=0; rep<numSets; ++rep)
    {
      std::cout << rep << " " << std::flush;
      expWriter->putNext(expSets[rep]);
    }
  std::cout << std::endl;

  reader.stop();
}


void fullExpResults()
{
  std::string path("/usr/local/bguthier/videos/static_full/");
  std::vector<std::string> fileNames;
  fileNames.push_back("parkinglot");
  fileNames.push_back("fancySun2");
  fileNames.push_back("GartenmitSonne");
  fileNames.push_back("strasserechts");
  fileNames.push_back("TestModel");
  fileNames.push_back("Wohnzimmerdaheim");

  fileNames.push_back("b6");
  fileNames.push_back("desk");
  fileNames.push_back("gartendaheim");
  fileNames.push_back("hausdaheim");
  fileNames.push_back("himmelundlandschaft");
  fileNames.push_back("Landschaftdaheim");
  fileNames.push_back("Strassedaheim");
  fileNames.push_back("Strassedaheim3");

  OptShutter opts;
  opts.numVideos = 14;
  opts.maxFrames = 5;
  //opts.reqCov = 0.275;//0.15;
  //opts.minUseFactor = 0;//0.25;
  uint32 expNums = 5;

  for (uint32 vid=0; vid<opts.numVideos; ++vid)
    {
      opts.filePrefix = fileNames[vid] + "_";
      std::cerr << fileNames[vid] << std::endl;
      std::cerr << "num_exps SNR_opt SNR_equi" << std::endl;
      opts.loadHDRVideo(path + fileNames[vid]);
      opts.createHist(200);
      opts.createWeightMask();

      for (uint32 expNum=1; expNum<=expNums; ++expNum)
        {
          std::stringstream ss;
          ss << fileNames[vid] << "_" << expNum << "_";
          opts.filePrefix = ss.str() + "opt_";
          std::cerr << expNum << " ";
          opts.findBestShutters(expNum);
          for (uint32 i=0; i<20 && i<opts.maxFrames; ++i)
            opts.stitchHDRFrame(i, false);
          std::cerr << opts.computePSNR() << " ";

          opts.filePrefix = ss.str() + "equi_";
          opts.findEquiShutters(expNum);
          for (uint32 i=0; i<20 && i<opts.maxFrames; ++i)
            opts.stitchHDRFrame(i, false);
          std::cerr << opts.computePSNR() << std::endl;
        }
    }
}


void guiMain();

int main(int argc, char** argv)
{
  try
    {
      //captureTestSet(pow(2, 1/8.0), "/usr/local/bguthier/videos/static_full3", 10);
      //return 0;

      //fullExpResults();

      //OptShutter opts;
      //opts.estimateSNRVector();
      
      guiMain();
    }
  catch(MocaException& e)
    {
      std::cerr << diagnostic_information(e);
    }

  return 0;
}

#else //HAVE_LIBDC1394

int main(int argc, char** argv)
{
  std::cout << "this program requires libdc1394." << std::endl;

  return 0;
}

#endif //HAVE_LIBDC1394

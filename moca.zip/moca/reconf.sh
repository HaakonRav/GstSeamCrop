#!/bin/bash
echo configuring system...
rm -f config.status config.cache  
rm -f autom4te.cache/output.0 autom4te.cache/requests autom4te.cache/traces.0 
echo starting aclocal... && \
aclocal -I m4 && \
echo starting libtoolize... && \
libtoolize --force && \
echo starting autoconf... && \
autoconf && \
echo starting autoheader... && \
autoheader && \
echo starting automake... && \
automake -a && \
echo starting configure... && \
./configure --enable-shared --disable-static $* && \
echo && \
echo && \
echo --------------------------------------------------- && \
echo call make to compile moca library && \
echo ---------------------------------------------------

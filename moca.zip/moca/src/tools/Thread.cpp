#include "tools/Thread.h"

#include "types/MocaException.h"


Thread::Thread()
  : isRunning(false)
{
}


Thread::~Thread()
{
  // don't allow detached threads
  stop();
}


void Thread::start()
{
  if (!isRunning)
    {
      thread = boost::thread(boost::ref(*this));
      isRunning = true;
    }
}


void Thread::stop()
{
  thread.interrupt();
  thread.join();
  isRunning = false;
}


void Thread::operator()()
{
  try
    {
      try
        {
          doOnce();
          while (true)
            {
              // this function throws an exception if interrupt() was called
              // (waiting on a condition_variable throws as well)
              boost::this_thread::interruption_point();
              doStuff();
            }
        }
      catch (boost::thread_interrupted&)
        {
          cleanup();
        }
    }
  catch (MocaException& e)
    {
      std::cerr << diagnostic_information(e);
    }
}


void Thread::doOnce()
{
}


void Thread::cleanup()
{
}


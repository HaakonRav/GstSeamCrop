#include "io/IO.h"
#include "types/MocaException.h"
#include <opencv/highgui.h>
#include <boost/algorithm/string.hpp>
#include <boost/filesystem.hpp>


// maybe this could be avoided by using boost/filesystem/fstream.hpp...
#ifdef WIN32
char const IO::dirSeperator[] = "\\";
#else
char const IO::dirSeperator[] = "/";
#endif


boost::shared_ptr<Image8U> IO::loadImage(std::string const& filename)
{
  if (filename.length() == 0)
    BOOST_THROW_EXCEPTION(ArgumentException("No file name given for loading."));
  
  IplImage* loaded = cvLoadImage(filename.c_str(), -1);
  if (loaded == NULL)
    BOOST_THROW_EXCEPTION(IOException("Image file not found for loading."));
  if (loaded->depth != IPL_DEPTH_8U)
    BOOST_THROW_EXCEPTION(NotImplementedException("only 8-bit images are supported."));

  return boost::shared_ptr<Image8U>(new Image8U(loaded));
}


void IO::saveImage(std::string const& fileName, ImageBase const& image)
{
  //filename extension determines format
  if(!cvSaveImage(fileName.c_str(), image.image))
    BOOST_THROW_EXCEPTION(IOException("Could not save Image.") << ErrImg1(image));
}


void IO::checkPath(std::string& path)
{
  uint32 len = path.length();
  if(len == 0 || path[len-1] != dirSeperator[0])
    path.append(dirSeperator);
}


void IO::createDirectories(std::string const& path)
{
  char const* ptr = path.c_str();
  std::vector<std::string> tokens;
  boost::split(tokens, ptr, boost::is_any_of(dirSeperator));
  std::string newPath;
  for(uint32 i=0; i<tokens.size()-1; ++i)
  {
    newPath.append(tokens[i]);
    newPath.append(dirSeperator);
    try {
      boost::filesystem::create_directory(newPath);
    } catch(boost::exception&) {
      BOOST_THROW_EXCEPTION(IOException(std::string("Can't create directory: ")+newPath));
    }
  }
}



#include "filter/CvtColorSpace.h"
#include "gui/DisplayWindow.h"
#include "gui/GUIutils.h"
#include "tools/Maths.h"
#include "types/MocaException.h"
#include "tools/Timing.h"

#include <boost/shared_ptr.hpp>


#ifdef HAVE_LIBFLTK

#include "winHDR/ImageRegistration.h"
#include "winHDR/Logic.h"
#include "winHDR/FrameSource.h"
#include "winHDR/FrameWriter.h"


boost::shared_ptr<ImageRegistration> imgReg;
boost::shared_ptr<FrameSource> frameSource;
boost::shared_ptr<FrameWriter> frameWriter;
boost::shared_ptr<GroundTruth> gTruth;
boost::shared_ptr<WinHDRStatus> status;
boost::shared_ptr<HDRFrame> frame;

#ifdef HAVE_CAMERA


class HDRWindow : public DisplayWindow
{
  static int const imgWidth = 640;
  static int const imgHeight = 480;
  static CaptureMode const captureMode = OPTSHUTTER;

public:
  HDRWindow()
    : DisplayWindow(Rect(0, 0, imgWidth, imgHeight), "Windowed HDR")
  {
    frameSource = boost::shared_ptr<HDRCamera>(new HDRCamera(captureMode));
    frame = frameSource->createFrame();
    imgReg = boost::shared_ptr<ImageRegistration>(new ImageRegistration());
    status = boost::shared_ptr<WinHDRStatus>(new WinHDRStatus());

    addMenuEntry("HDR/print info", 'a', printCB);
    addMenuEntry("HDR/register HDR", 's', wardCB);
    addMenuEntry("HDR/capture HDR", 'd', hdrCB);
    addMenuEntry("HDR/save Exposures", 'w', saveCB);
    addMenuEntry("Exposures/toggle load|camera", 'q', loadCB);
    addMenuEntry("Exposures/next set", 'n', nextSetCB);
    addMenuEntry("Exposures/previous set", 'p', prevSetCB);
    addMenuEntry("Exposures/next exposure", 'f', nextExpCB);
    addMenuEntry("Exposures/previous exposure", 'b', prevExpCB);
    addMenuEntry("Ground Truth/toggle GT Registration", 't', gTruthCB);
    addMenuEntry("Ground Truth/Load GT", 'q', gTruthLoadCB);
    addMenuEntry("Ground Truth/Save GT", 'q', gTruthSaveCB);
    addMenuEntry("Ground Truth/Initialize GT", 'q', gTruthInitCB);
    addMenuEntry("Ground Truth/Move Up", 'i', gTruthUpCB);
    addMenuEntry("Ground Truth/Move Down", 'k', gTruthDownCB);
    addMenuEntry("Ground Truth/Move Left", 'j', gTruthLeftCB);
    addMenuEntry("Ground Truth/Move Right", 'l', gTruthRightCB);
  }

  void doStuff()
  {
    Timing::start(5);
    frameSource->getFrame(*frame);

    if (status->saveSwitch)
      frameWriter->putNext(frame->expSet);

    if (gTruth)
      gTruth->getGroundTruth(*frame);

    if (status->hdrSwitch)
      {
        Timing::start(6);
        frame->convertToYxy();
        //std::cout << "Color conversion: " << Timing::stop(6) << std::endl;

        Timing::start(6);
        if (status->regSwitch)
          imgReg->registerFrame(*frame);
        else if (status->loadSwitch && status->gTruthSwitch) // edit ground truth mode
          gTruth->editGT(*frame);
        //std::cout << "Registration: " << Timing::stop(6) << std::endl;

        Timing::start(6);
        frame->stitchHDR();
        //std::cout << "HDR Stitching and TM: " << Timing::stop(6) << std::endl;
        frame->print();

        boost::shared_ptr<HDRCamera> cam;
        cam = boost::dynamic_pointer_cast<HDRCamera>(frameSource);
        if (cam != 0)
          cam->estimateNextShutter(*frame);
      }

    showImage(frame->displayImage);
    //double total = Timing::stop(5);
    //std::cout << "Entire HDR process: " << total << " ms (" << 1000/total << " fps)" << std::endl << std::endl;
  }

  // ==================== callbacks ====================
#define SWITCH_CALLBACK(switchVar, switchString) \
  status->switchVar ^= true; \
  std::cout << switchString << (status->switchVar?"ON":"OFF") << std::endl;

  static void printCB(DisplayWindow* dWnd)
  {
    SWITCH_CALLBACK(printSwitch, "Parameter printing is ");
  }

  static void wardCB(DisplayWindow* dWnd)
  {
    SWITCH_CALLBACK(regSwitch, "Image Registration is ");
  }

  static void hdrCB(DisplayWindow* dWnd)
  {
    SWITCH_CALLBACK(hdrSwitch, "HDR is ");
  }
  
  static void gTruthCB(DisplayWindow* dWnd)
  {
    imgReg->switchGroundTruth();
  }
  
  static void loadCB(DisplayWindow* dWnd)
  {
    SWITCH_CALLBACK(loadSwitch, "Loading Exposures is ");
    if(status->loadSwitch)
      {
        std::string path;
        status->loadSwitch = getLoadSavePath(path);
        if (!status->loadSwitch)
          return;
        boost::shared_ptr<ExposureLoader> loader;
        loader = boost::shared_ptr<ExposureLoader>(new ExposureLoader(path));
        frameSource = loader;
        frame = frameSource->createFrame();
        gTruth = boost::shared_ptr<GroundTruth>(new GroundTruth(loader));
      }
    else
      {
        frameSource = boost::shared_ptr<HDRCamera>(new HDRCamera(captureMode));
        frame = frameSource->createFrame();
      }
  }
  
  static void saveCB(DisplayWindow* dWnd)
  {
    if (status->loadSwitch || !status->hdrSwitch)
      return;
    SWITCH_CALLBACK(saveSwitch, "Saving Exposures is ");
    if(status->saveSwitch)
      frameWriter = boost::shared_ptr<FrameWriter>(new FrameWriter());
    else
      {
        std::string path;
        bool write =  getLoadSavePath(path);
        if (write)
          frameWriter->write(path);
        frameWriter.reset();
      }
  }

  static bool getLoadSavePath(std::string& path)
  {
    GUIutils::showFileChooser("Pick a file", "", path);
    if (path.empty()) // cancel?
      return false;
    size_t slashIndex = path.find_last_of('/');
    path = path.substr(0, slashIndex);
    return true;
  }

#define NAV_CALLBACK() \
  if (!status->loadSwitch) \
    return; \
  boost::shared_ptr<ExposureLoader> loader = boost::dynamic_pointer_cast<ExposureLoader>(frameSource); \
  if (loader == 0) \
    return;

  static void nextSetCB(DisplayWindow* dWnd)
  {
    NAV_CALLBACK();
    loader->nextSet();
  }

  static void prevSetCB(DisplayWindow* dWnd)
  {
    NAV_CALLBACK();
    loader->prevSet();
  }

  static void nextExpCB(DisplayWindow* dWnd)
  {
    NAV_CALLBACK();
    loader->nextExp();
  }

  static void prevExpCB(DisplayWindow* dWnd)
  {
    NAV_CALLBACK();
    loader->prevExp();
  }

  static void gTruthLoadCB(DisplayWindow* dWnd)
  {
    NAV_CALLBACK();
    gTruth->load();
  }

  static void gTruthSaveCB(DisplayWindow* dWnd)
  {
    NAV_CALLBACK();
    gTruth->save();
  }

  static void gTruthInitCB(DisplayWindow* dWnd)
  {
    NAV_CALLBACK();
    uint32 choice = GUIutils::showChoice("Are you sure you wanna overwrite all stuff?", "uh huh", "nope");
    if (choice != 0)
      return;
    gTruth->init();
  }

  static void gTruthLeftCB(DisplayWindow* dWnd)
  {
    NAV_CALLBACK();
    gTruth->moveGT(-1, 0);
  }

  static void gTruthRightCB(DisplayWindow* dWnd)
  {
    NAV_CALLBACK();
    gTruth->moveGT(1, 0);
  }

  static void gTruthUpCB(DisplayWindow* dWnd)
  {
    NAV_CALLBACK();
    gTruth->moveGT(0, -1);
  }

  static void gTruthDownCB(DisplayWindow* dWnd)
  {
    NAV_CALLBACK();
    gTruth->moveGT(0, 1);
  }
};


int main(int argc, char** argv)
{
  try
    {
      HDRWindow hdr;
      hdr.mainLoop();
    }
  catch(MocaException& e)
    {
      std::cerr << diagnostic_information(e);
    }
  
  return 0;
}

#else // HAVE_CAMERA

int main(int argc, char** argv)
{
  std::cout << "this example requires a supported camera." << std::endl;
  return 0;
}


#endif // HAVE_CAMERA
#else // HAVE_LIBFLTK

int main(int argc, char** argv)
{
  std::cout << "this example requires FLTK." << std::endl;
  return 0;
}


#endif // HAVE_LIBFLTK


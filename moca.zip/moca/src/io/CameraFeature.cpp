#include "io/CameraFeature.h"
#include "types/MocaException.h"


// ==================== CameraFeature ====================
std::map<CameraFeature::Type, std::string> CameraFeature::featureNames;


void CameraFeature::initNameMap()
{
  if (featureNames.size() > 0)
    return;
    
  featureNames[FEATURE_Shutter] = "Shutter";
  featureNames[FEATURE_Brightness] = "Brightness";
  featureNames[FEATURE_Exposure] = "Exposure";
  featureNames[FEATURE_Gain] = "Gain";
  featureNames[FEATURE_Gamma] = "Gamma";
  featureNames[FEATURE_FrameRate] = "Frame Rate";
  featureNames[FEATURE_Sharpness] = "Sharpness";
  featureNames[FEATURE_Hue] = "Hue";
  featureNames[FEATURE_Saturation] = "Saturation";
  featureNames[FEATURE_Iris] = "Iris";
  featureNames[FEATURE_Focus] = "Focus";
  featureNames[FEATURE_Trigger] = "Trigger";
  featureNames[FEATURE_TriggerDelay] = "Trigger Delay";
  featureNames[FEATURE_WhiteBalanceUB] = "White Balance u/B";
  featureNames[FEATURE_WhiteBalanceVR] = "White Balance v/R";
  featureNames[FEATURE_WhiteShading] = "White Shading";
  featureNames[FEATURE_Zoom] = "Zoom";
  featureNames[FEATURE_Pan] = "Pan";
  featureNames[FEATURE_Tilt] = "Tilt";
  featureNames[FEATURE_OpticalFilter] = "Optical Filter";
  featureNames[FEATURE_CaptureSize] = "Capture Size";
  featureNames[FEATURE_CaptureQuality] = "Capture Quality";
}


CameraFeature::CameraFeature(Type feature)
{
  this->feature = feature;

  bIsPresent = bIsReadable = bIsSwitchable = bHasValue = bHasAbsValue = false;
  bHasManualMode = bHasAutoMode = bHasOneShotAutoMode = false;
  uiMin = uiMax = 0;
  fMin = fMax = 0;
  
  if (featureNames.size() == 0)
    initNameMap();
}


std::string CameraFeature::getName() const
{
  std::map<Type, std::string>::iterator it = featureNames.find(feature);  
  if (it == featureNames.end())
    BOOST_THROW_EXCEPTION(NotImplementedException("CameraFeature::featureNames is out of date!"));

  return it->second;
}


void CameraFeature::setPower(bool newPow)
{
  BOOST_THROW_EXCEPTION(NotImplementedException("Function not available in abstract superclass."));
}


bool CameraFeature::getPower() const
{
  BOOST_THROW_EXCEPTION(NotImplementedException("Function not available in abstract superclass."));
  return false;
}


void CameraFeature::setValue(uint32 newVal)
{
  BOOST_THROW_EXCEPTION(NotImplementedException("Function not available in abstract superclass."));
}


uint32 CameraFeature::getValue() const
{
  BOOST_THROW_EXCEPTION(NotImplementedException("Function not available in abstract superclass."));
  return 0;
}


void CameraFeature::setAbsValue(float newVal)
{
  BOOST_THROW_EXCEPTION(NotImplementedException("Function not available in abstract superclass."));
}


float CameraFeature::getAbsValue() const
{
  BOOST_THROW_EXCEPTION(NotImplementedException("Function not available in abstract superclass."));
  return 0;
}


void CameraFeature::setAbsControl(bool newCMode)
{
  BOOST_THROW_EXCEPTION(NotImplementedException("Function not available in abstract superclass."));
}


bool CameraFeature::getAbsControl() const
{
  BOOST_THROW_EXCEPTION(NotImplementedException("Function not available in abstract superclass."));
  return false;
}


void CameraFeature::setMode(Mode newMode)
{
  BOOST_THROW_EXCEPTION(NotImplementedException("Function not available in abstract superclass."));
}


CameraFeature::Mode CameraFeature::getMode() const
{
  BOOST_THROW_EXCEPTION(NotImplementedException("Function not available in abstract superclass."));
  return CameraFeature::MODE_Manual;
}


std::ostream& operator<<(std::ostream& stream, CameraFeature const& feature)
{
  stream << "name:" << feature.getName() << " present:" << feature.isPresent();
  stream << " readable:" << feature.isReadable() << " switchable:" << feature.isSwitchable();
  stream << " hasValue:" << feature.hasValue() << " hasManualMode:" << feature.hasManualMode();
  stream << " hasAutoMode:" << feature.hasAutoMode() << " hasOneShotAuto:" << feature.hasOneShotAutoMode();
  stream << " power:" << feature.getPower() << " mode:" << feature.getMode();
  stream << " minVal:" << feature.getMin() << " maxVal:" << feature.getMax();
  stream << " value:" << feature.getValue();
  return stream;
}



#include "types/MocaTypes.h"

#ifdef HAVE_CUDA

#include "cudaHDR/GPUToneMapping.h"
#include "cudaHDR/KernelFunctions.h"
#include "cudaHDR/CudaVectorHandle.h"
#include "tools/KalmanFilter.h"


Histogram GPUToneMapping::histNorm(CudaImage32FHandle const& image, CudaImage8UHandle& result)
{
  // Check image dimensions
  if ((image.getWidth() != result.getWidth()) || (image.getHeight() != result.getHeight()) || 
      (image.getChannels() != 3) || (result.getChannels() != 3))
    BOOST_THROW_EXCEPTION(MocaException("Image parameters do not match!"));

  // Compute logarithmic minimum, maximum and average
  float min, max, avg;
  if (KernelFunctions::minMaxAvg(image.getDataDescPtr(), min, max, avg, 1/4096.0f) != success)
    BOOST_THROW_EXCEPTION(MocaException("Problem executing minMaxAvg kernel!"));
  min = log(min);
  max = log(max);

  // Hack for completely black or white images
  if (min == max) 
    min = min-1;

  // Compute the logarithmic histogram
  CudaVectorHandle<unsigned int> uint_histohandle(256);
  uint_histohandle.clear();
  if (KernelFunctions::logHisto(image.getDataDescPtr(), uint_histohandle.getDataDescPtr(), min, max) != success)
    BOOST_THROW_EXCEPTION(MocaException("Problem executing log histogram kernel!"));

  // Download histogram and copy to Histogram object
  unsigned int uint_tmp[256];
  uint_histohandle.getData(uint_tmp);
  Histogram histo_cpu(min, max, 256);
  for (unsigned int i = 0; i < 256; i++)
    histo_cpu.bin(i) = (double) uint_tmp[i];

  // Trim histogram and upload again
  ToneMapping::trimHisto(histo_cpu);
  ToneMapping::cumulateAndNormalizeHisto(histo_cpu);
  float float_tmp[256];
  for (unsigned int i = 0; i < 256; i++)
    {
      float_tmp[i] = (float) histo_cpu.bin(i);
      histo_cpu.bin(i) = uint_tmp[i]; // reset histogram for return
    }
  CudaVectorHandle<float> float_histohandle;
  float_histohandle.put(float_tmp, 256);

  // Perform Tonemapping
  if (KernelFunctions::mapImage(image.getDataDescPtr(), result.getDataDescPtr(), float_histohandle.getDataDescPtr(), min, max))
    BOOST_THROW_EXCEPTION(MocaException("Problem executing maoImage kernel!"));

  // Return log histogram
  return histo_cpu;
}


#endif

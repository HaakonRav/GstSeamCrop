
// MOCA headers 
#include "types/MocaTypes.h"
#include "types/Image8U.h"
#include "io/IO.h"
#include "types/MocaException.h"
#include "gui/FLTKHeaders.h"
#include "gui/DisplayWindow.h"
 
// C++ headers 
#include <string>
using namespace std;

class FirstTest : public DisplayWindow
{
public:
  FirstTest()
    : DisplayWindow(Rect(0, 0, 1024, 1024), "First Test with the new MoCA")
  {
    for (uint32 y=0; y<image->height(); ++y)
      for (uint32 x=0; x<image->width(); ++x)
        (*image)(x, y) = 0;
  }

  void clickedRect(Rect rect)
  {
    for (int y=rect.y; y<rect.h+rect.y; ++y)
      for (int x=rect.x; x<rect.w+rect.x; ++x)
        (*image)(x, y) = 255;
  }
  void show(boost::shared_ptr<Image8U const> img)
  {
    for (int32 c=0; c<img->channels(); ++c)
	    for (uint32 y=0; y<img->height(); ++y)
		  for (uint32 x=0; x<img->width(); ++x)
			(*image)(x, y, c) = (*img)(x, y, c);
  }

  void doStuff()
  {
    showImage(image);
  }
};



int main(int argc, char **argv)
{
	string fnSrc="lena.jpg";
	string fnDest1="lena_src.jpg";
	string fnDest2="lena_modified.jpg";

	cerr << "test LIBMOCA" << endl;
	boost::shared_ptr<Image8U> srcImage, destImage;
	try {
		cerr << "read image: " << fnSrc << endl;        
		srcImage = IO::loadImage(fnSrc);
		destImage = IO::loadImage(fnSrc);
	} catch (MocaException e) {
		std::cout << "read Image error: " << e.what() << std::endl;
		exit (-1);
	}
	int w=srcImage->width();
	int h=srcImage->height();
	cerr << "image size: " << w << "x" << h << endl;

	// modify image (use OpenCV)
	(*destImage)=(*srcImage);
	CvPoint center_position;
	center_position = cvPoint(destImage->width()/2,destImage->height()/2);
	double scaleFactor=-3;
	for(int32 i=0;i<(int)destImage->height();i++){
		for(int32 j=0;j<(int)destImage->width();j++){
			for(int32 b=0;b<destImage->channels();b++){

				double dx=(double)(j-center_position.x)/center_position.x;
				double dy=(double)(i-center_position.y)/center_position.y;
				double weight=exp((dx*dx+dy*dy)*scaleFactor);
				(*destImage)(i,j,b) = cvRound((*srcImage)(i,j,b) *weight);
			}
		}
	}

	try {
		cerr << "save image" << endl;        
		IO::saveImage(fnDest1, *srcImage); 
		IO::saveImage(fnDest2, *destImage); 
	} catch (MocaException e) {
		std::cout << "save Image error: " << e.what() << std::endl;
		exit (-1);
	}  


	// show image (use FLTK)
#ifdef HAVE_LIBFLTK
	FirstTest win;
	win.show(destImage);
    win.mainLoop();
#endif

	return 0;
}


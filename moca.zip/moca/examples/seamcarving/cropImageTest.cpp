
// MOCA headers 
#include "types/MocaTypes.h"
#include "types/Image8U.h"
#include "types/Image32F.h"
#include "io/IO.h"
#include "types/MocaException.h"
#include "gui/FLTKHeaders.h"
#include "gui/DisplayWindow.h"

#include "filter/Filter.h"
//#include "feature/AttendedAreas.h"

// C++ headers 
#include <string>
using namespace std;


static void computeEnergy(Image8U const& image, Image32F& energy, int width)
{
  int borderTop, borderBottom, borderLeft, borderRight; // these values change the formula if the current position is close to image borders.
  int grad; // gradient: sum of absolute pixel values on all color channels -> grad = (x-1, y) + (x+1, y) + (x, y-1) + (x, y+1).
  int height = image.height();
  int channels = image.channels();

  for (int x=0; x < width; x++)
      for (int y = 0; y < height; y++)
        {
	  borderTop = 1;	// y-1 -> y
	  borderBottom = 1;	// y+1 -> y
	  borderLeft = 1;	// x-1 -> x
	  borderRight = 1; 	// x+1 -> x
	  grad = 0;
	  
	  if (x == 0) // left border: x-1 -> x
	    borderLeft = 0;
	  if (x == width-1) // right border: x+1 -> x
	    borderRight = 0;
	  if (y == 0) // top border: y-1 -> y
	    borderTop = 0; 
	  if (y == height-1) // bottom border: y+1 -> y
	    borderBottom = 0;
	  
	  for(int c = 0; c < channels; c++)
            grad += (abs(image(x + borderRight, y, c) - image(x - borderLeft, y, c))) + (abs(image(x, y + borderBottom, c) - image(x, y - borderTop, c)));
	 
          energy(x,y) = grad;
        }// for y
}

static void computeCostCropWidth(Image32F& energy, int width)
{ 
  int height = energy.height();

  for (int x=0; x < width; x++)
      for (int y = 0; y < height; y++)
	  if(y != 0)
	    energy(x,y) = energy(x,y-1) + energy(x,y);
}

static void cropImage(Image8U const& image, Image8U& destImage, Image32F& energy, int& tmpWidth, int& targetWidth)
{  
  int height= image.height();
  int channels = image.channels();
  //int totalEnergy = 0;		// Summed up energy of all pixels
  int tmpEnergy = 0;		// Summed up energy of all pixels in the cropping window
  int energyArray [tmpWidth];   // energy values summed up from left to right (rightmost position = total energy)
  
  int resultX = 0;
  int cropLeft, cropRight, tmpLeft, tmpRight;
  
  cropLeft = 0;
  cropRight = tmpWidth-1;
  tmpLeft = cropLeft;
  tmpRight = cropRight;
 
  for (int i=0; i < tmpWidth-targetWidth; i++)
     {
	 if (energy(cropLeft,height-1) < energy(cropRight,height-1)) 
	   cropLeft += 1;
	 else
	   cropRight -= 1;
      }// for x
      
  cout << "Cut Edges: cropLeft=" << cropLeft << ", cropRight=" << cropRight << endl;
  
  energyArray[0] = energy(0, height-1);
  for (int x=1; x < tmpWidth; x++)
    energyArray[x] = energy(x, height-1) + energyArray[x-1];
  //totalEnergy = energyArray[tmpWidth-1];
  
  for (int i=1; i < tmpWidth-targetWidth; i++)
     { 
       for (int j=0; j < i+1; j++)
         {
	   cropLeft = j;
	   cropRight = (tmpWidth-1)-i+j;	// rightmost position - reducement of window size + shifting
	  if(j==0) // initialize values
	     {
	       tmpLeft = cropLeft;
	       tmpRight = cropRight;
	       tmpEnergy = energyArray[cropRight];
	     }
	   else if( (energyArray[cropRight]-energyArray[cropLeft-1]) > tmpEnergy ) // store values when energy in window is higher than tmpEnergy
	     {
	       tmpLeft = cropLeft;
	       tmpRight = cropRight;
	       tmpEnergy = energyArray[cropRight]-energyArray[cropLeft-1];
	     }
	 }
      
      // if ((tmpEnergy < 0.95*totalEnergy))
      //   {
	//   cropLeft = tmpLeft;
	//   cropRight = tmpRight;
	//   break;
	// }
       //else

       tmpEnergy = 0;
     }// for x
     
  cropLeft = tmpLeft;
  cropRight = tmpRight;
    
  cout << "Move CroppingWindow: cropLeft=" << cropLeft << ", cropRight=" << cropRight << endl;
  cout << "Cropped " << tmpWidth - (cropRight - cropLeft) << " column(s)";
  tmpWidth = cropRight - cropLeft;
  cout << ", tmpWidth = " << tmpWidth << endl;
      
  for(int x = cropLeft; x < cropRight+1; x++)
    {
      for(int y = 0; y < height; y++)  
	  for(int c = 0; c < channels; c++)
	    destImage(resultX, y, c) = image(x, y, c);
      resultX += 1;
    }
}

/*
static void convert (Image8U const& saliency, Image32F& energy, int width)
{
  int height = saliency.height();
  int channels = saliency.channels();
  
  for (int y = 0; y < height; y++)
    for(int x = 0; x < width; x++)
      for(int c = 0; c < channels; c++)
        energy(x,y,c) = saliency(x,y,c);
}
*/


// ###############################################################################################
// main
// ###############################################################################################

int main(int argc, char **argv)
{
	string fnSrc="/home/stud/kiess/Pictures/2011_ACM_MM/Test/boote.jpg";
	string fnDest="/home/stud/kiess/Pictures/2011_ACM_MM/Test/boote_cropped.png";

	cerr << "test LIBMOCA Cropping" << endl;
	boost::shared_ptr<Image8U> srcImage;//, destImage;
	try {
		cerr << "read image: " << fnSrc << endl;        
		srcImage = IO::loadImage(fnSrc);
		//destImage = IO::loadImage(fnSrc);
	} catch (MocaException e) {
		std::cout << "read Image error: " << e.what() << std::endl;
		exit (-1);
	}
	int w=srcImage->width();
	int h=srcImage->height();
	int c=srcImage->channels();
	int targetWidth = 0.5*w;
	cerr << "image size: " << w << "x" << h << endl;

	
	//------------------------------------------------------------------
	// crop image (width)
	//------------------------------------------------------------------
	
	// variables 
	Image8U destImage(targetWidth, h, c);
	Image32F energy(w, h, c);
	Image32F dilatedEnergy(w, h, c);
	//Image8U saliency(w, h, c);

	// algorithm
	computeEnergy(*srcImage, energy, w);
	//AttendedAreas a;
	//a.processSaliencyMap(*srcImage, saliency, SAL);
	//cout << "Saliency Map calculated" << endl;
	//convert(saliency, energy, w);
	Filter::dilate(energy, dilatedEnergy, 25);
	computeCostCropWidth(dilatedEnergy,w);
	cropImage(*srcImage, destImage, dilatedEnergy, w, targetWidth);
	
	cerr << "new size: " << targetWidth << "x" << h << endl;
	
	//------------------------------------------------------------------

	try {
		cerr << "save image" << endl;        
		//IO::saveImage(fnDest, *srcImage); 
		IO::saveImage(fnDest, destImage); 
	} catch (MocaException e) {
		std::cout << "save Image error: " << e.what() << std::endl;
		exit (-1);
	}  

	return 0;
}


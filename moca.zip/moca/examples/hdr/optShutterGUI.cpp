#include "feature/Histogram.h"
#include "feature/OptimalShutter.h"
#include "filter/CvtColorSpace.h"
#include "filter/Filter.h"
#include "filter/HDRStitching.h"
#include "filter/ToneMapping.h"
#include "gui/DisplayWindow.h"
#include "gui/GUIutils.h"
#include "io/HDRExposureIO.h"
#include "io/IO.h"
#include "tools/Drawing.h"
#include "types/Image32F.h"
#include "types/MocaException.h"

#include <fstream>


std::string path("/usr/local/bguthier/videos/static_full/");
std::string fileNames[] = {"parkinglot", "fancySun2", "GartenmitSonne", "strasserechts", 
                           "TestModel", "Wohnzimmerdaheim", "b6", "desk", "gartendaheim", 
                           "hausdaheim", "himmelundlandschaft", "Landschaftdaheim", 
                           "Strassedaheim", "Strassedaheim3"};

enum ActiveSet {FULL=0, EQUI, OPT, CUSTOM};

class Dataset
{
public:
  Dataset() : hist(0, 1, 1) {}

  Dataset(uint32 width, uint32 height)
    : hist(0, 1, 1)
  {
    image = boost::shared_ptr<Image8U>(new Image8U(width, height, 3));
    hdrImage = boost::shared_ptr<Image32F>(new Image32F(width, height, 3));
  }
  
  boost::shared_ptr<Image8U> image;
  boost::shared_ptr<Image32F> hdrImage;
  Histogram hist;
  std::vector<double> coverage;
  std::vector<double> shutters;
};


class OptShutterGUI : public DisplayWindow
{
public:
  OptShutterGUI()
    : DisplayWindow(Rect(0, 0, 640+320, 480), "Optimal Shutters"),
      dataset(4), activeSet(FULL), activeVid(0), activeShut(0), numExps(3)
  {
    loadVideo();
    drawImages();

    addMenuEntry("View/Load Video", 'w', loadCB);
    addMenuEntry("View/Choose Alg", 'd', algCB);
    addMenuEntry("View/Next Alg", 'f', nextAlgCB);
    addMenuEntry("View/Prev Alg", 'b', prevAlgCB);
    addMenuEntry("View/Next Vid", 'n', nextVidCB);
    addMenuEntry("View/Prev Vid", 'p', prevVidCB);

    addMenuEntry("Shutter/add", 'i', addShutCB);
    addMenuEntry("Shutter/del", 'k', delShutCB);
    addMenuEntry("Shutter/next", 'l', nextShutCB);
    addMenuEntry("Shutter/prev", 'j', prevShutCB);

    addMenuEntry("save dataset", 's', saveCB);
  }
  
  static void saveCB(DisplayWindow* dWnd)
  {
    OptShutterGUI* opt = dynamic_cast<OptShutterGUI*>(dWnd);
    opt->save();
  }

  // saves: Referenzbild, EQUI, OPT, Referenzhistogramm, EQUI coverage, OPT coverage, EQUI shutters, OPT shutters
  // drei Bilddateien. Name = [fileName]_[equi/opt/ref].png
  // Textdatei [fileName].txt
  // Histogram \n hist \n\n [was gespeichert] \n\n [Werte] \n
  void save()
  {
    std::string fileName(fileNames[activeVid]);
    IO::saveImage(fileName + "_ref.png", *dataset[FULL].image);
    IO::saveImage(fileName + "_equi.png", *dataset[EQUI].image);
    IO::saveImage(fileName + "_opt.png", *dataset[OPT].image);

    std::ofstream file(std::string(fileName + ".csv").c_str());
    file << "Histogram" << std::endl;
    for (uint32 i=0; i<dataset[FULL].hist.size(); ++i)
      file << dataset[FULL].hist.bin(i) << " ";
    file << std::endl << std::endl;
      
    writeArray("EQUI coverage", dataset[EQUI].coverage, file);
    writeArray("OPT coverage", dataset[OPT].coverage, file);
    writeArray("EQUI shutters", dataset[EQUI].shutters, file, 0.02);
    writeArray("OPT shutters", dataset[OPT].shutters, file, 0.02);
    file.close();
    std::cout << "Dataset saved" << std::endl;
  }

  void writeArray(std::string const& text, std::vector<double> const& array, std::ofstream& file, double fac=1.0)
  {
    file << text << std::endl;
    for (uint32 i=0; i<array.size(); ++i)
      file << array[i] * fac << " ";
    file << std::endl << std::endl;
  }

  static void loadCB(DisplayWindow* dWnd)
  {
    OptShutterGUI* opt = dynamic_cast<OptShutterGUI*>(dWnd);
    std::string choice = GUIutils::showInput("Index of video to load? (0-13)", "");
    std::stringstream ss;
    ss << choice; ss >> opt->activeVid;
    opt->loadVideo();
  }

  static void algCB(DisplayWindow* dWnd)
  {
    OptShutterGUI* opt = dynamic_cast<OptShutterGUI*>(dWnd);
    std::string choice = GUIutils::showInput("Which algorithm to display? (0:FULL, 1:EQUI, 2:OPT, 3:CUSTOM)", "");
    std::stringstream ss; int index;
    ss << choice; ss >> index;
    opt->activeSet = (ActiveSet)index;
    opt->drawImages();
  }

  static void nextAlgCB(DisplayWindow* dWnd)
  {
    OptShutterGUI* opt = dynamic_cast<OptShutterGUI*>(dWnd);
    opt->activeSet = (ActiveSet)((opt->activeSet+1) % 4);
    opt->printAlgName();
    opt->drawImages();
  }

  static void prevAlgCB(DisplayWindow* dWnd)
  {
    OptShutterGUI* opt = dynamic_cast<OptShutterGUI*>(dWnd);
    opt->activeSet = (ActiveSet)((opt->activeSet+3) % 4);
    opt->printAlgName();
    opt->drawImages();
  }

  static void nextVidCB(DisplayWindow* dWnd)
  {
    OptShutterGUI* opt = dynamic_cast<OptShutterGUI*>(dWnd);
    opt->activeVid = (opt->activeVid+1) % 14;
    opt->loadVideo();
    opt->drawImages();
  }

  static void prevVidCB(DisplayWindow* dWnd)
  {
    OptShutterGUI* opt = dynamic_cast<OptShutterGUI*>(dWnd);
    opt->activeVid = (opt->activeVid+13) % 14;
    opt->loadVideo();
    opt->drawImages();
  }

  static void addShutCB(DisplayWindow* dWnd)
  {
    OptShutterGUI* opt = dynamic_cast<OptShutterGUI*>(dWnd);
    if (opt->activeSet != CUSTOM)
      opt->numExps++;
    else {
      opt->dataset[CUSTOM].shutters.push_back(2000);
      opt->activeShut = opt->dataset[CUSTOM].shutters.size() - 1;
    }
    opt->updateImages(opt->activeSet != CUSTOM);
    std::cout << "Added shutter" << std::endl;
  }

  static void delShutCB(DisplayWindow* dWnd)
  {
    OptShutterGUI* opt = dynamic_cast<OptShutterGUI*>(dWnd);
    if (opt->activeSet != CUSTOM)
      opt->numExps--;
    else {
      std::vector<double>& s = opt->dataset[CUSTOM].shutters;
      if (s.size() > 1)
        s.erase(s.begin() + opt->activeShut);
      opt->activeShut = std::min<uint32>(opt->activeShut, s.size()-1);
    }
    opt->updateImages(opt->activeSet != CUSTOM);
    std::cout << "Deleted shutter" << std::endl;
  }

  static void nextShutCB(DisplayWindow* dWnd)
  {
    OptShutterGUI* opt = dynamic_cast<OptShutterGUI*>(dWnd);
    std::vector<double>& s = opt->dataset[CUSTOM].shutters;
    opt->activeShut = (opt->activeShut + 1) % s.size();
    std::cout << "Shutter: " << opt->activeShut << std::endl;
  }

  static void prevShutCB(DisplayWindow* dWnd)
  {
    OptShutterGUI* opt = dynamic_cast<OptShutterGUI*>(dWnd);
    std::vector<double>& s = opt->dataset[CUSTOM].shutters;
    opt->activeShut = (opt->activeShut + s.size() - 1) % s.size();
    std::cout << "Shutter: " << opt->activeShut << std::endl;
  }

  void printAlgName()
  {
    switch(activeSet)
      {
      case FULL: std::cout << "FULL" << std::endl; break;
      case EQUI: std::cout << "EQUI" << std::endl; break;
      case OPT: std::cout << "OPT" << std::endl; break;
      case CUSTOM: std::cout << "CUSTOM" << std::endl; break;
      }
  }

protected:
  void doStuff()
  {
    showImage(image);
  }
  
  void loadVideo()
  {
    // load exposure set from disk and convert to Yxy
    boost::shared_ptr<HDRExposureIO> reader = HDRExposureIO::createReader(path + fileNames[activeVid]);
    expSet.clear();
    reader->getNext(expSet);
    reader->close();
    for (uint32 j=0; j<expSet.size(); ++j) {
      Exposure& e = expSet[j];
      CvtColorSpace::convert(*e.image, *e.image, COLOR_BGR, COLOR_Yxy);
    }
    assert(expSet.size() > 0);
    uint32 w = expSet[0].image->width(), h = expSet[0].image->height();

    for (uint32 i=0; i<dataset.size(); ++i)
      dataset[i] = Dataset(w, h);
    activeShut = 0;

    // create FULL dataset
    HDRStitching::weighted(expSet, *dataset[FULL].hdrImage);
    dataset[FULL].hist = createHisto(*dataset[FULL].hdrImage, true);
    ToneMapping::histNorm(*dataset[FULL].hdrImage, *dataset[FULL].image);
    CvtColorSpace::convert(*dataset[FULL].image, *dataset[FULL].image, COLOR_Yxy, COLOR_BGR);
    dataset[FULL].shutters.clear();
    for (uint32 i=0; i<expSet.size(); ++i)
      dataset[FULL].shutters.push_back(expSet[i].shutter);
    wfunc = OptimalShutter::createWeightMask(dataset[FULL].hist);
    createCoverage(dataset[FULL]);

    updateImages(true);
  }

  void updateImages(bool newShutters)
  {
    if (newShutters)
      {
        dataset[OPT].shutters = OptimalShutter::findBestShutters(dataset[FULL].hist, wfunc, numExps, 0.75);
        dataset[EQUI].shutters = OptimalShutter::findEquiShutters(dataset[OPT].shutters.size(), dataset[FULL].hist);
        dataset[CUSTOM].shutters = OptimalShutter::findEquiShutters(1, dataset[FULL].hist);
      }
    for (uint32 i=1; i<dataset.size(); ++i) {
      createHDR(dataset[i]);
      createCoverage(dataset[i]);
    }
    drawImages();
  }

  Histogram createHisto(Image32F const& image, bool isFull)
  {
    float avg, min, max;
    if (isFull) {
      ToneMapping::minMaxAvg(image, min, max, avg);
      min = log(min); max = log(max);
    } else {
      min = dataset[FULL].hist.getMinVal();
      max = dataset[FULL].hist.getMaxVal();
    }

    Histogram result(min, max, 200);
    float step = 1/(float)(image.width() * image.height());
    ToneMapping::logHisto(image, result, step);
    return result;
  }

  // fills ds image and hist. shutters must be filled
  void createHDR(Dataset& ds)
  {
    std::vector<Exposure> exposures = OptimalShutter::selectExposures(expSet, ds.shutters);
    HDRStitching::weighted(exposures, *ds.hdrImage);
    ds.hist = createHisto(*ds.hdrImage, false);
    ToneMapping::histNorm(*ds.hdrImage, *ds.image);
    CvtColorSpace::convert(*ds.image, *ds.image, COLOR_Yxy, COLOR_BGR);
  }

  // fills ds coverage. Hist and shutters must be filled
  void createCoverage(Dataset& ds)
  {
    ds.coverage = OptimalShutter::createCoverage(ds.hist, ds.shutters, wfunc);
  }

  double computePSNR(Image32F const& img)
  {
    Image32F& ref = *dataset[FULL].hdrImage;
    uint32 width = ref.width(), height = ref.height();//, channels = ref.channels();
    double psnr = 0;
    float max = -INFINITY;
    for (uint32 y=0; y<height; ++y)
      for (uint32 x=0; x<width; ++x)
        for (uint32 c=0; c<1; ++c)
          {
            max = std::max(ref(x, y, c), max);
            double diff = ref(x, y, c) - img(x, y, c);
            psnr += diff * diff;
          }
    psnr /= width*height;
    psnr = 20 * log10(max/sqrt(psnr));

    return psnr;
  }

  void drawImages()
  {
    Dataset& ds = dataset[activeSet];
    // create an image of the histogram
    Image8U histimg(ds.image->width()/2, ds.image->height()/2, 3);
    std::vector<double> array(ds.hist.size());
    for (uint32 i=0; i<ds.hist.size(); ++i)
      array[i] = ds.hist.bin(i);
    Drawing::arrayToImage(histimg, array);

    //  create coverage image
    Image8U covimg(ds.image->width()/2, ds.image->height()/2, 3);
    Drawing::arrayToImage(covimg, ds.coverage);

    // put them all together
    image = boost::shared_ptr<Image8U>(new Image8U(ds.image->width()/2*3, ds.image->height(), 3));
    Filter::copyImage(*ds.image, *image, Vector2D::create(0, 0));
    Filter::copyImage(histimg, *image, Vector2D::create((int32)ds.image->width(), 0));
    Filter::copyImage(covimg, *image, Vector2D::create((int32)ds.image->width(), ds.image->height()/2));

    double psnr = computePSNR(*dataset[activeSet].hdrImage);
    double use = OptimalShutter::estimateCoverage(dataset[FULL].hist, dataset[activeSet].coverage);
    std::cout << "PSNR: " << psnr << "   USE: " << use << std::endl;
  }

  void clickedPoint(VectorI p)
  {
    p[0] -= 640;
    p[1] -= 240;
    if (!(p[0] >= 0 && p[0] < 320 && p[1] >= 0 && p[1] <= 480) || activeSet != CUSTOM)
      return;

    // convert p[0] into radiance and then shutter value
    double rad = p[0] / 320.0; // [0..1)
    rad *= dataset[CUSTOM].hist.getMaxVal() - dataset[CUSTOM].hist.getMinVal();
    rad += dataset[CUSTOM].hist.getMinVal();
    double shutter = 255.0 / exp(rad);
    std::cout << "Shutter: " << shutter << std::endl;
    dataset[CUSTOM].shutters[activeShut] = shutter;

    // how many percent of hist lie left of click
    uint32 histSize = dataset[CUSTOM].hist.size();
    uint32 click = p[0] / 320.0 * histSize + 0.5;
    double sum = 0;
    for (uint32 i=click; i<histSize; ++i)
      sum += dataset[CUSTOM].hist.bin(i);
    std::cout << (1-sum/histSize)*100 << "%" << std::endl;

    updateImages(false);
  }

  void clickedRect(Rect rect){}
  void clickedLine(VectorI p1, VectorI p2){}

  std::vector<Exposure> expSet;
  std::vector<Dataset> dataset;
  std::vector<double> wfunc;
  ActiveSet activeSet;
  uint32 activeVid, activeShut;
  uint32 numExps;
};


void guiMain()
{
  OptShutterGUI osg;
  osg.mainLoop();
}

#include "feature/OpticalFlow.h"

#include "types/MocaException.h"
#include <opencv/highgui.h>
#include <iostream>


OpticalFlow::featuresPointer OpticalFlow::calcOpticalFlow(Image8U const& firstImage,Image8U const& secondImage,int maxFeatures, Vector* srcFeatures) {
  CvSize frameSize = cvSize(firstImage.height(),firstImage.width());
  IplImage* imgA = cvCreateImage(frameSize, IPL_DEPTH_8U, 1 );
  IplImage* imgB = cvCreateImage(frameSize, IPL_DEPTH_8U, 1 );
  cvConvertImage(firstImage.image, imgA, 0);
  cvConvertImage(secondImage.image, imgB, 0);
  
  featuresPointer f(new features);
  
  CvPoint2D32f *destF = new CvPoint2D32f[maxFeatures];
  CvPoint2D32f *srcF  = new CvPoint2D32f[maxFeatures];
  
  if(srcFeatures == NULL){ 
    getGoodFeatures(imgA, frameSize, maxFeatures, srcF);

  }
  else {
    for(int x=0;x<maxFeatures;x++){
      srcF[x].x = (float)srcFeatures[x][0];
      srcF[x].y = (float)srcFeatures[x][1];
    }
  }

  float *feature_errors = new float [maxFeatures];
  char *features_found = new char [maxFeatures];

  IplImage* pyrA = cvCreateImage( frameSize, IPL_DEPTH_8U, 1 );
  IplImage* pyrB = cvCreateImage( frameSize, IPL_DEPTH_8U, 1 );

  cvCalcOpticalFlowPyrLK( imgA, imgB, pyrA, pyrB, srcF, destF, maxFeatures, cvSize(15, 15), 5, features_found, feature_errors,
          cvTermCriteria( CV_TERMCRIT_ITER | CV_TERMCRIT_EPS, 20, 0.3 ), 0 );
  
  for(int x=0;x<maxFeatures;x++) {
    if(features_found != 0){
      Vector src = Vector2D::create(srcF[x].x, srcF[x].y);
      Vector dest = Vector2D::create(destF[x].x, destF[x].y);
      (*f).push_back(make_pair(src, dest));
    }
  }

  delete []destF;
  delete []srcF;
  delete []feature_errors;
  delete []features_found;

  return f;
}

void OpticalFlow::getGoodFeatures(IplImage* firstImage, CvSize& frameSize, int& maxFeatures, CvPoint2D32f* srcF) {
  IplImage* eig_image = cvCreateImage( frameSize, IPL_DEPTH_32F, 1 );
  IplImage* tmp_image = cvCreateImage( frameSize, IPL_DEPTH_32F, 1 );
  cvGoodFeaturesToTrack( firstImage, eig_image, tmp_image, srcF, &maxFeatures, 0.01, 3.0, 0, 3, 1, 0.1);

  cvFindCornerSubPix( firstImage, srcF, maxFeatures, cvSize(15, 15),
                      cvSize( -1, -1 ), cvTermCriteria( CV_TERMCRIT_ITER | CV_TERMCRIT_EPS, 20, 0.03 ) );
}

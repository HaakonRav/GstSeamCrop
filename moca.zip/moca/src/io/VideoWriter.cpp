#include "io/VideoWriter.h"
#include "types/MocaException.h"

std::map<int32, long int> VideoWriter::codecMap;

// ==================== VideoReader ====================

VideoWriter::VideoWriter(std::string const& fileName, sizeType const& width, sizeType const& height)
  : fileName(fileName), width(width), height(height), currentFrame(0), started(false), bit_rate(12000000), frame_rate(25), codec(NONE)
{
  initCodecMap();
}

VideoWriter::~VideoWriter()
{
  if(started)
    stop();
}

void VideoWriter::start()
{
  if (started)
    BOOST_THROW_EXCEPTION(IOException(std::string("You have to call stop() before you start again.") + fileName + std::string("'.")));

  av_register_all();
  fmt = av_guess_format(NULL, fileName.c_str(), NULL);
  if (!fmt) {
      std::cout << "Could not deduce output format from file extension: using avi." << std::endl;
      fmt = av_guess_format("avi", NULL, NULL);
  }
  
  if(codec != NONE)
    fmt->video_codec = (CodecID) codecMap[codec];

  if (!fmt)
      BOOST_THROW_EXCEPTION(IOException(std::string("Could not find suitable output format.") + fileName + std::string("'.")));

  oc = avformat_alloc_context();
  if (!oc)
      BOOST_THROW_EXCEPTION(IOException(std::string("Memory error.") + fileName + std::string("'.")));

  oc->oformat = fmt;
  video_st = NULL;
  if (fmt->video_codec != CODEC_ID_NONE) {
      video_st = add_video_stream(fmt->video_codec);
  }
  //if (av_set_parameters(oc, NULL) < 0)
  //    BOOST_THROW_EXCEPTION(IOException(std::string("Invalid output format parameters.") + fileName + std::string("'.")));

  if (video_st)
      open_video();
  if (!(fmt->flags & AVFMT_NOFILE))
      if (avio_open(&oc->pb, fileName.c_str(), AVIO_FLAG_READ_WRITE) < 0)
          BOOST_THROW_EXCEPTION(IOException(std::string("Could not open the file.") + fileName + std::string("'.")));

  avformat_write_header(oc, NULL);

  started = true;
}

void VideoWriter::stop()
{
  av_write_trailer(oc);

  if (video_st){
      
    avcodec_close(video_st->codec);
    av_free(picture->data[0]);
    av_free(picture);
    if (tmp_picture) {
        av_free(tmp_picture->data[0]);
        av_free(tmp_picture);
    }
    av_free(video_outbuf);
  }

  for(uint32 i = 0; i < oc->nb_streams; i++) {
      av_freep(&oc->streams[i]->codec);
      av_freep(&oc->streams[i]);
  }

  if (!(fmt->flags & AVFMT_NOFILE)) {
      avio_close(oc->pb);
  }

  av_free(oc);

  started = false;
  currentFrame = 0;
}

void VideoWriter::putImage(Image8U const& image)
{
  if (!started)
    BOOST_THROW_EXCEPTION(IOException(std::string("You have to call start() first.") + fileName + std::string("'.")));
  
  int out_size, ret;
  AVCodecContext *c;
  double video_pts;
  if (video_st)
    video_pts = (double)video_st->pts.val * video_st->time_base.num / video_st->time_base.den;
  else
    video_pts = 0.0;
  
  static struct SwsContext *img_convert_ctx;

  c = video_st->codec;
  if (img_convert_ctx == NULL) {
      img_convert_ctx = sws_getContext(c->width, c->height, PIX_FMT_BGR24, c->width, c->height, c->pix_fmt, SWS_BICUBIC, NULL, NULL, NULL);
      if (img_convert_ctx == NULL)
          BOOST_THROW_EXCEPTION(IOException(std::string("Cannot initialize the conversion context.") + fileName + std::string("'.")));
  }

  uint8_t* dataP = tmp_picture->data[0];
  for(uint32 y=0;y<height;y++)
    for(uint32 x=0;x<width;x++)
      for(uint32 z=0;z<3;z++)
        *dataP++ = image(x, y, z);

  sws_scale(img_convert_ctx, tmp_picture->data, tmp_picture->linesize, 0, c->height, picture->data, picture->linesize);
  if (oc->oformat->flags & AVFMT_RAWPICTURE) {
      AVPacket pkt;
      av_init_packet(&pkt);

      pkt.flags |= AV_PKT_FLAG_KEY;
      pkt.stream_index= video_st->index;
      pkt.data= (uint8_t *)picture;
      pkt.size= sizeof(AVPicture);
      ret = av_interleaved_write_frame(oc, &pkt);
  } else {
      out_size = avcodec_encode_video(c, video_outbuf, video_outbuf_size, picture);
      if (out_size > 0) {
          AVPacket pkt;
          av_init_packet(&pkt);
          if (c->coded_frame->pts != (int64_t)(AV_NOPTS_VALUE))
              pkt.pts= av_rescale_q(c->coded_frame->pts, c->time_base, video_st->time_base);
          if(c->coded_frame->key_frame)
              pkt.flags |= AV_PKT_FLAG_KEY;
          pkt.stream_index= video_st->index;
          pkt.data= video_outbuf;
          pkt.size= out_size;

          ret = av_interleaved_write_frame(oc, &pkt);
      } else {
          ret = 0;
      }
  }
  if (ret != 0)
      BOOST_THROW_EXCEPTION(IOException(std::string("Error while writing video frame.") + fileName + std::string("'.")));

  currentFrame++;
}
  

sizeType VideoWriter::getImageWidth()
{
  return width;
}

sizeType VideoWriter::getImageHeight()
{
  return height;
}

Rect VideoWriter::getImageDimension()
{
  return Rect(0,0,width,height);
}

int32 VideoWriter::getCurrentFrame()
{
  return currentFrame;
}

void VideoWriter::setFilename(std::string const& newFileName){
  if(!started)
    fileName = newFileName;
  else
    BOOST_THROW_EXCEPTION(IOException(std::string("You have to call stop() before you change the filename.") + fileName + std::string("'.")));
}

void VideoWriter::setBitRate(int32 const& new_bit_rate){
  if(!started)
    bit_rate = new_bit_rate;
  else
    BOOST_THROW_EXCEPTION(IOException(std::string("You have to call stop() before you change the bit rate.") + fileName + std::string("'.")));
}

void VideoWriter::setFrameRate(int32 const& new_frame_rate){
  if(!started)
    frame_rate = new_frame_rate;
  else
    BOOST_THROW_EXCEPTION(IOException(std::string("You have to call stop() before you change the frame rate.") + fileName + std::string("'.")));
}

void VideoWriter::setCodec(Codec const& newCodec){
  if(!started)
    codec = newCodec;
  else
    BOOST_THROW_EXCEPTION(IOException(std::string("You have to call stop() before you change the codec.") + fileName + std::string("'.")));
}

/*
* private methods
*/

AVStream* VideoWriter::add_video_stream(enum CodecID codec_id)
{
    AVCodecContext *c;
    AVStream *st;

    st = av_new_stream(oc, 0);
    if (!st)
        BOOST_THROW_EXCEPTION(IOException(std::string("Could not alloc stream.") + fileName + std::string("'.")));

    c = st->codec;
    c->codec_id = codec_id;
    c->codec_type = AVMEDIA_TYPE_VIDEO;

    c->bit_rate = bit_rate;
    c->width = width;
    c->height = height;
    c->time_base.den = frame_rate;
    c->time_base.num = 1;
    c->gop_size = 12;
    c->pix_fmt = PIX_FMT_YUV420P;
    if (c->codec_id == CODEC_ID_MPEG1VIDEO){
        c->mb_decision=2;
    }
    if(oc->oformat->flags & AVFMT_GLOBALHEADER)
        c->flags |= CODEC_FLAG_GLOBAL_HEADER;


    return st;
}

AVFrame* VideoWriter::alloc_picture(enum PixelFormat pix_fmt)
{
    AVFrame *picture;
    uint8_t *picture_buf = NULL;
    int size;

    picture = avcodec_alloc_frame();
    if (!picture)
        return NULL;
    size = avpicture_get_size(pix_fmt, width, height);
    picture_buf = (uint8_t*) av_malloc(size);
    if (!picture_buf) {
        av_free(picture);
        return NULL;
    }
    avpicture_fill((AVPicture *)picture, picture_buf,
                   pix_fmt, width, height);

    return picture;
}

void VideoWriter::open_video()
{
    AVCodec *codec;
    AVCodecContext *c;

    c = video_st->codec;

    codec = avcodec_find_encoder(c->codec_id);
    if (!codec)
        BOOST_THROW_EXCEPTION(IOException(std::string("codec not found.") + fileName + std::string("'.")));

    if (avcodec_open(c, codec) < 0)
        BOOST_THROW_EXCEPTION(IOException(std::string("could not open codec.") + fileName + std::string("'.")));

    video_outbuf = NULL;
    if (!(oc->oformat->flags & AVFMT_RAWPICTURE)) {
        video_outbuf_size = bit_rate/2;
        video_outbuf = (uint8_t*) av_malloc(video_outbuf_size);
    }

    picture = alloc_picture(c->pix_fmt);
    if (!picture)
        BOOST_THROW_EXCEPTION(IOException(std::string("Could not allocate picture.") + fileName + std::string("'.")));

    tmp_picture = alloc_picture(PIX_FMT_BGR24);
    if (!tmp_picture)
        BOOST_THROW_EXCEPTION(IOException(std::string("Could not allocate temporary picture.") + fileName + std::string("'.")));
}

void VideoWriter::initCodecMap(){
  if (codecMap.size() > 0)
    return;

  codecMap[CODEC_MPEG1] = CODEC_ID_MPEG1VIDEO;
  codecMap[CODEC_MPEG2] = CODEC_ID_MPEG2VIDEO;
  codecMap[CODEC_MPEG4] = CODEC_ID_MPEG4;
  codecMap[CODEC_FLV1] = CODEC_ID_FLV1;
  codecMap[CODEC_FFV1] = CODEC_ID_FFV1;
  codecMap[CODEC_RAW] = CODEC_ID_RAWVIDEO;
  codecMap[CODEC_WMV1] = CODEC_ID_WMV1;
  codecMap[CODEC_WMV2] = CODEC_ID_WMV2;
}

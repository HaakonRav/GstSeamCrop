#include "types/MocaTypes.h"
#include <iostream>

#ifdef HAVE_CAMERA
#ifdef HAVE_LIBFLTK

#include "gui/CameraWindow.h"
#include "gui/ImageWindow.h"
#include "io/IO.h"
#include "filter/Filter.h"
#include "types/MocaException.h"

/*
  Program to test the triggered reader.
  Computes two random regions of interests, one of which being completely included in the other.
  Captures an image of each ROI and computes a difference image of the intersecting area.
  If the scene is static and the reader is working correctly, the difference image is nearly black.
*/

class TestWindow : public CameraWindow
{
public:
  TestWindow()
    : CameraWindow(Rect(0, 0, 1000, 1000), "ROI test", Rect(0, 0, 640, 480),
                   CameraReader::SPEED_800, CameraReader::MODE_RAW8, -1, false)
      //  : ImageWindow(dim, title, "examples/church.png")
  {
    uint32 w, h;
    reader->getMaxImageSize(w, h);
    image = boost::shared_ptr<Image8U>(new Image8U(w, h, 1));

    reader->getUnitPos(unitX, unitY);
    reader->getUnitSize(unitW, unitH);
    std::cout << "ROI units: (" << unitX << ", " << unitY << ", " << unitW << ", " << unitH << ")" << std::endl;
    CameraFeaturePtr shut = reader->getFeature(CameraFeature::FEATURE_Shutter);
    minShut = shut->getMin();
    maxShut = shut->getMax();
    CameraFeaturePtr gain = reader->getFeature(CameraFeature::FEATURE_Gain);
    minGain = gain->getAbsMin();
    maxGain = gain->getAbsMax();

    saveIndex = 0;
  }

protected:
  void doStuff()
  {
    // some constants
    int32 const width   = image->width();
    int32 const height  = image->height();
    int32 const minRoiW = 256;
    int32 const minRoiH = 256;
    bool const shutTest = true;
    bool const gainTest = true;
    bool const roiTest  = true;
    bool const saveBad  = false;

    // random region of interest
    Rect firstRoi(0, 0, width, height);
    if (roiTest)
      {
        firstRoi.w = random(minRoiW, width);
        firstRoi.h = random(minRoiH, height);
        quant(firstRoi.w, unitW);
        quant(firstRoi.h, unitH);
        if (firstRoi.w < width)
          firstRoi.x = random(0, width-firstRoi.w);
        quant(firstRoi.x, unitX);
        if (firstRoi.h < height)
          firstRoi.y = random(0, height-firstRoi.h);
        quant(firstRoi.y, unitY);
      }

    // second ROI is guaranteed to be included in the first
    Rect secondRoi(0, 0, width, height);
    if (roiTest)
      {
        secondRoi.w = random(minRoiW, firstRoi.w);
        secondRoi.h = random(minRoiH, firstRoi.h);
        quant(secondRoi.w, unitW);
        quant(secondRoi.h, unitH);
        if (secondRoi.w < firstRoi.w)
          secondRoi.x = random(0, firstRoi.w-secondRoi.w);
        secondRoi.x += firstRoi.x;
        quant(secondRoi.x, unitX);
        if (secondRoi.h < firstRoi.h)
          secondRoi.y = random(0, firstRoi.h-secondRoi.h);
        secondRoi.y += firstRoi.y;
        quant(secondRoi.y, unitY);
      }

    Image8U first(firstRoi.w, firstRoi.h, 1); // bigger image
    Image8U second(secondRoi.w, secondRoi.h, 1); // included in first

    // capture images
    //Image8U church(image->width(), image->height(), image->channels());
    //reader->getImage(church);
    //Filter::copyImage(*image, first, firstRoi, Vector2D::create(0, 0));
    //Filter::copyImage(*image, second, secondRoi, Vector2D::create(0, 0));
    uint32 shutter = shutTest ? random(minShut, maxShut/4) : (maxShut+minShut)/2;
    float gain = gainTest ? random(minGain*1000, maxGain/4*1000)/1000.0 : (maxGain+minGain)/2;
    reader->captureImage(firstRoi, shutter, gain);
    reader->getImage(first);
    reader->captureImage(secondRoi, shutter, gain);
    reader->getImage(second);

    // copy inner region of bigger image into new temp
    Image8U temp(secondRoi.w, secondRoi.h, 1); // smaller region copied from first
    Rect tempRoi(secondRoi.x - firstRoi.x, secondRoi.y - firstRoi.y, secondRoi.w, secondRoi.h);
    Filter::copyImage(first, temp, tempRoi, Vector2D::create(0, 0));

    // compute difference
    Image16S firstS(secondRoi.w, secondRoi.h, 1);
    Image16S secondS(secondRoi.w, secondRoi.h, 1);
    Filter::convert(temp, firstS);
    Filter::convert(second, secondS);
    Filter::sub(firstS, secondS, firstS);
    Filter::convert(firstS, temp, true);

    // display textual information
    double diff = countPixels(temp);
    std::cout << "Average pixel difference: " << diff << std::endl;
    if (diff == 0 || diff > 30)
      {
        std::cout << "ROI 1: (" << firstRoi << ")    ROI 2: (" << secondRoi << ")" << std::endl;
        if (saveBad)
          savePair(first, second);
      }
    
    //display graphical information
    Filter::set(*image, 128);
    Filter::copyImage(temp, *image, Vector2D::create(0, 0));
    showImage(image);
  }

  int32 random(int32 min, int32 max) // both inclusive
  {
    return (rand() % (max-min+1)) + min;
  }

  void quant(int32& value, int32 unit)
  {
    value = value/unit*unit;
  }

  double countPixels(Image8U const& img)
  {
    double result = 0;
    for (uint32 y=0; y<img.height(); ++y)
      for (uint32 x=0; x<img.width(); ++x)
        result += img(x, y);
    result /= img.width() * img.height();
    return result;
  }

  void savePair(Image8U const& first, Image8U const& second)
  {
    std::stringstream name;
    name << "image" << saveIndex++;
    IO::saveImage(name.str() + std::string("a.png"), first);
    IO::saveImage(name.str() + std::string("b.png"), second);
    std::cout << "Saved " << name.str() << "." << std::endl;
  }

protected:
  uint32 unitX, unitY, unitW, unitH;
  int32 minShut, maxShut;
  float minGain, maxGain;
  uint32 saveIndex;
};


int main(int argc, char **argv)
{
  srand(time(0));

  try
  {
    TestWindow wnd;
    wnd.mainLoop();
  }
  catch(MocaException& e)
  {
    std::cerr << diagnostic_information(e);
  }
  
  return 0;
}


#else // HAVE_LIBFLTK

int main(int argc, char** argv)
{
  std::cout << "this example requires FLTK." << std::endl;
  return 0;
}


#endif // HAVE_LIBFLTK
#else // HAVE_CAMERA

int main(int argc, char** argv)
{
  std::cout << "this example requires a supported camera." << std::endl;
  return 0;
}


#endif // HAVE_CAMERA


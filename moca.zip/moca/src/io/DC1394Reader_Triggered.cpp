#include "io/DC1394Reader_Triggered.h"


#ifdef HAVE_LIBDC1394

#include "types/MocaException.h"


// ==================== DC1394Reader sequence mode helper functions ====================

/* these functions help to read/write individual bitstrings from/to a 32 bit variable (in our case containing a copy of a register)
 *
 * reg       - variable being read or written to
 * value     - value to write as bitstring to a given position
 * substring - first : position where the bitstring starts (0 being the left-most bit)
 *             second: position of the first bit after the bitstring
 *
 * Use with care (especially setInRegister) since no boundary checks are done!
 */

// constants for working with the sequence mode of AVT Pike cameras
// register offsets
static uint64 const SEQUENCE_CTRL_OFFSET = 0x220;
static uint64 const SEQUENCE_PARAM_OFFSET = 0x224;

// position/length-pairs for specific substrings in the registers
static std::pair<uint8,uint8> const SEQUENCE_CTRL_AUTOREWIND(5, 6);
static std::pair<uint8,uint8> const SEQUENCE_CTRL_ONOFF(6, 7);
static std::pair<uint8,uint8> const SEQUENCE_CTRL_SETUP(7, 8);
static std::pair<uint8,uint8> const SEQUENCE_CTRL_MAXLEN(16, 24);
static std::pair<uint8,uint8> const SEQUENCE_CTRL_LEN(24, 32);

static std::pair<uint8,uint8> const SEQUENCE_PARAM_APPLY(5, 6);
static std::pair<uint8,uint8> const SEQUENCE_PARAM_NUMIMG(24, 32);


inline uint32 getBitmask(std::pair<uint8,uint8> const& substring)
{
  uint8 const& begin = substring.first;
  uint8 const& end = substring.second;
  
  // shifting by 32-bit wide registers by 32 or more positions is undefined (and may default to a NOP...)
  uint32 upper = (begin == 0 ? 0 : 0xFFFFFFFF << (32-begin));
  uint32 lower = (end == 32 ? 0 : 0xFFFFFFFF >> end);
  
  return upper | lower;
}


inline uint32 readFromRegister(uint32 const& reg, std::pair<uint8,uint8> const& substring)
{
  uint8 const& end = substring.second;
  
  return (reg & ~getBitmask(substring)) >> (32-end);
}


inline void resetInRegister(uint32& reg, std::pair<uint8,uint8> const& substring)
{
  reg &= getBitmask(substring);
}


inline void setInRegister(uint32& reg, uint32 const& value, std::pair<uint8,uint8> const& substring)
{
  uint8 const& end = substring.second;

  resetInRegister(reg, substring);
  reg |= value << (32-end);
}


// ==================== DC1394Reader triggered mode ====================

DC1394Reader_Triggered::DC1394Reader_Triggered(BusSpeed speed, ColorMode color, indexType selectedCamera)
  : DC1394Reader(speed, color, selectedCamera), hasSequenceMode(false), inSequenceMode(false)
{
  roi = Rect(-1, 0, 0, 0);
}


DC1394Reader_Triggered::~DC1394Reader_Triggered()
{
  try{
    stop();
  }catch(MocaException e){}
}


void DC1394Reader_Triggered::start()
{
  try
  {
    DC1394Reader::start();

    if (strcmp(camera->vendor, "AVT") == 0 && strcmp(camera->model, "Pike F032C") == 0)
      hasSequenceMode = true;
  }
  catch(MocaException& e)
  {
    if (camera)
      dc1394_camera_free(camera);
    camera = 0;
    initialized = false;
    throw;
  }
  initialized = true;
}


void DC1394Reader_Triggered::stop()
{
  if (initialized)
  {
    disableSequenceMode();
  }
}


void DC1394Reader_Triggered::captureImage(Rect roi, uint32 shutter, float gain)
{
  if (!initialized)
    BOOST_THROW_EXCEPTION(IOException("Unable to capture single image. Camera not initialized."));
  disableSequenceMode();

  setFeatureValue(CameraFeature::FEATURE_Shutter, shutter);
  if (gain != -10034) // ignore the default value... -.-;
    {
      CameraFeaturePtr gainFeat = getFeature(CameraFeature::FEATURE_Gain);
      gainFeat->setValue((int)(gain/0.0353+0.5));
    }
  setImageDimension(roi);
  triggerImage();
}


void DC1394Reader_Triggered::captureImages(std::vector<DC1394ReaderParameters> const& params)
{
  if (!initialized)
    BOOST_THROW_EXCEPTION(IOException("Unable to capture image sequence. Camera not initialized."));
  enableSequenceMode();
  if (this->params.size() > 0 && getNumRemainingImages() > 0)
    BOOST_THROW_EXCEPTION(IOException("Can't capture a new sequence while another sequence hasn't been fully captured and retrieved."));
   
  this->params = params;
  paramsIndex = 0;
  setupSequence();

  for (uint32 i = 0; i < this->params.size(); ++i)
    {
      DC1394ReaderParameters& curParams = this->params[i];
      bool roiChanged = true, shutterChanged = true, gainChanged = true;
      
      if (i > 0)
        {
          DC1394ReaderParameters& lastParams = this->params[i-1];
          if (curParams.roi.w == lastParams.roi.w && curParams.roi.h == lastParams.roi.h &&
              curParams.roi.x == lastParams.roi.x && curParams.roi.y == lastParams.roi.y)
            {
              roiChanged = false;
              curParams.bpp = lastParams.bpp;
            }
          if (curParams.shutter == lastParams.shutter)
            shutterChanged = false;
          if (curParams.gain == lastParams.gain)
            gainChanged = false;
        }
      else
        {
          if (curParams.gain == -10034) // ignore the "default" value... -.-;
            gainChanged = false;
        }
    
      setInRegister(seqRegisters[1], 0, SEQUENCE_PARAM_APPLY);
    
      // set the image number (this causes the functions which set the capture parameters to write to the correct camera registers)
      setInRegister(seqRegisters[1], i, SEQUENCE_PARAM_NUMIMG);
      if (dc1394_set_adv_control_register(camera, SEQUENCE_PARAM_OFFSET, seqRegisters[1]) != DC1394_SUCCESS)
        BOOST_THROW_EXCEPTION(IOException("Unable to set image number."));
        
      // set capture parameters
      if (shutterChanged)      
        setFeatureValue(CameraFeature::FEATURE_Shutter, curParams.shutter);
      if (gainChanged)
        {
          CameraFeaturePtr gainFeat = getFeature(CameraFeature::FEATURE_Gain);
          gainFeat->setValue((int)(curParams.gain/0.0353+0.5));
        }
      if (roiChanged)
        {
          if (curParams.roi.w != roi.w || curParams.roi.h != roi.h)
            {
              double roiFraction = ((double)curParams.roi.w * curParams.roi.h) / (roi.w * roi.h);
              curParams.bpp = ((uint32)(maxBPP*roiFraction)) / unitBPP * unitBPP;
              curParams.bpp -= unitBPP;
            }
          else
            curParams.bpp = maxBPP;
            
          DC1394Reader::setImageDimension(curParams.roi, curParams.bpp, &curParams.bpp);
        }
        
      // apply the capture parameters
      setInRegister(seqRegisters[1], 1, SEQUENCE_PARAM_APPLY);
      if (dc1394_set_adv_control_register(camera, SEQUENCE_PARAM_OFFSET, seqRegisters[1]) != DC1394_SUCCESS)
        BOOST_THROW_EXCEPTION(IOException("Unable to apply parameters for current image in sequence."));
    }

  triggerSequence();
}


void DC1394Reader_Triggered::captureImages(std::vector<uint32> const& newShutter, std::vector<float> const& newGain)
{
  if (!initialized)
    BOOST_THROW_EXCEPTION(IOException("Unable to capture image sequence. Camera not initialized."));
  enableSequenceMode();
  if (params.size() == 0)
    BOOST_THROW_EXCEPTION(IOException("Can't update the current sequence because no sequence has been set."));
  if (getNumRemainingImages() > 0)
    BOOST_THROW_EXCEPTION(IOException("Can't capture a new sequence while another sequence hasn't been fully captured and retrieved."));
  if (params.size() != newShutter.size() || params.size() != newGain.size())
    BOOST_THROW_EXCEPTION(IOException("The number of new exposure parameters doesn't match the number of old exposure parameters"));
    
  paramsIndex = 0;

  setInRegister(seqRegisters[0], 1, SEQUENCE_CTRL_SETUP);
  if (dc1394_set_adv_control_register(camera, SEQUENCE_CTRL_OFFSET, seqRegisters[0]) != DC1394_SUCCESS)
    BOOST_THROW_EXCEPTION(IOException("Unable to enable sequence mode."));

  for (uint32 i = 0; i < params.size(); ++i)
    {
      DC1394ReaderParameters& curParams = params[i];
    
      setInRegister(seqRegisters[1], 0, SEQUENCE_PARAM_APPLY);
    
      // set the image number (this causes the functions which set the capture parameters to write to the correct camera registers)
      setInRegister(seqRegisters[1], i, SEQUENCE_PARAM_NUMIMG);
      if (dc1394_set_adv_control_register(camera, SEQUENCE_PARAM_OFFSET, seqRegisters[1]) != DC1394_SUCCESS)
        BOOST_THROW_EXCEPTION(IOException("Unable to set image number."));
        
      // set capture parameters
      if (curParams.shutter != newShutter[i])
        {
          curParams.shutter = newShutter[i];
          setFeatureValue(CameraFeature::FEATURE_Shutter, curParams.shutter);
        }
      if (curParams.gain != newGain[i])
        {
          curParams.gain = newGain[i];
          CameraFeaturePtr gainFeat = getFeature(CameraFeature::FEATURE_Gain);
          gainFeat->setValue((int)(curParams.gain/0.0353+0.5));
        }
        
      // apply the capture parameters
      setInRegister(seqRegisters[1], 1, SEQUENCE_PARAM_APPLY);
      if (dc1394_set_adv_control_register(camera, SEQUENCE_PARAM_OFFSET, seqRegisters[1]) != DC1394_SUCCESS)
        BOOST_THROW_EXCEPTION(IOException("Unable to apply parameters for current image in sequence."));
    }
      
  triggerSequence();
}


void DC1394Reader_Triggered::captureImages()
{
  if (!initialized)
    BOOST_THROW_EXCEPTION(IOException("Unable to capture image sequence. Camera not initialized."));
  enableSequenceMode();
  if (params.size() == 0)
    BOOST_THROW_EXCEPTION(IOException("No sequence has been set."));
  if (getNumRemainingImages() > 0)
    BOOST_THROW_EXCEPTION(IOException("Can't capture a new sequence while another sequence hasn't been fully captured and retrieved."));
  
  paramsIndex = 0;
  triggerSequence();
}


DC1394ReaderParameters DC1394Reader_Triggered::getImageParams() const
{
  if (paramsIndex >= params.size())
    BOOST_THROW_EXCEPTION(IOException("Cannot retrieve image parameters because no further images are in the queue."));
    
  return params[paramsIndex];
}


void DC1394Reader_Triggered::getImage(Image8U& img)
{
  if (!inSequenceMode)
    {
      DC1394Reader::getImage(img);
      return;
    }

  if(getNumRemainingImages() == 0)
    BOOST_THROW_EXCEPTION(IOException("More images requested than have been captured."));
  
  DC1394ReaderParameters curParams = getImageParams();
  paramsIndex += 1;

  if (curParams.bpp == maxBPP)
    {
      DC1394Reader::getImage(img);
      return;
    }

  // if a sequence contains images with variable size the retrieved images will still have the maximal occuring
  // size and the actual image data has to be "extracted" from this larger image
  Image8U temp(roi.w, roi.h);
  DC1394Reader::getImage(temp);
      
  uint8* src = temp.ptr();
  uint8* dst = img.ptr();
  uint8* limit = dst + img.width() * img.height(); // this line assumes that only one channel with 8 bits per pixel is used
      
  while(dst < limit)
    {
      uint32 numBytes = std::min<uint32>(uint32(limit-dst), curParams.bpp);
      memcpy(dst, src, numBytes);
      src += maxBPP;
      dst += curParams.bpp;
    }
}


void DC1394Reader_Triggered::setImageDimension(Rect roi)
{
  bool posChanged  = this->roi.x != roi.x || this->roi.y != roi.y;
  bool sizeChanged = this->roi.w != roi.w || this->roi.h != roi.h;
  if (sizeChanged)
    dc1394_capture_stop(camera);

  if (sizeChanged || posChanged)
    DC1394Reader::setImageDimension(roi);

  if (sizeChanged)
    if (dc1394_capture_setup(camera, 5, DC1394_CAPTURE_FLAGS_DEFAULT) != DC1394_SUCCESS)
      BOOST_THROW_EXCEPTION(IOException("Cannot set image dimension. Unable to setup camera."));

  this->roi = roi;
}


void DC1394Reader_Triggered::triggerImage()
{
  // enable the transmission of a single image
  if (dc1394_video_set_one_shot(camera, DC1394_ON) != DC1394_SUCCESS)
    BOOST_THROW_EXCEPTION(IOException("Unable to capture single image. Can't set one-shot mode."));
}


void DC1394Reader_Triggered::setupSequence()
{
  // check if the given sequence isn't too long
  if (params.size() > readFromRegister(seqRegisters[0], SEQUENCE_CTRL_MAXLEN))
    BOOST_THROW_EXCEPTION(IOException("Sequence is too long."));
    
  dc1394_capture_stop(camera);
    
  // enable sequence mode and go into sequence setup state
  setInRegister(seqRegisters[0], 1, SEQUENCE_CTRL_ONOFF);
  setInRegister(seqRegisters[0], 1, SEQUENCE_CTRL_SETUP);
  if (dc1394_set_adv_control_register(camera, SEQUENCE_CTRL_OFFSET, seqRegisters[0]) != DC1394_SUCCESS)
    BOOST_THROW_EXCEPTION(IOException("Unable to enable sequence mode."));

  // set sequence length
  setInRegister(seqRegisters[0], params.size(), SEQUENCE_CTRL_LEN);
  if (dc1394_set_adv_control_register(camera, SEQUENCE_CTRL_OFFSET, seqRegisters[0]) != DC1394_SUCCESS)
    BOOST_THROW_EXCEPTION(IOException("Unable to set sequence length."));

  // setup packet/buffer parameters
  setMaxROI();
  DC1394Reader::setImageDimension(roi, 0, &maxBPP);
  if (dc1394_capture_setup(camera, params.size(), DC1394_CAPTURE_FLAGS_DEFAULT) != DC1394_SUCCESS)
    BOOST_THROW_EXCEPTION(IOException("Unable to setup camera."));
    
}


void DC1394Reader_Triggered::triggerSequence()
{
  // disable sequence setup
  setInRegister(seqRegisters[0], 0, SEQUENCE_CTRL_SETUP);
  setInRegister(seqRegisters[0], 1, SEQUENCE_CTRL_AUTOREWIND);
  if (dc1394_set_adv_control_register(camera, SEQUENCE_CTRL_OFFSET, seqRegisters[0]) != DC1394_SUCCESS)
    BOOST_THROW_EXCEPTION(IOException("Unable to finish sequence setup."));
    
  // start capturing
  if (dc1394_video_set_multi_shot(camera, params.size(), DC1394_ON) != DC1394_SUCCESS)
    BOOST_THROW_EXCEPTION(IOException("Unable to enable multi-shot mode."));
}


void DC1394Reader_Triggered::setMaxROI()
{
  roi = Rect(0, 0, MOCA_INT32_MIN, MOCA_INT32_MIN);
  std::vector<DC1394ReaderParameters>::const_iterator it;
  for (it = params.begin(); it != params.end(); ++it)
    {
      Rect const& curRoi = it->roi;
      roi.w = std::max(roi.w, curRoi.w);
      roi.h = std::max(roi.h, curRoi.h);
      //!!! this overestimates the maximum ROI if the maximum .w and .h are not from the same Rect
    }
}


void DC1394Reader_Triggered::enableSequenceMode()
{
  if (!hasSequenceMode)
    BOOST_THROW_EXCEPTION(IOException("Sequence not implemented for the selected camera."));

  if (!inSequenceMode)
  {  
    // read current sequence registers content
    if (dc1394_get_adv_control_registers(camera, SEQUENCE_CTRL_OFFSET, seqRegisters, 3) != DC1394_SUCCESS)
      BOOST_THROW_EXCEPTION(IOException("Unable to read sequence mode registers."));
      
    params.clear();
    paramsIndex = 0;

    inSequenceMode = true;
  }
}


void DC1394Reader_Triggered::disableSequenceMode()
{
  if (inSequenceMode)
  {
    if (getNumRemainingImages() > 0)
      BOOST_THROW_EXCEPTION(IOException("Not all images of the last sequence capture have been retrieved."));

    if (dc1394_set_adv_control_register(camera, SEQUENCE_CTRL_OFFSET, 0) != DC1394_SUCCESS)
      BOOST_THROW_EXCEPTION(IOException("Error while disabling sequence mode."));
    
    roi = Rect(-1, 0, 0, 0);
    
    inSequenceMode = false;
  }
}


#endif // HAVE_LIBDC1394


#include "testcases.h"

#include <stdlib.h>
#include <time.h>

float compareImage8U(Image8U& img1, Image8U& img2, int channel)
{
	//Test dimensions and channels
	if (img1.width() != img2.width() || img1.height() != img2.height() || img1.channels() != img2.channels())
		throw MocaException("Images differ in size or number of channels!");

	//Calculate difference
	float diff = 0;
	for (unsigned int y = 0; y < img1.height(); ++y)
	{
		for (unsigned int x = 0; x < img1.width(); ++x)
		{
			if (channel == -1)
			{
				for (int ch = 0; ch < img1.channels(); ch++)
				{
					diff += abs(img1(x,y,ch) - img2(x,y,ch));
				}
			} else diff += abs(img1(x,y,channel) - img2(x,y,channel));
		}
	}
	return (diff / (img1.height() * img1.width()));
}

float compareImage32F(Image32F& img1, Image32F& img2, int channel)
{
	//Test dimensions and channels
	if (img1.width() != img2.width() || img1.height() != img2.height() || img1.channels() != img2.channels())
		throw MocaException("Images differ in size or number of channels!");

	//Calculate difference
	float diff = 0;
	for (unsigned int y = 0; y < img1.height(); ++y)
	{
		for (unsigned int x = 0; x < img1.width(); ++x)
		{
			if (channel == -1)
			{
				for (int ch = 0; ch < img1.channels(); ch++)
				{
					diff += abs(img1(x,y,ch) - img2(x,y,ch));
				}
			} else diff += abs(img1(x,y,channel) - img2(x,y,channel));
		}
	}
	return (diff / (img1.height() * img1.width()));
}

void cropImage8U(Image8U& src, Image8U& tgt)
{
	//Test dimensions and channels
	if (src.width() < tgt.width() || src.height() < tgt.height() || src.channels() != tgt.channels())
		throw MocaException("Images do not meet requirements!");

	for (unsigned int y = 0; y < tgt.height(); ++y)
	{
		for (unsigned int x = 0; x < tgt.width(); ++x)
		{
			for (int ch = 0; ch < tgt.channels(); ch++)
			{
				tgt(x, y, ch) = src(x, y, ch);
			}
		}
	}
}

void cropImage32F(Image32F& src, Image32F& tgt)
{
	//Test dimensions and channels
	if (src.width() < tgt.width() || src.height() < tgt.height() || src.channels() != tgt.channels())
		throw MocaException("Images do not meet requirements!");

	for (unsigned int y = 0; y < tgt.height(); ++y)
	{
		for (unsigned int x = 0; x < tgt.width(); ++x)
		{
			for (int ch = 0; ch < tgt.channels(); ch++)
			{
				tgt(x, y, ch) = src(x, y, ch);
			}
		}
	}
}

void randFillImage(Image32F& src, float max, float min)
{
	//Initialize random number generator
	srand((unsigned int) time(NULL));

	//Fill image
	for (unsigned int y = 0; y < src.height(); ++y)
	{
		for (unsigned int x = 0; x < src.width(); ++x)
		{
			for (int ch = 0; ch < src.channels(); ch++)
			{
				//The multiplication increases the result range of the rand() function.
				//Otherwise, the result space is too small delivering always the same
				//maximum and minimum for VGA images.
				src(x, y, ch) = ((float) rand() / RAND_MAX) * (max - min) + min;
			}
		}
	}
}
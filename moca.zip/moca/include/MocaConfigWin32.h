#ifndef MOCA_CONFIG_WIN32_H
#define MOCA_CONFIG_WIN32_H 

#define HAVE_MSVC 1

// compiler warnings
//#pragma warning(disable:4996)
#define _SCL_SECURE_NO_WARNINGS  // disable warnings from un-checked iterators 

/* special defines required for MSVC */
#define NOMINMAX
#define _USE_MATH_DEFINES

#define for if(0);else for
#define popen _popen
#define pclose _pclose 


/* define if library is available */
#define HAVE_BOOST 1
#define HAVE_LIBCV 1
#define HAVE_LIBHIGHGUI 1
#define HAVE_LIBFLTK 1
#define HAVE_LIBGSL 1
#define HAVE_LIBGSLCBLAS 1

#define HAVE_LIBAVCODEC 1
#define HAVE_LIBAVDEVICE 1
#define HAVE_LIBAVFILTER 1
#define HAVE_LIBAVFORMAT 1
#define HAVE_LIBAVUTIL 1
#define HAVE_LIBPOSTPROC 1
#define HAVE_LIBSWSCALE 1

#undef HAVE_LIBDC1394 
#undef HAVE_LIBRAW1394 
#undef HAVE_LIBPOSTPROC 


/* define if header is available */
#define HAVE_DLFCN_H 1
#define HAVE_FCNTL_H 1
#define HAVE_INTTYPES_H 1
#define HAVE_LIMITS_H 1
#define HAVE_MEMORY_H 1

#define HAVE_STDINT_H 1
#define HAVE_STDLIB_H 1
#define HAVE_STRINGS_H 1
#define HAVE_STRING_H 1
#define HAVE_SYS_IOCTL_H 1
#define HAVE_SYS_STAT_H 1
#define HAVE_SYS_TYPES_H 1
#define HAVE_UNISTD_H 1
#define STDC_HEADERS 1

/* define if function is available */
#define HAVE_SQRT 1


/* Name of package */
#define PACKAGE "libmoca"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "Stephan Kopf <kopf@informatik.uni-mannheim.de>"

/* Define to the full name of this package. */
#define PACKAGE_NAME "libmoca"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "libmoca 1.0.0"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "libmoca"

/* Define to the version of this package. */
#define PACKAGE_VERSION "1.0.0"

/* Version number of package */
#define VERSION "1.0.0"


/* additional defines */
#define SIZEOF_CHAR 1
#define SIZEOF_DOUBLE 8
#define SIZEOF_FLOAT 4
#define SIZEOF_INT 4
#define SIZEOF_LONG_INT 8
#define SIZEOF_LONG_LONG_INT 8
#define SIZEOF_SHORT_INT 2
#define SIZEOF_UNSIGNED_CHAR 1
#define SIZEOF_UNSIGNED_INT 4
#define SIZEOF_UNSIGNED_LONG_INT 8
#define SIZEOF_UNSIGNED_LONG_LONG_INT 8
#define SIZEOF_UNSIGNED_SHORT_INT 2


/* Define to the sub-directory in which libtool stores uninstalled libraries. */
#undef LT_OBJDIR 

/* Define to `__inline__' or `__inline' if that's what the C compiler
   calls it, or to nothing if 'inline' is not supported under any name.  */
#ifndef __cplusplus
/* #undef inline */
#endif

#ifdef HAVE_LIBDC1394
#define HAVE_CAMERA 1
#endif

#endif

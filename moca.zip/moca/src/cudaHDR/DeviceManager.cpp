#include "types/MocaTypes.h"

#ifdef HAVE_CUDA

#include "cudaHDR/DeviceManager.h"
#include "cudaHDR/DataStructures.h"
#include "driver_types.h"
#include "cuda_runtime.h"
#include "types/MocaException.h"

//Returns the number of CUDA enabled devices present on this system.
//If no devices are found, a RuntimeException is thrown.
int DeviceManager::getNumberOfDevices()
{
	//Get number of devices
	int devcount;
	if (cudaGetDeviceCount(&devcount) != cudaSuccess)
		BOOST_THROW_EXCEPTION(MocaException("Could not fetch number of devices!"));

	//If only one device is being returned and its minor and
	//major revision are 9999, throw an exception
	if (devcount == 1)
	{
		//Fetch device properties
		cudaDeviceProp devprop;
		if (cudaGetDeviceProperties(&devprop, 0) != cudaSuccess)
			BOOST_THROW_EXCEPTION(MocaException("Could not query device properties!"));

		//Check first device's revision numbers
		if (devprop.minor == 9999 && devprop.major == 9999)
		{
			//Return error, because there is no CUDA enabled device
			BOOST_THROW_EXCEPTION(MocaException("No devices available!"));
		}
	}

	//Return counted devices
	return devcount;
}

//Returns the device index of the device with the maximal theoretical
//throughput of floating point multiplies and adds. This number
//is estimated from different parameters and can be seen as a hint
//to choose the correct device. This function should be rewritten
//for devices more recent than GeForce GTX 480.
int DeviceManager::getMaxGFLOPSDevice()
{
	//Query devices and check for errors
	std::vector<cudaDeviceProp> devices;
	deviceQuery(devices);

	//Receive number of devices and check for errors
	int devcount = getNumberOfDevices();

	//Calculate theoretical GFLOPs
	int flops = 0;
	int bestdevice = 0;
	for (int i = 0; i < devcount; i++)
	{
		int tempflops = (devices[i].major == 1 ? 8 : 32) * \
						(devices[i].major == 1 ? 1 : 2)  * \
						devices[i].multiProcessorCount   * \
						devices[i].clockRate;

		if  (tempflops > flops)
		{
			flops = tempflops;
			bestdevice = i;
		}
	}

	//Return index of best device found
	return bestdevice;
}

//Returns a vector containing the properties of all
//found devices on this machine.
void DeviceManager::deviceQuery(std::vector<cudaDeviceProp>& devices)
{
	//Receive number of devices
	int devcount = getNumberOfDevices();

	//Iterate devices and assign device properties to vector
	cudaDeviceProp deviceprop;
	for (int i = 0; i < devcount; i++)
	{
		cudaGetDeviceProperties(&deviceprop, i);
		devices.push_back(deviceprop);
	}
}

void DeviceManager::setDevice(int number)
{
	if (cudaSetDevice(number) != cudaSuccess) 
			BOOST_THROW_EXCEPTION(MocaException("Could not set device!"));
}

//Synchronizes the host thread and the device threads.
void DeviceManager::threadSynchronize()
{
	//Get last cuda error, if it is not cudaSuccess, return 0
	cudaThreadSynchronize();
}

#endif


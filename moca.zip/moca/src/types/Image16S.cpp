#include "types/Image16S.h"
#include "types/MocaException.h"


Image16S::Image16S()
  : ImageBase(0, 0, 1, IPL_DEPTH_16S)
{
  cvCreateData(image);
}


Image16S::Image16S(sizeType width, sizeType height, int32 channels)
  : ImageBase(width, height, channels, IPL_DEPTH_16S)
{
  cvCreateData(image);
}


Image16S::Image16S(IplImage* image)
  : ImageBase(image)
{
  if(depth() != (int32)IPL_DEPTH_16S)
    BOOST_THROW_EXCEPTION(ArgumentException("IplImage has invalid depth"));
}


Image16S::Image16S(Image16S const& other)
  : ImageBase(other.width(), other.height(), other.channels(), IPL_DEPTH_16S)
{
  cvCreateData(image);
  copyFrom(other);
}


Image16S::~Image16S()
{
  cvReleaseData(image);
}


Image16S& Image16S::operator=(Image16S const& other)
{
  cvReleaseImage(&image);
  image = cvCreateImage(cvSize(other.width(), other.height()), IPL_DEPTH_16S, other.channels());
  copyFrom(other);
  return *this;
}

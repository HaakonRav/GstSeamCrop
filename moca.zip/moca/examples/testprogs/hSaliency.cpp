#include <iostream>
#include "io/IO.h"
#include "filter/Filter.h"
#include "types/MocaException.h"
#include "types/Image32F.h"

#include "filter/HistogramSaliency.h"


int main(int argc, char* argv[]){ 
  if (argc != 3) {
    std::cerr << "not enough arguments: \"source picture\" \"destination picture\"" << std::endl;
    return 1;
  }
  
  boost::shared_ptr<Image8U> srcImage;
  
  try {
    std::cerr << "read image" << std::endl;        
    srcImage = IO::loadImage(argv[1]);

  } catch (MocaException e) {
    std::cout << "read Image error: " << e.what() << std::endl;
    exit (-1);
  }

  Image32F sal(srcImage->width(), srcImage->height(), 1);
  
  
  HistogramSaliency* hs = new HistogramSaliency();
  hs->hContrast(*srcImage, sal);

  
  Image8U dest(srcImage->width(), srcImage->height(), 1);
  Filter::convertScale(sal, dest);

  try {
    std::cerr << "save image" << std::endl;        
    IO::saveImage(argv[2], dest); 

  } catch (MocaException e) {
    std::cout << "save Image error: " << e.what() << std::endl;
    exit (-1);
  } 
}

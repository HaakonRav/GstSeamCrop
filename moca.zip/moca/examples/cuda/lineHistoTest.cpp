#define BOOST_TEST_DYN_LINK
#include "boost/test/unit_test.hpp"

#include "testcases.h"

#include "cudaHDR/CudaImage8UHandle.h"
#include "cudaHDR/KernelFunctions.h"
#include "cudaHDR/CudaWrapper.h"
#include "cudaHDR/CudaVectorHandle.h"
#include "cudaHDR/DeviceManager.h"

#include "io/ImageFileReader.h"
#include "io/ImageFileWriter.h"
#include "types/MocaException.h"
#include "feature/HistogramReg.h"
#include "feature/LineHistogram.h"

//Initially load needed testdata
struct testDataLineHisto
{
	//Will be available in every test case
	Image8U srcimg;

	//Initialize struct via constructor
	testDataLineHisto() : srcimg(640, 480, 3)
	{
		//Load bayer pattern testimage from hdd
		ImageFileReader ifr(Yxy_IMG);
		ifr.getImage(srcimg);
	}
};

BOOST_FIXTURE_TEST_SUITE(LineHistoTestSuite, testDataLineHisto)

BOOST_AUTO_TEST_CASE(LineHistoTest)
{
	//Generate line histogram on CPU
	LineHist histo_cpu(Rect(0,0,640,480));
	histo_cpu.create(srcimg, 128, 2, false);

	//Generate line histogram on GPU
	CudaImage8UHandle imghandle;
	imghandle.put(srcimg);
	CudaImage8UHandle changedstride;
	changedstride.allocate(640, 480, 3, 4);
	CudaWrapper::changeStride(imghandle, changedstride);
	CudaVectorHandle<unsigned int>	blackhandle;
	CudaVectorHandle<unsigned int>	whitehandle;
	CudaWrapper::lineHisto(changedstride, 
						   blackhandle,
						   whitehandle,
						   128,
						   2,
						   false);
	unsigned int black_gpu[640];
	unsigned int white_gpu[640];
	blackhandle.getData(black_gpu);
	whitehandle.getData(white_gpu);

	//Compare histograms
	for (int i = 0; i < 640; i++)
	{
		BOOST_CHECK(black_gpu[i] == histo_cpu.black[i]);
		BOOST_CHECK(white_gpu[i] == histo_cpu.white[i]);
	}
}

BOOST_AUTO_TEST_CASE(LineHistoTestVaryBoth)
{
	//Crop sourceim
	Image8U srcimg_crop(624, 470, 3);
	cropImage8U(srcimg, srcimg_crop);

	//Generate line histogram on CPU
	LineHist histo_cpu(Rect(0,0,624,470));
	histo_cpu.create(srcimg_crop, 128, 2, true);

	//Generate line histogram on GPU
	CudaImage8UHandle imghandle;
	imghandle.put(srcimg_crop);
	CudaImage8UHandle changedstride;
	changedstride.allocate(624, 470, 3, 4);
	CudaWrapper::changeStride(imghandle, changedstride);
	CudaVectorHandle<unsigned int>	blackhandle;
	CudaVectorHandle<unsigned int>	whitehandle;
	CudaWrapper::lineHisto(changedstride, 
		blackhandle, whitehandle,
		128, 2,
		true);
	unsigned int black_gpu[470];
	unsigned int white_gpu[470];
	blackhandle.getData(black_gpu);
	whitehandle.getData(white_gpu);

	//Compare histograms
	for (int i = 0; i < 470; i++)
	{
		BOOST_CHECK(black_gpu[i] == histo_cpu.black[i]);
		BOOST_CHECK(white_gpu[i] == histo_cpu.white[i]);
	}
}

BOOST_AUTO_TEST_CASE(LineHistoRoiTestVaryBoth)
{
	//Crop sourceimg
	Image8U srcimg_crop(624, 470, 3);
	cropImage8U(srcimg, srcimg_crop);

	//Generate line histogram on CPU
	Rect roi(3,5,301,230);
	LineHist histo_cpu(roi);
	histo_cpu.create(srcimg_crop, 128, 2, true);

	//Generate line histogram on GPU
	CudaImage8UHandle imghandle;
	imghandle.put(srcimg_crop);
	CudaImage8UHandle changedstride;
	changedstride.allocate(624, 470, 3, 4);
	CudaWrapper::changeStride(imghandle, changedstride);
	CudaVectorHandle<unsigned int>	blackhandle;
	CudaVectorHandle<unsigned int>	whitehandle;
	CudaWrapper::lineHisto(changedstride, 
		blackhandle, whitehandle,
		roi,
		128, 2,
		true,
		0);
	unsigned int black_gpu[230];
	unsigned int white_gpu[230];
	blackhandle.getData(black_gpu);
	whitehandle.getData(white_gpu);

	//Compare histograms
	for (int i = 0; i < 230; i++)
	{
		BOOST_CHECK(black_gpu[i] == histo_cpu.black[i]);
		BOOST_CHECK(white_gpu[i] == histo_cpu.white[i]);
	}
}

BOOST_AUTO_TEST_SUITE_END()
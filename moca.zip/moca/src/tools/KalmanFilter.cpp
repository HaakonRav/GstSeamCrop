#include "tools/KalmanFilter.h"

#include "types/MocaException.h"
#include "tools/Maths.h"


KalmanFilter::KalmanFilter(uint32 stateDim, uint32 obsDim)
  : stateDim(stateDim), obsDim(obsDim),
    state(boost::numeric::ublas::zero_vector<double>(stateDim)),
    stateCov(identity(stateDim, stateDim)),
    stateTrans(identity(stateDim, stateDim)),
    obsModel(identity(obsDim, stateDim)),
    procCov(identity(stateDim, stateDim)),
    obsCov(identity(obsDim, obsDim))
{
}


void KalmanFilter::setInitialState(Vector const& vect)
{
  if (vect.size() != state.size())
    BOOST_THROW_EXCEPTION(ArgumentException("Vector size mismatch."));
  state.assign(vect);
}


void KalmanFilter::setInitialCov(Matrix const& mat)
{
  if (mat.size1() != stateCov.size1() || mat.size2() != stateCov.size2())
    BOOST_THROW_EXCEPTION(ArgumentException("Matrix size mismatch."));
  stateCov.assign(mat);
}


void KalmanFilter::setStateTrans(Matrix const& mat)
{
  if (mat.size1() != stateTrans.size1() || mat.size2() != stateTrans.size2())
    BOOST_THROW_EXCEPTION(ArgumentException("Matrix size mismatch."));
  stateTrans.assign(mat);
}


void KalmanFilter::setObsModel(Matrix const& mat)
{
  if (mat.size1() != obsModel.size1() || mat.size2() != obsModel.size2())
    BOOST_THROW_EXCEPTION(ArgumentException("Matrix size mismatch."));
  obsModel.assign(mat);
}


void KalmanFilter::setProcCov(Matrix const& mat)
{
  if (mat.size1() != procCov.size1() || mat.size2() != procCov.size2())
    BOOST_THROW_EXCEPTION(ArgumentException("Matrix size mismatch."));
  procCov.assign(mat);
}


void KalmanFilter::setObsCov(Matrix const& mat)
{
  if (mat.size1() != obsCov.size1() || mat.size2() != obsCov.size2())
    BOOST_THROW_EXCEPTION(ArgumentException("Matrix size mismatch."));
  obsCov.assign(mat);
}


void KalmanFilter::updateState(Vector const& obs)
{
  if (obs.size() != obsDim)
    BOOST_THROW_EXCEPTION(ArgumentException("Dimension of observations must be as specified.") << ErrInt(obsDim));
  // ***predict state and covariance***
  // state = stateTrans * state + contModel * cont
  state = prod(stateTrans, state); // + prod(contModel, cont);
  // stateCov = stateTrans * stateCov * stateTrans^T + procCov
  stateCov = prod(stateTrans, stateCov);
  stateCov = prod(stateCov, boost::numeric::ublas::trans(stateTrans));
  stateCov += procCov;

  // ***compute temporary values***
  // residual = obs - obsModel * state
  Vector residual(obs - prod(obsModel, state));
  // resCov = obsModel * stateCov * obsModel^T + obsCov
  Matrix resCov(prod(obsModel, stateCov));
  resCov = prod(resCov, boost::numeric::ublas::trans(obsModel));
  resCov += obsCov;
  Matrix invResCov(resCov.size1(), resCov.size2());
  Maths::invertMatrix(resCov, invResCov);
  // gain = stateCov * obsModel^T * resCov^-1
  Matrix gain(prod(stateCov, boost::numeric::ublas::trans(obsModel)));
  gain = prod(gain, invResCov);
  // temp = I_stateDim - gain * obsModel
  Matrix temp(boost::numeric::ublas::identity_matrix<double>(stateDim, stateDim));
  temp -= prod(gain, obsModel);
    
  // ***update state and covariance***
  // state = state + gain * residual
  state += prod(gain, residual);
  // stateCov = temp * stateCov
  stateCov = prod(temp, stateCov);
}


Vector KalmanFilter::getStateEstimate()
{
  return state;
}


Matrix KalmanFilter::getStateCov()
{
  return stateCov;
}


Matrix KalmanFilter::identity(uint32 size1, uint32 size2)
{
  return boost::numeric::ublas::identity_matrix<double>(size1, size2);
}

#include "feature/HistogramReg.h"
#include "feature/LineHistogram.h"

#include <fstream>

#include "types/Exposure.h"
#include "feature/Feature.h"
#include "tools/Timing.h"
#include "types/MocaException.h"
#include "types/Rect.h"
#include "tools/Maths.h"
#include "tools/Timing.h"

#include <fstream>
#include <iostream>
using namespace std;

HistogramReg::HistogramReg(int32 maxOffset, double maxConf)
  :  kf(2, 2), maxOffset(maxOffset), maxConf(maxConf), noiseThresh(2),
     obsCovFactor(0.0), badMean(10), nextMeanStep(30), startWithRows(false),
     nccIters(2), initCov(50), procCov(30)
{
  initFilter();
}


void HistogramReg::initFilter()
{
  Matrix mat(2, 2);
  mat(0, 0) = initCov; mat(0, 1) = 0; mat(1, 0) = 0; mat(1, 1) = initCov;
  kf.setInitialCov(mat);
  mat(0, 0) = procCov; mat(1, 1) = procCov;
  kf.setProcCov(mat);
  Vector vec(2);
  vec -= vec;
  kf.setInitialState(vec);
}


VectorI HistogramReg::filterOffset(VectorI const& offset, Vector const& confidence)
{
  Matrix mat(2, 2);
  mat(0, 1) = 0; mat(1, 0) = 0;
  if (std::max(confidence[0], confidence[1]) >= maxConf) // that's not confident enough
    {
      mat(0, 0) = INFINITY;
      mat(1, 1) = INFINITY;
    }
  else
    {
      mat(0, 0) = confidence[0] * obsCovFactor;
      mat(1, 1) = confidence[1] * obsCovFactor;
    }

  kf.setObsCov(mat);
  Vector filtered(2);
  filtered[0] = offset[0]; filtered[1] = offset[1];
  kf.updateState(filtered);
  filtered = kf.getStateEstimate();

  VectorI result(2);
  result[0] = (int32)(filtered[0]+0.5); result[1] = (int32)(filtered[1]+0.5);
  return result;
}

void HistogramReg::computeMeans(Exposure const& exp1, Exposure const& exp2, uint8& mean1, uint8& mean2)
{
  VectorI hist(256);
  Feature::computeHist(*exp2.image, hist);
  mean2 = findMean(hist, 50);
  float expRatio = exp1.shutter / exp2.shutter;
  mean1 = (uint8)(mean2*expRatio);
  if (std::min<uint8>(mean1, mean2) < badMean)
    {
      mean2 = findMean(hist, 50+nextMeanStep);
      mean1 = (uint8)(mean2*expRatio);
    }
  else if (std::max<uint8>(mean1, mean2) > 255-badMean)
    {
      mean2 = findMean(hist, 50-nextMeanStep);
      mean1 = (uint8)(mean2*expRatio);
    }
}


int32 HistogramReg::findMean(VectorI const& hist, int32 percentage)
{
  int32 totalSum = 0;
  for (uint32 i=0; i<hist.size(); ++i)
    totalSum += hist[i];
  totalSum = (totalSum * percentage) / 100;
  int32 sum = 0;
  for (uint32 i=0; i<hist.size(); ++i)
    {
      sum += hist[i];
      if (sum >= totalSum)
        return i;
    }
  std::cout << "totalSum:" << totalSum << " sum:" << sum << std::endl;
  BOOST_THROW_EXCEPTION(RuntimeException("Funky error..."));
  return 0;
}

void HistogramReg::computeShift(Exposure const& exp1, Exposure const& exp2, VectorI& offset, Vector& confidence)
{
  offset.resize(2);
  confidence.resize(2);
  VectorI guess(offset);

  uint8 mean1, mean2;
  computeMeans(exp1, exp2, mean1, mean2);

  // two ROIs for the two exposures
  Rect roi1(exp1.topLeft[0], exp1.topLeft[1], exp1.image->width(), exp1.image->height());
  Rect roi2(exp2.topLeft[0], exp2.topLeft[1], exp2.image->width(), exp2.image->height());

  bool rows = startWithRows;
  for (uint32 i=0; i<nccIters; ++i)
    {
      // width and height of the intersecting ROI
      int32 interWidth  = std::min(roi1.x+roi1.w, roi2.x+roi2.w) - std::max(roi1.x, roi2.x);
      int32 interHeight = std::min(roi1.y+roi1.h, roi2.y+roi2.h) - std::max(roi1.y, roi2.y);
      if (interWidth <= 0 || interHeight <= 0)
        std::cout << "!!!NO INTERSECTION!!!" << std::endl;

      // build two histograms
      LineHist hist1(Rect(std::max(roi2.x-roi1.x, 0), std::max(roi2.y-roi1.y, 0), interWidth, interHeight));
      hist1.create(*exp1.image, mean1, noiseThresh, rows);
      LineHist hist2(Rect(std::max(roi1.x-roi2.x, 0), std::max(roi1.y-roi2.y, 0), interWidth, interHeight));
      hist2.create(*exp2.image, mean2, noiseThresh, rows);

      int32 off = hist1.corrOffset(hist2, rows ? guess[1] : guess[0], maxOffset);
      if (rows)
        {
          roi2.y += off;
          offset[1] += off;
        }
      else
        {
          roi2.x += off;
          offset[0] += off;
        }
      rows = !rows;
    }

  confidence = offset-guess;
  confidence[0] = abs(confidence[0]);
  confidence[1] = abs(confidence[1]);
}

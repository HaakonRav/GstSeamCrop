#include <iostream>
#include <cstdio>
#include "io/IO.h"
#include "io/VideoWriter.h"
#include "types/MocaException.h"
#include <string>
#include <sstream>
#include <list>
#include <boost/filesystem/operations.hpp>
#include <boost/filesystem/path.hpp>

namespace fs = boost::filesystem;

/*
* make all numbers the same length, so that they can be compared. Function is needed for sorting the map of filenames.
*/
bool compare_fill(std::string first, std::string second) {
	std::stringstream sstr1;
	std::stringstream sstr2;

	int numb1 = 20 - first.length();
	int numb2 = 20 - second.length();

	size_t position;
	position = first.find_first_of("0123456789");
	if(position != std::string::npos){
		std::string first1 = first.substr(0, position);
		std::string first2 = first.substr(position);
		sstr1 << first1;
		for(int x = 0; x < numb1 ; x++)
			sstr1 << "0";
		sstr1 << first2;
	}
	else {
		sstr1 << first;
	}

	size_t position2;
	position2 = second.find_first_of("0123456789");
	if(position2 != std::string::npos){
		std::string second1 = second.substr(0, position2);
		std::string second2 = second.substr(position2);
		sstr2 << second1;
		for(int x = 0; x < numb2 ; x++)
			sstr2 << "0";
		sstr2 << second2;
	}
	else {
		sstr2 << second;
	}

	if(sstr1.str() < sstr2.str())
		return true;
	else
		return false;
}

int main(int argc, char* argv[]){ 
	if (argc != 5) {
		std::cerr << "not enough arguements: \"path of pictures\" \"width\" \"height\" \"video\"" << std::endl;
		return 1;
	}

	std::list<std::string> pictures;
	VideoWriter writer(argv[4], std::atoi(argv[2]), std::atoi(argv[3]));
	writer.start();

	boost::shared_ptr<Image8U> srcBild;

	fs::path full_path(fs::initial_path<fs::path>());
	full_path = fs::system_complete(fs::path(argv[1]));

	if(!fs::exists(full_path)) {
		std::cerr << "path not found" << std::endl;
		return 1;
	}

	if(fs::is_directory(full_path)) {
		fs::directory_iterator end_iter;
		for(fs::directory_iterator dir_itr(full_path);dir_itr != end_iter;++dir_itr) {
			try {
				if(fs::is_regular_file(dir_itr->status())) {
					if(dir_itr->path().extension() == ".jpg" || dir_itr->path().extension() == ".jpeg" || dir_itr->path().extension() == ".png")
						pictures.push_back(dir_itr->path().string());
				}
			}
			catch ( const std::exception & ex ) {
				std::cerr << dir_itr->path().filename() << " " << ex.what() << std::endl;
			}
		}
	}
	else {
		std::cerr << "please give a path not a file." << std::endl;
	}

	pictures.sort(compare_fill);

	std::list<std::string>::iterator picItr = pictures.begin();
	while(picItr != pictures.end()) {
		try {      
			srcBild = IO::loadImage(*picItr); 
			std::cout << "process file: " << (*picItr) << std::endl;

		} catch (MocaException e) {
			std::cerr << "end of files" << std::endl;
			break;
		}
		if(srcBild->width() == (uint32) std::atoi(argv[2]) && srcBild->height() == (uint32) std::atoi(argv[3])){
			writer.putImage(*srcBild);
		}

		picItr++;
	}
	writer.stop();
}

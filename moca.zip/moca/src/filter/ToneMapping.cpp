#include "filter/ToneMapping.h"

#include "types/Image32F.h"
#include "types/Image8U.h"
#include "types/MocaException.h"
#include "filter/CvtColorSpace.h"
#include "filter/Filter.h"


float ToneMapping::simpleLog(Image32F const& image, Image8U& result)
{
  if ((image.width() != result.width()) || (image.height() != result.height()) || (image.channels() != result.channels()))
    BOOST_THROW_EXCEPTION(ArgumentException("Image parameters don't match.") << ErrImg1(image) << ErrImg2(result));

  uint32 w = image.width(), h = image.height();
  float min, max, avg;
  minMaxAvg(image, min, max, avg);
  if (min < 0)
    BOOST_THROW_EXCEPTION(RuntimeException("Float image contains negative pixels. Can't take logarithm."));
  max = log(1+max-min);

  float sat = 1.0F; // color saturation
  for (uint32 y=0; y<h; ++y)
    for (uint32 x=0; x<w; ++x)
      {
	float pixVal = log(1+image(x, y, 0)-min);
	result(x, y, 0) = (uint8)(pixVal/max*255.0f);
        if (result.channels() == 3)
          {
            result(x, y, 1) = (uint8)((image(x, y, 1)-85)*sat+85); // scale around value 85
            result(x, y, 2) = (uint8)((image(x, y, 2)-85)*sat+85);
          }
      }

  return avg;
}


float ToneMapping::dragoLog(Image32F const& image, Image8U& result)
{
  if ((image.width() != result.width()) || (image.height() != result.height()) || (image.channels() != result.channels()))
    BOOST_THROW_EXCEPTION(ArgumentException("Image parameters don't match.") << ErrImg1(image) << ErrImg2(result));

  uint32 w = image.width(), h = image.height();
  float min, max, avg;
  minMaxAvg(image, min, max, avg);
  float range = max-min;

  float sat = 0.33F; // color saturation
  float p = 0.7F; // user parameter of the drago mapping
  p = (float) (log10(p) / log10(0.5)); // invariant
  for (uint32 y=0; y<h; ++y)
    for (uint32 x=0; x<w; ++x)
      {
	float pixVal = std::max<float>(image(x, y, 0) - min, 0);
        float res = log10(1 + pixVal);
        res /= log10(1 + range);
        res /= log10(2 + 8 * pow(pixVal/range, p));
	result(x, y, 0) = (uint8)(res*255);
        if (result.channels() == 3)
          {
            result(x, y, 1) = (uint8)((image(x, y, 1)-85)*sat+85); // scale around value 85
            result(x, y, 2) = (uint8)((image(x, y, 2)-85)*sat+85);
          }
      }

  return avg;
}


float ToneMapping::wardContrast(Image32F const& image, Image8U& result, float scale)
{
  uint32 w = image.width(), h = image.height();
  if ((result.width() != w) || (result.height() != h) || (image.channels() != result.channels()))
    BOOST_THROW_EXCEPTION(ArgumentException("Image parameters don't match.") << ErrImg1(image) << ErrImg2(result));
  if (scale <= 0)
    BOOST_THROW_EXCEPTION(ArgumentException("Scale must be greater than zero.") << ErrDouble(scale));

  Image32F tempResult(w, h, image.channels());
  float Ldmax = 100;

  double Lwa = 0;
  for (uint32 y=0; y<h; ++y)
    for (uint32 x=0; x<w; ++x)
      Lwa += log(0.00001 + image(x, y, 0));
  Lwa = exp(Lwa / (float)(w * h));

  double factor = (1./Ldmax) * pow((1.219 + pow((Ldmax/2.0), 0.4)) / (1.219 + pow (Lwa, 0.4)), 2.5);

  for (uint32 y=0; y<h; ++y)
    for (uint32 x=0; x<w; ++x)
      {
        tempResult(x, y, 0) = image(x, y, 0) * factor;
        tempResult(x, y, 1) = image(x, y, 1);
        tempResult(x, y, 2) = image(x, y, 2);
      }


  CvtColorSpace::cvtYxy_BGR(tempResult, tempResult);

  Filter::clip(tempResult, tempResult, 0, 255);
  normalize(tempResult, 1);
  applyGamma(tempResult, 2.0);
  double avg = normalize(tempResult, scale);
  Filter::clip(tempResult, tempResult, 0, 255);

  for (uint32 y=0; y<h; ++y)
    for (uint32 x=0; x<w; ++x)
      for (int32 c=0; c<image.channels(); ++c)
        result(x, y, c) = (uint8)tempResult(x, y, c);

  return avg;
}


Histogram ToneMapping::histNorm(Image32F const& image, Image8U& result, float scale)
{
  uint32 w = image.width(), h = image.height();
  if ((w != result.width()) || (h != result.height()) || (image.channels() != result.channels()))
    BOOST_THROW_EXCEPTION(ArgumentException("Image parameters don't match.") << ErrImg1(image) << ErrImg2(result));

  Image32F tempResult(w, h, image.channels());

  // constants throughout the function
  float min, max, avg;
  minMaxAvg(image, min, max, avg, 1/4096.0);
  min = log(min); max = log(max);
  if (min == max) // hack for completely black/white images
    min = min-1;

  // compute histogram
  Histogram hist(min, max, 256);
  logHisto(image, hist);
  Histogram resultHist(min, max, 256);
  for (uint32 i=0; i<256; ++i)
    resultHist.bin(i) = hist.bin(i);

  // cap the maximum peak height ( = cap max derivative of the cumulative histogram)
  trimHisto(hist);

  // Cumulate and Normalize histogram
  cumulateAndNormalizeHisto(hist);

  // perform tone mapping
  mapImageHist(image, tempResult, hist);

  if (scale > 0) {
    CvtColorSpace::cvtYxy_BGR(tempResult, tempResult);
    normalize(tempResult, scale);
  }

  for (uint32 y=0; y<h; ++y)
    for (uint32 x=0; x<w; ++x)
      for (int32 c=0; c<image.channels(); ++c)
        result(x, y, c) = (uint8)tempResult(x, y, c);

  return resultHist;
}


void ToneMapping::mapImageHist(Image32F const& image, Image32F& result, Histogram const& hist)
{
  double sat = 0.4;
  unsigned int w = image.width();
  unsigned int h = image.height();
  double min = (double) hist.getMinVal();
  double max = (double) hist.getMaxVal();
  for (uint32 y=0; y<h; ++y)
    {
      for (uint32 x=0; x<w; ++x)
        {
          double pixVal = log(image(x, y, 0));
          pixVal = std::min(max, std::max(min, pixVal));
          pixVal = (float)(255 * hist.binLerp(pixVal));
          result(x, y, 0) = std::min(pixVal, 255.0);
          if (result.channels() == 3)
            {
              result(x, y, 1) = (image(x, y, 1)-85)*sat+85; // scale around value 85
              result(x, y, 2) = (image(x, y, 2)-85)*sat+85;
            }
        }
    }
}


void ToneMapping::cumulateAndNormalizeHisto(Histogram& hist)
{
  double pixCount = hist.binSum();
  hist.bin(0u) /= pixCount;
  for (uint32 i=1; i<hist.size(); ++i)
    {
      hist.bin(i) = hist.bin(i)/pixCount + hist.bin(i-1);
    }
}


double ToneMapping::trimHisto(Histogram& hist)
{
  // cap the maximum peak height ( = cap max derivative of the cumulative histogram)
  double init_pixCount = hist.binSum();
  double pixCount = init_pixCount;
  double max = hist.getMaxVal();
  double min = hist.getMinVal();
  double trimmings = 1;
  // stop when less than 2.5% were cut off
  for (uint32 iter=0; iter<100 && trimmings >= 0.025; ++iter)
    {
      double cap = pixCount * (max - min)/hist.size() / log(255.0);
      pixCount = 0; trimmings = 0;
      for (uint32 i=0; i<hist.size(); ++i)
        {
          double& bin = hist.bin(i);
          trimmings += std::max(bin-cap, 0.0);
          bin = std::min(bin, cap);
          pixCount += bin;
        }
      trimmings /= init_pixCount;
    }
  return pixCount;
}


void ToneMapping::logHisto(Image32F const& image, Histogram& hist, float inc)
{
  float histmin = (float) hist.getMinVal();
  float histmax = (float) hist.getMaxVal();
  hist.clear();
  uint32 xmax = image.width();
  uint32 ymax = image.height();
  for (uint32 y=0; y<ymax; ++y)
    {
      for (uint32 x=0; x<xmax; ++x)
        {
          float pixVal = log(image(x, y, 0));
          pixVal = std::min(histmax, std::max(histmin, pixVal));
          hist.bin(pixVal) += inc;
        }
    }
}


float ToneMapping::photographic(Image32F const& hdrImage, Image8U& result, float scale)
{
  Image32F tempResult(hdrImage);

  scaleToMidtone(tempResult, 0.18);
  std::vector<Image32F> pyramid;
  buildPyramid(tempResult, pyramid, 8);
  mapImagePhoto(pyramid, tempResult, 0.18);

  CvtColorSpace::cvtYxy_BGR(tempResult, tempResult);
  normalize(tempResult, 1);
  applyGamma(tempResult, 2.0);
  float avg = normalize(tempResult, scale);

  uint32 w = hdrImage.width(), h = hdrImage.height();
  for (uint32 y=0; y<h; ++y)
    for (uint32 x=0; x<w; ++x)
      for (uint32 c=0; c<3; ++c)
        result(x, y, c) = (uint8)tempResult(x, y, c);

  return avg;
}


void ToneMapping::scaleToMidtone(Image32F& image, float key)
{
  uint32 w = image.width(), h = image.height();
  float min, max, avg;
  ToneMapping::minMaxAvg(image, min, max, avg, 0.00001);
  float factor = key / exp(avg);
  for (uint32 y=0; y<h; ++y)
    for (uint32 x=0; x<w; ++x)
      image(x, y, 0) *= factor;
}


void ToneMapping::buildPyramid(Image32F const& image, std::vector<Image32F>& result, uint32 range)
{
  result.reserve(range);
  result.push_back(image);
  for (uint32 scale=1; scale<range; ++scale)
    {
      Image32F& prev = result[scale-1];
      Image32F level(prev.width()/2, prev.height()/2, prev.channels());
      Filter::pyramidDown(prev, level);
      result.push_back(level);
    }
}


inline float getPix(std::vector<Image32F> const& pyramid, uint32 scale, uint32 x, uint32 y)
{
  int factor = 1 << scale;
  return pyramid[scale](x/factor, y/factor);
}

void ToneMapping::mapImagePhoto(std::vector<Image32F> const& pyramid, Image32F& image, float key)
{
  uint32 w = image.width(), h = image.height();
  uint32 range = pyramid.size();
  float sigma_0 = log( 1.0); // scale low
  float sigma_1 = log(43.0); // scale high: 1.6^8 = 43
  float threshold = 0.05;
  float phi = 8;

  for (uint32 y=0; y<h; ++y)
    for (uint32 x=0; x<w; ++x) {
      uint32 prefScale = range - 1;

      for (uint32 scale=0; scale<range-1; ++scale) {
        float si = exp(sigma_0 + scale/(float)range*(sigma_1 - sigma_0));
        float activity = getPix(pyramid, scale, x, y) - getPix(pyramid, scale+1, x, y);
        activity /= (key * pow(2, phi)) / (si*si);
        activity += getPix(pyramid, scale, x, y);

        if (fabs(activity) > threshold) {
          prefScale = scale;
          break;
        }
      }
        
      image(x, y, 0) /= 1 + getPix(pyramid, prefScale, x, y);
    }
}


void ToneMapping::minMaxAvg(Image32F const& image, float& min, float& max, float& avg, float minVal)
{
  uint32 w = image.width(), h = image.height();
  min = (float)INFINITY; max = (float)-INFINITY; avg = 0;
  for (uint32 y=0; y<h; ++y)
    for (uint32 x=0; x<w; ++x)
      {
	float pixVal = luminance(image, x, y);
        pixVal = std::max<float>(minVal, pixVal);
        min = std::min<float>(min, pixVal);
        max = std::max<float>(max, pixVal);
        avg += log(pixVal);
      }
  avg /= w*h;
}


float ToneMapping::luminance(Image32F const& image, uint32 x, uint32 y, bool isBGR)
{
  if (isBGR)
    return 0.0721 * image(x, y, 0) +
      0.7154 * image(x, y, 1) + 
      0.2125 * image(x, y, 2); 
  else
    return image(x, y);
}


float ToneMapping::normalize(Image32F& image, float range)
{
  float min, max, avg;
  minMaxAvg(image, min, max, avg);
  float inRange = max - min;

  for (uint32 y=0; y<image.height(); ++y)
    for (uint32 x=0; x<image.width(); ++x)
      for (int32 c=0; c<image.channels(); ++c)
        {
          float value = image(x, y, c);
          value = range * ((value - min) / inRange);
          value = std::min(range, std::max(0.0f, value));
          image(x, y, c) = value;
        }

  return avg;
}


void ToneMapping::applyGamma(Image32F& image, float gamma)
{
  uint32 w = image.width(), h = image.height();
  for (uint32 y=0; y<h; ++y)
    for (uint32 x=0; x<w; ++x)
      {
        image(x, y, 0) = pow(image(x, y, 0), 1/gamma);
        image(x, y, 1) = pow(image(x, y, 1), 1/gamma);
        image(x, y, 2) = pow(image(x, y, 2), 1/gamma);
      }
}

#include "types/ImageBase.h"
#include "types/MocaException.h"
#include "types/Rect.h"


ImageBase::ImageBase(ImageBase const& other)
{
  image = cvCreateImageHeader(cvSize(other.width(), other.height()), other.depth(), other.channels());
  bpp = other.bpp;
  timestamp = other.timestamp;
}


ImageBase::ImageBase(sizeType width, sizeType height, int32 channels, int32 depth)
{
  if (width <= 0 || height <= 0)
    BOOST_THROW_EXCEPTION(ArgumentException("Invalid image size"));
  if (channels < 1 || channels > 4)
    BOOST_THROW_EXCEPTION(ArgumentException("Invalid number of channels"));

  image = cvCreateImageHeader(cvSize(width, height), depth, channels);
  bpp = (image->depth & ~IPL_DEPTH_SIGN) / 8;
  timestamp = 0;
}


ImageBase::ImageBase(IplImage* image)
  : image(image)
{
  bpp = (image->depth & ~IPL_DEPTH_SIGN) / 8;
  timestamp = 0;
}


ImageBase::~ImageBase()
{
  cvReleaseImageHeader(&image);
}


ImageBase& ImageBase::operator=(ImageBase const& other)
{
  BOOST_THROW_EXCEPTION(RuntimeException("The target image class doesn't support the assign operator") << ErrImg1(*this));
  return *this;
}


void ImageBase::copyFrom(IplImage const* other)
{
  if(!matchingParams(other))
    BOOST_THROW_EXCEPTION(ArgumentException("Image parameters do not match") << ErrImg1(*this) << ErrIplImg(*other));

  cvCopy(other, image, NULL);
  timestamp = 0;
}


void ImageBase::copyFrom(ImageBase const& other)
{
  copyFrom(other.image);
  timestamp = other.timestamp;
}


Rect ImageBase::getRoi() const
{
  CvRect rect(cvGetImageROI(image));
  return Rect(rect.x, rect.y, rect.width, rect.height);
}


void ImageBase::setRoi(Rect const& newRoi)
{
  // cvSetImageROI allows ROI sizes of 0, etc., but function calls on such images will fail
  // ROI size is capped to image size automatically
  if (newRoi.x < 0 || newRoi.x >= (int32)width() ||
      newRoi.y < 0 || newRoi.y >= (int32)height())
    BOOST_THROW_EXCEPTION(ArgumentException("Must be: ROI.x <= img.width() && ROI.y <= img.height()"));
  if (newRoi.w <= 0 || newRoi.h <= 0)
    BOOST_THROW_EXCEPTION(ArgumentException("ROI width and height must be >= 0"));
    
  cvSetImageROI(image, cvRect(newRoi.x, newRoi.y, newRoi.w, newRoi.h));
}


void ImageBase::resetRoi()
{
  cvResetImageROI(image);
}


sizeType ImageBase::width() const
{
  return (sizeType)image->width;
}


sizeType ImageBase::height() const
{
  return (sizeType)image->height;
}


int32 ImageBase::channels() const
{
  return (int32)image->nChannels;
}


int32 ImageBase::depth() const
{
  return (int32)image->depth;
}


int32 ImageBase::widthStep() const
{
  return (int32)image->widthStep;
}


uint64 ImageBase::getTimestamp() const
{
  return timestamp;
}


void ImageBase::setTimestamp(uint64 newTimestamp)
{
  timestamp = newTimestamp;
}


bool ImageBase::matchingParams(IplImage const* other) const
{
  bool result = (image->width == other->width);
  result &= (image->height    == other->height);
  result &= (image->nChannels == other->nChannels);
  result &= (image->depth     == other->depth);
  result &= (image->widthStep == other->widthStep);
  return result;
}


bool ImageBase::matchingParams(ImageBase const& other) const
{
  return matchingParams(other.image);
}


uint8* ImageBase::ptr()
{
  return (uint8*)image->imageData;
}


uint8 const* ImageBase::ptr() const
{
  return (uint8*)image->imageData;
}


std::ostream& operator<<(std::ostream& stream, IplImage const& image)
{
  stream << "width:" << image.width << " height:" << image.height;
  stream << " channels:" << image.nChannels << " depth:" << image.depth;
  return stream;
}


std::ostream& operator<<(std::ostream& stream, ImageBase const& image)
{
  stream << "width:" << image.width() << " height:" << image.height();
  stream << " channels:" << image.channels() << " depth:" << image.depth();
  return stream;
}



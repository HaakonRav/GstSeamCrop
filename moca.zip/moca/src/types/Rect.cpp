#include "types/Rect.h"

std::ostream& operator<<(std::ostream& stream, Rect const& r)
{
  return stream << "x:" << r.x << " y:" << r.y << " w:" << r.w << " h:" << r.h;
}

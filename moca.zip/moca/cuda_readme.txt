To enable the CUDA code included in moca you have to do the following:
(Note: the following text assumes you're using Fedora 17+, GCC 4.7 and
CUDA 5.0 with a modified compiler check)

Execute the following two lines in a console to add CUDA 5.0 to the search
paths:

  export PATH=$PATH:/usr/local/cuda/bin
  export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/cuda/lib:/usr/local/cuda/lib64

To automatically modify the search paths every time you use your system
add the above two lines to the file '~/.bashrc'.

Your environment is now set up properly to use CUDA. To enable CUDA in the
moca itself, execute the following commands in a console in the moca
directory:

  ./reconf.sh --enable-cuda=<arch>
  make

<arch> must be set to the compute capability of the GPU. E.g. use this for
a Geforce GTX 650 Ti which has compute capability 3.0:

  ./reconf.sh --enable-cuda=sm_30


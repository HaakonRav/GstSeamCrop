#include "types/Image32F.h"
#include "types/MocaException.h"


Image32F::Image32F()
  : ImageBase(0, 0, 1, IPL_DEPTH_32F)
{
  cvCreateData(image);
}


Image32F::Image32F(sizeType width, sizeType height, int32 channels)
  : ImageBase(width, height, channels, IPL_DEPTH_32F)
{
  cvCreateData(image);
}


Image32F::Image32F(IplImage* image)
  : ImageBase(image)
{
  if(depth() != IPL_DEPTH_32F)
    BOOST_THROW_EXCEPTION(ArgumentException("IplImage has invalid depth"));
}


Image32F::Image32F(Image32F const& other)
  : ImageBase(other.width(), other.height(), other.channels(), IPL_DEPTH_32F)
{
  cvCreateData(image);
  copyFrom(other);
}


Image32F::~Image32F()
{
  cvReleaseData(image);
}


Image32F& Image32F::operator=(Image32F const& other)
{
  cvReleaseImage(&image);
  image = cvCreateImage(cvSize(other.width(), other.height()), IPL_DEPTH_32F, other.channels());
  copyFrom(other);
  return *this;
}

#include "gui/DisplayWindow.h"

#ifdef HAVE_LIBFLTK

#include "gui/ImagePanel.h"
#include "types/Image8U.h"
#include "types/MocaException.h"
#include "gui/HistogramWindow.h"

using boost::shared_ptr;
using boost::dynamic_pointer_cast;


// ==================== DisplayWindow ====================


const int32 DisplayWindow::menuHeight = 30;
const int32 DisplayWindow::scrollbarSize = 16;


DisplayWindow::DisplayWindow(Rect rect, std::string title)
  : Fl_Double_Window(rect.x, rect.y, rect.w, rect.h, title.c_str())
{
  Fl::visual(FL_DOUBLE | FL_INDEX);

  menuBar = new Fl_Menu_Bar(0, 0, rect.w, menuHeight);
  vScrollbar = new Fl_Scrollbar(rect.w-scrollbarSize, menuHeight, scrollbarSize, rect.h-(menuHeight+scrollbarSize));
  hScrollbar = new Fl_Scrollbar(0, rect.h-scrollbarSize, rect.w-scrollbarSize, scrollbarSize);
  hScrollbar->type(FL_HORIZONTAL);
  // you have to create the ImagePanel last because every widget/window created afterwards will be a child of the ImagePanel
  panel = new ImagePanel(0, menuHeight, rect.w-scrollbarSize, rect.h-(menuHeight+scrollbarSize), "Image");
  image = boost::shared_ptr<Image8U>(new Image8U(rect.w, rect.h, 1));

  addMenuEntry("Image/Histogram", 'h', histogramCB);
  addMenuEntry("Image/Capture Image", 'z', captureImageCB);

  this->resizable(panel);

  this->size_range(50, 50);
  this->resize(Rect(rect.x, rect.y, rect.w, rect.h+menuHeight));
  this->end(); // all widgets/windows created before this call get destroyed by FLTK automatically

  histogram = boost::shared_ptr<HistogramWindow>(new HistogramWindow(50, 120));
  histogram->end();

  this->show();
}


DisplayWindow::~DisplayWindow()
{
}


void DisplayWindow::mainLoop()
{
  try
  {
    while(shown())
      mainLoopFunc();
  }
  catch(MocaException& e)
  {
    std::cerr << diagnostic_information(e);
    hide();
  }
}


void DisplayWindow::mainLoopFunc()
{
  Fl::wait(0.01);
  doStuff();
  if (histogram->shown())
    histogram->computeHist(*image);
}


void DisplayWindow::addMenuEntry(std::string name, char shortcut, void (*callback)(DisplayWindow*))
{
  menuBar->add(name.c_str(), FL_CTRL+shortcut, cbFunction, (void*)callback);
}


DisplayWindow::Scrollbars DisplayWindow::checkForScrollbars(Size wndSize)
{
  int imgWidth = shownImageWidth;
  int imgHeight = shownImageHeight;
  int spaceWidth = wndSize.w;
  int spaceHeight = wndSize.h - menuHeight;
  bool needVScrollbar = false, needHScrollbar = false;
 
  if(spaceWidth < imgWidth)
    needHScrollbar = true;
  if(spaceHeight - (needHScrollbar ? scrollbarSize : 0) < imgHeight)
  {
    needVScrollbar = true;
    if(spaceWidth - scrollbarSize < imgWidth)
      needHScrollbar = true;
  }
  
  if(needVScrollbar && needHScrollbar)
    return SCROLLBARS_BOTH;
  else if(needVScrollbar)
    return SCROLLBARS_VERTICAL;
  else if(needHScrollbar)
    return SCROLLBARS_HORIZONTAL;
  else
    return SCROLLBARS_NONE;
}


void DisplayWindow::updateScrollbars(Size wndSize)
{
  int imgWidth = shownImageWidth;
  int imgHeight = shownImageHeight;
  int newPanelWidth = wndSize.w;
  int newPanelHeight = wndSize.h - menuHeight;
  int newVVal = vScrollbar->value();
  int newHVal = hScrollbar->value();
  
  switch(checkForScrollbars(wndSize))
  {
  case SCROLLBARS_BOTH:
    newPanelWidth -= scrollbarSize;
    newPanelHeight -= scrollbarSize;

    vScrollbar->resize(newPanelWidth, menuHeight, scrollbarSize, newPanelHeight);
    if(newVVal + newPanelHeight > imgHeight)
      newVVal = imgHeight - newPanelHeight;
    vScrollbar->show();

    hScrollbar->resize(0, wndSize.h-scrollbarSize, newPanelWidth, scrollbarSize);
    if(newHVal + newPanelWidth > imgWidth)
      newHVal = imgWidth - newPanelWidth;
    hScrollbar->show();
    break;
    
  case SCROLLBARS_VERTICAL:
    newPanelWidth -= scrollbarSize;

    vScrollbar->resize(newPanelWidth, menuHeight, scrollbarSize, newPanelHeight);
    if(newVVal + newPanelHeight > imgHeight)
      newVVal = imgHeight - newPanelHeight;
    vScrollbar->show();

    newHVal = 0;
    hScrollbar->hide();
    break;
    
  case SCROLLBARS_HORIZONTAL:
    newPanelHeight -= scrollbarSize;

    newVVal = 0;
    vScrollbar->hide();

    hScrollbar->resize(0, wndSize.h-scrollbarSize, newPanelWidth, scrollbarSize);
    if(newHVal + newPanelWidth > imgWidth)
      newHVal = imgWidth - newPanelWidth;
    hScrollbar->show();
    break;
    
  case SCROLLBARS_NONE:
    newVVal = 0;
    vScrollbar->hide();

    newHVal = 0;
    hScrollbar->hide();
    break;
  }

  vScrollbar->value(newVVal, newPanelHeight, 0, imgHeight);
  hScrollbar->value(newHVal, newPanelWidth, 0, imgWidth);
  panel->size(newPanelWidth, newPanelHeight);
}


void DisplayWindow::resize(Rect size)
{
  Fl_Double_Window::resize(size.x, size.y, size.w, size.h);

  updateScrollbars(size);
}


void DisplayWindow::showImage(boost::shared_ptr<Image8U const> image)
{
  shownImageWidth = image->width();
  shownImageHeight = image->height();

  updateScrollbars(Size(w(),h()));
  panel->showImage(image);
}

void DisplayWindow::histogramCB(DisplayWindow* wnd)
{
  wnd->histogram->show();
}


void DisplayWindow::captureImageCB(DisplayWindow* wnd)
{
  wnd->panel->captureImage();
}


void DisplayWindow::cbFunction(Fl_Widget* widget, void* data)
{
  assert(data);
  void (*func)(DisplayWindow*) = (void (*)(DisplayWindow*))data;
  DisplayWindow* wnd = dynamic_cast<DisplayWindow*>(widget->parent());
  if(wnd != NULL)
    func(wnd);
}

#endif // HAVE_LIBFLTK

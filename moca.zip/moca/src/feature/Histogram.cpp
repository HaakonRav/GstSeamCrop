#include "feature/Histogram.h"
#include <cassert>


Histogram::Histogram(double minVal, double maxVal, indexType binCount)
  : bins(binCount, 0), minVal(minVal), maxVal(maxVal)
{
  assert(binCount > 0);
  assert(minVal < maxVal);
}

  
double& Histogram::bin(indexType index)
{
  assert(index < bins.size());
  return bins[index];
}

  
double const& Histogram::bin(indexType index) const
{
  assert(index < bins.size());
  return bins[index];
}

  
double& Histogram::bin(double value)
{
  return bins[valueToBin(value)];
}


double const& Histogram::bin(double value) const
{
  return bins[valueToBin(value)];
}


double Histogram::binLerp(double value) const
{
  indexType index = valueToBin(value);
  if (index == 0 || index == bins.size()-1)
    return bins[index];
  double binVal = binToValue(index); //!!! user LUT for optimization?
  indexType otherIndex = value >= binVal ? index+1 : index-1;
  double otherVal = binToValue(otherIndex);
  
  double fact = (value - binVal) / (otherVal - binVal);
  return (1-fact) * bins[index] + fact*bins[otherIndex];
}


double Histogram::binToValue(indexType bin) const
{
  assert(bin < bins.size());
  return (bin+0.5) / (double)bins.size() * (maxVal-minVal) + minVal;
}


indexType Histogram::valueToBin(double value) const
{
  //assert(value>=minVal && value<=maxVal);
  value = std::max(minVal, std::min(value ,maxVal));
  indexType const s = bins.size();
  indexType index = (indexType)((value-minVal) / (maxVal-minVal) * s);
  index = (index>=s) ? s-1 : index;
  return index;
}


void Histogram::smooth()
{
  indexType const s = bins.size();
  std::vector<double> smoothed(s);
  for (indexType i=0; i<s; ++i)
    smoothed[i] = 0.25*bins[(i+s-1)%s] + 0.5*bins[i] + 0.25*bins[(i+1)%s];
  smoothed.swap(bins);
}


double Histogram::findMaxPos() const
{
  double max = bins[0];
  indexType maxPos = 0;
  indexType const s = bins.size();
  for (indexType i=0; i<s; ++i)
    if (bins[i] > max)
      {
	max = bins[i];
	maxPos = i;
      }
  return binToValue(maxPos);
}


indexType Histogram::size() const
{
  return bins.size();
}


double Histogram::binSum() const
{
  double result = 0;
  for (uint32 i=0; i<bins.size(); ++i)
    result += bins[i];
  return result;
}


double Histogram::avg() const
{
  double result = 0;
  double sum = 0;
  for (uint32 i=0; i<bins.size(); ++i)
    {
      sum += bins[i];
      result += bins[i] * binToValue(i);
    }
  return result/sum;
}


void Histogram::clear()
{
  for (uint32 i=0; i<bins.size(); ++i)
    bins[i] = 0;
}

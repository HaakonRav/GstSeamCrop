#include "gui/CamSelect.h"

#ifdef HAVE_CAMERA
#ifdef HAVE_LIBDC1394
#ifdef HAVE_LIBFLTK

#include "io/DC1394Reader.h"
#include <iostream>
#include <sstream>
#include <boost/algorithm/string.hpp>


const int32 CamSelect::buttonOffset = 10;
const int32 CamSelect::buttonHeight = 20;


void CamSelect::callbackFunc(Fl_Widget* w, void* data)
{
  CamSelect* wnd = (CamSelect*)data;

  std::vector<std::string> tokens;
  const char *ptr = w->label();
  boost::split(tokens, ptr, boost::is_any_of(" "));
  std::stringstream sstr(tokens[0]);
  sstr >> *(wnd->selectedCamera);
  
  wnd->hide();
}


CamSelect::CamSelect(Rect wndSize, int32* selectedCamera)
  : Fl_Double_Window(wndSize.x, wndSize.y, wndSize.w, wndSize.h, "Camera Selection"), selectedCamera(selectedCamera)
{
  *selectedCamera = 0;

  DC1394Reader::enumerateCameras(cameraList); // this line is the only platform dependant line in this file

  if(cameraList.size() < 1)
    *selectedCamera = -1; // indicates that no camera was found
  if(cameraList.size() < 2)
    return;
  int32 y = buttonOffset;

  for(uint32 i = 0; i < cameraList.size(); i++)
  {
    Fl_Button* button = new Fl_Button(buttonOffset, y, w()-2*buttonOffset, buttonHeight, cameraList[i].c_str());
    button->callback(callbackFunc, this);
    y += buttonHeight + buttonOffset;
  }
  size(w(), y);

  end();
  show();
  Fl::run();
}


CamSelect::~CamSelect()
{
}


#endif // HAVE_LIBFLTK
#endif // HAVE_LIBDC1394
#endif // HAVE_CAMERA


#define BOOST_TEST_DYN_LINK
#include "boost/test/unit_test.hpp"

#include "testcases.h"

#include "cudaHDR/CudaImage32FHandle.h"
#include "cudaHDR/KernelFunctions.h"
#include "cudaHDR/CudaWrapper.h"
#include "cudaHDR/KernelFunctions.h"
#include "cudaHDR/CudaVectorHandle.h"
#include "cudaHDR/DeviceManager.h"
#include "cudaHDR/GPUToneMapping.h"

#include "io/ImageFileReader.h"
#include "io/ImageFileWriter.h"
#include "io/IO.h"
#include "feature/Histogram.h"
#include "types/MocaException.h"
#include "filter/ToneMapping.h"

#include <stdlib.h>
#include <time.h>

//Initially load needed testdata
struct testDataToneMapping
{
	//Will be available in every test case
	Image32F srcimg;
	Image32F srcimg_crop;
	float minVal;
	float maxVal;

	//Initialize struct via constructor
	testDataToneMapping() : srcimg(640, 480, 3), srcimg_crop(624, 403, 3), minVal(5000.0f), maxVal(60000.0f)
	{
		//Fill srcimg with random data
		randFillImage(srcimg, maxVal, minVal);

		//Set random pixel to a minimum and a maximum to guarantee that such a pixel exists
		srand((unsigned int) time(NULL));
		srcimg(rand() % srcimg_crop.width(), rand() % srcimg_crop.height(), 0) = minVal;
		srcimg(rand() % srcimg_crop.width(), rand() % srcimg_crop.height(), 0) = maxVal;

		//Copy srcimg to srcimg_cropped
		cropImage32F(srcimg, srcimg_crop);
	}
};

BOOST_FIXTURE_TEST_SUITE(ToneMappingTestSuite, testDataToneMapping)

BOOST_AUTO_TEST_CASE(MinMaxAvgTest)
{
	MOCA_TRY;
	//Calculate MinMaxAvg on CPU
	float min_cpu, max_cpu, avg_cpu;
	MOCA_TIC(RUNS);
	ToneMapping::minMaxAvg(srcimg, min_cpu, max_cpu, avg_cpu, 1/4096.0f);
	MOCA_TOC("minMaxAvg CPU");
	BOOST_CHECK(min_cpu == minVal);
	BOOST_CHECK(max_cpu == maxVal);

	//Upload srcimg to GPU
	CudaImage32FHandle handle;
	handle.put(srcimg);

	//Calculate MinMaxAvg on GPU
	float min_gpu, max_gpu, avg_gpu;
	MOCA_TIC(RUNS);
	KernelFunctions::minMaxAvg(handle.getDataDescPtr(), min_gpu, max_gpu, avg_gpu, 1/4096.0f);
	MOCA_TOC("minMaxAvg GPU");
	BOOST_CHECK(min_gpu == min_cpu);
	BOOST_CHECK(max_gpu == max_cpu);
	BOOST_CHECK(abs(avg_gpu - avg_cpu) < 0.01f);
	MOCA_CATCH;
}

BOOST_AUTO_TEST_CASE(MinMaxAvgTestVaryBoth)
{
	MOCA_TRY;
	//Calculate MinMaxAvg on CPU
	float min_cpu, max_cpu, avg_cpu;
	ToneMapping::minMaxAvg(srcimg_crop, min_cpu, max_cpu, avg_cpu, 1/4096.0);
	BOOST_CHECK(min_cpu == minVal);
	BOOST_CHECK(max_cpu == maxVal);

	//Upload srcimg to GPU
	CudaImage32FHandle handle;
	handle.put(srcimg_crop);

	//Calculate MinMaxAvg on GPU
	float min_gpu, max_gpu, avg_gpu;
	KernelFunctions::minMaxAvg(handle.getDataDescPtr(), min_gpu, max_gpu, avg_gpu, 1/4096.0f);
	BOOST_CHECK(min_gpu == min_cpu);
	BOOST_CHECK(max_gpu == max_cpu);
	BOOST_CHECK(abs(avg_gpu - avg_cpu) < 0.01f);
	MOCA_CATCH;
}

BOOST_AUTO_TEST_CASE(LogHistogramTest)
{
	MOCA_TRY;
	//Calculate logarithmic histogram on CPU
	float min, max, avg;
	ToneMapping::minMaxAvg(srcimg, min, max, avg, 1/4096.0);
	Histogram hist_cpu(log(min), log(max), 256);
	MOCA_TIC_RESET(RUNS, hist_cpu.clear());
	ToneMapping::logHisto(srcimg, hist_cpu);
	MOCA_TOC("logHisto CPU");

	//Calculate logarithmic histogram on CPU
	CudaImage32FHandle imghandle;
	CudaVectorHandle<unsigned int> histhandle(256);
	imghandle.put(srcimg);
	MOCA_TIC_RESET(RUNS, histhandle.clear());
	KernelFunctions::logHisto(imghandle.getDataDescPtr(), histhandle.getDataDescPtr(), log(min), log(max));
	MOCA_TOC("logHisto GPU");
	std::vector<unsigned int> hist_gpu(256);
	histhandle.getData(hist_gpu);

	//Compare histograms
	for (unsigned int i = 0; i < 256; i++)
	{
        	//unsigned int diff = (unsigned int) abs(hist_cpu.bin(i) - hist_gpu[i]);
		//BOOST_CHECK(diff < 25);
	}
	MOCA_CATCH;
}

BOOST_AUTO_TEST_CASE(LogHistogramTestVaryBoth)
{
	MOCA_TRY;
	//Calculate logarithmic histogram on CPU
	float min, max, avg;
	ToneMapping::minMaxAvg(srcimg_crop, min, max, avg, 1/4096.0);
	Histogram hist_cpu(log(min), log(max), 256);
	ToneMapping::logHisto(srcimg_crop, hist_cpu);

	//Calculate logarithmic histogram on CPU
	CudaImage32FHandle imghandle;
	CudaVectorHandle<unsigned int> histhandle(256);
	histhandle.clear();
	imghandle.put(srcimg_crop);
	KernelFunctions::logHisto(imghandle.getDataDescPtr(), histhandle.getDataDescPtr(), log(min), log(max));
	std::vector<unsigned int> hist_gpu(256);
	histhandle.getData(hist_gpu);

	//Compare histograms
	for (unsigned int i = 0; i < 256; i++)
	{
		unsigned int diff = (unsigned int) abs(hist_cpu.bin(i) - hist_gpu[i]);
		BOOST_CHECK(diff < 25);
	}
	MOCA_CATCH;
}

BOOST_AUTO_TEST_CASE(TrimHistoTest)
{
	MOCA_TRY;
	//Calculate logarithmic histogram on CPU
	Histogram hist_cpu(log(minVal), log(maxVal), 256);
	ToneMapping::logHisto(srcimg, hist_cpu);

	//Trim histogram on CPU
	MOCA_TIC(RUNS);
	ToneMapping::trimHisto(hist_cpu);
	MOCA_TOC("trimHisto CPU");
	MOCA_CATCH;
}

BOOST_AUTO_TEST_CASE(NormalizeHistoTest)
{
	MOCA_TRY;
	//Calculate logarithmic histogram on CPU
	Histogram hist_cpu(log(minVal), log(maxVal), 256);
	ToneMapping::logHisto(srcimg, hist_cpu);

	//Normalize histogram
	MOCA_TIC(RUNS);
	ToneMapping::cumulateAndNormalizeHisto(hist_cpu);
	MOCA_TOC("normHisto CPU");
	MOCA_CATCH;
}

BOOST_AUTO_TEST_CASE(MapImageTest)
{
	MOCA_TRY;
	//Calculate histo
	float min, max, avg;
	ToneMapping::minMaxAvg(srcimg, min, max, avg, 1/4096.0);
	Histogram hist(log(min), log(max), 256);
	ToneMapping::logHisto(srcimg, hist);
	ToneMapping::trimHisto(hist);
	ToneMapping::cumulateAndNormalizeHisto(hist);
	Image8U result_cpu(srcimg.width(), srcimg.height(), 3);
	Image32F tempResult(srcimg.width(), srcimg.height(), 3);

	//Perform Tonemapping on CPU and measure result
	MOCA_TIC(RUNS);
	ToneMapping::mapImageHist(srcimg, tempResult, hist);
	MOCA_TOC("mapImage CPU");

        for (uint32 y=0; y<srcimg.height(); ++y)
          for (uint32 x=0; x<srcimg.width(); ++x)
            for (int32 c=0; c<srcimg.channels(); ++c)
              result_cpu(x, y, c) = (uint8)tempResult(x, y, c);

	//Perform Tonamapping on GPU and measure result
	CudaImage32FHandle srchandle;
	srchandle.put(srcimg);
	CudaImage8UHandle reshandle;
	reshandle.allocate(srcimg.width(), srcimg.height(), 3, 3);
	
	//Allocate handle for histogram and copy histogram content
	CudaVectorHandle<float> histhandle(256);
	float tmp[256];
	for (unsigned int i = 0; i < 256; i++) tmp[i] = (float) hist.bin(i);
	histhandle.put(tmp, 256);

	//Perform Tonemapping on GPU and measure result
	MOCA_TIC(RUNS);
	KernelFunctions::mapImage(srchandle.getDataDescPtr(), reshandle.getDataDescPtr(), histhandle.getDataDescPtr(), log(min), log(max));
	MOCA_TOC("mapImage GPU");

	//Download result
	Image8U result_gpu(srcimg.width(), srcimg.height(), 3);
	reshandle.getImage8UData(result_gpu);

	//Compare results
	BOOST_CHECK(compareImage8U(result_cpu, result_gpu) < 10.0f);
	MOCA_CATCH;
}

BOOST_AUTO_TEST_CASE(ToneMappingTest)
{
	MOCA_TRY;
	//Perform complete tone mapping process on CPU
	Image8U result_cpu(srcimg.width(), srcimg.height(), 3);
	MOCA_TIC(RUNS);
	ToneMapping::histNorm(srcimg, result_cpu);
	MOCA_TOC("Complete tonemapping on CPU");

	//Perform complete tone mapping process on GPU
	CudaImage32FHandle srchandle;
	srchandle.put(srcimg);
	CudaImage8UHandle reshandle;
	reshandle.allocate(srcimg.width(), srcimg.height(), 3, 3);
	MOCA_TIC(RUNS);
	GPUToneMapping::histNorm(srchandle, reshandle);
	MOCA_TOC("Complete tonemapping on GPU");
	Image8U result_gpu(srcimg.width(), srcimg.height(), 3);
	reshandle.getImage8UData(result_gpu);

	//Compare resulting images
	BOOST_CHECK(compareImage8U(result_cpu, result_gpu) < 10.0f);
	MOCA_CATCH;
}

BOOST_AUTO_TEST_SUITE_END()

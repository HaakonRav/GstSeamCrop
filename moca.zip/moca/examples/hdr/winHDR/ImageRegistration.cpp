#include "ImageRegistration.h"

#include "FrameSource.h"
#include <boost/archive/text_oarchive.hpp>
#include <boost/archive/text_iarchive.hpp>
#include <boost/serialization/vector.hpp>
#include <fstream>

extern WinHDRStatus* status;
extern ImageRegistration* imgReg;


ImageRegistration::ImageRegistration()
  : histReg(64, 10.0)
{
}


void ImageRegistration::registerFrame(HDRFrame& frame)
{
  if (status->gTruthSwitch) // register according to ground truth
    for (uint32 i=0; i<frame.expSet.size(); ++i)
      frame.expSet[i].topLeft = frame.gTruth[i];
  else // register according to Semi algorithm
    registerImages(frame.expSet, &frame);
}


void ImageRegistration::switchGroundTruth()
{
  status->gTruthSwitch ^= true;
  std::cout << "Ground Truth Registration is " << (status->gTruthSwitch?"ON":"OFF") << std::endl;
}


void ImageRegistration::initFilter()
{
  histReg.initFilter();
}


void ImageRegistration::registerImages(std::vector<Exposure>& expSet, HDRFrame* frame)
{
#ifdef HAVE_CUDA
      CudaHDRFrame* cudaFrame = dynamic_cast<CudaHDRFrame*>(frame);
      assert(cudaFrame);
#endif

  std::vector<VectorI> regTL(expSet.size(), Vector2D::create(0, 0)); // registration results
  for (uint32 i=1; i<expSet.size(); ++i)
    {
      Exposure& exp = expSet[i];
      Exposure& parent = expSet[exp.parent];

      // ward image registration
      /*
        exp.topLeft -= regTL[exp.parent];
        ward.computeShift(*parent.image, *exp.image, 6, exp.topLeft);
        exp.topLeft += parent.topLeft;
      */

      // semi image registration
      VectorI offset(2); offset -= offset;
      Vector confidence(2);

#ifndef HAVE_CUDA
      histReg.computeShift(expSet[exp.parent], expSet[i], offset, confidence);
#else
      histReg.computeShift(cudaFrame->expHandles[exp.parent], cudaFrame->expHandles[i], offset, confidence);
#endif

      offset = histReg.filterOffset(offset, confidence);
      regTL[i] = offset + exp.topLeft + (regTL[exp.parent]-parent.topLeft);
    }

  // set the registration results
  for (uint32 i=1; i<expSet.size(); ++i)
    {
#ifndef HAVE_CUDA
      expSet[i].topLeft = regTL[i];
#else
      cudaFrame->expHandles[i].setOffsetX(regTL[i][0]);
      cudaFrame->expHandles[i].setOffsetY(regTL[i][1]);
#endif
    }
}


// ==================== GroundTruth ====================

GroundTruth::GroundTruth(boost::shared_ptr<ExposureLoader> loader)
  : loader(loader)
{
  gTruth.resize(loader->expSets.size());
  for (uint32 i=0; i<gTruth.size(); ++i)
    {
      uint32 size = loader->expSets[i].size();
      gTruth[i].resize(size);
      for (uint32 j=0; j<size; ++j)
        gTruth[i][j] = loader->expSets[i][j].topLeft;
    }
}


void GroundTruth::getGroundTruth(HDRFrame& frame)
{
  frame.gTruth.clear();
  frame.gTruth = gTruth[loader->currentSet];
}


void GroundTruth::load()
{
  gTruth.clear();
  std::string filename(loader->path);
  filename += "/gtruth.txt";
  std::ifstream fs(filename.c_str());
  boost::archive::text_iarchive archive(fs);
  archive >> gTruth;
}


void GroundTruth::save()
{
  std::string filename(loader->path);
  filename += "/gtruth.txt";
  std::ofstream fs(filename.c_str());
  boost::archive::text_oarchive archive(fs);
  archive << gTruth;
}


void GroundTruth::init()
{
  assert(gTruth.size() == loader->expSets.size());
  imgReg->initFilter();
  std::cout << "Registering " << gTruth.size() << " image sets." << std::endl;
  for (uint32 i=0; i<gTruth.size(); ++i)
    {
      std::cout << i << "  "; std::cout.flush();
      std::vector<Exposure> expSet(loader->expSets[i]);
      imgReg->registerImages(expSet);
      assert(gTruth[i].size() == expSet.size());
      for (uint32 j=0; j<expSet.size(); ++j)
        gTruth[i][j] = expSet[j].topLeft;
    }
}


void GroundTruth::moveGT(int dx, int dy)
{
  VectorI& vect = gTruth[loader->currentSet][loader->currentExp];
  vect[0] += dx;
  vect[1] += dy;
}


void GroundTruth::editGT(HDRFrame& frame)
{
  // only show base image and edit image
  Exposure selected = frame.expSet[loader->currentExp];
  selected.topLeft = gTruth[loader->currentSet][loader->currentExp];
  frame.expSet.resize(2);
  frame.expSet[1] = selected;
}

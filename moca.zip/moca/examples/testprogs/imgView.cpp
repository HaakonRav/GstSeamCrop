
#include "gui/ImageWindow.h"
#include "gui/GUIutils.h"
#include "tools/Drawing.h"
#include "types/MocaException.h"

#include <FL/fl_draw.h>

#include <iostream>


#ifdef HAVE_LIBFLTK


class TestWindow : public ImageWindow
{
public:
  TestWindow(Rect dim, std::string title, std::string fileName)
   : ImageWindow(dim, title, fileName)
  {
    image = reader->getImage();
  }

protected:
  void doStuff()
  {
    showImage(image);
  }
  
  void clickedPoint(VectorI p)
  {
    Color col(255);
    Drawing::drawCross(*image, p, 10, 1, col);
  }

  void clickedRect(Rect rect)
  {
    Color col(255);
    Drawing::drawRect(*image, rect, col);
  }
  
  void clickedLine(VectorI p1, VectorI p2)
  {
    Color col(255);
    Drawing::drawLine(*image, p1, p2, 1, col);
  }
};



int main(int argc, char** argv)
{
  if(argc<4)
  {
    std::cout << "usage: " << argv[0] << " filename window-width window-height" << std::endl;
    return 1;
  }


  try
  {
    TestWindow wnd( Rect(256, 256, atoi(argv[2]), atoi(argv[3])), std::string("Image Viewer: ")+std::string(argv[1]), argv[1]);
    wnd.mainLoop();
  }
  catch(MocaException& e)
  {
    std::cerr << diagnostic_information(e);
  }

  return 0;
}


#else // HAVE_LIBFLTK


int main(int argc, char** argv)
{
  std::cout << "this example requires FLTK." << std::endl;
  return 0;
}

#endif // HAVE_LIBFLTK





#include "types/MocaTypes.h"
#include "types/Image8U.h"
#include "types/Image32F.h"
#include "types/Exposure.h"
#include "types/Vector.h"
#include "types/MocaException.h"
#include "io/IO.h"
#include "io/ImageFileWriter.h"
#include "io/HDRExposureIO.h"
#include "filter/Filter.h"
#include "filter/CvtColorSpace.h"
#include "filter/HDRStitching.h"
#include "filter/ToneMapping.h"
#include "feature/WardImageReg.h"
#include "tools/Timing.h"
#include <fstream>
#include <boost/archive/text_iarchive.hpp>
#include <boost/serialization/vector.hpp>


int extraTM = 0;
int flickerRepaired = 0;
double m = 50.0;


class ExposureSetHandler
{
public:
  ExposureSetHandler(std::vector<Exposure>& expSet, std::vector<VectorI>& gTruth, std::string const& tmOp)
    : expSet(expSet), gTruth(gTruth), tmOp(tmOp)
  {
    color = expSet[0].image->channels() == 3;
  }
  
  void process(Image32F& hdrImage, Image8U& ldrImage, double& avg_lum_pred)
  {
    for (uint32 i = 0; i < expSet.size(); i++)
    {
      Exposure& e = expSet[i];
      CvtColorSpace::convert(*e.image, *e.image, COLOR_BGR, COLOR_Yxy);
    }
      
    imageRegistrationGroundTruth();
    HDRStitching::weighted(expSet, hdrImage);
    toneMapping(hdrImage, ldrImage, avg_lum_pred);
  }

private:
  void imageRegistrationGroundTruth()
  {
    for(uint32 i = 0; i < expSet.size(); i++)
      expSet[i].topLeft = gTruth[i];
  }

  double geometricAvg(Image8U const& image)
  {
    uint32 w = image.width(), h = image.height();
    double epsilon = 0.00001;
    double result = 0;
    for (uint32 y = 0; y < h; ++y)
      for (uint32 x = 0; x < w; ++x)
        result += log(image(x, y, 0) + epsilon);
    result = exp(result / (double)(h * w));
    return result;
  }

  // tone-mapping
  void toneMapping(Image32F const& hdrImage, Image8U& result, double& prevAvg)
  {
    double stevensExp = 0.33;
    double stevens = 2.13255;
    double scale = 1.0;
    double scaleDiff = 0;
    double targetPerc = 0.5; // target area = [prev+thresh*%, prev+thresh]

    tmOperator(hdrImage, result, 255*scale);
    double avg = geometricAvg(result);
    std::cerr << avg << std::endl;

    if (prevAvg != 0)
      {
        double origAvg = avg;
        double stevensThresh = stevens * pow(prevAvg, stevensExp);
        
        if (avg > prevAvg+stevensThresh || avg < prevAvg-stevensThresh)
          {
            // Zielgebiet ist entweder [prev+thresh*%, prev+thresh] oder [prev-thresh, prev-thresh*%]
            double lowerThresh, upperThresh;
            if (origAvg > prevAvg)
              {
                lowerThresh = prevAvg + stevensThresh * targetPerc;
                upperThresh = prevAvg + stevensThresh;
              }
            else // origAvg <= prevAvg
              {
                lowerThresh = prevAvg - stevensThresh;
                upperThresh = prevAvg - stevensThresh * targetPerc;
              }
            double target = (lowerThresh + upperThresh) / 2;

            scaleDiff = (target - origAvg) / m;
            scaleDiff = scaleDiff < (1e-5 - 1) ? (1e-5 - 1) : scaleDiff;
            std::cout << "prevAvg: " << prevAvg << "  avg: " << origAvg;
            std::cout << "  thresholds: " << lowerThresh << ", " << upperThresh;
            std::cout << "  scaleDiff: " << scaleDiff << std::endl;

            while (avg < lowerThresh || avg > upperThresh)
              {
                ++extraTM;
                tmOperator(hdrImage, result, (scale+scaleDiff)*255);
                avg = geometricAvg(result);

                m = (avg - origAvg) / scaleDiff;
                scaleDiff = (target - origAvg) / m;

                std::cout << "avg: " << avg << "  m: " << m << "  scaleDiff: " << scaleDiff << std::endl;
              }
            ++flickerRepaired;
          }
      }

    prevAvg = avg;
  }

  void tmOperator(Image32F const& image, Image8U& result, float scale)
  {
    if (tmOp == "ward")
      ToneMapping::wardContrast(image, result, scale);
    else if (tmOp == "hist")
      ToneMapping::histNorm(image, result, scale);
    else if (tmOp == "photo")
      ToneMapping::photographic(image, result, scale);
    else
      assert(!"OPERATOR NOT FOUND!");
  }

  std::vector<Exposure>& expSet; // exposure set used as input
  std::vector<VectorI>& gTruth; // ground truth used as input when Ward's image registration algorithm shouldn't be used
  bool color; // true if the input exposures are color images instead of black-and-white
  std::string tmOp;
};


class HDRVideoHandler
{
public:
	
  // initialization (e.g. reading the input files)
  HDRVideoHandler(std::string const& inputPath, std::string const& outputPath, std::string const& tmOp)
    : avg_lum_pred(0), tmOp(tmOp)
  {
    // read input files
    std::cout << "reading input files..." << std::flush;
    readExposureSets(inputPath);
    readGroundTruth(inputPath);
    std::cout << " done (" << expSets.size() << " frame(s))" << std::endl;
    
    // prepare a writer object for writing the resulting images
    std::string realOutputPath(outputPath);
    IO::checkPath(realOutputPath);
    realOutputPath += "frame";
    imgWriter = boost::shared_ptr<ImageFileWriter>(new ImageFileWriter(realOutputPath, "png"));
  }
  
  // converts the entire input sequence
  void process()
  {
    std::cerr << "# frameNo origAvg correctedAvg" << std::endl;
    boost::shared_ptr<Image8U> firstImage = expSets[0][0].image;
    sizeType imgWidth = firstImage->width();
    sizeType imgHeight = firstImage->height();
    int32 imgChannels = firstImage->channels();
    
    Image32F hdrImage(imgWidth, imgHeight, imgChannels);
    Image8U ldrImage(imgWidth, imgHeight, imgChannels);

    for(uint32 i = 0; i < expSets.size(); i++)
    {
      if (i < 70 || i > 72)
        continue;
      std::cerr << i << " ";

      ExposureSetHandler expSetHandler(expSets[i], gTruth[i], tmOp);
      expSetHandler.process(hdrImage, ldrImage, avg_lum_pred);
      
      imgWriter->putImage(ldrImage);
      // write duplicate frames for video processing
      /*
      if (i < expSets.size()-1)
        {
          double timeDiff = expSets[i+1][0].image->getTimestamp();
          timeDiff -= expSets[i][0].image->getTimestamp();
          int numFrames = (int)(timeDiff / (1000/15.0));
          for (int j=0; j<numFrames; ++j)
            imgWriter->putImage(ldrImage);
        }
      else
        imgWriter->putImage(ldrImage);
      */
    }
    std::cerr << "# " << extraTM << " extra TM operations" << std::endl;
    std::cerr << "# " << flickerRepaired << " flickering frames repaired." << std::endl;
  }
  
private:
  void readExposureSets(std::string const& inputPath)
  {
    boost::shared_ptr<HDRExposureIO> reader = HDRExposureIO::createReader(inputPath);

    expSets.resize(reader->getNumExposures());
    gTruth.resize(reader->getNumExposures());

    for(uint32 i = 0; i < expSets.size(); i++)
    {
      reader->getNext(expSets[i]);
      uint32 size = expSets[i].size();
      gTruth[i].resize(size);
      for(uint32 j = 0; j < size; j++)
        gTruth[i][j] = expSets[i][j].topLeft;
    }
    reader->close();
    
    assert(expSets.size() > 0 && expSets[0].size() > 0);
  }
  
  void readGroundTruth(std::string const& inputPath)
  {
    std::string filename(inputPath);
    IO::checkPath(filename);
    filename += "gtruth.txt";
    std::ifstream fs(filename.c_str());
    if(fs.good())
    {
      boost::archive::text_iarchive archive(fs);
      archive >> gTruth;
    }
  }
  
  std::vector<std::vector<Exposure> > expSets; // stores the sequences of exposure sets
  std::vector<std::vector<VectorI> > gTruth; // stores the corresponding ground truth values
  boost::shared_ptr<ImageFileWriter> imgWriter; // used for writing the resulting images to the hard disk
  double avg_lum_pred;
  std::string tmOp;
};


int main(int argc, char** argv)
{
  if(argc < 4)
  {
    std::cout << "please supply input path, output path and tonemapper as parameters." << std::endl;
    std::cout << "example: " << argv[0] << " myExposures/sequence1 myVideos/result1 ward" << std::endl;
    return 0;
  }

  try
  {
    HDRVideoHandler hdr(argv[1], argv[2], argv[3]);
    hdr.process();
  }
  catch(MocaException& e)
  {
    std::cerr << diagnostic_information(e);
  }

  return 0;
}

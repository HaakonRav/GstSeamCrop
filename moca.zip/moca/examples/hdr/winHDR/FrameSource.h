#ifndef WINHDR_FRAME_SOURCE_H
#define WINHDR_FRAME_SOURCE_H

#include "Logic.h"
#include <boost/shared_ptr.hpp>

class HDR;
class CameraReader;

enum CaptureMode {TRIGGERED, SEQUENCE, OPTSHUTTER};


class FrameSource
{
public:
  virtual void getFrame(HDRFrame& frame) = 0;
  virtual boost::shared_ptr<HDRFrame> createFrame() = 0;
};


class HDRCamera : public FrameSource
{
public:
  HDRCamera(CaptureMode mode);

  void getFrame(HDRFrame& frame);
  boost::shared_ptr<HDRFrame> createFrame();
  void estimateNextShutter(HDRFrame& frame);

private:
  boost::shared_ptr<CameraReader> reader;
  boost::shared_ptr<HDR> hdr;
  uint32 imgWidth, imgHeight;
  uint32 minShutter, maxShutter;
  CaptureMode mode;
};


class ExposureLoader : public FrameSource
{
public:
  ExposureLoader(std::string path);

  void getFrame(HDRFrame& frame);
  boost::shared_ptr<HDRFrame> createFrame();
  void nextSet();
  void prevSet();
  void nextExp();
  void prevExp();
  
private:
  friend class GroundTruth;

  std::string path;
  std::vector<std::vector<Exposure> > expSets;
  uint32 currentSet, currentExp;
};


#endif

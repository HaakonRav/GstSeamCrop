#include "types/MocaTypes.h"
#include <iostream>

#ifdef HAVE_CAMERA

#include "io/DC1394Reader_Triggered.h"
#include "tools/Timing.h"
#include "types/MocaException.h"


class ROITest
{
public:
  ROITest()
  {
    reader = boost::shared_ptr<DC1394Reader_Triggered>(
               new DC1394Reader_Triggered(CameraReader::SPEED_400, CameraReader::MODE_RAW8));
    reader->start();
    image = boost::shared_ptr<Image8U>(new Image8U(640, 480, 1));
  }

  ~ROITest()
  {
    reader->stop();
  }

  void runTest(Rect startRoi, Rect increment, Rect stop, std::string const& caption, unsigned int avgCount, unsigned int shutter)
  {
    assert(increment.x != 0 || increment.y != 0 || increment.w != 0 || increment.h != 0);

    std::cerr << "#_____________________________" << caption << "______________________________\n";
    std::cerr << "#x\t y\t w\t h\t shutter\t captureImage\t getImage\n";

    image = boost::shared_ptr<Image8U>(new Image8U(startRoi.w, startRoi.h, 1));
    
    while (lessThan(startRoi, stop))
      {
	if (increment.w != 0 || increment.h != 0)
	  image = boost::shared_ptr<Image8U>(new Image8U(startRoi.w, startRoi.h, 1));
	  
	for (unsigned int i=0; i<avgCount; ++i)
	  {
	    Timing::start(1);
	    reader->captureImage(startRoi, shutter);
	    Timing::stop(1);
	    Timing::start(2);
	    reader->getImage(*image);
	    Timing::stop(2);
	  }
    std::cout << "Rate: " << reader->getFeatureValue(CameraFeature::FEATURE_FrameRate) << std::endl;
	std::cerr << startRoi.x << "\t" << startRoi.y << "\t" << startRoi.w << "\t" << startRoi.h << "\t" << shutter;
	std::cerr << "\t" << Timing::avg(1) << "\t" << Timing::avg(2) << std::endl;
	Timing::reset(1);
	Timing::reset(2);
	addStep(startRoi, increment);
      }
  }

  void shutterTest(Rect roi, int startShutter, int increment, int stop, unsigned int avgCount)
  {
    assert((stop-startShutter)*increment > 0); // make sure the loop terminates

    std::cerr << "#_____________________________shutter speeds______________________________\n";
    std::cerr << "#x\t y\t w\t h\t size\t shutter\t captureImage\t getImage\n";

    image = boost::shared_ptr<Image8U>(new Image8U(roi.w, roi.h, 1));
    
    while ((stop-startShutter)*increment > 0)
      {
	for (unsigned int i=0; i<avgCount; ++i)
	  {
	    Timing::start(1);
	    reader->captureImage(roi, (uint32)startShutter);
	    Timing::stop(1);
	    Timing::start(2);
	    reader->getImage(*image);
	    Timing::stop(2);
            usleep(1000*14);
	  }
	std::cerr << roi.x << "\t" << roi.y << "\t" << roi.w << "\t" << roi.h << "\t" << roi.w*roi.h << "\t";
	std::cerr << startShutter << "\t" << Timing::avg(1) << "\t" << Timing::avg(2) << std::endl;
	Timing::reset(1);
	Timing::reset(2);
	startShutter += increment;
      }
  }

private:
  void addStep(Rect& rect, Rect const& increment)
  {
    rect.x += increment.x;
    rect.y += increment.y;
    rect.w += increment.w;
    rect.h += increment.h;
  }

  bool lessThan(Rect const& rect, Rect const& stop)
  {
    return (rect.x <= stop.x && rect.y <= stop.y && rect.w <= stop.w && rect.h <= stop.h);
  }

  boost::shared_ptr<DC1394Reader_Triggered> reader;
  boost::shared_ptr<Image8U> image;
};

int main(int argc, char** argv)
{
  try
    {
      ROITest t;
      t.runTest(Rect(0, 0, 24, 480), Rect(0, 0, 8, 0), Rect(0, 0, 640, 480), "ROI height", 10, 67);
      //t.shutterTest(Rect(0, 0, 640, 480), 1600, 100, 4000, 5);
    }
  catch(MocaException& e)
    {
      std::cerr << diagnostic_information(e);
    }
  return 0;
}

#else

int main(int argc, char** argv)
{
  std::cout << "This program requires camera support." << std::endl;
  return 0;
}

#endif //HAVE_CAMERA

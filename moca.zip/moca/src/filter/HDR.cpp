#include "filter/HDR.h"

#include <deque>

#include "feature/Histogram.h"
#include "filter/CvtColorSpace.h"
#include "filter/Filter.h"
#include "io/CameraReader.h"
#include "io/DC1394Reader_Triggered.h"
#include "tools/Timing.h"
#include "types/Exposure.h"
#include "types/Image32F.h"
#include "types/Image8U.h"
#include "types/MocaException.h"

#ifndef HAVE_LIBDC1394
// these definitions are necessary to avoid problems during compilation if only non-libdc1394-based cameras are available
struct DC1394ReaderParameters
{
  Rect roi;
  uint32 shutter;
  float gain;
};

class DC1394Reader_Triggered
{
public:
  void captureImages(std::vector<DC1394ReaderParameters> const& params)
  {
  }
  
  DC1394ReaderParameters getImageParams()
  {
    DC1394ReaderParameters params; 
    return params;
  }

  void getImage(Image8U& img)
  {
  }
};
#endif


/*
List of timers used throughout the library:
0) unused
1) total time of the HDR capturing and analyzation
2) time for capturing the images
3) computation time for image analysis
4) HDR stitching
 */


HDR::HDR(boost::shared_ptr<CameraReader> reader, uint32 darkest, uint32 brightest, double minInvalidPerLine)
  : reader(reader), darkest(darkest), brightest(brightest),
    minInvalidPerLine(minInvalidPerLine)
{
  reader->getUnitSize(unitSizeX, unitSizeY);
  reader->getUnitPos(unitPosX, unitPosY);

  uint32 imgWidth, imgHeight;
  reader->getMaxImageSize(imgWidth, imgHeight);
  roi = Rect(0, 0, imgWidth, imgHeight);
  
  CameraFeaturePtr shut = reader->getFeature(CameraFeature::FEATURE_Shutter);
  minShutter = shut->getMin();
  maxShutter = shut->getMax();

  CameraFeaturePtr gain = reader->getFeature(CameraFeature::FEATURE_Gain);
  float minGain = std::max<float>(gain->getAbsMin(), 0); // disallow negative gain for our purposes
  float maxGain = gain->getAbsMax();
  // transform gain settings into amplification factors: gain = 20*log_10(factor)
  maxGainFact = pow(10, maxGain/20);
  minGainFact = pow(10, minGain/20); // >= 1
}


void HDR::captureFullHDR(std::vector<Exposure>& exposures)
{
  Timing::reset(1); Timing::reset(2); Timing::reset(3);
  Timing::start(1);
  Timing::start(2);
  for (indexType i=0; i<exposures.size(); ++i)
    {
      Exposure& e = exposures[i];
      Rect roi(e.topLeft[0], e.topLeft[1], e.image->width(), e.image->height());
      reader->captureImage(roi, (uint32)e.shutter);
      reader->getImage(*e.image);
    }
  Timing::stop(2);
  Timing::stop(1);
}


void HDR::captureHDR(std::vector<Exposure>& exposures)
{
  if(exposures.size() == 0) // bootstrap if no exposures are given
    exposures.push_back(Exposure(boost::shared_ptr<Image8U>(new Image8U(roi.w, roi.h, 1)),
                                 Vector2D::create(0, 0), 256, Exposure::TOO_BOTH, 0));

  Timing::reset(1); Timing::reset(2); Timing::reset(3);
  Timing::start(1);
  Timing::start(2);
  std::queue<Exposure> toCapture;
  std::queue<uint32> toAnalyze; // index into the "exposures" vector
  uint32 shutter; // temporary values used later
  float gain;
  exposures.resize(1); // clear the result vector just in case

  // capture and examine the base image individually
  Exposure& baseExposure = exposures[0];
  baseExposure.direction = Exposure::TOO_BOTH;
  baseExposure.topLeft = Vector2D::create(0, 0);
  exposureToShutGain(baseExposure.shutter, shutter, gain);
  reader->captureImage(roi, shutter, gain);
  reader->getImage(*baseExposure.image);
  Timing::stop(2);
  Timing::start(3);
  std::vector<Rect> darkRois, brightRois;
  nextExposureRoi(*baseExposure.image, baseExposure.direction, darkRois, brightRois);
  enqueueExposures(baseExposure, Exposure::TOO_BRIGHT, brightRois, toCapture, 0);
  enqueueExposures(baseExposure, Exposure::TOO_DARK, darkRois, toCapture, 0);
  Timing::stop(3);

  while (!toCapture.empty() || !toAnalyze.empty())
    {
      bool capture = !toCapture.empty();
      // start capturing the next image if there's something in the queue
      if (capture)
	{
	  Timing::start(2);
	  Exposure& capt = toCapture.front();
          exposureToShutGain(capt.shutter, shutter, gain);
	  reader->captureImage(Rect(capt.topLeft[0], capt.topLeft[1], capt.image->width(), capt.image->height()), shutter, gain);
	}

      // examine a captured image in the queue and determine the next regions to capture
      if (!toAnalyze.empty())
	{
	  if (!capture)
	    Timing::start(3);
	  Exposure& ana = exposures[toAnalyze.front()];
	  std::vector<Rect> rois;
	  nextExposureRoi(*(ana.image), ana.direction, rois);
	  enqueueExposures(ana, ana.direction, rois, toCapture, toAnalyze.front());
	  toAnalyze.pop();
	  if (!capture)
	    Timing::stop(3);
	}

      // receive the captured image
      if (capture)
	{
	  Exposure& capt = toCapture.front();
	  reader->getImage(*(capt.image));
	  //std::cout << "It took: " << Timing::stop(2) << "ms" << std::endl;
	  exposures.push_back(capt); // store the resulting exposure
	  toAnalyze.push(exposures.size()-1);
	  toCapture.pop();
	  Timing::stop(2);
	}
    }
  Timing::stop(1);
}


void HDR::enqueueExposures(Exposure const& currExposure, Exposure::CheckedInvalids direction, std::vector<Rect> const& rois, std::queue<Exposure>& exposures, uint32 parent)
{
  if(direction == Exposure::TOO_BOTH)
    BOOST_THROW_EXCEPTION(ArgumentException("HDR::enqueueExposures(): direction equals TOO_BOTH"));
  float nextShutter = (direction == Exposure::TOO_DARK) ? currExposure.shutter*2 : currExposure.shutter/2;
  if (nextShutter > maxShutter*maxGainFact || nextShutter < minShutter*minGainFact)
    return;
    
  for (indexType i=0; i<rois.size(); ++i)
    {
      uint32 xpos = rois[i].x + currExposure.topLeft[0];
      uint32 ypos = rois[i].y + currExposure.topLeft[1];
      //std::cout << "next area: (" << xpos << ", " << ypos << ", " << rois[i].w << ", " << rois[i].h << ")  ";
      //std::cout << "shutter: " << nextShutter << std::endl;
      boost::shared_ptr<Image8U> img(new Image8U(rois[i].w, rois[i].h, 1));
      Exposure next(img, Vector2D::create((int32)xpos, (int32)ypos), nextShutter, direction, parent);
      exposures.push(next);
    }
}


void HDR::nextExposureRoi(Image8U const& image, Exposure::CheckedInvalids direction,
			  std::vector<Rect>& darkRois, std::vector<Rect>& brightRois, uint32& tooDark, uint32& tooBright)
{
  uint32 const minimumHeight = 160/unitSizeY*unitSizeY; // minimum height of a ROI (making sure this is divisible by the unit size!)
  uint32 const minAreaDistance = 495; // minimum distance of two ROIs to be merged
  uint32 const imageHeight = image.height();

  if(image.height() < minimumHeight)
    BOOST_THROW_EXCEPTION(ArgumentException("HDR::nextExposureRoi(): the image height is too small"));
    
  std::vector<uint32> tooDarkPerLine, tooBrightPerLine;
  countInvalidPixels(image, tooDarkPerLine, tooBrightPerLine, tooDark, tooBright);

  indexType repetitions = direction==Exposure::TOO_BOTH ? 2 : 1;
  for (indexType cycle=0; cycle<repetitions; ++cycle)
    {
      // swap in the invalid pixels under consideration
      std::vector<uint32> invalid;
      if (direction==Exposure::TOO_BRIGHT || (direction==Exposure::TOO_BOTH && cycle==0))
	invalid.swap(tooBrightPerLine);
      else
	invalid.swap(tooDarkPerLine);

      Image32F lineImage(1, imageHeight, 1);

      for (uint32 y=0; y<imageHeight; ++y)
		lineImage(0, y) = (float)invalid[y];
    
      Filter::dilate(lineImage, lineImage, minimumHeight/2);
      Filter::erode(lineImage, lineImage, minimumHeight/2);
    
      // find regions of lines that contain more than [minInvalidPerLine] invalid pixels
      typedef std::pair<int32, int32> Region;
      std::vector<Region> regions;
      for (uint32 i=0; i<imageHeight; ++i)
	if (lineImage(0, i) >= (float)minInvalidPerLine)
	  {
	    uint32 j = i+1;
	    while (j<imageHeight && lineImage(0, j) >= (float)minInvalidPerLine)
	      ++j;
	    regions.push_back(Region((int32)i, (int32)j));
	    i = j+1;
	  }

      // widen regions so they're at least [minimumHeight] pixels high
      std::vector<double> lineSum(imageHeight);
      lineSum[0] = lineImage(0, 0); // these are defined according to an assertion in the beginning
      for (uint32 i=1; i<imageHeight; ++i)
	lineSum[i] = lineSum[i-1] + lineImage(0, i);
      for (uint32 i=0; i<regions.size(); ++i)
	{
	  Region& reg = regions[i];
	  if (reg.second - reg.first >= (int)minimumHeight)
	    continue;
	
	  // find a region of size [minimumHeight] that includes regions[i] and covers the most invalid pixels
	  double mostPixels = -1;
	  int32 start = reg.first;
	  int32 stretch = minimumHeight - (reg.second - reg.first);
	  for (int32 j=reg.first-stretch; j<=reg.first; ++j) // there's [stretch+1] possible placements of the region
	    {
	      if (j < 0 || j+minimumHeight > image.height())
		continue;
	      
	      double lineSumJ = j>0 ? lineSum[j-1] : 0;
	      double pixels = lineSum[j+minimumHeight-1] - lineSumJ;
	      if (pixels > mostPixels)
		{
		  mostPixels = pixels;
		  start = j;
		}
	    }
	  reg.first = start;
	  reg.second = start+minimumHeight;
	}

      // merge regions that are less than [minAreaDistance] apart.
      std::vector<Rect> rois;
      rois.reserve(regions.size());
      for (indexType i=0; i<regions.size(); ++i)
	{
	  Region& region = regions[i];
	  for (indexType j=i+1; j<regions.size() && region.second+(int32)minAreaDistance>regions[j].first; ++j)
	    {
	      region.second = regions[j].second;
	      i=j;
	    }

	  int32 startRow = region.first/unitPosY*unitPosY; // truncate the position to the unit supported by the camera
	  int32 rowHeight = (region.second-startRow)/unitSizeY*unitSizeY;
	  rois.push_back(Rect(0, startRow, image.width(), rowHeight));
	}

      // swap the detected regions into the correct output vector
      if (direction==Exposure::TOO_BRIGHT || (direction==Exposure::TOO_BOTH && cycle==0))
	rois.swap(brightRois);
      else
	rois.swap(darkRois);
    }

  // DEBUG: draw invalid pixels and found regions
  /*for (unsigned int y=0; y<lineImage.height(); ++y)
    for (unsigned int x=0; x<(unsigned int)lineImage.pixel32F(0, y); ++x)
    image.pixel8U(x, y) = 255;*/
  /*for (unsigned int i=0; i<rois.size(); ++i)
    for (unsigned int x=0; x<image.width(); ++x)
    {
    image.pixel8U(x, rois[i].y) = 0;
    image.pixel8U(x, rois[i].y+rois[i].h-1) = 0;
    }*/
}


void HDR::nextExposureRoi(Image8U const& image, Exposure::CheckedInvalids direction, std::vector<Rect>& darkRois, std::vector<Rect>& brightRois)
{
  uint32 dummy1, dummy2;
  nextExposureRoi(image, direction, darkRois, brightRois, dummy1, dummy2);
}


void HDR::nextExposureRoi(Image8U const& image, Exposure::CheckedInvalids direction, std::vector<Rect>& rois)
{
  if(direction == Exposure::TOO_BOTH)
    BOOST_THROW_EXCEPTION(ArgumentException("HDR::nextExposureRoi(): direction equals TOO_BOTH"));
  std::vector<Rect> dummy;
  if (direction == Exposure::TOO_DARK)
    nextExposureRoi(image, direction, rois, dummy);
  else
    nextExposureRoi(image, direction, dummy, rois);
}

void HDR::nextExposureRoi(Image8U const& image, Exposure::CheckedInvalids direction, std::vector<Rect>& rois, uint32& tooDark, uint32& tooBright)
{
  if(direction == Exposure::TOO_BOTH)
    BOOST_THROW_EXCEPTION(ArgumentException("HDR::nextExposureRoi(): direction equals TOO_BOTH"));
  std::vector<Rect> dummy;
  if (direction == Exposure::TOO_DARK)
    nextExposureRoi(image, direction, rois, dummy, tooDark,  tooBright);
  else
    nextExposureRoi(image, direction, dummy, rois, tooDark,  tooBright);
}



void HDR::countInvalidPixels(Image8U const& image, std::vector<uint32>& tooDarkPerLine, std::vector<uint32>& tooBrightPerLine,
			     uint32& tooDark, uint32& tooBright)
{
  tooDarkPerLine.resize(image.height());
  tooBrightPerLine.resize(image.height());
  tooDark = tooBright = 0;

  uint32 const w = image.width();
  uint32 const h = image.height();

  for (uint32 y=0; y<h; ++y)
    {
      uint32& darkLine = tooDarkPerLine[y];
      uint32& brightLine = tooBrightPerLine[y];
      for (uint32 x=0; x<w; ++x)
	{
	  uint8 const& value = image(x, y);
	  if (value < darkest)
	    ++darkLine;
	  if (value > brightest)
	    ++brightLine;
	}
      tooDark += darkLine;
      tooBright += brightLine;
    }
}


void HDR::countInvalidPixels(Image8U const& image, uint32& tooDark, uint32& tooBright)
{
  std::vector<uint32> a, b;
  countInvalidPixels(image, a, b, tooDark, tooBright);
}


void HDR::countInvalidPixels(Image8U const& image,std::vector<uint32>& tooDarkPerLine, std::vector<uint32>& tooBrightPerLine)
{
  uint32 a, b;
  countInvalidPixels(image, tooDarkPerLine, tooBrightPerLine, a, b);
}


void HDR::colorThresholdImage(Image8U const& image, Image8U& imgCol, bool linewise)
{
  if (imgCol.channels() != 3)
    BOOST_THROW_EXCEPTION(ArgumentException("Wrong image formats") << ErrImg1(imgCol));
  if (image.width() != imgCol.width() || image.height() != imgCol.height())
    BOOST_THROW_EXCEPTION(ArgumentException("Wrong image sizes") << ErrImg1(image) << ErrImg2(imgCol));
    
  // copy the entire image first
  for (uint32 y=0; y<image.height(); ++y)
    for (uint32 x=0; x<image.width(); ++x)
      {
	uint8 value = image(x, y);	
	imgCol(x, y, 0) = value;
	imgCol(x, y, 1) = value;
	imgCol(x, y, 2) = value;
      } 

  if (linewise)
    {
      std::vector<uint32> dark, bright;
      countInvalidPixels(image, dark, bright);

      if(dark.size() != image.height() || bright.size() != image.height())
        BOOST_THROW_EXCEPTION(RuntimeException("HDR::colorThresholdImage(): dark.size() and/or bright.size() doesn't match the image height"));

      for (uint32 y=0; y<image.height(); ++y)
	{
	  for (uint32 x=0; x<dark[y]; ++x)
	  {
	    // set pixel at (x,y) to red
	    imgCol(x, y, 0) = 0; imgCol(x, y, 1) = 0; imgCol(x, y, 2) = 255;
	  }
	  for (uint32 x=0; x<bright[y]; ++x)
	  {
	    // set pixel at (x,y) to green
	    imgCol(x, y, 0) = 0; imgCol(x, y, 1) = 255; imgCol(x, y, 2) = 0;
	  }
	}
    }
  else
    for (uint32 y=0; y<image.height(); ++y)
      for (uint32 x=0; x<image.width(); ++x)
        {
          uint8 val = image(x, y);
          if (val < darkest)
            {
              // set pixel at (x,y) to red
              imgCol(x, y, 0) = 0; imgCol(x, y, 1) = 0; imgCol(x, y, 2) = 255;
            }
          else if (val > brightest)
            {
              // set pixel at (x,y) to green
              imgCol(x, y, 0) = 0; imgCol(x, y, 1) = 255; imgCol(x, y, 2) = 0;
            }
        }
}

  
void HDR::virtualExposure(Image32F const& hdrImage, Image8U& ldrImage, uint32 shutter)
{
  if(hdrImage.channels() != 1)
    BOOST_THROW_EXCEPTION(ArgumentException("HDR::virtualExposure(): the HDR image has invalid parameters") << ErrImg1(hdrImage));
  if(ldrImage.channels() != 1)
    BOOST_THROW_EXCEPTION(ArgumentException("HDR::virtualExposure(): the 8-bit image has invalid parameters") << ErrImg1(ldrImage));
  if(hdrImage.width() != ldrImage.width() || hdrImage.height() != ldrImage.height())
    BOOST_THROW_EXCEPTION(ArgumentException("HDR::virtualExposure(): the image sizes do not match") << ErrImg1(hdrImage) << ErrImg2(ldrImage));
    
  for (uint32 y=0; y<hdrImage.height(); ++y)
    for (uint32 x=0; x<hdrImage.width(); ++x)
      {
	double value = hdrImage(x, y) * shutter;
	if (value > 300)
	  value = 300; // make sure values don't get higher than MAX_INT and wrap over. They get capped to 255 anyway.
	uint32 intVal = (uint32)(value + 0.5);
	intVal = intVal > 255 ? 255 : intVal;
	ldrImage(x, y) = (uint8)intVal;
      }
}


void HDR::exposureToShutGain(float totalExp, uint32& shutter, float& gain, bool shutFirst)
{
  if (totalExp > maxGainFact*maxShutter) // check if totalExp is out of bounds
    {
      shutter = maxShutter;
      gain = 20 * log10(maxGainFact);
      return;
    }
  if (totalExp < minGainFact*minShutter) // check other boundary
    {
      shutter = minShutter;
      gain = 20 * log10(minGainFact);
      return;
    }

  // now, we have: E <= g+ * s+  &&  E >= g- * s-
  if (shutFirst) {
    if (totalExp / minGainFact <= maxShutter) // try g = g-
      {
        shutter = (uint32)(totalExp / minGainFact + 0.5);
        // s = E / g-   <->   g- * s = E >= g- * s-   <->   s >= s-  OK
        // s <= s+  OK  (see previous if)
        gain = 20 * log10(minGainFact);
      }
    else {
      // E / g- > s+
      shutter = maxShutter;
      gain = 20 * log10(totalExp / shutter);
      // g = E / s+   <->   g * s+ = E <= g+ * s+   <->   g <= g+  OK
      // E / g- > s+   <->   g- < E / s+ = g  OK
    }
  } else { // gain first
    if (totalExp / minShutter <= maxGainFact) // try s = s- (very unlikely)
      {
        shutter = minShutter;
        gain = 20 * log10(totalExp/minShutter);
      }
    else {
      shutter = totalExp / maxGainFact;
      gain = 20 * log10(maxGainFact);
    }
  }
}

#include "feature/OptimalShutter.h"

#include "feature/Histogram.h"
#include "tools/Maths.h"
#include "types/Exposure.h"
#include "tools/Timing.h"


std::vector<double> OptimalShutter::findBestShutters(Histogram const& hist, uint32 numExps, double maxCoverage, double maxShutterSum)
{
  std::vector<double> weighting = createWeightMask(hist);
  return findBestShutters(hist, weighting, numExps, maxCoverage, maxShutterSum);
}


// the first parameter is a full set of exposures (e.g. 79 LDR exposures)
// second parameter is a list of shutter speeds
// returns an exposure set containing only the selected shutters
std::vector<Exposure> OptimalShutter::selectExposures(std::vector<Exposure> const& expSet,
                                                      std::vector<double> const& shutters)
{
  std::vector<Exposure> result;
  for (uint32 i=0; i<shutters.size(); ++i)
    {
      double shut = shutters[i];
      double minDiff = INFINITY;
      uint32 minIndex = 0;
      for (uint32 j=0; j<expSet.size(); ++j)
        {
          double diff = abs(expSet[j].shutter - shut);
          if (diff < minDiff)
            {
              minDiff = diff;
              minIndex = j;
            }
        }
      result.push_back(expSet[minIndex]);
    }
  return result;
}


// calculate shutter speed so that first bin has pixel value 1
// bin to which pixel value 255 gets mapped
// for each element of weighting:
//   pixVal = exp(hist.binToValue(index)) * shut
std::vector<double> OptimalShutter::createWeightMask(Histogram const& hist)
{
  uint32 begin = 0;
  // shutter speed such that the first bin has pixel value 1
  double shut = 1 / exp(hist.binToValue(begin));
  //std::cout << "shutter: " << shut << std::endl;
  // bin to which pixel value 255 gets mapped
  uint32 end = (log(255/shut)-hist.getMinVal()) / (hist.getMaxVal() - hist.getMinVal()) * hist.size();
  //std::cout << "end: " << log(255/shut) << std::endl;
  std::vector<double> result(end-begin);

  for (uint32 i=0; i<result.size(); ++i)
    {
      // log radiance corresponding to bin i
      float rad = (i-begin+0.5) / (double)hist.size() * (hist.getMaxVal()-hist.getMinVal()) + hist.getMinVal();
      // pixel value corresponding to radiance
      double pixVal = exp(rad) * shut;
      // maximum of weighting function at pixVal==223.837, weight==216.087
      //result[i] = (1 - pow(pixVal/127.5 - 1, 12)) * pixVal / 216.087; // p*M/N
      result[i] = (1 - pow(pixVal/127.5 - 1, 1)) * pixVal / 127.5; // p*M/N with earlier peak
      //result[i] = (1 - pow((pixVal-1)/127 - 1, 12)); // just M/N symmetric
    }

  return result;
}


// Creates coverage vector corresponding to the given shutter speeds (and weighting function).
// The histogram is needed for scale.
std::vector<double> OptimalShutter::createCoverage(Histogram const& hist, std::vector<double> const& shutters, std::vector<double> const& weighting)
{
  std::vector<double> coverage(hist.size(), 0);
  for (uint32 i=0; i<shutters.size(); ++i) {
    // log radiance value to which pixel value 1 gets mapped
    double rad = log(1.0 / shutters[i]);
    int32 bin = (rad-hist.getMinVal()) / (hist.getMaxVal()-hist.getMinVal()) * hist.size() + 0.5;
    int32 start = std::max(bin, 0);
    int32 end = std::min((int32)hist.size(), (int32)weighting.size()+bin);
    for (int32 j=start; j<end; ++j)
      coverage[j] = std::max(coverage[j], weighting[j-bin]);
  }
  return coverage;
}


double OptimalShutter::estimateCoverage(Histogram const& hist, std::vector<double> const& coverage)
{
  assert(hist.size() == coverage.size());
  double use = 0;
  for (uint32 i=0; i<coverage.size(); ++i)
    use += coverage[i] * hist.bin(i);
  return use;
}


// stops finding shutters when:
// -numExps exposures found, OR
// -maxCoverage reached, OR
// -the sum of shutter speeds exceeds maxShutterSum
std::vector<double> OptimalShutter::findBestShutters(Histogram const& hist, std::vector<double> const& weighting, uint32 numExps, double maxCoverage, double maxShutterSum)
{
  std::vector<double> shutters;
  std::vector<double> coverage(hist.size(), 0);
  double totalCoverage = 0, shutterSum = 0;

  while (shutters.size() < numExps && totalCoverage < maxCoverage)
    {
      double shut = findNextShutter(hist, weighting, coverage, numExps>1 && shutters.size() == 0);
      shutters.push_back(shut);
      shutterSum += shut * 0.02;
      coverage = createCoverage(hist, shutters, weighting);
      totalCoverage = estimateCoverage(hist, coverage);
    }

  // refine shutters. one shutter at a time
  for (uint32 i=1; i<shutters.size(); ++i) {
    std::vector<double> tempShuts;
    for (uint32 j=0; j<shutters.size(); ++j)
      if (j != i)
        tempShuts.push_back(shutters[j]);
    coverage = createCoverage(hist, tempShuts, weighting);
    shutters[i] = findNextShutter(hist, weighting, coverage, false);
  }

  // Debug info
  /*
  std::cout << "determined optimal shutters (numExps:" << numExps << "): ";
  for (uint32 i=0; i<shutters.size(); ++i)
    std::cout << shutters[i] << " ";
  std::cout << " (sum of shutters: " << shutterSum << ")" << std::endl;
  std::cout << "total coverage: " << totalCoverage << std::endl;
  */

  return shutters;
}


double OptimalShutter::findNextShutter(Histogram const& hist, std::vector<double> const& weighting, std::vector<double> const& coverage, bool maxShut)
{
  // boundaries of the possible shifts between weighting function and log histogram
  int32 minOff = -((int32)hist.size() - 1);
  int32 maxOff = weighting.size() - 1;

  if (maxShut)
    return 254 / exp(hist.binToValue(hist.size()-1));

  int32 bestOff = minOff;
  double max = -INFINITY;
  for (int32 off=minOff; off<=maxOff; ++off)
    {
      double use = 0;
      int32 start = std::max(-off, 0);
      int32 end = std::min((int32)hist.size(), (int32)weighting.size()-off);
      for (int32 j=start; j<end; ++j) {
        double gain = weighting[off+j] - coverage[j];
        if (gain > 0)
          use += gain * hist.bin((uint32)j);
      }

      if (use > max) {
        max = use;
        bestOff = off;
      }
    }

  // log radiace value corresponding to the beginning of the weighting array
  double lowestRad = (-bestOff+0.5) / (double)hist.size() * (hist.getMaxVal()-hist.getMinVal());
  lowestRad += hist.getMinVal();
  // shutter value resulting in lowestRad to have pixel value 1
  lowestRad = 1/exp(lowestRad);
  return std::min(lowestRad, HIGH_SHUT);
}


std::vector<double> OptimalShutter::findEquiShutters(uint32 numExps, Histogram const& hist)
{
  // shutter such that lowest log radiance gets mapped to 40 and highest to 254
  double lowShut = 254 / exp(hist.binToValue(hist.size()-1));
  double hiShut = 40 / exp(hist.binToValue(0));

  // add two exposures so that the 1 or 2 are in the middle,
  // then delete the outter exposures again
  bool addTwo = numExps == 1 || numExps == 2;
  if (addTwo)
    numExps += 2;

  assert(numExps > 0);
  std::vector<double> result;
  double factor = pow(hiShut/lowShut, 1/(double)(numExps-1));
  for (uint32 i=0; i<numExps; ++i)
    result.push_back(lowShut * pow(factor, i));

  if (addTwo) {
    result.erase(result.begin(), result.begin()+1);
    result.erase(result.end()-1, result.end());
  }

  return result;
}

#include "gui/GUIutils.h"

#include "gui/FLTKHeaders.h"
#include "gui/DisplayWindow.h"
#include "types/MocaException.h"
#include "opencv/highgui.h"

#ifdef HAVE_LIBFLTK


class ListView : public Fl_Double_Window
{
 public:
  ListView(std::string const& title, std::vector<std::string> const& list);
    
  uint32 select();
    
 private:
  static void callbackFunc(Fl_Widget* w, void* data);
    
  static int32 const buttonOffset;
  static int32 const buttonHeight;
  
  uint32 selectedElement;
};


int32 const ListView::buttonOffset = 10;
int32 const ListView::buttonHeight = 20;


ListView::ListView(std::string const& title, std::vector<std::string> const& list)
 : Fl_Double_Window(50, 50, 500, 500, title.c_str())
{
  if(list.empty())
    BOOST_THROW_EXCEPTION(ArgumentException("list must not be empty"));
    
  selectedElement = 0;
    
  uint32 y = buttonOffset;
  for(uint64 i = 0; i < list.size(); i++)
  {
    Fl_Button* button = new Fl_Button(buttonOffset, y, w()-2*buttonOffset, buttonHeight, list[i].c_str());
    button->callback(callbackFunc, (void*)i);
    y += buttonHeight + buttonOffset;    
  }
  size(w(), y);
  
  end();
}


uint32 ListView::select()
{
  show();
  while(shown())
    Fl::wait(0.01);
  return selectedElement;
}


void ListView::callbackFunc(Fl_Widget* w, void* data)
{
  uint32 id = (uint64)data; // gcc complains if you try to cast a pointer to uint32 on 64-bit systems but not about the implicit conversion from uint64 to uint32...
  ListView* wnd = (ListView*)w->parent();
  wnd->selectedElement = id;
  wnd->hide();
}


void GUIutils::showAlert(std::string const msg)
{
  fl_alert(msg.c_str());
}


std::string GUIutils::showInput(std::string label, std::string defaultVal)
{
  char const* result = fl_input(label.c_str(), defaultVal.c_str());
  if (result)
    return std::string(result);
  else
    return std::string();
}


void GUIutils::showMessage(std::string const msg)
{
  fl_message(msg.c_str());
}


void GUIutils::showFileChooser(std::string const title, std::string const pattern, char* fileName, sizeType fnBufSize)
{
  char* ptr = fl_file_chooser(title.c_str(), pattern.c_str(), fileName, 0);
  if(ptr != NULL)
  {
    std::stringstream sstr(ptr);
	uint32 n = sstr.readsome(fileName, fnBufSize);
	if(n == fnBufSize)
	  n -= 1;
	fileName[n] = '\0';
  }
  else
    fileName[0] = '\0';
}


void GUIutils::showFileChooser(std::string const title, std::string const pattern, std::string& fileName)
{
  char buf[1024];
  std::stringstream sstr("");
  sstr << fileName;
  uint32 n = sstr.readsome(buf, 1024);
  if(n == 1024)
    n -= 1;
  buf[n] = '\0';
  showFileChooser(title, pattern, buf, 1024);
  fileName.assign(buf);
}


uint32 GUIutils::showListView(std::string const title, std::vector<std::string> const& list)
{
  ListView lView(title, list);
  return lView.select();
}


uint32 GUIutils::showChoice(std::string const text, std::string const option0,
                            std::string const option1, std::string const option2)
{
  if(option2.empty())
    return fl_choice(text.c_str(), option0.c_str(), option1.c_str(), NULL);
  else
    return fl_choice(text.c_str(), option0.c_str(), option1.c_str(), option2.c_str());
}


#endif // HAVE_LIBFLTK


GUIutils::SimpleImageWindow::SimpleImageWindow(std::string const& name)
  : name(name)
{
  image = cvCreateImage(cvSize(128, 128), IPL_DEPTH_8U, 1);
  cvNamedWindow(name.c_str(), CV_WINDOW_AUTOSIZE);
}


GUIutils::SimpleImageWindow::~SimpleImageWindow()
{
  cvDestroyWindow(name.c_str());
  cvReleaseImage(&image);
}


void GUIutils::SimpleImageWindow::showImage(Image8U const& newImage)
{  
  uint32 width = newImage.width();
  uint32 height = newImage.height();
  uint32 channels = newImage.channels();
  IplImage* newImage2 = cvCreateImage(cvSize(width, height), IPL_DEPTH_8U, channels);
  for(uint32 line = 0; line < height; line++)
  {
    uint32 offset1 = line*newImage2->widthStep;
    uint32 offset2 = line*newImage.widthStep();
    memcpy(newImage2->imageData + offset1, newImage.ptr() + offset2, width*channels);
  }
  
  cvShowImage(name.c_str(), newImage2);
  
  IplImage* temp = image;
  image = newImage2;
  cvReleaseImage(&temp);
}


int32 GUIutils::SimpleImageWindow::wait(int32 ms)
{
  return cvWaitKey(ms);
}

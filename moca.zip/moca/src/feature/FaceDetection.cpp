#include "feature/FaceDetection.h"

#include "types/MocaException.h"
#include <opencv/highgui.h>
#include <iostream>


FaceDetection::FaceDetection(cascadeType type) {
  switch(type){
    case FRONTAL_FACE:
      cascadeFile = "/usr/share/opencv/haarcascades/haarcascade_frontalface_alt.xml";
      break;
    case PROFILE_FACE:
      cascadeFile = "/usr/share/opencv/haarcascades/haarcascade_profileface.xml";
      break;
    case FULL_BODY:
      cascadeFile = "/usr/share/opencv/haarcascades/haarcascade_fullbody.xml";
      break;
    default:
      BOOST_THROW_EXCEPTION(ArgumentException("No valid cascade type.")); 
  }
  
  cascade = (CvHaarClassifierCascade*)cvLoad( cascadeFile, 0, 0, 0 );
  if(!cascade){
    BOOST_THROW_EXCEPTION(ArgumentException("Could not load cascade file.")); 
  }
}

void FaceDetection::detect(Image8U const& srcImage, std::vector<Rect>& objects) {
  static CvMemStorage* storage = 0;
  storage = cvCreateMemStorage(0);
  cvClearMemStorage( storage );
  
  CvSeq* obj = cvHaarDetectObjects(srcImage.image, cascade, storage, 1.1, 2, CV_HAAR_DO_CANNY_PRUNING, cvSize(40, 40));
  
  for(int i = 0; i < (obj ? obj->total : 0); i++){
    CvRect* r = (CvRect*)cvGetSeqElem( obj, i );
    Rect o;

    o.x = r->x;
    o.y = r->y;
    o.w = r->width;
    o.h = r->height;
    
    objects.push_back(o);
  }
} 

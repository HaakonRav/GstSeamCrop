#ifndef WINHDR_LOGIC_H
#define WINHDR_LOGIC_H

#include "types/Exposure.h"
#include "types/Image8U.h"
#include "types/Image32F.h"
#include "feature/Histogram.h"

#include <vector>
#include <boost/shared_ptr.hpp>


class WinHDRStatus
{
public:
  WinHDRStatus();

  bool hdrSwitch, regSwitch, printSwitch;
  bool loadSwitch, saveSwitch, gTruthSwitch;
};


class HDRFrame
{
public:
  HDRFrame(uint32 width, uint32 height);

  virtual void clear();
  virtual void convertToYxy();
  virtual void convertBayerToBGR();
  virtual void stitchHDR();
  void print();

  std::vector<Exposure> expSet;
  std::vector<VectorI> gTruth;
  Image32F hdrImage;
  boost::shared_ptr<Image8U> displayImage;
  boost::shared_ptr<Image8U> captureImage;
  Histogram hist;
};


#ifdef HAVE_CUDA

#include "cudaHDR/CudaWrapper.h"
#include "cudaHDR/GPUToneMapping.h"


class CudaHDRFrame : public HDRFrame
{
 public:
  CudaHDRFrame(uint32 width, uint32 height);

  bool allocateHandles();
  void clear();
  void convertToYxy();
  void convertBayerToBGR();
  void stitchHDR();

  std::vector<CudaExposureHandle> expHandles;
};

#endif


#endif

#include <stdio.h>
#include "io/ImageFileReader.h"
#include "io/ImageFileWriter.h"
#include "types/Image8U.h"
#include "cudaHDR/dataStructures_common.h"
#include "cudaHDR/bayerPattern_common.h"
#include "cudaHDR/cudaImageDataHandle.h"
#include "cuda_runtime.h"

int main(int argc, char** argv)
{
  //Variables hold the handle and the image pointer
  boost::shared_ptr<Image8U>	srcimg;

  //Read bayerpattern testimage from hdd
  ImageFileReader ifr("bayerpattern3.png");
  srcimg = ifr.getImage();
  cudaImageDataHandle	sourcehandle(*srcimg);
  cudaImageDataHandle	targethandle(640, 480, 3, 8, 4);

  //Prepare processing of bayer kernel
  cudaImageDataDescriptor sourcedesc = sourcehandle.getDataDescriptor();
  cudaImageDataDescriptor targetdesc = targethandle.getDataDescriptor();

  //Start Bayer conversion
  BayerGRBGRBilinear(sourcedesc, targetdesc);
  cudaThreadSynchronize();

  return 0;
}

#include "tools/Timing.h"

#include <cassert>
#include <iostream>


#if defined WIN32

// Windows

#include "types/MocaException.h"

inline void timing_get_time(LARGE_INTEGER& value)
{
	QueryPerformanceCounter(&value);
}


inline double largeIntegerToDouble(LARGE_INTEGER const& value, LARGE_INTEGER const& freq)
{
	long double v=(long double)value.QuadPart;
	long double f=(long double)freq.QuadPart;
	long double r=(1000 * v / f);
	return (double)r;
}


Timing::Timing(sizeType noOfTimers)
  : timers(noOfTimers), counters(noOfTimers, 0), sums(noOfTimers, 0.0)
{
	LARGE_INTEGER temp;
	temp.HighPart=0;
	temp.LowPart=0;
	temp.QuadPart=0;
	for (uint32 i=0; i<noOfTimers; ++i)
	{
		sums[i] = counters[i] = 0;
		timers[i] = temp;
	}
	
	if(!QueryPerformanceFrequency(&freq))
		BOOST_THROW_EXCEPTION(RuntimeException("No high-resolution timer available."));
}


double Timing::stop(indexType timer)
{
	LARGE_INTEGER temp;
	timing_get_time(temp);
	
	Timing& timing = instance();
	double endTime = largeIntegerToDouble(temp, timing.freq);
	
	assert(timer < timing.timers.size());
	double startTime = largeIntegerToDouble(timing.timers[timer], timing.freq);
	double result = endTime - startTime;
	
	timing.counters[timer] += 1;
	timing.sums[timer] += result;
	temp.HighPart=0;
	temp.LowPart=0;
	temp.QuadPart=0;
	timing.timers[timer] = temp;
	return result;
}


double Timing::stopAndPrint(indexType timer)
{
	LARGE_INTEGER temp;
	timing_get_time(temp);
	
	Timing& timing = instance();
	double endTime = largeIntegerToDouble(temp, timing.freq);
	
	assert(timer < timing.timers.size());
	double startTime = largeIntegerToDouble(timing.timers[timer], timing.freq);
	double result = endTime - startTime;
	std::cout << result << "ms" << std::endl;
	
	timing.counters[timer] += 1;
	timing.sums[timer] += result;
	temp.HighPart=0;
	temp.LowPart=0;
	temp.QuadPart=0;
	timing.timers[timer] = temp;
	return result;
}


void Timing::reset(indexType timer)
{
	Timing& timing = instance();
	assert(timer < timing.timers.size());
	timing.counters[timer] = 0;
	timing.sums[timer] = 0;
	LARGE_INTEGER temp;
	temp.HighPart=0;
	temp.LowPart=0;
	temp.QuadPart=0;
	timing.timers[timer] = temp;
}

#elif defined DARWIN

// Mac OS X

inline void timing_get_time(uint64& value)
{
	value = mach_absolute_time();
}


inline double uint64ToDouble(uint64 const& value, mach_timebase_info_data_t const& info)
{
	uint64 ns = value * (info.numer / info.denom);
	return ns / 1000000.0;
}


Timing::Timing(sizeType noOfTimers)
  : timers(noOfTimers), counters(noOfTimers, 0), sums(noOfTimers, 0.0)
{
	for (uint32 i=0; i<noOfTimers; ++i)
		timers[i] = sums[i] = counters[i] = 0;
	mach_timebase_info(&timeinfo);
}


double Timing::stop(indexType timer)
{
	uint64 temp;
	timing_get_time(temp);
	
	Timing& timing = instance();
	assert(timer < timing.timers.size());
	double startTime = uint64ToDouble(timing.timers[timer], timing.timeinfo);
	double endTime = uint64ToDouble(temp, timing.timeinfo);
	double result = endTime - startTime;
	
	timing.counters[timer] += 1;
	timing.sums[timer] += result;
	timing.timers[timer] = 0;
	return result;
}


double Timing::stopAndPrint(indexType timer)
{
	uint64 temp;
	timing_get_time(temp);
	
	Timing& timing = instance();
	assert(timer < timing.timers.size());
	double startTime = uint64ToDouble(timing.timers[timer], timing.timeinfo);
	double endTime = uint64ToDouble(temp, timing.timeinfo);
	double result = endTime - startTime;
	std::cout << result << "ms" << std::endl;
	
	timing.counters[timer] += 1;
	timing.sums[timer] += result;
	timing.timers[timer] = 0;
	return result;
}

void Timing::reset(indexType timer)
{
	Timing& timing = instance();
	assert(timer < timing.timers.size());
	timing.counters[timer] = 0;
	timing.sums[timer] = 0;
	timing.timers[timer] = 0;
}

#else

// Linux

// stores the current in ts using a non-settable, constant rate timer (the time is relative to some unspecified point in time)
inline void timing_get_time(timespec& ts)
{
	clock_gettime(CLOCK_MONOTONIC, &ts); // actually has a return value indicating success but it's ignored for performance
}


// returns the time represented by ts in milliseconds as a double
inline double timespecToDouble(timespec const& ts)
{
	return (((double)ts.tv_sec) * 1000) + (((double)ts.tv_nsec) / 1000000);
}


Timing::Timing(sizeType noOfTimers)
  : timers(noOfTimers), counters(noOfTimers, 0), sums(noOfTimers, 0.0)
{
	for (uint32 i=0; i<noOfTimers; ++i)
	{
		sums[i] = counters[i] = 0;
		timers[i].tv_sec = 0;
		timers[i].tv_nsec = 0;
	}
}


double Timing::stop(indexType timer)
{
	timespec temp;
	timing_get_time(temp);
	double endTime = timespecToDouble(temp);
	
	Timing& timing = instance();
	assert(timer < timing.timers.size());
	double startTime = timespecToDouble(timing.timers[timer]);
	double result = endTime - startTime;
	
	timing.counters[timer] += 1;
	timing.sums[timer] += result;
	timing.timers[timer].tv_sec = 0;
	timing.timers[timer].tv_nsec = 0;
	return result;
}


// reimplemented for performace reasons. Simply calling stop() would cost more time and give false results.
double Timing::stopAndPrint(indexType timer)
{
	timespec temp;
	timing_get_time(temp);
	double endTime = timespecToDouble(temp);
	
	Timing& timing = instance();
	assert(timer < timing.timers.size());
	double startTime = timespecToDouble(timing.timers[timer]);
	double result = endTime - startTime;
	std::cout << result << "ms" << std::endl;
	
	timing.counters[timer] += 1;
	timing.sums[timer] += result;
	timing.timers[timer].tv_sec = 0;
	timing.timers[timer].tv_nsec = 0;
	return result;
}

void Timing::reset(indexType timer)
{
	Timing& timing = instance();
	assert(timer < timing.timers.size());
	timing.counters[timer] = 0;
	timing.sums[timer] = 0;
	timing.timers[timer].tv_sec = 0;
	timing.timers[timer].tv_nsec = 0;
}

#endif


Timing* Timing::_instance = 0;


Timing::~Timing()
{
}


Timing& Timing::instance()
{
  if (!_instance)
    _instance = new Timing(20);
  return *_instance;
}


void Timing::start(indexType timer)
{
  Timing& timing = instance();
  assert(timer < timing.timers.size());
  timing_get_time(timing.timers[timer]);
}


double Timing::sum(indexType timer)
{
  Timing& timing = instance();
  assert(timer < timing.sums.size());
  return timing.sums[timer];
}


double Timing::avg(indexType timer)
{
  Timing& timing = instance();
  assert(timer < timing.sums.size());
  return timing.sums[timer] /  timing.counters[timer];
}


uint32 Timing::count(indexType timer)
{
  Timing& timing = instance();
  assert(timer < timing.counters.size());
  return timing.counters[timer];
}

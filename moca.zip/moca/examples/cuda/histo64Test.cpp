#define BOOST_TEST_DYN_LINK
#include "boost/test/unit_test.hpp"

#include "testcases.h"

#include "cudaHDR/CudaImage8UHandle.h"
#include "cudaHDR/CudaWrapper.h"
#include "cudaHDR/CudaVectorHandle.h"
#include "cudaHDR/DeviceManager.h"

#include "io/ImageFileReader.h"
#include "io/ImageFileWriter.h"
#include "types/MocaException.h"
#include "filter/CvtColorSpace.h"
#include "feature/Feature.h"

//Initially load needed testdata
struct testDataHisto64
{
	//Will be available in every test case
	Image8U srcimg;

	//Initialize struct via constructor
	testDataHisto64() : srcimg(640, 480, 3)
	{
		//Load bayer pattern testimage from hdd
		ImageFileReader ifr(Yxy_IMG);
		ifr.getImage(srcimg);
	}
};

BOOST_FIXTURE_TEST_SUITE(Histo64TestSuite, testDataHisto64)

BOOST_AUTO_TEST_CASE(Histo64Test)
{
	//Generate 64 bin histogram on CPU
	VectorI histo_cpu_256(256);
	histo_cpu_256.clear();
	Feature::computeHist(srcimg, histo_cpu_256);
	VectorI histo_cpu_64(64);
	histo_cpu_64.clear();
	for (int i = 0; i < 64; i++)
	{
		histo_cpu_64[i] += histo_cpu_256[i*4];
		histo_cpu_64[i] += histo_cpu_256[i*4+1];
		histo_cpu_64[i] += histo_cpu_256[i*4+2];
		histo_cpu_64[i] += histo_cpu_256[i*4+3];
	}

	//Generate 64 bin histogram on GPU
	CudaImage8UHandle imghandle;
	imghandle.put(srcimg);
	CudaImage8UHandle changedstride;
	changedstride.allocate(640, 480, 3, 4);
	CudaWrapper::changeStride(imghandle, changedstride);
	CudaVectorHandle<int>	histohandle(64);
	MOCA_TIC(RUNS);
	CudaWrapper::histo64(changedstride, histohandle);
	MOCA_TOC("Histo64 GPU");
	DeviceManager::threadSynchronize();
	VectorI histo_gpu_64(64);
	histohandle.getData(histo_gpu_64);

	//Compare histograms
	for (int i = 0; i < 64; i++)
	{
		BOOST_CHECK(histo_cpu_64[i] == histo_gpu_64[i]);
	}
}

BOOST_AUTO_TEST_CASE(Histo64TestVaryBoth)
{
	//Crop sourceim
	Image8U srcimg_crop(624, 470, 3);
	cropImage8U(srcimg, srcimg_crop);

	//Generate 64 bin histogram on CPU
	VectorI histo_cpu_256(256);
	histo_cpu_256.clear();
	Feature::computeHist(srcimg_crop, histo_cpu_256);
	VectorI histo_cpu_64(64);
	histo_cpu_64.clear();
	for (int i = 0; i < 64; i++)
	{
		histo_cpu_64[i] += histo_cpu_256[i*4];
		histo_cpu_64[i] += histo_cpu_256[i*4+1];
		histo_cpu_64[i] += histo_cpu_256[i*4+2];
		histo_cpu_64[i] += histo_cpu_256[i*4+3];
	}

	//Generate 64 bin histogram on GPU
	CudaImage8UHandle imghandle;
	imghandle.put(srcimg_crop);
	CudaImage8UHandle changedstride;
	changedstride.allocate(624, 470, 3, 4);
	CudaWrapper::changeStride(imghandle, changedstride);
	CudaVectorHandle<int>	histohandle(64);
	CudaWrapper::histo64(changedstride, histohandle);
	VectorI histo_gpu_64(64);
	histohandle.getData(histo_gpu_64);

	//Compare histograms
	for (int i = 0; i < 64; i++)
	{
		BOOST_CHECK(histo_cpu_64[i] == histo_gpu_64[i]);
	}
}

BOOST_AUTO_TEST_SUITE_END()
#include "filter/SeamCropImage.h"

using namespace std;


void SeamCropImage::reduceWidth(Image8U const& image, Image8U& result, int targetWidth)
{
    if (image.width() == 0 || image.height() == 0)
      BOOST_THROW_EXCEPTION(ArgumentException("One of the image dimensions is zero.") << ErrImg1(image));
    if (targetWidth < 1)
      BOOST_THROW_EXCEPTION(ArgumentException("Target width is not valid.") << ErrImg1(image) << ErrInt(targetWidth));

    int w = image.width();
    int h = image.height();
    int c = image.channels();

    int storeX = 0;
    int numberCroppedLines = 0;
    int numberOfSeams = 0;
    int tmpWidth = w;		// temporary width during computation.
    Image8U tmpImage(w, h, c); 	// temporal image for computation
    
    copyWidth(image, tmpImage, w);
    
    while(tmpWidth > targetWidth)
      {
	// seam carving part
	storeX = tmpWidth;
	seamCarvImage(tmpImage, tmpWidth, targetWidth);
	numberOfSeams += storeX-tmpWidth;
      
	if (tmpWidth <= targetWidth)
	  break;
	
	// cropping part
	storeX = tmpWidth;
	cropImage(tmpImage, tmpWidth, targetWidth);
	numberCroppedLines += storeX-tmpWidth;
      }
      
      copyWidth(tmpImage, result, targetWidth);

      cerr << "new size: " << tmpWidth << "x" << h << endl;
      cerr << "Total: removed " << numberOfSeams << " seams, cropped " << numberCroppedLines << " lines." << endl;
}


void SeamCropImage::computeEnergy(Image8U image, Image32F& energy, int tmpWidth)
{
    int height = image.height();
    int channels = image.channels();
    int totalWidth = image.width();
    
    Image8U saliency(totalWidth, height, channels); 
    double rad = 4;
    double sigma = 12;
  
#if 0
    // make image black on right side greater than tmpWidth
    for (int x = tmpWidth-1; x < totalWidth; x++)
      for (int y=0; y < height; y++)
	for (int c=0; c < channels; c++)
	  image(x, y, c) = 0;
#endif
	  
    Feature::saliencyMap(image, saliency, rad, sigma);
    
    // convert
    for (int x=0; x < tmpWidth; x++)
      for (int y=0; y < height; y++)
	energy(x,y) = saliency(x, y);
}


void SeamCropImage::seamCarvImage(Image8U& tmpImage, int& tmpWidth, int& targetWidth)
{
    int width = tmpImage.width();
    int height = tmpImage.height();
    
    int maxCost = 1;		// maximum cost of a seam in the current image (with initial value).
    int minCost = 100000;	// minimum cost of a seam in the current image (with initial value).
    int minPosition = 1;	// x-position of the minimal cost (with initial value).
    int storeX = 0;

    int totalEnergy = 0; 	// totalEnergy for the calculated seams
    int tmpEnergy = 0;		// tmp Energy = totalEnergy - current seam
    bool noThresholdReached = true;	

    Image32F energy(width, height, 1);		// energy map
    Image32F costWidth(width, height); 		// stores the minimum summed up energy values for each position
    Image32F predecessors(width, height); 	// stores the x-position of the optimal predecessor for each position
    Image32F seams(width, height); 		// stores the positions of the seams (value = -1)
    
    cerr << "---------------------------------------------------------" << endl;
    cout << "New Iteration: tmpWidth = " << tmpWidth << ", targetWidth = " << targetWidth << endl;
    
    computeEnergy(tmpImage, energy, tmpWidth);
    computeCostWidth(tmpImage, energy, costWidth, predecessors, tmpWidth);
    getMaxCostWidth(costWidth, maxCost, tmpWidth);
    getMinCostWidth(costWidth, minCost, minPosition, tmpWidth); 

    summarize(energy, totalEnergy, tmpWidth);
    tmpEnergy = totalEnergy;
      
    // seam carving similar to the crop: seams are allowed to remove up to 1% of the total energy but 
    // must at the same time discard more than 1% of image width.
    for(int x = tmpWidth-1; x > targetWidth-1; x--)
      {
	storeX = x;
	getMinCostWidth(costWidth, minCost, minPosition, tmpWidth);  
	if( (tmpEnergy-minCost) > 0.99*totalEnergy )
	  {
	    markSeamWidth(costWidth, energy, predecessors, seams, tmpWidth);
	    tmpEnergy -= minCost;
	  }
	else
	  {
	    noThresholdReached = false;
	    break;
	  }
	minCost = costWidth(tmpWidth-1, height-1);   // Initialize next iteration
	computeCostWidth(tmpImage, energy, costWidth, predecessors, tmpWidth);
      }// for
      
    if(storeX <= 0.99*tmpWidth || noThresholdReached) 
      {
	removeSeamsWidth(tmpImage, energy, seams, tmpWidth);
	cerr << "Found " << tmpWidth-storeX << " seam(s), tmpWidth = " << storeX << endl;
	tmpWidth = storeX; 
      }
    else
      cerr << "No seams found in this iteration" << endl;

}


void SeamCropImage::computeCostCropWidth(Image32F& costCrop, int width)
{ 
    int height = costCrop.height();

    for (int x=0; x < width; x++)
	for (int y = 0; y < height; y++)
	    if(y != 0)
	      costCrop(x,y) = costCrop(x,y-1) + costCrop(x,y);
}



// find the best cropping window. First, reduce the window in size by 1 and search the best position. Repeat the 
// step with size minus one until the threshold is reached. If more than 85% of the total energy lie in the 
// cropping window when 15% or more of the image are removed (or the threshold wasn´t reached), the crop is 
// done. Otherwise, no crop is done in this iteration.
void SeamCropImage::cropImage(Image8U& tmpImage, int& tmpWidth, int& targetWidth)
{  
    int height= tmpImage.height();
    int channels = tmpImage.channels();
    long double totalEnergy = 0;		// Summed up energy of all pixels
    long double tmpEnergy = 0;			// Summed up energy of all pixels in the cropping window
    long double energyArray [tmpWidth];   	// energy values summed up from left to right (rightmost position = total energy)
    Image32F energy(tmpWidth, height, 1);	// energy map
    Image32F costCrop(tmpWidth, height); 	// stores the minimum summed up energy values for each position
    
    
    int resultX = 0;
    int cropLeft, cropRight, tmpLeft, tmpRight;
    
    int maxCost = 1;		// maximum cost of a seam in the current image (with initial value).
    int minCost = 100000;	// minimum cost of a seam in the current image (with initial value).
    int minPosition = 1;	// x-position of the minimal cost (with initial value).
    bool noThresholdReached = true;
	  
    cropLeft = 0;
    cropRight = tmpWidth-1;
    tmpLeft = cropLeft;
    tmpRight = cropRight;
    
    // compute energy and costs
    computeEnergy(tmpImage, energy, tmpWidth);
    costCrop = energy;
    computeCostCropWidth(costCrop, tmpWidth);
    
    // energyArray cumulates the summed energy in the last row of costCrop in ascending positions.
    energyArray[0] = costCrop(0, height-1);
    for (int x=1; x < tmpWidth; x++)
      energyArray[x] = costCrop(x, height-1) + energyArray[x-1];

    totalEnergy = energyArray[tmpWidth-1];
    getMinCostWidth(energy, minCost, minPosition, tmpWidth);
    getMaxCostWidth(energy, maxCost, tmpWidth);
    
    for (int i=1; i < tmpWidth-targetWidth; i++)
      { 
	for (int j=0; j < i+1; j++)
	  {
	    cropLeft = j;
	    cropRight = (tmpWidth-1)-i+j;	// rightmost position - reducement of window size + shifting
	    if(j==0) // initialize values
	      {
		tmpLeft = cropLeft;
		tmpRight = cropRight;
		tmpEnergy = energyArray[cropRight];
	      }
	    else if( (energyArray[cropRight]-energyArray[cropLeft-1]) > tmpEnergy ) // store values when energy in window is higher than tmpEnergy
	      {
		tmpLeft = cropLeft;
		tmpRight = cropRight;
		tmpEnergy = energyArray[cropRight]-energyArray[cropLeft-1];
	      }
	  }// for j
	
	if ((tmpEnergy < 0.85*totalEnergy)) 
	  {
	    noThresholdReached = false;
	    break;
	  }
	else
	    tmpEnergy = 0;
      }// for i
	
    if( (cropRight - cropLeft) <= 0.85*tmpWidth || noThresholdReached )
      {
	cropLeft = tmpLeft;
	cropRight = tmpRight;
	cerr << "Cropped " << tmpWidth - (cropRight - cropLeft) << " column(s)";
	tmpWidth = cropRight - cropLeft;
	cerr << ", tmpWidth = " << tmpWidth << endl;
	    
	for(int x = cropLeft; x < cropRight+1; x++)
	  {
	    for(int y = 0; y < height; y++)  
		for(int c = 0; c < channels; c++)
		  tmpImage(resultX, y, c) = tmpImage(x, y, c);
	    resultX += 1;
	  }
      }
      else
	cerr << "No suitable crop found this iteration" << endl;
}



void SeamCropImage::summarize(Image32F cost, int& totalCost, int width)
{
    int h = cost.height();
    for (int x=0; x < width; x++)
      for (int y=0; y < h; y++)
	totalCost += cost(x, y);
}


void SeamCropImage::removeSeamsWidth(Image8U& image, Image32F& energy, Image32F& seams, int width)
{
    int height = image.height();
    int channels = image.channels();
    int resultX = 0;		// cursor for x-value in image.

    for (int y = 0; y < height; y++) // removes seams by copying all normal pixels while skipping seam pixels.
      {
	for(int x = 0; x < width; x++)
	    if(seams(x,y) != -1)
	      {
		for(int c = 0; c < channels; c++)
		    image(resultX,y,c) = image (x,y,c);
		resultX += 1;
	      }//if
	resultX = 0;
      }//for y
}


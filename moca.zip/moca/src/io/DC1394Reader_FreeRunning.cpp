#include "io/DC1394Reader_FreeRunning.h"


#ifdef HAVE_LIBDC1394

#include "types/MocaException.h"


// ==================== DC1394Reader free running mode ====================

DC1394Reader_FreeRunning::DC1394Reader_FreeRunning(Rect dimension, BusSpeed speed, ColorMode color, indexType selectedCamera)
  : DC1394Reader(speed, color, selectedCamera), initialDimension(dimension)
{
}


DC1394Reader_FreeRunning::~DC1394Reader_FreeRunning()
{
  try{
    stop();
  }catch(...){}
}


void DC1394Reader_FreeRunning::start()
{
  try
  {
    DC1394Reader::start();
    DC1394Reader::setImageDimension(initialDimension);

    dc1394error_t err = dc1394_capture_setup(camera, 1, DC1394_CAPTURE_FLAGS_DEFAULT);
    if (err != DC1394_SUCCESS)
      {
        //DC1394_ERR(err, "Unable to setup camera.");	  
        throw std::string("Unable to setup camera.");
      }   

    err = dc1394_video_set_transmission(camera, DC1394_ON);
    if (err != DC1394_SUCCESS)
      {
        //DC1394_ERR(err, "Unable to set transmission.");
        throw std::string("Could not start ISO transmission.");
      }
  }
  catch(std::string& s)
  {
    if (camera)
      dc1394_camera_free(camera);
    camera = 0;
    initialized = false;
    BOOST_THROW_EXCEPTION(IOException(s));
  }
  initialized = true;
}


void DC1394Reader_FreeRunning::stop()
{
  if (!initialized)
    return;

  if (dc1394_video_set_transmission(camera, DC1394_OFF) != DC1394_SUCCESS)
    {
      initialized = false;
      BOOST_THROW_EXCEPTION(IOException("Unable to stop transmission."));
    }
}


#endif // HAVE_LIBDC1394

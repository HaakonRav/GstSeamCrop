#!/bin/bash

# Setting CPP-/LDFLAGS is actually only necessary if some of the
# libraries have been installed using MacPorts (www.macports.org).
# If all libraries are installed using "./configure && make && make
# install" or something equivalent you don't need to set these flags.

echo you have to execute setup_once_mac.sh at least once before using this script
export CPPFLAGS=-I/opt/local/include
export LDFLAGS=-L/opt/local/lib
./reconf.sh $* && \
rm libtool && \
ln -s /usr/bin/glibtool libtool
unset CPPFLAGS
unset LDFLAGS

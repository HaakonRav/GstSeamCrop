#include "feature/HistogramReg.h"
#include "feature/WardImageReg.h"
#include "filter/CvtColorSpace.h"
#include "filter/Filter.h"
#include "io/HDRExposureIO.h"
#include "tools/KalmanFilter.h"
#include "tools/Timing.h"
#include "types/Exposure.h"
#include "types/MocaException.h"

#include <fstream>
#include <boost/archive/text_iarchive.hpp>
#include <boost/serialization/vector.hpp>


class RegTest
{
public:
  RegTest()
    : histReg(64, 10.0)
  {
    exposuresPath = "/home/users/bguthier/programme/moca/videos/turn";
  }

  void doThings()
  {
    load();
    gTruthLoad();
  }

  void load()
  {
    boost::shared_ptr<HDRExposureIO> reader = HDRExposureIO::createReader(exposuresPath);
    expSets.resize(reader->getNumExposures());
    gTruth.resize(reader->getNumExposures());
    std::cout << "Loading " << expSets.size() << " exposures: ";
    for (uint32 i=0; i<expSets.size(); ++i)
      {
        std::cout << i << "  "; std::cout.flush();
        reader->getNext(expSets[i]);
        uint32 size = expSets[i].size();
        gTruth[i].resize(size);
        for (uint32 j=0; j<size; ++j)
          gTruth[i][j] = expSets[i][j].topLeft;
      }
    std::cout << std::endl;
    reader->close();
    assert(expSets.size() > 0 && expSets[0].size() > 0);
  }

  void gTruthLoad()
  {
    std::string filename(exposuresPath);
    filename += "/gtruth.txt";
    std::ifstream fs(filename.c_str());
    boost::archive::text_iarchive archive(fs);
    archive >> gTruth;
    debugStuffz();
    //stitchSpeedTest();
  }

  void computeTrajectory()
  {
    for (uint32 i=0; i<expSets.size(); ++i)
      {
        std::vector<Exposure> exp(expSets[i]);
        for (uint32 j=0; j<exp.size(); ++j)
          CvtColorSpace::convert(*exp[j].image, *exp[j].image, COLOR_BGR, COLOR_Yxy);
        for (uint32 j=1; j<exp.size(); ++j)
          {
            VectorI diff1 = exp[j].topLeft - exp[exp[j].parent].topLeft;
            VectorI diff2 = gTruth[i][j] - gTruth[i][exp[j].parent];
            VectorI diff = diff2 - diff1;
            std::cout << diff << " ||| ";
          }
        std::cout << std::endl;
      }
  }

  void stitchSpeedTest()
  {
    assert(expSets.size() > 0 && expSets[0].size() > 0);
    Exposure exp1(expSets[0][0]);
    Exposure exp2(expSets[0][0]);

    std::cout << "height, Ward, Semi" << std::endl;
    for (int32 h=100; h<=480; h+=10)
      {
        exp2.image = boost::shared_ptr<Image8U>(new Image8U(exp2.image->width(), h, exp2.image->channels()));
        VectorI vec(2); vec -= vec;
        Filter::copyImage(*exp1.image, *exp2.image, Rect(0, 0, exp2.image->width(), h), vec);

        Timing::reset(0);
        Timing::reset(1);
        for (int32 i=0; i<10; ++i)
          {
            VectorI offset(2); offset -= offset;
            Vector confidence(2);
            Timing::start(1);
            ward.computeShift(*exp1.image, *exp2.image, 6, exp1.topLeft);
            Timing::stop(1);
            Timing::start(0);
            histReg.computeShift(exp1, exp2, offset, confidence);
            Timing::stop(0);
            exp1.topLeft -= exp1.topLeft;
          }
        std::cout << h << ", " << Timing::avg(1) << ", " << Timing::avg(0) << std::endl;
      }
  }

  void compRegErrors(std::vector<double>& errors, std::vector<double>& conf)
  {
    for (uint32 i=0; i<expSets.size(); ++i)
      {
        std::vector<Exposure> exp(expSets[i]);
        //for (uint32 j=0; j<exp.size(); ++j)
        //  CvtColorSpace::convert(*exp[j].image, *exp[j].image, COLOR_BGR, COLOR_Yxy);

        for (uint32 j=1; j<exp.size(); ++j)
          {
            VectorI realOff = gTruth[i][j] - gTruth[i][exp[j].parent];
            VectorI offset(2); offset -= offset;
            Vector confidence(2);
            
            histReg.computeShift(exp[exp[j].parent], exp[j], offset, confidence);
            offset = histReg.filterOffset(offset, confidence);
            offset += exp[j].topLeft - exp[exp[j].parent].topLeft;

            //offset = exp[j].topLeft - exp[exp[j].parent].topLeft;
            //ward.computeShift(*exp[exp[j].parent].image, *exp[j].image, 4, offset);

            //std::cout << realOff << " *** " << offset << std::endl;
            double diff = sqrt(pow(offset[0]-realOff[0], 2) + pow(offset[1]-realOff[1], 2));
            errors.push_back(diff);
            conf.push_back(std::max(confidence[0], confidence[1]));
          }
      }
  }

  void calcStats(std::vector<double> const& errors, std::vector<double> const& conf)
  {
    double const maxErr = 3.0;
    double okayImg = 0, notRecog = 0, repaired = 0, repFailed = 0;
    double mean = 0;
    assert(errors.size() == conf.size());
    for (uint32 i=0; i<errors.size(); ++i)
      {
        if (errors[i] <= maxErr)
          if (conf[i] < 10)
            okayImg += 1;
          else
            repaired += 1;
        else
          if (conf[i] < 10)
            notRecog += 1;
          else
            repFailed += 1;
        mean += errors[i];
      }
    double perc = 100.0/errors.size();
    okayImg *= perc; notRecog *= perc; repaired *= perc; repFailed *= perc;
    mean /= errors.size();
    double stddev = 0;
    for (uint32 i=0; i<errors.size(); ++i)
      stddev += pow(errors[i] - mean, 2) / errors.size();
    stddev = sqrt(stddev);
    std::cout << "correct registration (max error " << maxErr << "): " << okayImg << "%" << std::endl;
    std::cout << "recognized and repaired: " << repaired << "%" << std::endl;
    std::cout << "recognized, but repair failed: " << repFailed << "%" << std::endl;
    std::cout << "error not recognized: " << notRecog << "%" << std::endl;
    std::cout << mean << " " << stddev << std::endl;
  }

  void debugStuffz()
  {
    for (uint32 i=0; i<expSets.size(); ++i)
      for (uint32 j=0; j<expSets[i].size(); ++j)
        CvtColorSpace::convert(*expSets[i][j].image, *expSets[i][j].image, COLOR_BGR, COLOR_Yxy);

    // Gotta make the attributes in HistogramReg public for this to work
    //std::cout << "maxOffset mean_err std_dev" << std::endl;
    //for (int32 param=22; param<90; param += 2) {
    //  histReg.maxOffset = param;
    //for (double param=1.0; param<=20.0; param += 1.0) {
    //  histReg.maxConf = param;
    //for (int32 param=0; param<=15; param += 1) {
    //  histReg.noiseThresh = param;
    //for (double param=0.0; param<=2.0; param += 0.1) {
    //  histReg.obsCovFactor = param;
    //for (uint8 param=0; param<=25; param += 1) {
    //  histReg.badMean = param;
    //for (uint8 param=0; param<=50; param += 5) {
    //  histReg.nextMeanStep = param;
    //for (uint8 param=0; param<=1; param += 1) {
    //  histReg.startWithRows = param==0;
    //for (uint32 param=0; param<=10; param += 1) {
    //histReg.nccIters = param;
    //for (uint32 param=1; param<=15; param += 1) {
    //  histReg.procCov = param;

    //std::cout << param << " ";

      histReg.initFilter();
      std::vector<double> errors;
      std::vector<double> conf;
      compRegErrors(errors, conf);
      calcStats(errors, conf);
      //}
  }

  WardImageReg ward;
  HistogramReg histReg;

  std::vector<std::vector<Exposure> > expSets;
  std::vector<std::vector<VectorI> > gTruth;
  std::string exposuresPath;
};


int main(int argc, char** argv)
{
  try
    {
      RegTest hdr;
      hdr.doThings();
    }
  catch(MocaException& e)
    {
      std::cerr << diagnostic_information(e);
    }
  
  return 0;
}

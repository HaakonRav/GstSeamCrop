
#include "types/Vector.h"
#include "types/MocaException.h"


Vector Vector2D::create(double x, double y)
{
  Vector v(2);
  v[0] = x;
  v[1] = y;
  return v;
}


Vector Vector2D::create(Vector v)
{
  assert(v.size() == 3);
  return create(v[0]/v[2], v[1]/v[2]);
}


VectorI Vector2D::create(int32 x, int32 y)
{
  VectorI v(2);
  v[0] = x;
  v[1] = y;
  return v;
}


VectorI Vector2D::create(VectorI v)
{
  assert(v.size() == 3);
  return create(v[0]/v[2], v[1]/v[2]);
}


Vector Vector3D::create(double x, double y, double z)
{
  Vector v(3);
  v[0] = x;
  v[1] = y;
  v[2] = z;
  return v;
}


Vector Vector3D::create(Vector v, double z)
{
  if(v.size() != 2)
    BOOST_THROW_EXCEPTION(ArgumentException("expected a two-dimensional vector"));

  return create(v[0], v[1], z);    
}


VectorI Vector3D::create(int32 x, int32 y, int32 z)
{
  VectorI v(3);
  v[0] = x;
  v[1] = y;
  v[2] = z;
  return v;
}


VectorI Vector3D::create(VectorI v, int32 z)
{
  if(v.size() != 2)
    BOOST_THROW_EXCEPTION(ArgumentException("expected a two-dimensional vector"));
    
  return create(v[0], v[1], z);
}



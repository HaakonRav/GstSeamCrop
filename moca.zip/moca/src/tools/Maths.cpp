#include "tools/Maths.h"
#include "types/MocaException.h"

#ifdef HAVE_LIBGSL
#include <gsl/gsl_linalg.h>
#include <gsl/gsl_multifit.h>
#include <tools/NLinSolver.h>
#endif // HAVE_LIBGSL
#include <boost/numeric/ublas/lu.hpp>


namespace Maths
{
  bool isNaN(double value)
  {
    return !(value == value);
  }


  double distance(Vector const& p1, Vector const& p2)
  {
    return norm_2(p1-p2);
  }
  
  
  double angle(Vector const& p)
  {
    if(p.size() != 2)
      BOOST_THROW_EXCEPTION(ArgumentException("Vector must be two-dimensional"));
  
    if(p[1] == 0 && p[0] == 0)
      return 0;
      
    double result = atan(p[1]/p[0]) / M_PI * 180.0;
    if(p[0] < 0)
    {
      if(p[1] < 0)
	result = -180 + result;
      else
	result = 180 + result;
    }
	
    if(isNaN(result))
      BOOST_THROW_EXCEPTION(RuntimeException("NaN result in angle computation"));
      
    return result;
  }


  double angle(Vector const& p1, Vector const& p2)
  {
    return angle(p2) - angle(p1);
  }


  double gaussVal[121] = {
    6.07588e-09, 1.10158e-08, 1.97732e-08, 3.51396e-08, 6.18262e-08, 1.07698e-07, 1.85736e-07, 3.17135e-07, 5.36104e-07, 8.97244e-07, 
    1.48672e-06, 2.43896e-06, 3.9613e-06, 6.36983e-06, 1.01409e-05, 1.59837e-05, 2.49425e-05, 3.85352e-05, 5.89431e-05, 8.92617e-05, 
    0.00013383, 0.000198655, 0.000291947, 0.00042478, 0.000611902, 0.000872683, 0.00123222, 0.00172257, 0.00238409, 0.00326682, 
    0.00443185, 0.00595253, 0.00791545, 0.0104209, 0.013583, 0.0175283, 0.0223945, 0.028327, 0.0354746, 0.0439836, 
    0.053991, 0.0656158, 0.0789502, 0.0940491, 0.110921, 0.129518, 0.149727, 0.171369, 0.194186, 0.217852, 
    0.241971, 0.266085, 0.289692, 0.312254, 0.333225, 0.352065, 0.36827, 0.381388, 0.391043, 0.396953, 
    0.398942, 0.396953, 0.391043, 0.381388, 0.36827, 0.352065, 0.333225, 0.312254, 0.289692, 0.266085, 
    0.241971, 0.217852, 0.194186, 0.171369, 0.149727, 0.129518, 0.110921, 0.0940491, 0.0789502, 0.0656158, 
    0.053991, 0.0439836, 0.0354746, 0.028327, 0.0223945, 0.0175283, 0.013583, 0.0104209, 0.00791545, 0.00595253, 
    0.00443185, 0.00326682, 0.00238409, 0.00172257, 0.00123222, 0.000872683, 0.000611902, 0.00042478, 0.000291947, 0.000198655, 
    0.00013383, 8.92617e-05, 5.89431e-05, 3.85352e-05, 2.49425e-05, 1.59837e-05, 1.01409e-05, 6.36983e-06, 3.9613e-06, 2.43896e-06, 
    1.48672e-06, 8.97244e-07, 5.36104e-07, 3.17135e-07, 1.85736e-07, 1.07698e-07, 6.18262e-08, 3.51396e-08, 1.97732e-08, 1.10158e-08, 
    6.07588e-09};
    /*
    for (int i=0; i<=120; i++)
    {
      double result = i/10.0 - 6;
      result *= result;
      result *= -0.5;
      result = exp(result);
      result /= sqrt(2*M_PI);
      std::cout << result << ", ";
      if((i+1)%10 == 0)
        std::cout << std::endl;
    }
    */

  double gaussian(double const x, double const mu, double const sigma)
  {
    if(sigma <= 0)
      BOOST_THROW_EXCEPTION(ArgumentException("Illegal sigma value."));
      
    double xx = (x - mu) / sigma;
    int32 index = (int32)(10*(xx+6) + 0.5);
    double result = 0;
    if((index >= 0) && (index <= 120))
      result = gaussVal[index]/sigma; //!!! evtl beide nächsten Werte betrachten und interpolieren

    /*double result = (x - mu) / sigma;
    result *= result;
    result *= -0.5;
    result = exp(result);
    result /= sigma * sqrt(2*M_PI);*/
    return result;
  }
  
  
  #ifdef HAVE_LIBGSL
  // ========================= conversion functions =========================

  void mat2gsl(Matrix const& matrix, gsl_matrix& gslMatrix)
  {
    assert((matrix.size1() == gslMatrix.size1) && (matrix.size2() == gslMatrix.size2));
    
    for (indexType row=0; row<gslMatrix.size1; ++row)
      for (indexType col=0; col<gslMatrix.size2; ++col)
	gsl_matrix_set(&gslMatrix, row, col, matrix(row,col));
  }


  void vec2gslMatrix(std::vector<Vector> const& vector, gsl_matrix& gslMatrix)
  {
    assert((gslMatrix.size1 == vector.size()) && (gslMatrix.size2 == 3));
    
    for (indexType row=0; row<gslMatrix.size1; ++row)
      {
        assert(vector[row].size() >= 3);
        
	gsl_matrix_set(&gslMatrix, row, 0, vector[row][0]);
	gsl_matrix_set(&gslMatrix, row, 1, vector[row][1]);
	gsl_matrix_set(&gslMatrix, row, 2, vector[row][2]);
      }
  }


  void gsl2mat(gsl_matrix const& gslMatrix, Matrix& matrix)
  {
    assert((matrix.size1() == gslMatrix.size1) && (matrix.size2() == gslMatrix.size2));
    
    for (indexType row=0; row<gslMatrix.size1; ++row)
      for (indexType col=0; col<gslMatrix.size2; ++col)
	matrix(row,col) = gsl_matrix_get(&gslMatrix, row, col);
  }


  void vec2gsl(Vector const& vector, gsl_vector& gslVector)
  {
    assert(vector.size() == gslVector.size);
    
    for (indexType i=0; i<gslVector.size; ++i)
      gsl_vector_set(&gslVector, i, vector(i));
  }


  void gsl2vec(gsl_vector const& gslVector, Vector& vector)
  {
    assert(vector.size() == gslVector.size);
    
    for (indexType i=0; i<gslVector.size; ++i)
      vector(i) = gsl_vector_get(&gslVector, i);
  }
  
  
  // ==================== Least-Squares Affine ====================
  
  void leastSquaresAffine(std::vector<Vector> const& modelPoints, std::vector<Vector> const& imagePoints, Matrix& transform)
  {
    if((transform.size2() != 3) || (transform.size1() != 2) || (modelPoints.size() != imagePoints.size()))
      BOOST_THROW_EXCEPTION(ArgumentException("Matrix size mismatch"));
    if(modelPoints.size() < 3)
      BOOST_THROW_EXCEPTION(ArgumentException("Not enough data points to estimate transformation."));

    // prepare data for gsl
    gsl_matrix& gslModelPoints = *gsl_matrix_alloc(modelPoints.size(), 3);
    gsl_matrix& gslImagePoints = *gsl_matrix_alloc(imagePoints.size(), 3); // 2?
    gsl_matrix& gslTransform   = *gsl_matrix_alloc(transform.size1(), transform.size2());
    vec2gslMatrix(modelPoints, gslModelPoints);
    vec2gslMatrix(imagePoints, gslImagePoints);
    mat2gsl(transform, gslTransform);

    double chisq;
    gsl_multifit_linear_workspace& workspace = *gsl_multifit_linear_alloc(gslModelPoints.size1, gslTransform.size2);
    gsl_matrix& cov = *gsl_matrix_alloc(gslTransform.size2, gslTransform.size2);
    gsl_vector& w = *gsl_vector_alloc(gslModelPoints.size1);
    gsl_vector_set_all(&w, 1);

    // compute the transformation for all dimensions (2, duh!)
    for (indexType i=0; i<gslTransform.size1; ++i)
      {
	gsl_vector_view tRow = gsl_matrix_row(&gslTransform, i);
	gsl_vector_const_view iCol = gsl_matrix_const_column(&gslImagePoints, i);
	gsl_multifit_wlinear(&gslModelPoints, &w, &iCol.vector, &tRow.vector, &cov, &chisq, &workspace);
      }
    
    gsl2mat(gslTransform, transform);

    gsl_matrix_free(&cov);
    gsl_vector_free(&w);
    gsl_multifit_linear_free(&workspace);
    gsl_matrix_free(&gslModelPoints);
    gsl_matrix_free(&gslImagePoints);
    gsl_matrix_free(&gslTransform);
  }


  // ==================== Least-Squares Euclidean ====================

  class EuclidSolver : public NLinSolver
  {
  public:
    EuclidSolver(std::vector<Vector> const& modelPoints, std::vector<Vector> const& imagePoints, sizeType paramCnt, sizeType funcCnt)
      : NLinSolver(modelPoints, imagePoints, paramCnt, funcCnt) {}
    ~EuclidSolver(){}

  protected:
    virtual void function(Vector const& position, Vector& values)
    {
      double const alpha = position[0];
      double const sinAlpha = sin(alpha);
      double const cosAlpha = cos(alpha);
      double const tx = position[1];
      double const ty = position[2];
      sizeType const n = modelPoints.size();

      for (indexType i=0; i<n; ++i)
	{
	  Vector model = Vector2D::create(modelPoints[i]);
	  Vector image = Vector2D::create(imagePoints[i]);
	  values[  i] = model[0]*cosAlpha - model[1]*sinAlpha + tx - image[0];
	  values[n+i] = model[0]*sinAlpha + model[1]*cosAlpha + ty - image[1];
	}
    }

    virtual void derivative(Vector const& position, Matrix& jacobi)
    {
      double const alpha = position[0];
      double const sinAlpha = sin(alpha);
      double const cosAlpha = cos(alpha);
      sizeType const n = modelPoints.size();

      for (indexType i=0; i<n; ++i)
	{
	  Vector model = Vector2D::create(modelPoints[i]);
	  jacobi(  i,1) = 1;
	  jacobi(  i,2) = 0;
	  jacobi(n+i,1) = 0;
	  jacobi(n+i,2) = 1;

	  jacobi(  i,0) = -model[0]*sinAlpha - model[1]*cosAlpha;
	  jacobi(n+i,0) = model[0]*cosAlpha - model[1]*sinAlpha;
	}
    }

    virtual void both(Vector const& position, Vector& values, Matrix& jacobi)
    {
      function(position, values);
      derivative(position, jacobi);
    }
  };


  void leastSquaresEuclid(std::vector<Vector> const& modelPoints, std::vector<Vector> const& imagePoints, Matrix& transform)
  {
    if ((transform.size2() != 3) || (transform.size1() != 2) || (modelPoints.size() != imagePoints.size()))
      BOOST_THROW_EXCEPTION(ArgumentException("Matrix size mismatch."));
    if (modelPoints.size() < 2)
      BOOST_THROW_EXCEPTION(ArgumentException("Not enough data points to estimate transformation."));

    sizeType const p = 3;
    sizeType const n = modelPoints.size();
    EuclidSolver euc(modelPoints, imagePoints, p, 2*n);
    Vector params(p);
    euc.solve(params);

    double alpha = params[0];
    transform(0,0) = cos(alpha);
    transform(1,0) = sin(alpha);
    transform(0,1) = -sin(alpha);
    transform(1,1) = cos(alpha);
    transform(0,2) = params[1];
    transform(1,2) = params[2];
  }


  // ==================== Least-Squares Similarity ====================

  class SimilaritySolver : public NLinSolver
  {
  public:
    SimilaritySolver(std::vector<Vector> const& modelPoints, std::vector<Vector> const& imagePoints, sizeType paramCnt, sizeType funcCnt)
      : NLinSolver(modelPoints, imagePoints, paramCnt, funcCnt) {}
    ~SimilaritySolver(){}

  protected:
    virtual void function(Vector const& position, Vector& values)
    {
      double const alpha = position[0];
      double const scale = position[1];
      double const tx = position[2];
      double const ty = position[3];
      sizeType const n = modelPoints.size();

      for (indexType i=0; i<n; ++i)
	{
	  Vector model = Vector2D::create(modelPoints[i]);
	  Vector image = Vector2D::create(imagePoints[i]);
	  values[  i] = scale * (model[0]*cos(alpha) - model[1]*sin(alpha)) + tx - image[0];
	  values[n+i] = scale * (model[0]*sin(alpha) + model[1]*cos(alpha)) + ty - image[1];
	}
    }

    virtual void derivative(Vector const& position, Matrix& jacobi)
    {
      double const alpha = position[0];
      double const scale = position[1];
      sizeType const n = modelPoints.size();

      for (indexType i=0; i<n; ++i)
	{
	  Vector model = Vector2D::create(modelPoints[i]);
	  jacobi(  i,0) = -model[0]*scale*sin(alpha) - model[1]*scale*cos(alpha);
	  jacobi(n+i,0) =  model[0]*scale*cos(alpha) - model[1]*scale*sin(alpha);
	  jacobi(  i,1) =  model[0]*      cos(alpha) - model[1]      *sin(alpha);
	  jacobi(n+i,1) =  model[0]*      sin(alpha) + model[1]      *cos(alpha);
	  jacobi(  i,2) = 1;
	  jacobi(n+i,2) = 0;
	  jacobi(  i,3) = 0;
	  jacobi(n+i,3) = 1;
	}
    }

    virtual void both(Vector const& position, Vector& values, Matrix& jacobi)
    {
      function(position, values);
      derivative(position, jacobi);
    }
  };


  void leastSquaresSimilar(std::vector<Vector> const& modelPoints, std::vector<Vector> const& imagePoints, Matrix& transform)
  {
    if ((transform.size2() != 3) || (transform.size1() != 2) || (modelPoints.size() != imagePoints.size()))
      BOOST_THROW_EXCEPTION(ArgumentException("Matrix size mismatch."));
    if (modelPoints.size() < 2)
      BOOST_THROW_EXCEPTION(ArgumentException("Not enough data points to estimate transformation."));

    sizeType const p = 4;
    sizeType const n = modelPoints.size();
    SimilaritySolver sim(modelPoints, imagePoints, p, 2*n);
    Vector params(p);
    sim.solve(params);

    double const alpha = params[0];
    double const scale = params[1];
    transform(0,0) = scale * cos(alpha);
    transform(1,0) = scale * sin(alpha);
    transform(0,1) = scale * -sin(alpha);
    transform(1,1) = scale * cos(alpha);
    transform(0,2) = params[2];
    transform(1,2) = params[3];
  }


  // ==================== Least-Squares Projective ====================

  class ProjectiveSolver : public NLinSolver
  {
  public:
    ProjectiveSolver(std::vector<Vector> const& modelPoints, std::vector<Vector> const& imagePoints, sizeType paramCnt, sizeType funcCnt)
      : NLinSolver(modelPoints, imagePoints, paramCnt, funcCnt) {}
    ~ProjectiveSolver(){}

  protected:
    virtual void function(Vector const& position, Vector& values)
    {
      sizeType const n = modelPoints.size();
      for (indexType i=0; i<n; ++i)
	{
	  Vector model = Vector2D::create(modelPoints[i]);
	  Vector image = Vector2D::create(imagePoints[i]);
	  double nx, ny, d, xi, yi;
	  xi = model[0];
	  yi = model[1];
	  nx = position[0] * xi + position[1] * yi + position[2];
	  ny = position[3] * xi + position[4] * yi + position[5];
	  d  = position[6] * xi + position[7] * yi + 1;

	  values[  i] = nx/d - image[0];
	  values[n+i] = ny/d - image[1];
	}
    }

    virtual void derivative(Vector const& position, Matrix& jacobi)
    {
      sizeType const n = modelPoints.size();
      for (indexType i=0; i<n; ++i)
	{
	  Vector model = Vector2D::create(modelPoints[i]);
	  double nx, ny, d, xi, yi;
	  xi = model[0];
	  yi = model[1];
	  nx = position[0] * xi + position[1] * yi + position[2];
	  ny = position[3] * xi + position[4] * yi + position[5];
	  d  = position[6] * xi + position[7] * yi + 1;

	  jacobi(i,0) = xi/d        ; jacobi(i+n,0) = 0;
	  jacobi(i,1) = yi/d        ; jacobi(i+n,1) = 0;
	  jacobi(i,2) = 1/d         ; jacobi(i+n,2) = 0;
	  jacobi(i,3) = 0           ; jacobi(i+n,3) = xi/d;
	  jacobi(i,4) = 0           ; jacobi(i+n,4) = yi/d;
	  jacobi(i,5) = 0           ; jacobi(i+n,5) = 1/d;
	  jacobi(i,6) = -nx*xi/(d*d); jacobi(i+n,6) = -ny*xi/(d*d);
	  jacobi(i,7) = -nx*yi/(d*d); jacobi(i+n,7) = -ny*yi/(d*d);
	}
    }

    virtual void both(Vector const& position, Vector& values, Matrix& jacobi)
    {
      function(position, values);
      derivative(position, jacobi);
    }
  };


  void leastSquaresProj(std::vector<Vector> const& modelPoints, std::vector<Vector> const& imagePoints, Matrix& transform)
  {
    if ((transform.size2() != 3) || (modelPoints.size() != imagePoints.size()) || (transform.size1() != 3))
      BOOST_THROW_EXCEPTION(ArgumentException("Matrix size mismatch."));
    if (modelPoints.size() < 4)
      BOOST_THROW_EXCEPTION(ArgumentException("Not enough data points to estimate transformation."));

    sizeType const p = 8;
    sizeType const n = modelPoints.size();
    ProjectiveSolver proj(modelPoints, imagePoints, p, 2*n);
    Vector params(p);
    proj.solve(params);

    for (indexType row=0; row<transform.size1(); ++row)
      for (indexType col=0; col<transform.size2(); ++col)
	if (row < 2 || col < 2)
	  transform(row,col) = params[row*3+col];
	else
	  transform(row,col) = 1;    
  }


  // ==================== exact Euclidean ====================
  
  void linSolveEuclid(std::vector<Vector> const& modelPoints, std::vector<Vector> const& imagePoints, Matrix& transform)
  {
    if(modelPoints.size() != 2 || imagePoints.size() != 2)
      BOOST_THROW_EXCEPTION(ArgumentException("two model points and two image points must be supplied."));
    if(modelPoints[0].size() < 2 || modelPoints[1].size() < 2 || imagePoints[0].size() < 2 || imagePoints[1].size() < 2)
      BOOST_THROW_EXCEPTION(ArgumentException("each supplied point must be at least two-dimensional."));
    if(transform.size1() != 2 || transform.size2() != 3)
      BOOST_THROW_EXCEPTION(ArgumentException("matrix size mismatch."));
      
    Vector const& modelVec1 = modelPoints[0];
    Vector const& modelVec2 = modelPoints[1];
    Vector const& imgVec1 = imagePoints[0];
    Vector const& imgVec2 = imagePoints[1];
  
    double const imageDiff0 = imgVec1[0] - imgVec2[0];
    double const imageDiff1 = imgVec1[1] - imgVec2[1];
    double const modelDiff0 = modelVec1[0] - modelVec2[0];
    double const modelDiff1 = modelVec1[1] - modelVec2[1];
  
    double const divisor = modelDiff0*modelDiff0 + modelDiff1*modelDiff1;
    double const cosAlpha = (imageDiff0*modelDiff0 + imageDiff1*modelDiff1) / divisor;
    double const sinAlpha = (imageDiff1*modelDiff0 - imageDiff0*modelDiff1) / divisor;
    
    /* the following code checks if the original transformation 'really' was an euclidean transformation
    double const thresh = 0.001; // how close do two floating point numbers have to be to be considered equal?
    if(fabs(cosAlpha) > (1+thresh) || fabs(sinAlpha) > (1+thresh))
      throw MathsException(0, "linSolveEuclid(): non-euclidean transformation.");
    double const alpha1 = acos(cosAlpha);
    double const alpha2 = asin(sinAlpha);
    double diff;
    if(cosAlpha >= 0 && sinAlpha >= 0)
      diff = fabs(alpha1 - alpha2);
    else if(cosAlpha < 0 && sinAlpha >= 0)
      diff = fabs(alpha1 - (M_PI-alpha2));
    else if(cosAlpha >= 0 && sinAlpha < 0)
      diff = fabs(alpha1 + alpha2);
    else // cosAlpha < 0 && sinAlpha < 0
      diff = fabs((2*M_PI-alpha1)-(M_PI-alpha2));
    if(diff > thresh)
	  throw MathsException(0, "linSolveEuclid(): probably non-euclidean transformation.");
    */

    double const tx = imgVec1[0] - cosAlpha*modelVec1[0] + sinAlpha*modelVec1[1];
    double const ty = imgVec1[1] - sinAlpha*modelVec1[0] - cosAlpha*modelVec1[1];
    // these two lines are equal to those two above (except for some small errors resulting from the limited precision of floating point numbers)
    // double const tx = imgVec2[0] - cosAlpha*modelVec2[0] + sinAlpha*modelVec2[1];
    // double const ty = imgVec2[1] - sinAlpha*modelVec2[0] - cosAlpha*modelVec2[1];
  
    transform(0,0) = cosAlpha;
    transform(0,1) = -sinAlpha;
    transform(0,2) = tx;
    transform(1,0) = sinAlpha;
    transform(1,1) = cosAlpha;
    transform(1,2) = ty;
  }
  

  // ==================== exact Affine ====================

  void linSolveAffine(std::vector<Vector> const& modelPoints, std::vector<Vector> const& imagePoints, Matrix& transform)
  {
    if ((transform.size1() != 2) || (transform.size2() != 3))
      BOOST_THROW_EXCEPTION(ArgumentException("matrix size mistmatch."));
    if ((modelPoints.size() < 3) || (imagePoints.size() < 3))
      BOOST_THROW_EXCEPTION(ArgumentException("Not enough data points to estimate transformation."));

    gsl_vector* tau = gsl_vector_alloc(6);
    gsl_vector* b = gsl_vector_alloc(6);
    gsl_vector* x = gsl_vector_alloc(6);
    gsl_matrix* a = gsl_matrix_alloc(6, 6);
    gsl_matrix_set_zero(a);

    for (indexType i=0; i<3; ++i) // initialize the matrix A and the vector b
      {
        Vector model = Vector2D::create(modelPoints[i]);
        Vector image = Vector2D::create(imagePoints[i]);
	gsl_matrix_set(a, i  , 0, model[0]);
	gsl_matrix_set(a, i  , 1, model[1]);
	gsl_matrix_set(a, i  , 2, 1);
	gsl_matrix_set(a, 3+i, 3, model[0]);
	gsl_matrix_set(a, 3+i, 4, model[1]);
	gsl_matrix_set(a, 3+i, 5, 1);
	gsl_vector_set(b, i  , image[0]);
	gsl_vector_set(b, i+3, image[1]);
      }    

    gsl_linalg_QR_decomp(a, tau);
    gsl_linalg_QR_solve(a, tau, b, x);

    for (indexType i=0; i<3; ++i) // copy the results into the matrix transform
      {
	transform(0,i) = gsl_vector_get(x, i);
	transform(1,i) = gsl_vector_get(x, i+3);
      }

    gsl_matrix_free(a);
    gsl_vector_free(x);
    gsl_vector_free(b);
    gsl_vector_free(tau);
  }  
  #endif // HAVE_LIBGSL
  
  
  // =============== matrix and vector stuff ===============

  void rotationMatrix2D(double angle, Matrix& matrix)
  {
    if((matrix.size1() < 2) || (matrix.size2() < 2))
      BOOST_THROW_EXCEPTION(ArgumentException("Matrix too small for 2D rotation."));    

    matrix(0,0) = cos(angle);
    matrix(0,1) = -sin(angle);
    matrix(1,0) = sin(angle);
    matrix(1,1) = cos(angle);
  }


  Matrix concatAffineTrans(Matrix const& matrix1, Matrix const& matrix2)
  {
    if((matrix1.size1() != 2) || (matrix2.size1() != 2) || (matrix1.size2() != 3) || (matrix2.size2() != 3))
      BOOST_THROW_EXCEPTION(ArgumentException("Matrix size mismatch."));

    Matrix result(2, 3);
    for (indexType dRow=0; dRow<2; ++dRow)
      for (indexType dCol=0; dCol<3; ++dCol)
	{
	  result(dRow,dCol) = 0;
	  for (indexType i=0; i<2; ++i)
	    result(dRow,dCol) += matrix1(dRow,i) * matrix2(i,dCol);
	  if (dCol == 2)
	    result(dRow,dCol) += matrix1(dRow,2);
	}
    return result;
  }


  double determinant3x3(Matrix const& mat)
  {
    if ((mat.size1() != 3) || (mat.size2() != 3))
      BOOST_THROW_EXCEPTION(ArgumentException("Matrix size mismatch."));    

    double d = 0;
    d += mat(0,0)*mat(1,1)*mat(2,2);
    d += mat(0,1)*mat(1,2)*mat(2,0);
    d += mat(0,2)*mat(1,0)*mat(2,1);
    d -= mat(0,2)*mat(1,1)*mat(2,0);
    d -= mat(0,0)*mat(1,2)*mat(2,1);
    d -= mat(0,1)*mat(1,0)*mat(2,2);
    return d;
  }


  void invertMatrix(Matrix const& s, Matrix& d)
  {
    if (s.size1() != s.size2() || s.size1() != d.size1() || s.size2() != d.size2())
      BOOST_THROW_EXCEPTION(ArgumentException("Matrix must be a square matrix."));

    using namespace boost::numeric::ublas;
    Matrix mat(s);
    permutation_matrix<uint32> pm(mat.size1());

    int res = lu_factorize(mat, pm);
    if (res != 0)
      BOOST_THROW_EXCEPTION(RuntimeException("Matrix not invertible."));
    
    d.assign(identity_matrix<double>(mat.size1()));
    // backsubstitute to get the inverse
    lu_substitute(mat, pm, d);
  }

  #ifdef HAVE_LIBGSL
  void linSolveQR(Matrix const& a, Vector const& b, Vector& x)
  {
    if (a.size1() != b.size() || a.size2() != x.size())
      BOOST_THROW_EXCEPTION(ArgumentException("Matrix/Vector sizes do not match."));

    gsl_matrix* gslA = gsl_matrix_alloc(a.size1(), a.size2());
    gsl_vector* tau = gsl_vector_alloc(std::min(a.size1(), a.size2()));
    gsl_vector* gslb = gsl_vector_alloc(b.size());
    gsl_vector* residual = gsl_vector_alloc(b.size());
    gsl_vector* gslx = gsl_vector_alloc(x.size());
    mat2gsl(a, *gslA);
    vec2gsl(b, *gslb);
    gsl_linalg_QR_decomp(gslA, tau);
    gsl_linalg_QR_lssolve(gslA, tau, gslb, gslx, residual);
    gsl2vec(*gslx, x);
    gsl_matrix_free(gslA);
    gsl_vector_free(tau);
    gsl_vector_free(gslb);
    gsl_vector_free(residual);
    gsl_vector_free(gslx);
  }
  #endif

  Matrix squareMatFromAffine(Matrix const& matrix)
  {
    if (matrix.size1() != 2 || matrix.size2() != 3)
      BOOST_THROW_EXCEPTION(ArgumentException("Matrix must be 2 by 3."));
    
    Matrix result(3,3);
    for (indexType row=0; row<matrix.size1(); ++row)
      for (indexType col=0; col<matrix.size2(); ++col)
	result(row,col) = matrix(row,col);
    for (indexType i=0; i<3; ++i)
      result(2, i) = (i == 2 ? 1 : 0);
	
    return result;
  }
};



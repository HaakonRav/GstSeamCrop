#include "gui/VideoWindow.h"
#include "types/MocaException.h"
#include <iostream>


#ifdef HAVE_LIBFLTK


class TestWindow : public VideoWindow
{
public:
  TestWindow(Rect dim, std::string title, std::string fileName)
   : VideoWindow(dim, title, fileName)
  {
    std::cout << "file info:" << std::endl;
    std::cout << "----------" << std::endl;
    std::cout << "dimensions  = " << reader->getImageWidth() << "x";
    std::cout << reader->getImageHeight() << std::endl;
	std::cout << "duration    = " << reader->getDuration() << std::endl;
	std::cout << "frameRate   = " << reader->getFrameRate() << std::endl;
    std::cout << "# of frames = " << reader->getTotalFrameCount() << std::endl << std::endl;
  }

protected:
  void doStuff()
  {
    reader->getImage(*image);
	std::cout << reader->getCurrentFrameCount() << std::endl;
    showImage(image);
  }
};


int main(int argc, char **argv)
{
  try
  {
    if(argc < 2)
    {
      std::cout << "usage: " << argv[0] << " path_to_video_file" << std::endl;
      return -1;
    }
    
    TestWindow wnd( Rect(256, 256, 512, 512), std::string("Video Viewer: ")+std::string(argv[1]), argv[1]);
    wnd.mainLoop();
  }
  catch(MocaException& e)
  {
    std::cerr << diagnostic_information(e);
  }
  
  return 0;
}


#else // HAVE_LIBFLTK


int main(int argc, char** argv)
{
  std::cout << "this example requires FLTK." << std::endl;
  return 0;
}


#endif // HAVE_LIBFLTK


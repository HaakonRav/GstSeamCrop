// Nicht die aktuelle Version


// MOCA headers 
#include "types/MocaTypes.h"
#include "types/Image8U.h"
#include "types/Image32F.h"
#include "types/MocaException.h"
#include "feature/Feature.h"
#include "feature/OpticalFlow.h"
#include "filter/Filter.h"
#include "filter/SeamCropImage.h"
#include "filter/SeamCarvingImage.h"
#include "filter/FrequencyTunedSaliency.h"
#include "io/IO.h"
#include "io/VideoReader.h"
#include "io/VideoWriter.h"
#include <sstream>

#include "tools/Timing.h"
 
// C++ headers 
#include <string>
#include <math.h>
#include <iostream>
#include <deque>
#include <algorithm>
using namespace std;

// Nearly identical to seamCropVideoInterpolate, but twice the number of seams (as necessary) is searched in the current 
// key frame and then the correct number is mapped to the ones from the last.


struct seamPair{
 uint32 Nr1;
 uint32 Nr2;
 float cost;
};

#if 0
static void printImage32F(Image32F const& frame, string const& destPath)
{
    uint32 width = frame.width();
    uint32 height = frame.height();
    Image8U print(width, height,1);
    
    float max = 0;
    float min = 1000;
    for (uint32 x = 0; x < width; x++) 
      for (uint32 y = 0; y < height; y++)
      {
	if(frame(x,y) < min)
	 min = frame(x,y);
	 
	if(frame(x,y) > max)
	 max = frame(x,y);
      }
    
    float v = 0;
    float factor = 255.0/(max - min);
    if(factor > 10.0) 
	factor = 10.0;
    
    for (uint32 x = 0; x < width; x++) 
      for (uint32 y = 0; y < height; y++)
      {
	v = frame(x,y);
	v -= min;
	v *= factor;
	print(x,y) = (int) ( v + 0.5);
      }
	
    try
      {
	    cerr << "save image" << endl; 
    	    IO::saveImage(destPath, print); 
      } 
    catch (MocaException e) 
      {
	    std::cout << "save Image error: " << e.what() << std::endl;
	    exit (-1);
   }    
}
#endif

#if 0
static void drawSeams(Image8U& drawImage, Image32F& allSeams, uint32 const& cropLeftPos, uint32 const& targetWidth)
{
  uint32 width = drawImage.width();
  uint32 height = drawImage.height();
  uint32 specialWidth = allSeams.width();
  uint32 cropRightPos = (int) (cropLeftPos + (0.75 * targetWidth));;
      
   for (uint32 n = 0; n < specialWidth; n++) 
	for(uint32 y = 0; y < height; y++)
	{
	      drawImage(allSeams(n,y),y,0) = 0;
	      drawImage(allSeams(n,y),y,1) = 0;
	      drawImage(allSeams(n,y),y,2) = 255;
	}
	
    for (uint32 x = 0; x < width; x++) 
	for(uint32 y = 0; y < height; y++)
	{
	if(x == cropLeftPos)
	      {
	        drawImage(x,y,0) = 0;
		drawImage(x,y,1) = 255;
		drawImage(x,y,2) = 0;
	      }
	  if(x == cropRightPos)
	      {
	        drawImage(x,y,0) = 0;
		drawImage(x,y,1) = 255;
		drawImage(x,y,2) = 0;
	      }
	}
}
#endif


static void normalize32F(Image32F& frame)
{
    uint32 width = frame.width();
    uint32 height = frame.height();

    float max = 0;
    float min = frame(width-1, height-1);
    for (uint32 x = 0; x < width; x++) 
      for (uint32 y = 0; y < height; y++)
      {
	if(frame(x,y) < min)
	 min = frame(x,y);
	 
	if(frame(x,y) > max)
	 max = frame(x,y);
      }
    
    float factor = 255.0/(max - min);
    //if(factor > 10.0) 
	//factor = 10.0;
    
    for (uint32 x = 0; x < width; x++) 
      for (uint32 y = 0; y < height; y++)
      {
	frame(x,y) -= min;
	frame(x,y) *= factor;
      }
}


static void normalize32FHalf(Image32F& frame)
{
    uint32 width = frame.width();  // special
    uint32 height = frame.height(); // buffer
    vector<float> values;

    float max = 0;
    float min = frame(width-1, height-1);
    for (uint32 x = 0; x < width; x++) 
      for (uint32 y = 0; y < height; y++)
      {
	values.push_back(frame(x,y));
	
	if(frame(x,y) < min)
	 min = frame(x,y);
	 
	//if(frame(x,y) > max)
	 //max = frame(x,y);
      }
      
    sort(values.begin(), values.end());
    max = values[values.size()/2];
    
    float factor = 255.0/(max - min);
    //if(factor > 10.0) 
	//factor = 10.0;
    
    for (uint32 x = 0; x < width; x++) 
      for (uint32 y = 0; y < height; y++)
      {
	frame(x,y) -= min;
	frame(x,y) *= factor;
      }
}



static void normalizeVector(vector<float>& values)
{
    uint32 size = values.size();
    vector<float> valuesCopy = values;

    sort(valuesCopy.begin(), valuesCopy.end());
    float min = valuesCopy[0];
    float max = valuesCopy[valuesCopy.size()*0.7];
    
    float factor = 255.0/(max - min);
    //if(factor > 10.0) 
	//factor = 10.0;
    
    for (uint32 i = 0; i < size; i++) 
      {
	values[i] -= min;
	values[i] *= factor;
      }
}


// load the frames of the video in a deque list
static void loadVideo(string const& videoPath, deque<Image8U>& video)
{
  VideoReader reader(videoPath);
  reader.start();
  Image8U frame(reader.getImageWidth(), reader.getImageHeight(), 3);
  
  while(!reader.getEndOfVideo()) 
    {
      reader.getImage(frame); 
      video.push_back(frame);
    }
    
  reader.stop();  
}


// substract the second from the first frame to find the positions of changing pixel values
static void findMotionSaliency(Image8U const& firstFrame, Image8U const& secondFrame, Image32F& result )
{
  uint32 width = firstFrame.width();
  uint32 height = firstFrame.height();
  uint32 channels = firstFrame.channels();
  
  float diff = 0;
  for(uint32 x=0; x < width; x++)
	for(uint32 y=0; y < height; y++)
	  {
	    diff = 0;
	    for(uint32 c=0; c < channels; c++) 
		diff += abs(firstFrame(x,y,c) - secondFrame(x,y,c));

	    result(x,y) = diff > 25 ? 255 : 0; // Standart value: 25
	  }

  Filter::smooth(result, result, 20); //smooth 15
}


// the energy map is computed by combining per frame saliency with simple motion saliency
static void computeSaliencyVideo(deque<Image8U>& video, deque<Image32F>& videoEnergyMap)
{
  deque<Image8U>::iterator it = video.begin();
  uint32 width = it->width();
  uint32 height = it->height();
  uint32 frameCount = video.size();
  
  //Image32F saliency(width, height, 1);
  Image32F gradient(width, height, 1);
  Image32F motionSaliency(width, height, 1);
  Image32F totalSaliency(width, height, 1);
  uint32 t = 0; 
  
#if 0
    VideoWriter writer("/home/stud/kiess/Videos/result/eagle_gesamt.avi", width, height);
    writer.start();
    Image8U print(width, height,1);
#endif
  
  while (it != video.end())
  {
    //FrequencyTunedSaliency::calculate((*it), saliency);
    SeamCarvingImage::computeEnergy((*it), gradient, width);
    
    if(t == 0)
	findMotionSaliency((*it), (*(it+1)), motionSaliency);
    else if (t < frameCount-1)
	findMotionSaliency((*(it-1)), (*(it+1)), motionSaliency);
    else
	findMotionSaliency((*(it-1)), (*it), motionSaliency);
      

    // motionSaliency is not normalized because its values are set to 0 or 255 before smoothing
    normalize32F(gradient);
    //normalize32F(saliency);
    
#if 0
    if(t == 50) 
    {
	printImage32F(gradient, "/home/stud/kiess/Videos/result/2_50_gradient.png");
	printImage32F(motionSaliency, "/home/stud/kiess/Videos/result/3_50_motionSaliency.png");
	printImage32F(saliency, "/home/stud/kiess/Videos/result/0_50_frequencySaliency.png");
	//IO::saveImage("/home/stud/kiess/Videos/result/0_59_saliency.png", saliency); 
    }
#endif
    
#if 0 
    for (uint32 x = 0; x < width; x++) 
      for (uint32 y = 0; y < height; y++)
	print(x,y) = motionSaliency(x,y);
      
    writer.putImage(print);
#endif

    for(uint32 x=0; x < width; x++)
	for(uint32 y=0; y < height; y++)
	    totalSaliency(x,y) = 2*motionSaliency(x,y) + 1*gradient(x,y);// + saliency(x,y); // 3*motionS+gradient
 
    videoEnergyMap.push_back(totalSaliency);
    
#if 0 
    for (uint32 x = 0; x < width; x++) 
      for (uint32 y = 0; y < height; y++)
	print(x,y) = totalSaliency(x,y);
      
    writer.putImage(print);
#endif
    
#if 0
    if(t == 50)
    {
	printImage32F(totalSaliency, "/home/stud/kiess/Videos/result/1_50_Gesamt.png");
	exit(1);
    }
#endif
    
    t++;
    it++;
  }
  
#if 0
  writer.stop();
  exit(1);
#endif

}


// sums up the energy values of all pixels for each column in each frame.
static void calculateCostColumTime(deque<Image32F>& videoEnergyMap, Image32F& costColumnTime)
{
  deque<Image32F>::iterator it = videoEnergyMap.begin();
  uint32 width = it->width();
  uint32 height = it->height();
  
  uint32 t = 0;
  while (it != videoEnergyMap.end())
  {
    for (uint32 y=0; y < height; y++)
	for (uint32 x=0; x < width; x++)
	  costColumnTime(x,t) += (*it)(x,y);
    t++;
    it++;
  }
}


// calculate the energy cost of each cropping window and store the value on the position of its left border.
static void calculateCostCroppingWindowTime(Image32F const& costColumnTime, Image32F& costCroppingWindowTime)
{
  uint32 width = costColumnTime.width();
  uint32 frameCount = costColumnTime.height();
  uint32 specialWidth = costCroppingWindowTime.width();
  uint32 targetWidth = width - specialWidth + 1;
  
  for(uint32 t=0; t < frameCount; t++)
  {
      // calculate cost of cropping frame on leftmost position
      costCroppingWindowTime(0,t) = 0;
      for (uint32 i = 0; i < targetWidth; i++)
	costCroppingWindowTime(0,t) += costColumnTime(i,t);
      
      // move cropping window a step to the right at a time and recalculate the costs for each position
      for (uint32 i = 1; i < specialWidth; i++)
	costCroppingWindowTime(i,t) += costColumnTime(i+targetWidth-1, t) - costColumnTime(i-1, t);
  }
}


// find the path of cropping windows with the maximum energy costs.
static void calculateMaxEnergyPath(Image32F const& costCroppingWindowTime, vector<uint32>& cropLeft)
{
  uint32 specialWidth = costCroppingWindowTime.width(); // specialWidth = width - targetWidth
  uint32 frameCount = costCroppingWindowTime.height();
  Image32F optimalCost(specialWidth, frameCount, 1); // optimal summed costs
  Image8U predecessors(specialWidth, frameCount, 1); // saves position of max predecessor
  
  uint32 v1 = 0; // predecessor up left (x-1, t-1)      |v1|v2|v3|   t-1
  uint32 v2 = 0; // predecessor up middle (x, t-1)  ->  |--|--|--|
  uint32 v3 = 0; // predecessor up right (x+1, t-1)     |  |x |  |    t

  // find maximum cost of a connected position in the previous line and store its x-position in predecessors.
  for (uint32 t = 0; t < frameCount; t++) 
      for (uint32 x = 0; x < specialWidth; x++)
          if (t == 0) // top border
              optimalCost(x,t) = costCroppingWindowTime(x,t);
          else if (x == 0) // left border
	    {
              v2 = optimalCost(x,t-1) + costCroppingWindowTime(x,t);
              v3 = optimalCost(x+1,t-1) + costCroppingWindowTime(x,t);
              if(v2 >= v3)
	        {
		  optimalCost(x,t) = v2;
		  predecessors(x,t) = x;
		}
	      else 
	        {
		  optimalCost(x,t) = v3;
		  predecessors(x,t) = x+1;
		}//if
	    }
	  else if (x == specialWidth-1) // right border
	    {
	      v1 = optimalCost(x-1,t-1) + costCroppingWindowTime(x,t);
	      v2 = optimalCost(x,t-1) + costCroppingWindowTime(x,t);
	      if(v2 >= v1)
	        {
		  optimalCost(x,t) = v2;
		  predecessors(x,t) = x;
		}
              else
	        {
		  optimalCost(x,t) = v1;
		  predecessors(x,t) = x-1;
	        }//if		
	    }
	  else // rest of the matix 
	    {
	      v1 = optimalCost(x-1,t-1) + costCroppingWindowTime(x,t);
	      v2 = optimalCost(x,t-1) + costCroppingWindowTime(x,t);
	      v3 = optimalCost(x+1,t-1) + costCroppingWindowTime(x,t);
	      if((v2 >= v1) && (v2 >= v3))
	        {
		  optimalCost(x,t) = v2;
		  predecessors(x,t) = x;
		}
	      else if((v1 >= v2) && (v1 >= v3))
	        {
		  optimalCost(x,t) = v1;
		  predecessors(x,t) = x-1;
		}
	      else
	        {
		  optimalCost(x,t) = v3;
		  predecessors(x,t) = x+1;
		}
	    }// if else (t==0)

  // find the maximum cost position in the last row (last frame of the shot)
  float max = optimalCost(specialWidth-1, frameCount-1);
  uint32 maxPosition = specialWidth-1;
  for (uint32 x = 0; x < specialWidth-1; x++) 
      if(optimalCost(x, frameCount-1) > max)
      {
	  max = optimalCost(x,frameCount-1);
	  maxPosition = x;
      } 
     
  // build optimal cropping window path by traversing back from maximum cost position in last row
  for(int t = frameCount-1; t > -1; t--) 
  {   
      cropLeft[t] = maxPosition;
      maxPosition = predecessors(maxPosition,t); // get x-position of maximum in line t-1.
  }
}


// smooth the path of the cropping windows to prevent shaking movement
static void smoothSignal(vector<uint32>& cropLeft)
{
  uint32 size = cropLeft.size();
  
  // gauss-based average, repeated
  //for(uint32 repeat = 0; repeat < 10; repeat++)
      for(uint32 i = 0; i < size; i++)
	  if(i == 0)
	      cropLeft[i] = (cropLeft[i] + cropLeft[i+1])/2; // (i + (i+1))/2
	  else if (i < size-1)  
	      cropLeft[i] = 0.25*cropLeft[i-1] + 0.5*cropLeft[i] + 0.25*cropLeft[i+1]; //(0.25 + 0.5 + 0.25)
	  else  
	      cropLeft[i] = (cropLeft[i] + cropLeft[i-1])/2;
}


#if 1
// the energy on the left and right side of the cropping window borders are decreased in a s-curve manner.
static void adjustSaliencyMapToCroppingWindow(deque<Image32F>& videoEnergyMap, vector<uint32> const& cropLeft, int const& targetWidth)
{
  deque<Image32F>::iterator itEnergy = videoEnergyMap.begin();
  uint32 width = itEnergy->width();
  uint32 height = itEnergy->height();
  
  uint32 t = 0;
  uint32 cropRightPos= 0;
  float leftToBorder = 0; // distance left side of the cropping window to the left border of the image
  float rightToBorder = 0;
  uint32 factorMultiply = 0; // used for linear progression
  float factorEnergy = 0;
  
  
  while (itEnergy != videoEnergyMap.end())
  {
    cropRightPos = cropLeft[t] + targetWidth-1;
    leftToBorder = cropLeft[t];
    rightToBorder = width - cropRightPos;
    
    //cout << "cropLeftPos = " << cropLeft[t] << ", cropRightPos = " << cropRightPos << endl;
    
    factorMultiply = 0;
    for (uint32 x=0 ; x < cropLeft[t]; x++)
    {
	factorEnergy = 1/(1 + exp(-(factorMultiply/leftToBorder) * 10 + 9)); // 1/(1 + exp(-(factorMultiply/leftToBorder) * 8 + 5)); *10+8
	for (uint32 y=0; y < height; y++)
	    (*itEnergy)(x,y) *= factorEnergy;
	factorMultiply++;
    }
    
    factorMultiply = 0;
    for (uint32 x = width-1; x > cropRightPos; x--)
    {
	factorEnergy = 1/(1 + exp(-(factorMultiply/rightToBorder) * 10 + 9)); // 1/(1 + exp(-(factorMultiply/leftToBorder) * 8 + 5)); *10+8
	for (uint32 y=0; y < height; y++)
	{
	    //cout << "x = " << x << ", y = " << y << ", energy before = " << (*itEnergy)(x,y) << ", factor = " << factorEnergy;
	    (*itEnergy)(x,y) *= factorEnergy;
	    //cout << ", energy after = " << (*itEnergy)(x,y) << endl;
	}
	factorMultiply++;
    }
   
    t++;
    itEnergy++;
    
#if 0
    for (uint32 y=0; y < height; y++)
    {
	for (uint32 x = 0; x < width; x++)
	      cout << " " << (int)((*itEnergy)(x,y)); 
	cout << endl;
    }
#endif
  }
  
}
#endif


// mark the position of the pixels of the found seam
static void markSeamWidth(Image32F& costWidth, Image32F& energy, Image32F const& predecessors, Image32F& seams, Image32F& seamsPositions, uint32 const seamID)
{
  int width = costWidth.width();
  int height = costWidth.height();
  int min = costWidth(width-1, height-1);  // stores the minimum costs.
  int minPosition = width-1; 		   // stores the x-position of the minumum costs.

  SeamCarvingImage::getMinCostWidth(costWidth, min, minPosition, width);
  
  for(int y = height-1; y > -1; y--) // builds the seam backwards beginning in the starting point minPostion and marks the pixels
    { 
      seams(minPosition,y) = -1;     		// -1 marks the seam in seams.
      energy(minPosition,y) = 99999999;		// high value prevents next iterations to pick the same pixel.
      seamsPositions(seamID, y) = minPosition;
      minPosition = predecessors(minPosition,y);// get x-position of minimum cost pixel in line y-1.
    }//for
    
}


#if 0
// calculate temporal coherence cost and add them to a temp energy map. the temporal costs are based on
// gradients and the distance of the pixel that should be removed to the according seam pixel from the last frame.
static void addTemporalCoherenceCost(Image8U const& frame, Image32F const& energy, Image32F& tmpEnergy, Image32F const& seamsLastFrame, uint32 const& seamID)
{
  int width = frame.width();
  uint32 height = frame.height();
  
  Image32F temporalCoherenceCost(width, height,1);
  int prevSeamPos = 0;
  
  for(uint32 y=0; y < height; y++)
  {
	prevSeamPos = seamsLastFrame(seamID,y);
	temporalCoherenceCost(prevSeamPos, y) = 0;
	
	// go from previous seam pixel to the left side, recursively calculate costs for each pixel to be removed 
	for(int l = prevSeamPos-1; l > -1; l--)
	    temporalCoherenceCost(l,y) = 10*(prevSeamPos-l) > 300 ? 300 : 10*(prevSeamPos-l); // 15, Grenze 300

	    
	// go from seam pixel to the right side118
	for(int r = prevSeamPos+1; r < width; r++)
	    temporalCoherenceCost(r,y) = 10*(r-prevSeamPos) > 300 ? 300 : 10*(r-prevSeamPos);

  }
 
  for (int x = 0; x < width; x++) 
      for (uint32 y = 0; y < height; y++)
	tmpEnergy(x,y) = 2*energy(x,y) + 1*temporalCoherenceCost(x,y); // 1*energy+ 1*temp

}
#endif


static void findSeamsFrame(Image8U const& frame, Image32F& energy, vector<Image32F>& allSeamsFinal, Image32F& seamCosts, uint32 const& t, uint32 const& counter)
{
  uint32 width = frame.width();
  uint32 height = frame.height();
  uint32 channels = frame.channels();
  uint32 specialWidth = allSeamsFinal[0].width();
  
  Image32F tmpEnergy(width, height); 		// temp energy for modification
  Image32F costWidth(width, height); 		// stores the minimum summed up energy values for each position
  Image32F predecessors(width, height); 	// stores the x-position of the optimal predecessor for each position
  Image32F seams(width, height); 		// stores the positions of the seams (value = -1)
  Image8U tmpImage(width, height, channels); 	// temporal image for computation
  
  int minCost = 99999999;	// minimum cost of a seam in the current image (with initial value).
  int minPosition = width-1;	// x-position of the minimal cost (with initial value).
  
  SeamCarvingImage::copyWidth(frame, tmpImage, width);
     
    for(uint32 seamID = 0; seamID < specialWidth; seamID++)
      {
	  tmpEnergy = energy;
#if 0
	  if(t > 0)
	      addTemporalCoherenceCost(frame, energy, tmpEnergy, allSeamsFinal[t-counter], seamID);
#endif
	  SeamCarvingImage::computeCostWidth(tmpImage, tmpEnergy, costWidth, predecessors, width);
	  SeamCarvingImage::getMinCostWidth(costWidth, minCost, minPosition, width);  
	  seamCosts(seamID, t) = minCost;
	  markSeamWidth(costWidth, energy, predecessors, seams, allSeamsFinal[t], seamID); 
	  
	  minCost = 99999999;	// minimum cost of a seam in the current image (with initial value).
          minPosition = width-1;
      }// for
 
}


// Builds pairs of seams from a first and a second frame based on the distance of its pixel positions.
static void findSeamPairs(uint32 const& firstFrame, uint32 const& secondFrame, vector<Image32F>& allSeamsFinal, vector<Image32F>& allSeamsBuffer, Image32F& seamCosts, uint32 const& cropLeftPos, uint32 const& targetWidth)
{
  uint32 specialWidth = allSeamsFinal[0].width(); // specialWidth equals number of seams
  uint32 bufferWidth = allSeamsBuffer[0].width();
  uint32 height = allSeamsFinal[0].height();
  cout << "specialWidth = " << specialWidth << ", bufferWidth = " << bufferWidth << endl;
  
  vector<seamPair> pairs(specialWidth);				//seamPair is a struct
  Image32F seamMatching(specialWidth, bufferWidth);
  Image32F sort(specialWidth, height);

#if 1
  float costs = 0;
  float average = 0;
							//  |x0,y0|x1,y0|x2,y0|  x = seams from first frame
  for(uint32 y = 0; y < bufferWidth; y++)		//  |x0,y1|x1,y1|x2,y1|  y = seams from second frame
    for(uint32 x = 0; x < specialWidth; x++)  		//  |x0,y2|x1,y2|x2,y2|
      {
	for(uint32 i = 0; i < height; i++) // go through the pixels of the seams
	      costs += abs( (allSeamsFinal[firstFrame])(x,i) - (allSeamsBuffer[secondFrame])(y,i) );
	seamMatching(x,y) = costs;
	costs = 0;
      }

  vector<float> values; // insert all relevant values of the seams in values
  for(uint32 y = 0; y < bufferWidth; y++)
      values.push_back(seamCosts(y, secondFrame));
  
      
  normalizeVector(values);	// sort and normalize values
  normalize32FHalf(seamMatching);
  
  for(uint32 y = 0; y < bufferWidth; y++)
    for(uint32 x = 0; x < specialWidth; x++)
    {
#if 0
      if(values[y] < 300)
      cout << "DEBUG y = " << y << ", x = " << x << ", costs = " << seamMatching(x,y)  << ", seamCosts = " << values[y] << endl;
#endif
      seamMatching(x,y) += values[y];
    }
    
  for(uint32 n = 0; n < specialWidth; n++) // n is number of seam pairs
  {
    pairs[n].Nr1 = specialWidth-1;
    pairs[n].Nr2 = bufferWidth-1;
    pairs[n].cost = 99999999;
    
    for(uint32 s1 = 0; s1 < specialWidth; s1++) // s1 = x (position from previous frame), s2 = y (position current frame)
    {
      for(uint32 s2 = 0; s2 < bufferWidth; s2++)
	if(seamMatching(s1,s2) < pairs[n].cost)
	{
	    pairs[n].Nr1 = s1;
	    pairs[n].Nr2 = s2;
	    pairs[n].cost = seamMatching(s1,s2);
	}
    }

    average += pairs[n].cost;

    for(uint32 y = 0; y < bufferWidth; y++)
	seamMatching(pairs[n].Nr1, y) = 99999999; 
      
    for(uint32 x = 0; x < specialWidth; x++)
	seamMatching(x, pairs[n].Nr2) = 99999999; 
	

    // sort the seams so that the pairs are at the same position in allSeamsFinal
    for(uint32 y = 0; y < height; y++)
	sort(pairs[n].Nr1, y) = allSeamsBuffer[secondFrame](pairs[n].Nr2,y);
    
    //cout << "costs =" << pairs[n].cost << endl;
  } 
   cout << "Durchschnitt: " << average/specialWidth << endl;
#endif

#if 0 
  // the x positions of the seams in the first row are compared and the leftmost are paired respectively 
  uint32 minA = 10000;
  uint32 minB = 10000;
  uint32 minPosA = 10000;
  uint32 minPosB = 10000;
  float atLeastA = -1;
  float atLeastB = -1;
  float distance = 0;
  
  for(uint32 n = 0; n < specialWidth; n++)
  {
     for(uint32 i = 0; i < specialWidth; i++)
     {
	if((allSeamsFinal[seamsFirstFrame](i,0) < minA) && (allSeamsFinal[seamsFirstFrame](i,0) > atLeastA))
	{ 
	  minA = allSeamsFinal[seamsFirstFrame](i,0);
	  minPosA = i;
	}
	
	if((allSeamsFinal[seamsSecondFrame](i,0) < minB) && (allSeamsFinal[seamsSecondFrame](i,0) > atLeastB))
	{  
	  minB = allSeamsFinal[seamsSecondFrame](i,0);
	  minPosB = i;
	}
     }
     
    pairs[n].Nr1 = minPosA;
    pairs[n].Nr2 = minPosB;
    atLeastA = minA;
    atLeastB = minB;
    minA = 10000;
    minB = 10000;
    
#if 1
    // sort the seams so that the pairs are at the same position in allSeamsFinal
    for(uint32 y = 0; y < height; y++)
	sort(pairs[n].Nr1, y) = allSeamsFinal[seamsSecondFrame](pairs[n].Nr2,y);
#endif

#if 0
    // sort the seams with additonal distance control
    distance = 0;
    for(uint32 y = 0; y < height; y++)
    {
	sort(pairs[n].Nr1, y) = allSeamsFinal[seamsSecondFrame](pairs[n].Nr2, y);
	distance += abs(allSeamsFinal[seamsFirstFrame](pairs[n].Nr1, y) - allSeamsFinal[seamsSecondFrame](pairs[n].Nr2, y));
    }
    
    //cout << "n = " << n << ", distance = " << distance << endl;
    if( distance > (height * 5))
	for(uint32 h = 0; h < height; h++)
	    sort(pairs[n].Nr1, h) = allSeamsFinal[seamsFirstFrame](pairs[n].Nr1,h);
#endif
  }
  
#endif

  allSeamsFinal[secondFrame] = sort;

}


static void interpolateSeams(uint32 const& firstFrame, uint32 const& secondFrame, vector<Image32F>& allSeamsFinal, vector<Image32F>& allSeamsBuffer, Image32F& seamCosts, uint32 const& cropLeftPos, uint32 const& targetWidth)
{
  uint32 specialWidth = allSeamsFinal[0].width(); // specialWidth equals number of seams
  uint32 height = allSeamsFinal[0].height();
  
  
  uint32 number = abs(secondFrame - firstFrame)-1; 	// number of frames to interpolate
  int counter = 1;
  float factor = 0;

  findSeamPairs(firstFrame, secondFrame, allSeamsFinal, allSeamsBuffer, seamCosts, cropLeftPos, targetWidth);
  
  for(uint32 n = 0; n < specialWidth; n++)	// jeder seam
    for(uint32 pos = 0; pos < height; pos++)	// jede position
    {
      factor = (allSeamsFinal[secondFrame](n, pos) - allSeamsFinal[firstFrame](n, pos) ) / number;
      counter = 1;
      for(uint32 t = firstFrame+1; t < secondFrame; t++) // jedes frames
      {
	allSeamsFinal[t](n, pos) = (uint32) ((allSeamsFinal[firstFrame](n, pos) + factor * counter)+0.5);
	counter++;
      }
    }
}

static void removeSeamsAndSave(deque<Image8U>& video, vector<Image32F>& allSeamsFinal, vector<uint32>& cropLeft, string const& destPath, uint32 const& targetWidth)
{
  deque<Image8U>::iterator it = video.begin();
  uint32 width = it->width();
  uint32 height = it->height();
  uint32 channels = it->channels();
  uint32 t = 0;			// cursor for frame in video
  
  VideoWriter writer(destPath, targetWidth, height);
#if 0
  VideoWriter writer(destPath, width, height);
  Image8U drawImage(width, height, channels);
#endif
  
  writer.setCodec(CODEC_MPEG4);
  //writer.setBitRate(1500000);
  writer.start();
  
  uint32 allSeamsWidth = allSeamsFinal[0].width();
  while (it != video.end())
  {
    //drawImage = (*it);
    
    for(uint32 n = 0; n < allSeamsWidth; n++)
	for(uint32 y = 0; y < height; y++) // removes seams by copying all normal pixels while skipping seam pixels.
	    for(uint32 x = allSeamsFinal[t](n,y); x < width-1; x++)
		for(uint32 c = 0; c < channels; c++)
		    (*it)(x,y,c) = (*it)(x+1,y,c);
	
#if 0
    drawSeams(drawImage, allSeamsFinal[t], cropLeft[t], targetWidth);
    writer.putImage(drawImage);
#endif
#if 0
    if(t == 250)
    {
	IO::saveImage("/home/stud/kiess/Videos/result/drawImage.png", drawImage);
	exit(1);
    }
#endif
     
    writer.putImage(*it);
    t++;
    it++;
  }
  
  writer.stop();
}


#if 1
// perform seam carving and save the modified frames into a video
static void seamCarvAndSaveVideo(deque<Image8U>& video, deque<Image32F>& videoEnergyMap, string const& destPath, vector<uint32>& cropLeft, uint32 const& targetWidth)
{
  deque<Image8U>::iterator itVideo = video.begin();
  uint32 width = itVideo->width();
  uint32 height = itVideo->height();
  uint32 specialWidth = width-targetWidth;
  uint32 bufferWidth = (specialWidth*2) < 40 ? 40 : (specialWidth*2);
  
  deque<Image32F>::iterator itEnergy = videoEnergyMap.begin();
  
  Image32F seamsPerFrame(specialWidth, height);
  vector<Image32F> allSeamsFinal(video.size(), seamsPerFrame);
  
  Image32F seamsBuffer(bufferWidth, height);
  vector<Image32F> allSeamsBuffer(video.size(), seamsBuffer);
  
  Image32F seamCosts(bufferWidth, video.size());
  uint32 t = 0;
  uint32 counter = 0;
  
  findSeamsFrame(*itVideo, *itEnergy, allSeamsFinal, seamCosts, t, counter);
  SeamCarvingImage::clearImage(seamCosts);
  findSeamsFrame(*itVideo, *itEnergy, allSeamsBuffer, seamCosts, t, counter);
  
  while (itVideo != video.end())
  {
    cout << "############### frame = " << t << endl;
    
    if((t % 10 == 0) && (t != 0))
    {
      findSeamsFrame(*itVideo, *itEnergy, allSeamsBuffer, seamCosts, t, counter);
      interpolateSeams(t-counter, t, allSeamsFinal, allSeamsBuffer, seamCosts, cropLeft[t], targetWidth);
      counter = 1;
    }
    else if(itVideo+1 == video.end())
    {
      findSeamsFrame(*itVideo, *itEnergy, allSeamsBuffer, seamCosts, t, counter);
      interpolateSeams(t-counter, t, allSeamsFinal, allSeamsBuffer, seamCosts, cropLeft[t], targetWidth);
    }
    else
    {
      counter++;
    }
    
    t++;
    itVideo++;
    itEnergy++;
  }
  
  removeSeamsAndSave(video, allSeamsFinal, cropLeft, destPath, targetWidth);
}
#endif  

  
//##################################################################################|
//main										    |
//##################################################################################|

int main(int argc, char* argv[])
{
  if (argc != 4) 
    {
      std::cerr << "not enough arguments: \"Video Source\" \"Destination Path\" \"Retarget Factor\" " << std::endl;
      return 1;
    }
  
  try 
    {
      Timing::start();
      
      string srcPath = argv[1]; 
      string destPath = argv[2];
      double retargetFactor = atof (argv[3]);
      
      // load the video to a deque-list consisting of the frames
      cout << "1: load video" << endl;
      deque<Image8U> video;
      loadVideo(srcPath, video);
   
      Image8U frame = video[1];
      int width = frame.width();
      int height = frame.height();
      int targetWidth = retargetFactor * width;
      int importantWidth = (retargetFactor*0.75) * width;
      int frameCount = video.size();
       
      cout << "frame size: " << width << "x" << height << ", target size: " << targetWidth;
      cout << "x" << height  << ", importantWidth = " << importantWidth;
      cout << ", frame count: " << frameCount << endl;
      
      // compute energy and sum up column costs for each frame
      cout << "2: calculate energy and column costs" << endl;
      deque<Image32F> videoEnergyMap;
      computeSaliencyVideo(video, videoEnergyMap);
      
      Image32F costColumnTime(width, frameCount, 1); 
      calculateCostColumTime(videoEnergyMap, costColumnTime);

      // sum the costs in each frame so that each position represents a cropping window in the frame.
      cout << "3: calculate cropping window costs" << endl;
      Image32F costCroppingWindowTime(width - importantWidth + 1, frameCount, 1);
      calculateCostCroppingWindowTime(costColumnTime, costCroppingWindowTime);
      
      // calculate the path with the maximum energy in the cropping windows over time based on seam carving
      cout << "4: build max energy paths" << endl;
      vector<uint32> cropLeft(frameCount);
      calculateMaxEnergyPath(costCroppingWindowTime, cropLeft);
      
      // smooth cropping window path
      cout << "5: smooth cropping window path" << endl;
      smoothSignal(cropLeft);
      
      // adjust energy map 
      cout << "6: adjust energy according to cropping window" << endl;
      adjustSaliencyMapToCroppingWindow(videoEnergyMap, cropLeft, importantWidth);   

      //seam carving part
      cout << "7: seam carv the frames and save them as video" << endl;
      seamCarvAndSaveVideo(video, videoEnergyMap, destPath, cropLeft, targetWidth);

      cout << "video finished" << endl;
      Timing::stopAndPrint();
    }
  catch(MocaException& e)
    {
      cerr << diagnostic_information(e);
    }
}

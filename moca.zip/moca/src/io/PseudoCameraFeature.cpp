#include "io/PseudoCameraFeature.h"



// ==================== PseudoCameraFeature ====================

PseudoCameraFeature::PseudoCameraFeature(Type feature) : CameraFeature(feature)
{
  if(feature == FEATURE_Shutter)
  {
    bIsPresent = true;
	bIsReadable = true;
	bHasValue = true;
	uiMin = 1;
	uiMax = 4095;
	shutterVal = 1024;
  }
}


void PseudoCameraFeature::setValue(uint32 newVal)
{
  if(newVal < uiMin)
    shutterVal = uiMin;
  else if(newVal > uiMax)
    shutterVal = uiMax;
  else
    shutterVal = newVal;
}


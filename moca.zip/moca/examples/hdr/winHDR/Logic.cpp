#include "Logic.h"

#include "filter/CvtColorSpace.h"
#include "filter/HDRStitching.h"
#include "filter/ToneMapping.h"

extern WinHDRStatus* status;


WinHDRStatus::WinHDRStatus()
  : hdrSwitch(false), regSwitch(true), printSwitch(false),
    loadSwitch(false), saveSwitch(false), gTruthSwitch(false)
{
}


HDRFrame::HDRFrame(uint32 width, uint32 height)
  : hdrImage(width, height, 3), displayImage(new Image8U(width, height, 3)),
    captureImage(new Image8U(width, height, 1)), hist(0, 1, 1)
{
}


void HDRFrame::clear()
{
  expSet.clear();
}


void HDRFrame::convertToYxy()
{
  for (uint32 i=0; i<expSet.size(); ++i)
    CvtColorSpace::convert(*expSet[i].image, *expSet[i].image, COLOR_BGR, COLOR_Yxy);
}


void HDRFrame::convertBayerToBGR()
{
  for (uint32 i=0; i<expSet.size(); ++i)
    {
      Exposure& e = expSet[i];
      boost::shared_ptr<Image8U> colImg(new Image8U(e.image->width(), e.image->height(), 3));
      colImg->setTimestamp(e.image->getTimestamp());
      CvtColorSpace::convert(*e.image, *colImg, COLOR_BayerGB, COLOR_BGR);
      e.image = colImg;
    }
}


void HDRFrame::stitchHDR()
{
  HDRStitching::weighted(expSet, hdrImage);
  hist = ToneMapping::histNorm(hdrImage, *displayImage);

  CvtColorSpace::convert(*displayImage, *displayImage, COLOR_Yxy, COLOR_BGR);
}


void HDRFrame::print()
{
  if (!(status->printSwitch && status->hdrSwitch))
    return;
  for (uint32 i=0; i<expSet.size(); ++i)
    std::cout << i << ") " << expSet[i] << std::endl;
  std::cout << std::endl;
}


#ifdef HAVE_CUDA

CudaHDRFrame::CudaHDRFrame(uint32 width, uint32 height)
  : HDRFrame(width, height)
{
}


bool CudaHDRFrame::allocateHandles()
{
  if (expHandles.size() != 0)
    return false;

  expHandles.resize(expSet.size());
  for (uint32 i=0; i<expSet.size(); ++i)
    expHandles[i].allocate(expSet[i].image->width(), expSet[i].image->height(),
                           3, 4, // channels, stride
                           expSet[i].topLeft[0], expSet[i].topLeft[1],
                           expSet[i].shutter, expSet[i].parent);
  return true;
}


void CudaHDRFrame::clear()
{
  expHandles.clear();
  expSet.clear();
}


void CudaHDRFrame::convertToYxy()
{
  bool allocated = allocateHandles();

  for (uint32 i=0; i<expSet.size(); ++i)
    {
      if (allocated)
        {
          CudaImage8UHandle img;
          img.put(*expSet[i].image);
          CudaWrapper::BGRYxy(img, expHandles[i]);
        }
      else
        CudaWrapper::BGRYxy(expHandles[i]);
    }
}


void CudaHDRFrame::convertBayerToBGR()
{
  bool allocated = allocateHandles();
  assert(allocated);
  
  for (uint32 i=0; i<expHandles.size(); ++i)
    {
      CudaImage8UHandle img;
      img.put(*expSet[i].image);
      CudaWrapper::BayerBilinear(img, expHandles[i]);
    }
}


void CudaHDRFrame::stitchHDR()
{
  assert(expHandles.size() == expSet.size());
  assert(hdrImage.width() == displayImage->width() && hdrImage.height() == displayImage->height() &&
         hdrImage.channels() == displayImage->channels());
  uint32 w = hdrImage.width(), h = hdrImage.height(), c = hdrImage.channels();

  CudaImage32FHandle hdrTarget;
  hdrTarget.allocate(w, h, c, c);
  CudaWrapper::stitchHDR(expHandles, hdrTarget);

  CudaImage8UHandle result;
  result.allocate(w, h, c, c);
  hist = GPUToneMapping::histNorm(hdrTarget, result);

  CudaWrapper::YxyBGR(result);

  result.getImage8UData(*displayImage);
}

#endif

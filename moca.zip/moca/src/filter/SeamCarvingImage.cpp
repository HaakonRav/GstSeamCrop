#include "filter/SeamCarvingImage.h"
#include "types/MocaException.h"
#include <math.h>

void SeamCarvingImage::changeWidth(Image8U const& image, Image8U& result, int targetWidth)
{
  Timing::start();
  if (image.width() == 0 || image.height() == 0)
    BOOST_THROW_EXCEPTION(ArgumentException("One of the image dimensions is zero.") << ErrImg1(image));
  if (targetWidth < 1)
    BOOST_THROW_EXCEPTION(ArgumentException("Target width is not valid.") << ErrImg1(image) << ErrInt(targetWidth));
  
  int width  = image.width();
  int height = image.height();
  int channels = image.channels();
  int tmpWidth = width;	// temporary width during computation.
  int maxWidth;		// the maximum of targetWidth and width.
  
  int maxCost = 1;		// maximum cost of a seam in the current image (with initial value).
  int minCost = 100000;	// minimum cost of a seam in the current image (with initial value).
  int minPosition = 1;		// x-position of the minimal cost (with initial value).
  
  if(targetWidth > width)		// sets maxWidth to targetWidth (enlarge width) or width (reduce width).
    maxWidth = targetWidth;
  else 
    maxWidth = width;
  
  Image32F energy(maxWidth, height); 		// stores the gradient-based energy values
  Image32F costWidth(maxWidth, height); 	// stores the minimum summed up energy values for each position
  Image32F predecessors(maxWidth, height); 	// stores the x-position of the optimal predecessor for each position
  Image32F seams(maxWidth, height); 		// stores the positions of the seams (value = -1)
  Image8U tmpImage(maxWidth, height, channels); // temporal image for computation
  Image8U drawImage(maxWidth, height, channels);// --------------------------------------------------
  
  copyWidth(image, tmpImage, width); 
  computeEnergy(tmpImage, energy, tmpWidth);
  computeCostWidth(tmpImage, energy, costWidth, predecessors, tmpWidth);
  getMaxCostWidth(costWidth, maxCost, tmpWidth);
  
  if (targetWidth < width)		// for reduction of image: formula equals width + change factor (size)
    maxWidth = 2*width - targetWidth;
  
  for(int x = width-1; x < maxWidth; x++) // mark seams until threshold, then remove/duplicate and start next iteration until target size is reached.
    {
      getMinCostWidth(costWidth, minCost, minPosition, tmpWidth);  
      if(minCost < 4*maxCost) // ACHTUNG: Angepasst für Beispielbilder #######################
	markSeamWidth(costWidth, energy, predecessors, seams, tmpWidth);
      else
        {
	  if(targetWidth > width)
	    {
	      duplicateSeamsWidth(tmpImage, seams, tmpWidth);
	      tmpWidth = x;
	    }
	  else
	    {
              removeSeamsWidth(tmpImage, seams, tmpWidth);
	      tmpWidth = 2*width - x;	// current size tmpImage: formula equals width - current change factor (size)
	    }                    
	  clearImage(seams);
	  computeEnergy(tmpImage, energy, tmpWidth);
          computeCostWidth(tmpImage, energy, costWidth, predecessors, tmpWidth);
	  getMaxCostWidth(costWidth, maxCost, tmpWidth);
	  markSeamWidth(costWidth, energy, predecessors, seams, tmpWidth);
	}
      minCost = costWidth(tmpWidth-1, height-1);
      computeCostWidth(tmpImage, energy, costWidth, predecessors, tmpWidth);
    }// for
        
  drawSeams(tmpImage, drawImage, seams, tmpWidth);
  if(targetWidth > width)
    duplicateSeamsWidth(tmpImage, seams, tmpWidth);
  else
    removeSeamsWidth(tmpImage, seams, tmpWidth);
      
  std::cout << "target size: " << targetWidth << "x" << height << std::endl;
  copyWidth(tmpImage, result, targetWidth);
  Timing::stopAndPrint();
}


void SeamCarvingImage::computeEnergy(Image8U const& image, Image32F& energy, int width)
{
  int borderTop, borderBottom, borderLeft, borderRight; // these values change the formula if the current position is close to image borders.
  int grad; // gradient: sum of absolute pixel values on all color channels -> grad = (x-1, y) + (x+1, y) + (x, y-1) + (x, y+1).
  int height = image.height();
  int channels = image.channels();

  for (int x=0; x < width; x++)
      for (int y = 0; y < height; y++)
        {
	  borderTop = 1;	// y-1 -> y
	  borderBottom = 1;	// y+1 -> y
	  borderLeft = 1;	// x-1 -> x
	  borderRight = 1; 	// x+1 -> x
	  grad = 0;
	  
	  if (x == 0) // left border: x-1 -> x
	    borderLeft = 0;
	  if (x == width-1) // right border: x+1 -> x
	    borderRight = 0;
	  if (y == 0) // top border: y-1 -> y
	    borderTop = 0; 
	  if (y == height-1) // bottom border: y+1 -> y
	    borderBottom = 0;
	  
	  for(int c = 0; c < channels; c++)
            grad += (abs(image(x + borderRight, y, c) - image(x - borderLeft, y, c))) + (abs(image(x, y + borderBottom, c) - image(x, y - borderTop, c)));
	 
          energy(x,y) = grad;
        }// for y

  /*
// Extra Section to load external saliency map

  string fnSal="/home/stud/kiess/Pictures/Effelsberg/lenna_face.png";

  cerr << "load extra salieny map" << endl;
  boost::shared_ptr<Image8U> salMap;
  try 
    {
	cerr << "read image: " << fnSal << endl;        
	salMap = IO::loadImage(fnSal);
    } 
  catch (MocaException e) 
    {
	std::cout << "read Image error: " << e.what() << std::endl;
	exit (-1);
    }
	
  Image8U saliency = *salMap;
	
  for (int x=0; x < width; x++)
      for (int y = 0; y < height; y++)
        {
          energy(x,y) += 2*saliency(x,y);
        }// for y
*/
  
  
}


void SeamCarvingImage::computeCostWidth(Image8U const& image, Image32F& energy, Image32F& costWidth, Image32F& predecessors, int width)
{
  int height = energy.height();
  
  unsigned int v1 = 0; // predecessor (x-1, y-1)
  unsigned int v2 = 0; // predecessor (x, y-1)
  unsigned int v3 = 0; // predecessor (x+1, y-1)

  //Forward Energy
  int Cl = 0; // predecessor cost left -> Cl = abs( image(x+1, y) - image(x-1,y) ) + abs( image(x, y-1) - image(x-1,y) );
  int Cu = 0; // predecessor cost up -> Cu = abs( image(x+1, y) - image(x-1,y) );
  int Cr = 0; // predecessor cost right ->  Cr = abs( image(x+1, y) - image(x-1,y) ) + abs( image(x, y-1) - image(x+1,y) );


  for (int y = 0; y < height; y++) // find minimum cost of a connected pixel in the previous line and store its x-position in predecessors.
      for (int x = 0; x < width; x++)
          if (y == 0) // top border
              costWidth(x,y) = energy(x,y);
          else if (x == 0) // left border
	    {
	      Cu = abs( image(x+1, y) - image(x,y) );
              Cr = abs( image(x+1, y) - image(x,y) ) + abs( image(x, y-1) - image(x+1,y) );
              v2 = costWidth(x,y-1) + energy(x,y) + Cu;
              v3 = costWidth(x+1,y-1) + energy(x,y) + Cr;
              if(v2 <= v3)
	        {
		  costWidth(x,y) = v2;
		  predecessors(x,y) = x;
		}
	      else 
	        {
		  costWidth(x,y) = v3;
		  predecessors(x,y) = x+1;
		}//if
	    }
	  else if (x == width-1) // right border
	    {
	      Cl = abs( image(x, y) - image(x-1,y) ) + abs( image(x, y-1) - image(x-1,y) );
              Cu = abs( image(x, y) - image(x-1,y) );
	      v1 = costWidth(x-1,y-1) + energy(x,y) + Cl;
	      v2 = costWidth(x,y-1) + energy(x,y) + Cu;
	      if(v2 <= v1)
	        {
		  costWidth(x,y) = v2;
		  predecessors(x,y) = x;
		}
              else
	        {
		  costWidth(x,y) = v1;
		  predecessors(x,y) = x-1;
	        }//if		
	    }
	  else // rest of the matix 
	    {
	      Cl = abs( image(x+1, y) - image(x-1,y) ) + abs( image(x, y-1) - image(x-1,y) );
              Cu = abs( image(x+1, y) - image(x-1,y) );
              Cr = abs( image(x+1, y) - image(x-1,y) ) + abs( image(x, y-1) - image(x+1,y) );
	      v1 = costWidth(x-1,y-1) + energy(x,y) + Cl;
	      v2 = costWidth(x,y-1) + energy(x,y) + Cu;
	      v3 = costWidth(x+1,y-1) + energy(x,y) + Cr;
	      if((v2 <= v1) && (v2 <= v3))
	        {
		  costWidth(x,y) = v2;
		  predecessors(x,y) = x;
		}
	      else if((v1 <= v2) && (v1 <= v3))
	        {
		  costWidth(x,y) = v1;
		  predecessors(x,y) = x-1;
		}
	      else if((v3 <= v1) && (v3 <= v2))
	        {
		  costWidth(x,y) = v3;
		  predecessors(x,y) = x+1;
		}
	      else
	          BOOST_THROW_EXCEPTION(ArgumentException("One of the image dimensions is not valid."));
	    }// if else (y==0)
}


void SeamCarvingImage::markSeamWidth(Image32F& costWidth, Image32F& energy, Image32F& predecessors, Image32F& seams, int width)
{
  int height = costWidth.height();
  int min = costWidth(width-1, height-1); // stores the minimum costs.
  int minPosition = width-1; 		   // stores the x-position of the minumum costs.

  getMinCostWidth(costWidth, min, minPosition, width);
 
  for(int y = height-1; y > -1; y--) // builds the seam backwards beginning in the starting point minPostion and marks the pixels
    {   
      seams(minPosition,y) = -1;     		// -1 marks the seam in seams.
      energy(minPosition,y) = 999999;		// high value prevents next iterations to pick the same pixel.
      minPosition = predecessors(minPosition,y);// get x-position of minimum cost pixel in line y-1.
    }//for
}


void SeamCarvingImage::removeSeamsWidth(Image8U& image, Image32F& seams, int width)
{
  int height = image.height();
  int channels = image.channels();
  int resultX = 0;		// cursor for x-value in image.

  for (int y = 0; y < height; y++) // removes seams by copying all normal pixels while skipping seam pixels.
    {
      for(int x = 0; x < width; x++)
          if(seams(x,y) != -1)
	    {
              for(int c = 0; c < channels; c++)
                  image(resultX,y,c) = image (x,y,c);
              resultX += 1;
            }//if
      resultX = 0;
    }//for y
}


void SeamCarvingImage::duplicateSeamsWidth(Image8U& image, Image32F& seams, int width)
{
  int height = image.height();
  int channels = image.channels();
  int resultX = 0;		// cursor for x-value in tmp image.
  int borderLeft, borderRight; // these values change the interpolation if the current position is close to image borders.
  Image8U tmp = image;

  for (int y = 0; y < height; y++)
    {
      for(int x = 0; x < width; x++)
          if(seams(x,y) != -1)	// no seam pixel -> copy pixel in tmp image.
	    {
              for(int c = 0; c < channels; c++)
                  tmp(resultX,y,c) = image (x,y,c);
              resultX += 1;
            }
          else			// seam pixel -> interpolate a pixel and copy it together with the normal pixel to tmp image.
	    {
	      borderLeft = 1;
	      borderRight = 1;
	      if(x == 0)		// if near the left border -> 0.
		  borderLeft = 0;
	      if(x == width-1)		// if near the right border -> 0.
		  borderRight = 0;
	      for(int c = 0; c < channels; c++)
	        {
		  tmp(resultX,y,c) = (image(x-borderLeft,y,c) + image(x+borderRight,y,c))/2;
		  tmp(resultX+1,y,c) = image(x,y,c);
		}
	      resultX += 2;
	    }//if
      resultX = 0;
    }//for y

  image = tmp;
}


void SeamCarvingImage::copyWidth (Image8U const& image, Image8U& result, int width)
{
  /*
  int height = image.height();
  int channels = image.channels();
  
  for (int y = 0; y < height; y++)
    for(int x = 0; x < width; x++)
      for(int c = 0; c < channels; c++)
        result(x,y,c) = image(x,y,c);
  */  
  Filter::copyImage(image, result, Rect(0, 0, width,image.height()), Vector2D::create(0, 0));
}


void SeamCarvingImage::getMinCostWidth(Image32F& costWidth, int& min, int& minPosition, int width)
{
  int height = costWidth.height();

  for (int x = 0; x < width; x++) // Find the minimal seam cost min in the last row and store its x-position in minPosition
    if(min > costWidth(x,height-1)) 
      {
        min = costWidth(x,height-1);
        minPosition = x;
      }// if
   
#if 0
  if(min < 0)
    cout << "DEBUG SeamCarvingImage min = " << min << endl;
#endif
}


void SeamCarvingImage::getMaxCostWidth(Image32F& costWidth, int& max, int width)
{
  int height = costWidth.height();
  max = costWidth(width-1, height-1);

  for (int x = 0; x < width; x++) // Find the maximum seam cost max in the last row
    if(max < costWidth(x,height-1)) 
      max = costWidth(x,height-1);
}


void SeamCarvingImage::clearImage(Image32F& image)
{
  int width = image.width();
  int height = image.height();
  
  for (int y = 0; y < height; y++)
    for(int x = 0; x < width; x++)
        image(x,y) = 0;
}


void SeamCarvingImage::drawSeams(Image8U& image, Image8U& drawImage, Image32F& seams, int width)
{
  int height = image.height();
  int channels = image.channels();

  for (int y = 0; y < height; y++) // Changes the color of each seam pixel
      for(int x = 0; x < width; x++)
          if(seams(x,y) != -1)
            for(int c = 0; c < channels; c++)
		drawImage(x,y,c) = image(x,y,c);
            else
	      {
	        drawImage(x,y,0) = 0;
		drawImage(x,y,1) = 0;
		drawImage(x,y,2) = 255;
	      }
	  
// ----------------------------------------------------
// Debug -> direct saving to disk
// ----------------------------------------------------
  try 
    {
      std::cerr << "save image" << std::endl;        
      IO::saveImage("/home/stud/kiess/Pictures/test_draw.png", drawImage); 
    } 
  catch (MocaException e) 
    {
      std::cout << "save Image error: " << e.what() << std::endl;
      exit (-1);
    }  
// ----------------------------------------------------
}

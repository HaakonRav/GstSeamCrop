#include "filter/DisparityMapBuilder.h"

using namespace cv;
using namespace std;

void DisparityMapBuilder::split_vertical(IplImage* img, IplImage* left_eye_view, IplImage* right_eye_view)
{
  //Create Left Eye Image
  cvSetImageROI(img, cvRect( 0, 0, (img->width)/2, (img->height) ) );
  cvCopy(img, left_eye_view);
  cvResetImageROI( img );

  //Create Right Eye Image
  cvSetImageROI(img, cvRect( (img->width)/2, 0, (img->width)/2, img->height));
  cvCopy(img, right_eye_view);
  cvResetImageROI( img );
}

//Block Matching
void DisparityMapBuilder::buildDisparityMapBM(Image8U const& img, Image8U& dest)
{
  IplImage* source = cvCreateImage(cvSize(img.width(), img.height()), IPL_DEPTH_8U, 3);
  cvCopy(img.image, source);
  
  IplImage* left_eye_view = cvCreateImage(cvSize(img.width()/2, img.height()), IPL_DEPTH_8U, 3);
  IplImage* right_eye_view = cvCreateImage(cvSize(img.width()/2, img.height()), IPL_DEPTH_8U, 3);
  
  split_vertical(source, left_eye_view, right_eye_view);
  
  IplImage* gray_left = cvCreateImage(cvSize(img.width()/2, img.height()), IPL_DEPTH_8U, 1);
  IplImage* gray_right = cvCreateImage(cvSize(img.width()/2, img.height()), IPL_DEPTH_8U, 1);
  
  //convert images to gray images as the algorithm expects gray scale images
  cvCvtColor(left_eye_view, gray_left, CV_BGR2GRAY);
  cvCvtColor(right_eye_view, gray_right, CV_BGR2GRAY);
  
  Mat mat_left  = gray_left;
  Mat mat_right = gray_right;

  Size size = cvGetSize(gray_left);
  
  //create the image in which to save the disparities
  Mat imgDisparity16S = Mat( mat_left.rows, mat_left.cols, CV_16S );
  Mat imgDisparity8U = Mat( mat_left.rows, mat_left.cols, CV_8UC2 );
  
  // calculate the number of disparities
  int numOfDisp;
  if( (size.width/32) % 16 == 0)
    numOfDisp = (size.width/32);
  else
    numOfDisp = ((size.width/32)) + (16-(size.width/32) % 16); 
  
  // size of the block window; must be odd
  int SADWindowSize = 19;       


  // call the constructor for StereoBM
  StereoBM sbm( StereoBM::BASIC_PRESET, numOfDisp, SADWindowSize );
  
  // calculate the disparity image
  sbm( mat_left, mat_right, imgDisparity16S, CV_16S );

  // check its extreme values
  double minVal; double maxVal;

  minMaxLoc( imgDisparity16S, &minVal, &maxVal );
  
  // convert it into a CV_8UC2 image
  imgDisparity16S.convertTo( imgDisparity8U, CV_8UC2, 255/(maxVal - minVal));

  //remove small depth regions and increase more confident regions
  cv::erode(imgDisparity8U, imgDisparity8U, 0, Point(-1, -1), 5);
  cv::dilate(imgDisparity8U, imgDisparity8U, 0, Point(-1, -1), 8);
  
  //*dest.image = imgDisparity8U; 
  for(int j=0; j<imgDisparity8U.size().height; j++)
    for(int i=0; i<imgDisparity8U.size().width; i++)
      dest(i, j) = imgDisparity8U.at<uchar>(j,i);
  
  
  cvReleaseImage(&gray_left);
  cvReleaseImage(&gray_right);
  cvReleaseImage(&source);
  cvReleaseImage(&left_eye_view);
  cvReleaseImage(&right_eye_view);
}

//Semi Global Block Matching
void DisparityMapBuilder::buildDisparityMapSGBM(Image8U const& img, Image8U& dest)
{
  IplImage* source = cvCreateImage(cvSize(img.width(), img.height()), IPL_DEPTH_8U, 3);
  cvCopy(img.image, source);
  
  IplImage* left_eye_view = cvCreateImage(cvSize(img.width()/2, img.height()), IPL_DEPTH_8U, 3);
  IplImage* right_eye_view = cvCreateImage(cvSize(img.width()/2, img.height()), IPL_DEPTH_8U, 3);
  
  split_vertical(source, left_eye_view, right_eye_view);
  
  IplImage* gray_left = cvCreateImage(cvSize(img.width()/2, img.height()), IPL_DEPTH_8U, 1);
  IplImage* gray_right = cvCreateImage(cvSize(img.width()/2, img.height()), IPL_DEPTH_8U, 1);
  
  //convert images to gray images as the algorithm expects gray scale images
  cvCvtColor(left_eye_view, gray_left, CV_BGR2GRAY);
  cvCvtColor(right_eye_view, gray_right, CV_BGR2GRAY);

  Size size = cvGetSize(gray_left);

  Mat mat_left  = gray_left;
  Mat mat_right = gray_right;

  int SADWindowSize = 3; //size of the block window

  int numOfDisp;

  //calculate number of disparities
  if( (size.width/32) % 16 == 0)
    numOfDisp = (size.width/32);
  else
    numOfDisp = ((size.width/32)) + (16-(size.width/32) % 16);
    
  StereoSGBM sgbm;
          
  //set state for stereo sgbm algorithm
  sgbm.preFilterCap = 63;
  sgbm.SADWindowSize = SADWindowSize;

  int cn = mat_left.channels();

  sgbm.P1 = 8*cn*sgbm.SADWindowSize*sgbm.SADWindowSize;
  sgbm.P2 = 32*cn*sgbm.SADWindowSize*sgbm.SADWindowSize;
  sgbm.minDisparity = 0;
  sgbm.numberOfDisparities = numOfDisp;
  sgbm.uniquenessRatio = 10;
  sgbm.speckleWindowSize = 100;
  sgbm.speckleRange = 32;
  sgbm.disp12MaxDiff = 1;
  sgbm.fullDP = 1;
    
  //images for the disparity map
  Mat imgDisparity16S;
  Mat imgDisparity8U;

  //compute disparity map
  sgbm(mat_left, mat_right, imgDisparity16S);

  // check its extreme values
  double minVal; double maxVal;

  minMaxLoc( imgDisparity16S, &minVal, &maxVal );

  //convert the disparity map to a CV_8U image
  imgDisparity16S.convertTo(imgDisparity8U, CV_8U, 255/(maxVal + minVal));

  //remove small depth regions and increase more confident regions
  cv::erode(imgDisparity8U, imgDisparity8U, 0, Point(-1, -1), 5);
  cv::dilate(imgDisparity8U, imgDisparity8U, 0, Point(-1, -1), 8);
  
  //*dest.image = imgDisparity8U; 
  for(int j=0; j<imgDisparity8U.size().height; j++)
    for(int i=0; i<imgDisparity8U.size().width; i++)
      dest(i, j) = imgDisparity8U.at<uchar>(j,i);
  
  //cleanup
  imgDisparity16S.~Mat();
  mat_left.~Mat();
  mat_right.~Mat();
  sgbm.~StereoSGBM();
  imgDisparity8U.~Mat();
  
  cvReleaseImage(&gray_left);
  cvReleaseImage(&gray_right);
  cvReleaseImage(&source);
  cvReleaseImage(&left_eye_view);
  cvReleaseImage(&right_eye_view);
}

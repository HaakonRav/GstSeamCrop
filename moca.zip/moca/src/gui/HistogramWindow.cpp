#include "gui/HistogramWindow.h"

#ifdef HAVE_LIBFLTK

#include "filter/Filter.h"
#include "feature/Feature.h"
#include "tools/Drawing.h"


HistogramWindow::HistogramWindow(int32 x, int32 y, int32 w, int32 h)
  : Fl_Double_Window(x, y, w, h, "Histogram")
{
  Fl::visual(FL_DOUBLE|FL_INDEX);

  histogram.resize(256);
  histImage = boost::shared_ptr<Image8U>(new Image8U(histogram.size(), 200, 1));
  Filter::set(*histImage, 255);
}


HistogramWindow::~HistogramWindow()
{
}


void HistogramWindow::computeHist(Image8U const& source)
{
  assert(source.channels() == 1);
  Feature::computeHist(source, histogram, 6400);

  int32 bins = histogram.size();
  for (int32 bin=0; bin<bins; ++bin)
    {
      int32 barHeight = histogram[bin];
      //std::cout << bin << ":" << barHeight << std::endl;
      barHeight = barHeight>200 ? 200 : barHeight;
      Drawing::drawLine(*histImage, Vector2D::create(bin, 200), Vector2D::create(bin, 200-barHeight), 1, Color(0,0,0));
      Drawing::drawLine(*histImage, Vector2D::create(bin, 200-barHeight), Vector2D::create(bin, 0), 1, Color(255,255,255));
    }
  redraw();
}


void HistogramWindow::draw()
{
  fl_draw_image_mono((uchar*)(histImage->ptr()), 0, 0, histImage->width(), histImage->height(), histImage->channels(), histImage->widthStep());
}

#endif // HAVE_LIBFLTK

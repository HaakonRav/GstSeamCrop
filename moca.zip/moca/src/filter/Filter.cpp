#include "filter/Filter.h"
#include "feature/Feature.h"
#include "types/CameraImage.h"
#include "types/MocaException.h"
#include <typeinfo>
#include <iostream>
#include <math.h>


void Filter::adaptiveThreshold(ImageBase const& image, ImageBase& result, int32 windSize)
{
  if ((image.width() != result.width()) || (image.height() != result.height()) || (image.channels() != 1) || (result.channels() != 1))
    BOOST_THROW_EXCEPTION(ArgumentException("Image parameters don't match.") << ErrImg1(image) << ErrImg2(result));
  if (windSize % 2 != 1 || windSize < 3)
    BOOST_THROW_EXCEPTION(ArgumentException("Window size must be an odd number starting from 3."));
  if(typeid(image) == typeid(CameraImage) || typeid(result) == typeid(CameraImage))
    BOOST_THROW_EXCEPTION(ArgumentException("CameraImages can't be passed to this OpenCV filter."));

  cvAdaptiveThreshold(image.image, result.image, 255, CV_ADAPTIVE_THRESH_GAUSSIAN_C, CV_THRESH_BINARY, windSize, -2); //-5);
  cvDilate(result.image, result.image, 0, 1);
  cvErode(result.image, result.image, 0, 1);
}


// computes the gradients with pixel differences and _not_ some derivative operator like sobel
void Filter::computeGradients(Image32F const& image, Image32F& orientations, Image32F& magnitudes)
{
  if (image.width() == 0 || image.height() == 0)
    BOOST_THROW_EXCEPTION(ArgumentException("One of the image dimensions is zero.") << ErrImg1(image));
  if (image.channels() != 1)
    BOOST_THROW_EXCEPTION(ArgumentException("Image must be one channel.") << ErrImg1(image));
  if (!image.matchingParams(orientations) || !image.matchingParams(magnitudes))
    BOOST_THROW_EXCEPTION(ArgumentException("Image parameters don't match.") << ErrImg1(orientations) << ErrImg2(magnitudes));

  unsigned int width  = image.width();
  unsigned int height = image.height();

  for (unsigned int y=0; y<height-1; ++y)
    for (unsigned int x=0; x<width-1; ++x)
      {
        double dx = image(x+1, y) - image(x, y);
        double dy = image(x, y+1) - image(x, y);
	
        // when using this pay attention to the for-loops!
        //double dx = image(x+1, y) - image(x-1, y);
        //double dy = image(x, y+1) - image(x, y-1);

        orientations(x,y) = (float)(M_PI + atan2(dy, dx));
        magnitudes(x,y) = (float)(sqrt(dx*dx + dy*dy));
      }

  for (unsigned int y=0; y<height; ++y)
    orientations(width-1, y) = magnitudes(width-1, y) = 0;
  for (unsigned int x=0; x<width-1; ++x)
    orientations(x, height-1) = magnitudes(x, height-1) = 0;
}


void Filter::derivative(ImageBase const& image, ImageBase& result, uint32 hOrder, uint32 vOrder, uint32 maskSize)
{
  if (maskSize%2 == 0 || maskSize > 7 || maskSize < 3)
    BOOST_THROW_EXCEPTION(ArgumentException("Invalid mask size for derivative computation."));
  if ((image.width() != result.width()) || (image.height() != result.height()))
    BOOST_THROW_EXCEPTION(ArgumentException("Image sizes or channels don't match.") << ErrImg1(image) << ErrImg2(result));
  if (image.channels() != result.channels())
    BOOST_THROW_EXCEPTION(ArgumentException("Number of image channels must be equal.") << ErrImg1(image) << ErrImg2(result));
  if(typeid(image) == typeid(CameraImage) || typeid(result) == typeid(CameraImage))
    BOOST_THROW_EXCEPTION(ArgumentException("CameraImages can't be passed to this OpenCV filter."));

  cvSobel(image.image, result.image, hOrder, vOrder, maskSize);
}


void Filter::warpAffine(ImageBase const& image, ImageBase& result, Matrix const& transMat, bool inverse)
{
  if((transMat.size1() != 2) || (transMat.size2() != 3))
    BOOST_THROW_EXCEPTION(ArgumentException("Invalid matrix size."));
  if(typeid(result) == typeid(CameraImage))
    BOOST_THROW_EXCEPTION(ArgumentException("Can't write to CameraImages"));

  CvMat* cvMat = cvCreateMat(transMat.size1(), transMat.size2(), CV_32FC1);
  for (unsigned int row=0; row<transMat.size1(); ++row)
    for (unsigned int col=0; col<transMat.size2(); ++col)
      cvSetReal2D(cvMat, row, col, transMat(row,col));
  cvWarpAffine(image.image, result.image, cvMat, CV_INTER_LINEAR+CV_WARP_FILL_OUTLIERS+(inverse?0:CV_WARP_INVERSE_MAP));
  cvReleaseMat(&cvMat);
}


void Filter::warpImage(ImageBase const& image, ImageBase& result, Matrix const& transMat, bool inverse)
{
  if ((transMat.size1() < 2) || (transMat.size1() > 3) || (transMat.size2() != 3))
    BOOST_THROW_EXCEPTION(ArgumentException("Invalid matrix size."));

  if (transMat.size1() == 2)
  {
    warpAffine(image, result, transMat, inverse);
  }
  else
  {
    Image8U *res = dynamic_cast<Image8U *>(&result);
 
    if(res == NULL)
      BOOST_THROW_EXCEPTION(ArgumentException("projective transformation requires 8-bit grayscale images") << ErrImg1(image) << ErrImg2(result));
    if(inverse)
      BOOST_THROW_EXCEPTION(ArgumentException("inverted projective transformation not implmented"));
        
    warpPerspective(image, *res, transMat);
  }
}


void Filter::warpPerspective(ImageBase const& image, Image8U& result, Matrix const& transMat)
{
  if(image.depth() != IPL_DEPTH_8U)
    BOOST_THROW_EXCEPTION(ArgumentException("projective transformation requires 8-bit grayscale images") << ErrImg1(image) << ErrImg2(result));
  if((image.channels() != 1) || (result.channels() != image.channels()))
    BOOST_THROW_EXCEPTION(ArgumentException("Invalid image format"));
  if((transMat.size1() != 3) || (transMat.size2() != 3))
    BOOST_THROW_EXCEPTION(ArgumentException("Invalid matrix size."));

  int const w1 = image.width(), w2 = result.width();
  int const h1 = image.height(), h2 = result.height();
  //cvSet(result.pImpl->image, cvScalar(0));
  
  Image8U const* src8U = dynamic_cast<Image8U const*>(&image);
  CameraImage const* srcCam = dynamic_cast<CameraImage const*>(&image);
  if(src8U == NULL || srcCam == NULL)
    BOOST_THROW_EXCEPTION(ArgumentException("only Image8U and CameraImage are supported as source image"));

  double m00, m01, m02, m10, m11, m12, m20, m21, m22;
  m00 = transMat(0,0); m01 = transMat(0,1); m02 = transMat(0,2);
  m10 = transMat(1,0); m11 = transMat(1,1); m12 = transMat(1,2);
  m20 = transMat(2,0); m21 = transMat(2,1); m22 = transMat(2,2);

  for (int y=0; y<h2; ++y)
    for (int x=0; x<w2; ++x)
      {
        double xt, yt, t, value;
        xt  = x * m00 + y * m01 + m02;
        yt  = x * m10 + y * m11 + m12;
        t   = x * m20 + y * m21 + m22;
        if (t == 0)
          continue;
        xt /= t;
        yt /= t;
        if ((xt < 0) || (yt < 0) || (xt >= w1-2) || (yt >= h1-2))
          continue;
	    
        if(src8U != NULL)
          Feature::pixelBilerp(*src8U, value, xt, yt);
        else
          Feature::pixelBilerp(*srcCam, value, xt, yt);
        result(x, y) = (uint8)value;
      }
}


void Filter::copyImage(ImageBase const& source, ImageBase &dest, Rect const& area, VectorI const& target)
{
  if(target.size() != 2)
    BOOST_THROW_EXCEPTION(ArgumentException("Expected a two-dimensional vector as position"));
  if(area.x < 0 || area.y < 0 || area.w < 0 || area.h < 0 || (area.x+area.w) > (int32)source.width() || (area.y+area.h) > (int32)source.height())
    BOOST_THROW_EXCEPTION(ArgumentException("Illegal source position for copy operation") << ErrRect(area) << ErrImg1(source));
  if(target[0] < 0 || target[1] < 0 || (target[0]+area.w) > (int32)dest.width() || (target[1]+area.h) > (int32)dest.height())
    BOOST_THROW_EXCEPTION(ArgumentException("Illegal destination position for copy operation") << ErrRect(area) << ErrImg1(dest));
  if(source.channels() != dest.channels())
    BOOST_THROW_EXCEPTION(ArgumentException("Number of channels doesn't match") << ErrImg1(source) << ErrImg2(dest));
  if(source.image->depth != dest.image->depth)
    BOOST_THROW_EXCEPTION(ArgumentException("Images must be of the same color depth."));
  if(typeid(dest) == typeid(CameraImage))
    BOOST_THROW_EXCEPTION(ArgumentException("Can't write to CameraImages"));

  uint32 bpp = 0; // bytes-per-pixel
  switch(source.image->depth)
  {
  case IPL_DEPTH_8U:
    bpp = 1;
    break;
  case IPL_DEPTH_16S:
    bpp = 2;
    break;
  case IPL_DEPTH_32F:
    bpp = 4;
    break;
  default:
    BOOST_THROW_EXCEPTION(ArgumentException("Unsupported source image type") << ErrImg1(source));
  }
    
  for(int32 lineOffset = 0; lineOffset < area.h; lineOffset++)
  {
    int32 srcOffset = source.widthStep()*(area.y+lineOffset);
    srcOffset += area.x*bpp*source.channels();

    int32 dstOffset = dest.widthStep()*(target[1]+lineOffset);
    dstOffset += target[0]*bpp*dest.channels();
   
    memcpy(dest.ptr() + dstOffset, source.ptr() + srcOffset, area.w*bpp*source.channels());
  }
}


void Filter::copyImage(ImageBase const& source, ImageBase& dest, VectorI const& target)
{
  if(target.size() != 2)
    BOOST_THROW_EXCEPTION(ArgumentException("Expected a two-dimensional vector as position"));
  
  copyImage(source, dest, Rect(0, 0, source.width(), source.height()), target);
}


void Filter::canny(ImageBase const& image, ImageBase& result, double thresh1, double thresh2)
{
  if(!image.matchingParams(result))
    BOOST_THROW_EXCEPTION(ArgumentException("Image parameters do not match."));
  if(typeid(image) == typeid(CameraImage) || typeid(result) == typeid(CameraImage))
    BOOST_THROW_EXCEPTION(ArgumentException("CameraImages can't be passed to this OpenCV filter."));

  cvCanny(image.image, result.image, thresh1, thresh2, 3);
}


void Filter::closing(ImageBase const& image, ImageBase& result, int maskSize)
{
  if(!image.matchingParams(result))
    BOOST_THROW_EXCEPTION(ArgumentException("Image parameters do not match."));
  if(typeid(image) == typeid(CameraImage) || typeid(result) == typeid(CameraImage))
    BOOST_THROW_EXCEPTION(ArgumentException("CameraImages can't be passed to this OpenCV filter."));
    
  IplImage* temp = cvCreateImage(cvSize(image.width(), image.height()), image.image->depth, image.channels());
  cvDilate(image.image, temp, 0, maskSize);
  cvErode(temp, result.image, 0, maskSize);
  cvReleaseImage(&temp);
}


void Filter::dilate(ImageBase const& image, ImageBase& result, int maskSize)
{
  if(!image.matchingParams(result))
    BOOST_THROW_EXCEPTION(ArgumentException("Image parameters do not match."));
  if(typeid(image) == typeid(CameraImage) || typeid(result) == typeid(CameraImage))
    BOOST_THROW_EXCEPTION(ArgumentException("CameraImages can't be passed to this OpenCV filter."));
    
  cvDilate(image.image, result.image, 0, maskSize);
}


void Filter::erode(ImageBase const& image, ImageBase& result, int maskSize)
{
  if(!image.matchingParams(result))
    BOOST_THROW_EXCEPTION(ArgumentException("Image parameters do not match."));
  if(typeid(image) == typeid(CameraImage) || typeid(result) == typeid(CameraImage))
    BOOST_THROW_EXCEPTION(ArgumentException("CameraImages can't be passed to this OpenCV filter."));
    
  cvErode(image.image, result.image, 0, maskSize);
}


void Filter::floodFill(ImageBase& image, Rect& rect, double& area, VectorI const& seed, Color color)
{
  if(seed.size() != 2)
    BOOST_THROW_EXCEPTION(ArgumentException("Expected a two-dimensional vector as seed position"));
  if(color.isGrayscale())
    BOOST_THROW_EXCEPTION(ArgumentException("Expected a RGB color, not a grayscale value"));
  if(typeid(image) == typeid(CameraImage))
    BOOST_THROW_EXCEPTION(ArgumentException("CameraImages can't be passed to this OpenCV filter."));    

  CvConnectedComp cvComp;
  cvFloodFill(image.image, cvPoint(seed[0], seed[1]), CV_RGB(color[Color::RED], color[Color::GREEN], color[Color::BLUE]), cvScalar(0), cvScalar(0), &cvComp);
  rect.x = cvComp.rect.x;     rect.y = cvComp.rect.y;
  rect.w = cvComp.rect.width; rect.h = cvComp.rect.height;
  area = cvComp.area;
}


void Filter::matchTemplate(ImageBase const& image, ImageBase& result, ImageBase const& templ)
{
  if (image.channels() != templ.channels())
    BOOST_THROW_EXCEPTION(ArgumentException("Search image and template image channels must match."));
  if (result.channels() != 1)
    BOOST_THROW_EXCEPTION(ArgumentException("Result image must be single channel."));
  if (image.image->depth != templ.image->depth || !((image.image->depth == IPL_DEPTH_8U) || (image.image->depth == IPL_DEPTH_32F)))
    BOOST_THROW_EXCEPTION(ArgumentException("Input images must be either both 8U or both 32F."));
  if (result.image->depth != IPL_DEPTH_32F)
    BOOST_THROW_EXCEPTION(ArgumentException("Result image must be 32F."));
  if ((result.width() != image.getRoi().w-templ.width()+1) || (result.height() != image.getRoi().h-templ.height()+1))
    BOOST_THROW_EXCEPTION(ArgumentException("Result image size must be (image.roi.w-templ.w+1) x (image.roi.h-templ.h+1)."));
  if(typeid(result) == typeid(CameraImage))
    BOOST_THROW_EXCEPTION(ArgumentException("Can't write to CameraImages"));
    
  cvMatchTemplate(image.image, templ.image, result.image, CV_TM_CCOEFF_NORMED);
}


void Filter::mul(ImageBase const& image1, ImageBase const& image2, ImageBase& result)
{
  if (!image1.matchingParams(result))
    BOOST_THROW_EXCEPTION(ArgumentException("Image parameters do not match. (image1 and result)") << ErrImg1(image1) << ErrImg2(result));
  if (!image2.matchingParams(result))
    BOOST_THROW_EXCEPTION(ArgumentException("Image parameters do not match. (image2 and result)") << ErrImg1(image2) << ErrImg2(result));
  if(typeid(result) == typeid(CameraImage))
    BOOST_THROW_EXCEPTION(ArgumentException("Can't write to CameraImages"));
    
  cvMul(image1.image, image2.image, result.image);
}


void Filter::opening(ImageBase const& image, ImageBase& result, int maskSize)
{
  if(!image.matchingParams(result))
    BOOST_THROW_EXCEPTION(ArgumentException("Image parameters do not match."));
  if(typeid(image) == typeid(CameraImage) || typeid(result) == typeid(CameraImage))
    BOOST_THROW_EXCEPTION(ArgumentException("CameraImages can't be passed to this OpenCV filter."));    
    
  IplImage* temp = cvCreateImage(cvSize(image.width(), image.height()), image.image->depth, image.channels());
  cvErode(image.image, temp, 0, maskSize);
  cvDilate(temp, result.image, 0, maskSize);
  cvReleaseImage(&temp);
}


void Filter::pyramidDown(ImageBase const& image, ImageBase& result)
{
  if ((image.image->depth != result.image->depth) || (image.channels() != result.channels()) ||
      (image.width()/2 != result.width()) || (image.height()/2 != result.height()))
    BOOST_THROW_EXCEPTION(ArgumentException("Image parameters do not match."));
  if(typeid(result) == typeid(CameraImage))
    BOOST_THROW_EXCEPTION(ArgumentException("Can't write to CameraImages"));
    
  cvPyrDown(image.image, result.image);
}


void Filter::pyramidUp(ImageBase const& image, ImageBase& result)
{
  if ((image.image->depth != result.image->depth) || (image.channels() != result.channels()) ||
      (image.width()*2 != result.width()) || (image.height()*2 != result.height()))
    BOOST_THROW_EXCEPTION(ArgumentException("Image parameters do not match."));
  if(typeid(result) == typeid(CameraImage))
    BOOST_THROW_EXCEPTION(ArgumentException("Can't write to CameraImages"));
    
  cvPyrUp(image.image, result.image);
}


void Filter::resize(ImageBase const& image, ImageBase& result, int32 mode)
{
  if((image.image->depth != result.image->depth) || (image.channels() != result.channels()))
    BOOST_THROW_EXCEPTION(ArgumentException("Image parameters do not match.") << ErrImg1(image) << ErrImg2(result));
  if(typeid(result) == typeid(CameraImage))
    BOOST_THROW_EXCEPTION(ArgumentException("Can't write to CameraImages"));
    
  cvResize(image.image, result.image, mode);
}


void Filter::set(ImageBase& image, double value)
{
  if(typeid(image) == typeid(CameraImage))
    BOOST_THROW_EXCEPTION(ArgumentException("Can't write to CameraImages"));
  if (image.channels() > 4)
    BOOST_THROW_EXCEPTION(ArgumentException("Might not work with images with more than 4 channels..."));
    
  cvSet(image.image, cvScalarAll(value));
}


void Filter::smooth(ImageBase const& image, ImageBase& result, double sigma)
{
  if (!image.matchingParams(result))
    BOOST_THROW_EXCEPTION(ArgumentException("Image parameters do not match.") << ErrImg1(image) << ErrImg2(result));
  if (sigma <= 0)
    BOOST_THROW_EXCEPTION(ArgumentException("Illegal sigma value for smoothing operation."));
  if (typeid(image) == typeid(CameraImage) || typeid(result) == typeid(CameraImage))
    BOOST_THROW_EXCEPTION(ArgumentException("CameraImages can't be passed to this OpenCV filter."));    
    
  cvSmooth(image.image, result.image, CV_GAUSSIAN, 0, 0, sigma);
}


void Filter::sub(ImageBase const& image1, ImageBase const& image2, ImageBase& result)
{
  if (!image1.matchingParams(result))
    BOOST_THROW_EXCEPTION(ArgumentException("Image parameters do not match. (image1 and result)") << ErrImg1(image1) << ErrImg2(result));
  if (!image2.matchingParams(result))
    BOOST_THROW_EXCEPTION(ArgumentException("Image parameters do not match. (image2 and result)") << ErrImg1(image2) << ErrImg2(result));
  if (typeid(result) == typeid(CameraImage))
    BOOST_THROW_EXCEPTION(ArgumentException("Can't write to CameraImages"));
    
  cvSub(image1.image, image2.image, result.image);
}


void Filter::threshold(ImageBase const& image, ImageBase& result, double thresh)
{
  if (image.channels() != 1 || result.channels() != 1)
    BOOST_THROW_EXCEPTION(ArgumentException("Images must be single channel.") << ErrImg1(image) << ErrImg2(result));
  if (image.depth() != result.depth() && result.depth() != 8)
    BOOST_THROW_EXCEPTION(ArgumentException("Result must be 8-bit or have the same depth as the source.") << ErrImg1(image) << ErrImg2(result));
  if (image.width() != result.width() || image.height() != result.height())
    BOOST_THROW_EXCEPTION(ArgumentException("Image parameters do not match.") << ErrImg1(image) << ErrImg2(result));
  if (typeid(result) == typeid(CameraImage))
    BOOST_THROW_EXCEPTION(ArgumentException("Can't write to CameraImages"));
    
  cvThreshold(image.image, result.image, thresh, 255, CV_THRESH_BINARY);
}

template <class Img, typename Pix>
inline void clipTempl(Img const& image, Img& result, Pix const lowClip, Pix const highClip)
{
  if (image.width() != result.width() || image.height() != result.height() || image.depth() != result.depth() || image.channels() != result.channels())
    BOOST_THROW_EXCEPTION(ArgumentException("Image parameters don't match.") << ErrImg1(image) << ErrImg2(result));

  if (lowClip >= highClip)
    BOOST_THROW_EXCEPTION(ArgumentException("lowClip has to be smaller then highClip.") );

  uint32 const width = image.width();
  uint32 const height = image.height();
  uint32 const channels = image.channels();

  for (uint32 y=0; y<height; ++y)
    for (uint32 x=0; x<width; ++x)
      for (uint32 z=0; z<channels; ++z)
        {
          if(image(x, y, z) < lowClip)
            result(x, y, z) = lowClip;
          else if(image(x, y, z) > highClip)
            result(x, y, z) = highClip;
          else
            result(x, y, z) = image (x, y, z);				
        }
}


void Filter::clip(Image8U const& image, Image8U& result, uint32 const lowClip, uint32 const highClip)
{
  clipTempl(image, result, lowClip, highClip);
}


void Filter::clip(Image32F const& image, Image32F& result, float const lowClip, float const highClip)
{
  clipTempl(image, result, lowClip, highClip);
}


void Filter::contrast(Image8U const& image, Image8U& result, double const& cValue)
{
  if (image.width() != result.width() || image.height() != result.height() || image.depth() != result.depth() || image.channels() != result.channels())
    BOOST_THROW_EXCEPTION(ArgumentException("Image parameters don't match.") << ErrImg1(image) << ErrImg2(result));

  if(cValue < -1 || cValue > 1)
    BOOST_THROW_EXCEPTION(ArgumentException("cValue hast to be between -1.0 and 1.0"));

  uint32 const width = image.width();
  uint32 const height = image.height();
  uint32 const channels = image.channels();	

  if (cValue <= 0)
  {
    for (uint32 y=0; y<height; ++y)
      for (uint32 x=0; x<width; ++x)
        for (uint32 z=0; z<channels; ++z)
          {
            double v = image(x, y, z);
            v = v - (128.0 - v) * cValue;
	
            v = std::min(v, 255.0);
            v = std::max(v, 0.0);
            result(x, y, z) = (int) v;
          }
  }
  else
  {
    for (uint32 y=0; y<height; ++y)
      for (uint32 x=0; x<width; ++x)
        for (uint32 z=0; z<channels; ++z)
          {
            double v = image(x, y, z);
            if (v < 128)
              v = v - 128.0 * cValue;
            else
              v = v + 128.0 * cValue;
	
            v = std::min(v, 255.0);
            v = std::max(v, 0.0);
            result(x, y, z) = (int) v;
          }
  }  
}


void Filter::transpose(Image8U const& image, Image8U& result)
{
  if (image.width() != result.width() || image.height() != result.height() || image.depth() != result.depth() || image.channels() != result.channels())
    BOOST_THROW_EXCEPTION(ArgumentException("Image parameters don't match.") << ErrImg1(image) << ErrImg2(result));

  uint32 const width = image.width();
  uint32 const height = image.height();
  uint32 const channels = image.channels();

  for (uint32 y=0; y<height; ++y)
    for (uint32 x=0; x<width; ++x)
      for (uint32 z=0; z<channels; ++z)
        result(x, y, z) = image(y, x, z);
}


void Filter::orFilter(ImageBase const& one, ImageBase const& two, ImageBase& result)
{
  if (one.width() != result.width() || one.height() != result.height() || one.depth() != result.depth() || one.channels() != result.channels())
    BOOST_THROW_EXCEPTION(ArgumentException("Image parameters don't match.") << ErrImg1(one) << ErrImg2(result));
  if (two.width() != result.width() || two.height() != result.height() || two.depth() != result.depth() || two.channels() != result.channels())
    BOOST_THROW_EXCEPTION(ArgumentException("Image parameters don't match.") << ErrImg1(two) << ErrImg2(result));
  if (one.width() != two.width() || one.height() != two.height() || one.depth() != two.depth() || one.channels() != two.channels())
    BOOST_THROW_EXCEPTION(ArgumentException("Image parameters don't match.") << ErrImg1(one) << ErrImg2(two));

  cvOr(one.image, two.image, result.image);
}


void Filter::luminance(Image8U const& image, Image8U& result, double const& value)
{
  if (image.width() != result.width() || image.height() != result.height() || image.depth() != result.depth() || image.channels() != result.channels())
    BOOST_THROW_EXCEPTION(ArgumentException("Image parameters don't match.") << ErrImg1(image) << ErrImg2(result));
  if(value < -1 || value > 1)
    BOOST_THROW_EXCEPTION(ArgumentException("cValue hast to be between -1.0 and 1.0"));

  uint32 const width = image.width();
  uint32 const height = image.height();
  uint32 const channels = image.channels();

  if (value > 0)
    for (uint32 y=0; y<height; ++y)
      for (uint32 x=0; x<width; ++x)
        for (uint32 z=0; z<channels; ++z)
          {
            double v = image(x, y, z);
					
            v += ((255.0-v)/255.0) * 255 * value;
            v = std::min(v, 255.0);
            v = std::max(v, 0.0);
            result(x, y, z) = (int) v;
          }
  else if (value < 0)
    for (uint32 y=0; y<height; ++y)
      for (uint32 x=0; x<width; ++x)
        for (uint32 z=0; z<channels; ++z)
          {
            double v = image(x, y, z);
					
            v += (v/255.0) * 255 * value;
            v = std::min(v, 255.0);
            v = std::max(v, 0.0);
            result(x, y, z) = (int) v;
          }
  else
    result = image;
}


void Filter::inverse(Image8U const& image, Image8U& result)
{
  if (image.width() != result.width() || image.height() != result.height() || image.depth() != result.depth() || image.channels() != result.channels())
    BOOST_THROW_EXCEPTION(ArgumentException("Image parameters don't match.") << ErrImg1(image) << ErrImg2(result));

  uint32 const width = image.width();
  uint32 const height = image.height();
  uint32 const channels = image.channels();

  for (uint32 y=0; y<height; ++y)
    for (uint32 x=0; x<width; ++x)
      for (uint32 z=0; z<channels; ++z)
        result(x, y, z) = (255 - image(x, y, z));
}


void Filter::flip(Image8U const& image, Image8U& result, bool horizontal, bool vertical)
{
  if (image.width() != result.width() || image.height() != result.height() || image.depth() != result.depth() || image.channels() != result.channels())
    BOOST_THROW_EXCEPTION(ArgumentException("Image parameters don't match.") << ErrImg1(image) << ErrImg2(result));

  uint32 const width = image.width();
  uint32 const height = image.height();
  uint32 const channels = image.channels();
	
  if( horizontal && !vertical)
    for (uint32 y=0; y<height; ++y)
      for (uint32 x=0; x<width; ++x)
        for (uint32 z=0; z<channels; ++z)
          result(x, y, z) = image(x, (height-1-y), z);
  else if (vertical && !horizontal)
    for (uint32 y=0; y<height; ++y)
      for (uint32 x=0; x<width; ++x)
        for (uint32 z=0; z<channels; ++z)
          result(x, y, z) = image((width-1-x), y, z);
  else if(vertical && horizontal)
    {
      Image8U tmp = Image8U(result.width(), result.height(), result.channels());
      Filter::flip(image, tmp, true, false);
      Filter::flip(tmp, result, false, true);
    }
  else
    result = image;
}


void Filter::shear(Image8U const& image, Image8U& result, bool left, bool top)
{
  if (image.channels() != result.channels())
    BOOST_THROW_EXCEPTION(ArgumentException("Image channels don't match.") << ErrImg1(image) << ErrImg2(result));
	
  uint32 rHeight = result.height();
  uint32 rWidth = result.width();
  uint32 channels = result.channels();	

  uint32 iHeight = image.height();
  uint32 iWidth = image.width();
  
  uint32 tmpWidth = iWidth;

  Image8U* tmp;

  if (rHeight != iHeight && rWidth != iWidth)
    {
      tmp = new Image8U(rWidth, iHeight, channels);
      tmpWidth = rWidth;
    }
  else if (rHeight != iHeight && rWidth == iWidth)
    tmp = (Image8U*)&image;
  else
    tmp = &result;


  // first shear horizontal
  if (iWidth != rWidth)
    {
      set(*tmp, 0);
    
      double skew = (rWidth-iWidth) / (iHeight-1.0);
      uint32 shear = 0;
	
      for (uint32 x=0; x<iWidth; ++x)
        for (uint32 y=0; y<iHeight; ++y)
          for (uint32 z=0; z<channels; ++z)
            {
              if (left)
                shear = (uint32)(x+(skew*y));
              else
                shear = rWidth - (uint32)(x+(skew*y));

              (*tmp)(shear, y, z) = image(x, y, z);
            }	
    }

  // then shear vertical
  if (iHeight != rHeight)
    {
      set(result, 0);
  
      double skew = (rHeight-iHeight) / (tmpWidth-1.0);
      uint32 shear = 0;
	
      for (uint32 x=0; x<tmpWidth; ++x)
        for (uint32 y=0; y<iHeight; ++y)
          for (uint32 z=0; z<channels; ++z)
            {
              if (top)
                shear = rHeight - (uint32)(y+(skew*x));
              else
                shear = (uint32)(y+(skew*x));

              result(x, shear, z) = (*tmp)(x, y, z);
            }	
    }

  if (rHeight != iHeight && rWidth != iWidth)
    delete tmp;	
}


/// The input has to be in the HSV or Y format.
void Filter::gammaCorrection(Image8U const& image, Image8U& result, double const& gamma)
{
  if (image.width() != result.width() || image.height() != result.height() || image.depth() != result.depth() || image.channels() != result.channels())
    BOOST_THROW_EXCEPTION(ArgumentException("Image parameters don't match.") << ErrImg1(image) << ErrImg2(result));

  if(gamma <= 0)
    BOOST_THROW_EXCEPTION(ArgumentException("gamma has to be bigger than zero"));

  uint32 const width = image.width();
  uint32 const height = image.height();
  uint32 const channels = image.channels();	

  for (uint32 y=0; y<height; ++y)
    for (uint32 x=0; x<width; ++x)
      for (uint32 z=0; z<channels; ++z)
      {
        if (z == (channels-1))
        {
          double v = image(x, y, z);
          v = v / 255.0;
          v = std::pow(v, gamma);
          v = v * 255.0;
	        v = std::min(v, 255.0);
          v = std::max(v, 0.0);
          result(x, y, z) = (int) v;
        }
        else
          result(x, y, z) = image(x, y, z);
      }

}


void Filter::findStereoCorrespondenceBM(Image8U const& left, Image8U const& right, Image16S& disparity, uint32 numDisps)
{
  if (left.width() != right.width() || right.width() != disparity.width())
    BOOST_THROW_EXCEPTION(ArgumentException("Image width doesn't match.") << ErrImg1(left) << ErrImg2(right) << ErrImg2(disparity));
  if (left.height() != right.height() || right.height() != disparity.height())
    BOOST_THROW_EXCEPTION(ArgumentException("Image height doesn't match.") << ErrImg1(left) << ErrImg2(right) << ErrImg2(disparity));
  if (left.channels() != 1 || right.channels() != 1 || disparity.channels() != 1)
    BOOST_THROW_EXCEPTION(ArgumentException("Has to be single-channel.") << ErrImg1(left) << ErrImg2(right) << ErrImg2(disparity));
  if (numDisps % 16 != 0)
    BOOST_THROW_EXCEPTION(ArgumentException("numDisps must be divisible by 16.") << ErrInt(numDisps));
  
  CvStereoBMState* state = cvCreateStereoBMState(CV_STEREO_BM_BASIC, numDisps);
  cvFindStereoCorrespondenceBM(left.image, right.image, disparity.image, state);
  cvReleaseStereoBMState(&state);
}


void Filter::findStereoCorrespondenceSGBM(Image8U const& left, Image8U const& right, Image16S& disparity, uint32 numDisps)
{
  if (left.width() != right.width() || right.width() != disparity.width())
    BOOST_THROW_EXCEPTION(ArgumentException("Image width doesn't match.") << ErrImg1(left) << ErrImg2(right) << ErrImg2(disparity));
  if (left.height() != right.height() || right.height() != disparity.height())
    BOOST_THROW_EXCEPTION(ArgumentException("Image height doesn't match.") << ErrImg1(left) << ErrImg2(right) << ErrImg2(disparity));
  if (left.channels() != right.channels() || disparity.channels() != 1)
    BOOST_THROW_EXCEPTION(ArgumentException("Left and right must have the same number of channels (disparity 1)") << ErrImg1(left) << ErrImg2(right) << ErrImg2(disparity));
  if (numDisps % 16 != 0)
    BOOST_THROW_EXCEPTION(ArgumentException("numDisps must be divisible by 16.") << ErrInt(numDisps));
  
  cv::Mat leftMat(left.image), rightMat(right.image), dispMat(disparity.image);
  cv::StereoSGBM sgbm(0, numDisps, 11); // minDisp, numDisps, windowSize
  sgbm.P1 = 400;
  sgbm.P2 = 1600;
  sgbm.disp12MaxDiff = 10;
  sgbm.uniquenessRatio = 2;
  sgbm.speckleWindowSize = 100;
  sgbm.speckleRange = 32;
  sgbm(leftMat, rightMat, dispMat);
  *disparity.image = (IplImage)dispMat;
}


// ==================== conversion functions ====================

void Filter::convert(ImageBase const& src, ImageBase& dst, bool abs)
{
  if (src.width() != dst.width() || src.height() != dst.height() || src.channels() != dst.channels())
    BOOST_THROW_EXCEPTION(ArgumentException("Image parameters don't match.") << ErrImg1(src) << ErrImg2(dst));

  if (abs)
    cvConvertScaleAbs(src.image, dst.image);
  else
    cvConvertScale(src.image, dst.image);
}


void Filter::convertScale(ImageBase const& src, Image8U& dst)
{
  if (src.width() != dst.width() || src.height() != dst.height() || src.channels() != dst.channels())
    BOOST_THROW_EXCEPTION(ArgumentException("Image parameters don't match.") << ErrImg1(src) << ErrImg2(dst));

  double srcMin, srcMax;
  cvMinMaxLoc(src.image, &srcMin, &srcMax);
  double scale = 255 / (srcMax - srcMin);
  double shift = - srcMin * scale;
  cvConvertScale(src.image, dst.image, scale, shift);
}

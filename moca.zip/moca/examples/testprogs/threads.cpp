#include <iostream>
#include "types/BlockingQueue.h"
#include "tools/Thread.h"
#include "boost/thread/thread.hpp"


class MyThread : public Thread
{
public:
  BlockingQueue<int> input;

protected:
  void doStuff()
  {
    boost::shared_ptr<int> val = input.pop(200);
    if (val == 0)
      {
        std::cout << "." << std::flush;
        return;
      }
    std::cout << *val << std::endl;
  }

  void cleanup()
  {
    std::cout << "Thread stopped!" << std::endl;
  }
};


int main(int argc, char** argv)
{
  MyThread t;
  t.start();

  for (int i=0; i<5; ++i)
    {
      t.input.push(boost::shared_ptr<int>(new int(i)));
	  boost::this_thread::sleep(boost::posix_time::seconds(1)); 
    }

  t.stop();
  return 0;
}

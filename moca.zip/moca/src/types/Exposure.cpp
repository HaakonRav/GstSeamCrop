#include "types/Exposure.h"

#include "types/Image8U.h"


Exposure::Exposure()
  : topLeft(0, 0), shutter(0), direction(TOO_BOTH), parent(0)
{
}


Exposure::Exposure(boost::shared_ptr<Image8U> image, VectorI topLeft, float shutter, CheckedInvalids direction, uint32 parent)
  : image(image), topLeft(topLeft), shutter(shutter), direction(direction), parent(parent)
{
}


Exposure::Exposure(Exposure const& other)
{
  if (other.image != 0)
    image = boost::shared_ptr<Image8U>(new Image8U(*other.image));
  topLeft = other.topLeft;
  shutter = other.shutter;
  direction = other.direction;
  parent = other.parent;
}


std::ostream& operator<<(std::ostream& stream, Exposure const& exp)
{
  stream << "shutter:" << 0.017 + exp.shutter*0.02 << " ROI:(x:" << exp.topLeft[0] << ", y:" << exp.topLeft[1] << ", w:";
  stream << exp.image->width() << ", h:" << exp.image->height() << ") ";
  switch(exp.direction)
    {
    case Exposure::TOO_BRIGHT: stream << " TOO_BRIGHT "; break;
    case Exposure::TOO_DARK: stream << " TOO_DARK "; break;
    case Exposure::TOO_BOTH: stream << " TOO_BOTH "; break;
    }
  stream << " parent:" << exp.parent;
  return stream;
}

#include "filter/HDRStitching.h"

#include <limits>
#include <vector>

#include "tools/Timing.h"
#include "types/Exposure.h"
#include "types/Image32F.h"
#include "types/Image8U.h"
#include "types/MocaException.h"
#include "filter/Filter.h"
#include "feature/Histogram.h"

double const HDRStitching::minRelativeSegmentSize = 0.001;
double const HDRStitching::histogramStepSize = 0.01;
int32 const  HDRStitching::minNumBins = 25;
double const HDRStitching::relativeNumOutliers = 0.02;
double const HDRStitching::smoothingStrength = 1; 

boost::shared_ptr<Image8U> HDRStitching::ghostSegments;


void HDRStitching::linear(std::vector<Exposure> const& exposures, Image32F& result, uint32 brightest)
{
  if (exposures.size() == 0)
    BOOST_THROW_EXCEPTION(ArgumentException("HDR::stitchLinearHDR(): exposures is empty"));

  Timing::reset(4);
  Timing::start(4);

  indexType imgCount = exposures.size();

  int32 w = result.width();
  int32 h = result.height();
  std::vector<std::pair<int32, int32> > imgSizes(imgCount);
  for (indexType i=0; i<imgCount; ++i)
    {
      Exposure const& e = exposures[i];
      imgSizes[i].first = (int32)e.image->width();
      imgSizes[i].second = (int32)e.image->height();
    }

  for (int32 y=0; y<h; ++y)
    for (int32 x=0; x<w; ++x)
      {
        float zero = 0;
	float lowestShutter = 1/zero; // lowest shutter to use in case that all pixels are saturated
	float highestShutter = -1/zero; // highest shutter to use in case that all pixels are black
	uint8 brightestPix = 0, chroX = 0, chroY = 0;
	float shutter = 0;
	for (indexType i=0; i<imgCount; ++i)
	  {
	    Exposure const& e = exposures[i];
	    std::pair<int32, int32> const& size = imgSizes[i];
	    int32 xpos = x-e.topLeft[0];
	    int32 ypos = y-e.topLeft[1];
	    if (ypos < 0 || ypos >= size.second || xpos < 0 || xpos >= size.first)
	      continue;

	    if (e.shutter < lowestShutter)
	      lowestShutter = e.shutter;
	    if (e.shutter > highestShutter)
	      highestShutter = e.shutter;
	      
	    uint8 value = (*(e.image))(xpos, ypos);
	    if (value >= brightestPix && value <= brightest)
	      {
		shutter = e.shutter;
		brightestPix = value;
                if (result.channels() == 3)
                  {
                    chroX = (*(e.image))(xpos, ypos, 1);
                    chroY = (*(e.image))(xpos, ypos, 2);
                  }
	      }
	  }

	if (shutter == 0) // this means that all pixels are saturated
	  {
	    brightestPix = 255;
	    shutter = lowestShutter;
	  }
	if (brightestPix == 0) // this means that the only non-saturated pixels are black (or all pixels are black)
	  {
	    brightestPix = 1;
	    shutter = highestShutter;
	  }

	result(x, y) = brightestPix / shutter;
        if (result.channels() == 3)
          {
            result(x, y, 1) = chroX;
            result(x, y, 2) = chroY;
          }
      }
  Timing::stop(4);
}
  

void HDRStitching::weighted(std::vector<Exposure> const& exposures, Image32F& result)
{
  if (exposures.size() == 0)
    BOOST_THROW_EXCEPTION(ArgumentException("Exposure vector is empty"));
  if (exposures[0].image->channels() != result.channels())
    BOOST_THROW_EXCEPTION(ArgumentException("Number of channels of exposures and result must match.")
                          << ErrImg1(*(exposures[0].image)) << ErrImg2(result));
  
  std::vector<float> weights(256);
  for (uint32 i=0; i<weights.size(); ++i)
    weights[i] = (1-pow(i/127.5-1, 12)) * i;

  uint32 imgCount = exposures.size();
  int32 w = result.width();
  int32 h = result.height();

  for (int32 y=0; y<h; ++y)
    for (int32 x=0; x<w; ++x)
      {
        float summedWeight = 0;
        float pixVal[3] = {0, 0, 0};
		float lowestShut = std::numeric_limits<float>::infinity(), highestShut = -std::numeric_limits<float>::infinity();
        bool tooBright = true;
        for (uint32 i=0; i<imgCount; ++i)
          {
            Exposure const& e = exposures[i];
            int32 xpos = x-e.topLeft[0];
            int32 ypos = y-e.topLeft[1];
	    if (ypos < 0 || ypos >= (int32)e.image->height() || xpos < 0 || xpos >= (int32)e.image->width())
	      continue;
            
            lowestShut = std::min(e.shutter, lowestShut);
            highestShut = std::max(e.shutter, highestShut);
            int32 value = (*e.image)(xpos, ypos);
            tooBright &= (value == 255);
            summedWeight += weights[value];
            pixVal[0] += (value / e.shutter) * weights[value];
            pixVal[1] += (*e.image)(xpos, ypos, 1) * weights[value];
            pixVal[2] += (*e.image)(xpos, ypos, 2) * weights[value];
          }
        // recover from pixels saturated in all exposures
        if (summedWeight == 0)
          {
            pixVal[0] = tooBright ? 255.0 / lowestShut : 1.0 / highestShut;
            pixVal[1] = pixVal[2] = 85;
            summedWeight = 1;
          }
        for (int32 chan=0; chan<result.channels(); ++chan)
          result(x, y, chan) = pixVal[chan] / summedWeight;
      }
}

#include "tools/Maths.h"

void HDRStitching::weightedNoGhosts(std::vector<Exposure> const& exposures, Image32F& result, uint32 brightest, float thresh)
{
  if (exposures.size() == 0)
    BOOST_THROW_EXCEPTION(ArgumentException("Exposure vector is empty"));
  if (exposures[0].image->channels() != result.channels())
    BOOST_THROW_EXCEPTION(ArgumentException("Number of channels of exposures and result must match.")
                          << ErrImg1(*(exposures[0].image)) << ErrImg2(result));
                          
  std::vector<float> weights(256);
  for (uint32 i=0; i<weights.size(); ++i)
    weights[i] = (1-pow(i/(float)128-1, 12));

  uint32 imgCount = exposures.size();
  int32 w = result.width();
  int32 h = result.height();
  Image32F var(w, h);
  
  for (int32 y=0; y<h; ++y)
    for (int32 x=0; x<w; ++x)
      {
        float summedWeight[3] = {0, 0, 0};
        float pixVal[3] = {0, 0, 0};
        for (uint32 i=0; i<imgCount; ++i)
          {
            Exposure const& e = exposures[i];
            int32 xpos = x-e.topLeft[0];
            int32 ypos = y-e.topLeft[1];
	    if (ypos < 0 || ypos >= (int32)e.image->height() || xpos < 0 || xpos >= (int32)e.image->width())
	      continue;
            
            int32 value = (*e.image)(xpos, ypos);
            summedWeight[0] += weights[value];
            pixVal[0] += (value / e.shutter) * weights[value];
            pixVal[1] += (*e.image)(xpos, ypos, 1) * weights[value];
            pixVal[2] += (*e.image)(xpos, ypos, 2) * weights[value];
            
            /*for (uint32 chan=0; chan<result.channels(); ++chan)
              {
                int32 value = (*e.image)(xpos, ypos, chan);
                summedWeight[chan] += weights[value];
                pixVal[chan] += (value / e.shutter) * weights[value];
                }*/
          }
        for (int32 chan=0; chan<result.channels(); ++chan)
          {
            if (summedWeight[0] == 0)
              summedWeight[0] = 1;
            result(x, y, chan) = pixVal[chan] / summedWeight[0];
          }
          
        // calculating the variance image
        float sum = 0;
        float avg = result(x, y, 0);
        if(avg == 0)
          avg = 1;
        for (uint32 i=0; i<imgCount; ++i)
          {
            Exposure const& e = exposures[i];
            int32 xpos = x-e.topLeft[0];
            int32 ypos = y-e.topLeft[1];
            if (ypos < 0 || ypos >= (int32)e.image->height() || xpos < 0 || xpos >= (int32)e.image->width())
              continue;
            
            int32 value = (*e.image)(xpos, ypos);
            float relDiff = (value / e.shutter) / avg;
            sum += relDiff * relDiff * weights[value];            
          }
        var(x, y) = fabs(sum / summedWeight[0] - 1);
      }
 
  int32 ghostW = w / reductionFactor;
  ghostW += (w % reductionFactor == 0 ? 0 : 1); // this ensures that for each pixel in the ghost segment image exists a corresponding block
                                                // in the original image of at least size 1x1
  int32 ghostH = h / reductionFactor;
  ghostH += (h % reductionFactor == 0 ? 0 : 1); // same as above
  
  ghostSegments = boost::shared_ptr<Image8U>(new Image8U(ghostW, ghostH));
  findGhostSegments(var, *ghostSegments, thresh);

  Image8U ghostSegWork(*ghostSegments);   
  for(int32 y = 0; y < ghostH; y++)
    for(int32 x = 0; x < ghostW; x++)
    {
      if(ghostSegWork(x,y) <= 127)
        continue;
    
      Rect region;
      double area;
      Filter::floodFill(ghostSegWork, region, area, Vector2D::create(x,y), Color(0,0,0));
      
      // calculate the corresponding image region
      region.x *= reductionFactor;
      region.y *= reductionFactor;
      region.w *= reductionFactor;
      region.h *= reductionFactor;
      if(region.x + region.w > w)
        region.w = w - region.x;
      if(region.y + region.h > h)
        region.h = h - region.y;
      
      // find the best shutter to use for the current ghost segment
      float bestShutter = (brightest / findBestValue(result,*ghostSegments,region)) * weights[brightest];
      Image32F singleExposure(region.w, region.h, result.channels());
      // create a "LDR"-image from as few exposure as possible
      findBestExposure(exposures, singleExposure, bestShutter, region);
      // copy the "LDR"-image into the HDR-image
      combine(result, singleExposure, var, *ghostSegments, region);
    }

  smoothEdges(result, *ghostSegments, reductionFactor);
}


boost::shared_ptr<Image8U> HDRStitching::getGhostSegments()
{
  return ghostSegments;
}


void HDRStitching::findGhostSegments(Image32F const& varImage, Image8U& result, double threshold)
{
  int32 w = result.width();
  int32 h = result.height();
  double segmentLimit = minRelativeSegmentSize * w * h;

  // create a working copy with reduced size
  Image32F varSmall(w, h);
  Filter::resize(varImage, varSmall);
  
  // compute threshold image
  Filter::threshold(varSmall, result, threshold);
    
  // smear edges
  Filter::dilate(result, result, 3);
  
  // find background (the background will be dark gray (31))
  removeLowAreaSegments(result, 0, 31, 255, segmentLimit);
  
  // remove ghost regions that are too small to be real ghosts (ghost will be light gray (223) and everything else will be background)
  removeLowAreaSegments(result, 255, 223, 31, segmentLimit);
}


void HDRStitching::removeLowAreaSegments(Image8U& image, uint8 oldRegionCol, uint8 newRegionCol, uint8 nonRegionCol, double segmentLimit)
{
  assert(oldRegionCol != newRegionCol && oldRegionCol != nonRegionCol && newRegionCol != nonRegionCol);

  int32 w = image.width();
  int32 h = image.height();
  Color newColor(newRegionCol, newRegionCol, newRegionCol), bgColor(nonRegionCol, nonRegionCol, nonRegionCol);
  
  for(int32 y = 0; y < h; y++)
    for(int32 x = 0; x < w; x++)
    {
      if(image(x,y) != oldRegionCol)
        continue;
        
      VectorI pos = Vector2D::create(x, y);

      Rect region;
      double area;
      Filter::floodFill(image, region, area, pos, newColor); // calculate size of the current region
      
      if(area < segmentLimit)
        Filter::floodFill(image, region, area, pos, bgColor); // remove current region because it's too small
    }
}


float HDRStitching::findBestValue(Image32F const& image, Image8U const& ghostSegments, Rect const& roi)
{
  int32 xEnd = roi.x + roi.w;
  int32 yEnd = roi.y + roi.h;

  // find the minimum and maximum occuring values
  float min = (float)INFINITY, max = (float)-INFINITY;
  for(int32 y = roi.y; y < yEnd; y++)
    for(int32 x = roi.x; x < xEnd; x++)
    {
      if(ghostSegments(x/reductionFactor,y/reductionFactor) <= 127)
        continue;
      float curValue = image(x, y);
      if(curValue < min)
        min = curValue;
      if(curValue > max)
        max = curValue;
    }

  // calculate the histogram
  int32 numBins = (int32)((max-min) / histogramStepSize);
  if(numBins < minNumBins)
    numBins = minNumBins;
    
  Histogram histogram(min, max, numBins);
  int32 numVals = 0;
  for(int32 y = roi.y; y < yEnd; y++)
    for(int32 x = roi.x; x < xEnd; x++)
    {
      if(ghostSegments(x/reductionFactor,y/reductionFactor) <= 127)
        continue;
      histogram.bin(image(x, y)) += 1;
      numVals += 1;
    }
  
  // find the largest valid value if the top x% are outliers
  int32 curNumVals = numVals;
  int32 curIndex = numBins - 1;
  while(curNumVals > (1-relativeNumOutliers)*numVals && curIndex >= 0)
  {
    curNumVals -= (int32)histogram.bin((indexType)curIndex);
    curIndex -= 1;
  }
  
  if(curIndex < 0)
    curIndex = 0;
      
  return (float)histogram.binToValue(curIndex);
}

void HDRStitching::findBestExposure(std::vector<Exposure> const& exposures, Image32F& result, float shutter, Rect const& roi)
{
  uint32 imgCount = exposures.size();
  std::vector<int32> map(imgCount);
  std::vector<int32> good(imgCount);
  std::vector<int32> bad(imgCount);
  
  // virtually seperate the set of exposures into good and bad ones (i.e. with good shutter values and with too high shutter values)
  int32 goodIndex = 0, badIndex = 0;
  for(uint32 i = 0; i < imgCount; i++)
  {
    Exposure const& e = exposures[i];
    if(e.shutter <= shutter)
    {
      good[goodIndex] = i;
      goodIndex += 1;
    }
    else
    {
      bad[badIndex] = i;
      badIndex += 1;
    }
  }
  
  // write the set of good exposures into map (sorted in ascending order)
  for(int32 i = 0; i < goodIndex; i++)
  {
    int32 maxIndex = i;
    for(int32 j = maxIndex+1; j < goodIndex; j++)
      if(exposures[good[j]].shutter > exposures[good[maxIndex]].shutter)
        maxIndex = j;
    
    int32 temp = good[maxIndex];
    good[maxIndex] = good[i];
    good[i] = map[i] = temp;
  }
  // append the set of bad exposures into map (sorted in descending order)
  for(int32 i = 0; i < badIndex; i++)
  {
    int32 minIndex = i;
    for(int32 j = minIndex+1; j < badIndex; j++)
      if(exposures[bad[j]].shutter < exposures[bad[minIndex]].shutter)
        minIndex = j;
    
    int32 temp = bad[minIndex];
    bad[minIndex] = bad[i];
    bad[i] = map[i+goodIndex] = temp;
  }
  
  // construct the resulting HDR image considering only one exposure for each pixel (the exposure are tried in the order in map for each pixel)
  for(int32 y = 0; y < roi.h; y++)
    for(int32 x = 0; x < roi.w; x++)
    {
      uint32 bestExposure = 0;
      int32 xpos = 0, ypos = 0;
      Exposure const* e = NULL;
      while(bestExposure < imgCount)
      {
        e = &exposures[map[bestExposure]];
        xpos = x+roi.x-e->topLeft[0];
        ypos = y+roi.y-e->topLeft[1];
        if (ypos >= 0 && ypos < (int32)e->image->height() && xpos >= 0 && xpos < (int32)e->image->width())
	  break; // at least one image contains data for the current pixel!
	bestExposure += 1;
      }
      
      for(int32 chan = 0; chan < result.channels(); chan++)
      {
        int32 value = (*e->image)(xpos, ypos, chan);
        result(x, y, chan) = value / (chan == 0 ? e->shutter : 1);
      }
    }
}


void HDRStitching::combine(Image32F& result, Image32F const& singleExposure, Image32F const& var, Image8U const& ghostSegments, Rect const& roi)
{
  int32 xEnd = roi.x + roi.w;
  int32 yEnd = roi.y + roi.h;

  for(int32 y = roi.y; y < yEnd; y++)
    for(int32 x = roi.x; x < xEnd; x++)
    {
      if(ghostSegments(x/reductionFactor,y/reductionFactor) <= 127)
        continue;

      for(int32 chan = 0; chan < result.channels(); chan++)
        result(x, y, chan) = singleExposure(x-roi.x, y-roi.y, chan);
    }
}


void HDRStitching::smoothEdges(Image32F& result, Image8U const& ghostSegments, int32 roiSize)
{
  // "horizontal" smoothing
  for(uint32 y = 0; y < ghostSegments.height(); y++)
    for(uint32 x = 1; x < ghostSegments.width(); x++)
    {
      if(ghostSegments(x-1,y) == ghostSegments(x,y))
        continue;
        
      int32 rx = x * reductionFactor;
      int32 ry = y * reductionFactor;
      Rect roi = Rect(rx-roiSize/2, ry, roiSize, reductionFactor);
      result.setRoi(roi);
      Filter::smooth(result, result, smoothingStrength);
    }
    
  // "vertical" smoothing
  for(uint32 x = 0; x < ghostSegments.width(); x++)
    for(uint32 y = 1; y < ghostSegments.height(); y++)
    {
      if(ghostSegments(x,y-1) == ghostSegments(x,y))
        continue;

      int32 rx = x * reductionFactor;
      int32 ry = y * reductionFactor;
      Rect roi = Rect(rx, ry-roiSize/2, reductionFactor, roiSize);
      result.setRoi(roi);
      Filter::smooth(result, result, smoothingStrength);
    }
    
  result.resetRoi();
}


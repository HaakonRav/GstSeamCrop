
// MOCA headers 
#include "types/MocaTypes.h"
#include "types/Image8U.h"
#include "io/IO.h"
#include "types/MocaException.h"
#include "gui/FLTKHeaders.h"
#include "gui/DisplayWindow.h"
#include "filter/SeamCarvingImage.h"
 
// C++ headers 
#include <string>
using namespace std;

class FirstTest : public DisplayWindow
{
  
public:
  
  FirstTest()
    : DisplayWindow(Rect(0, 0, 1024, 1024), "Seam Carving for Images test")
  {
    for (uint32 y=0; y<image->height(); ++y)
      for (uint32 x=0; x<image->width(); ++x)
        (*image)(x, y) = 0;
  }

  void clickedRect(Rect rect)
  {
    for (int y=rect.y; y<rect.h+rect.y; ++y)
      for (int x=rect.x; x<rect.w+rect.x; ++x)
        (*image)(x, y) = 255;
  }
  void show(boost::shared_ptr<Image8U const> img)
  {
    for (int32 c=0; c<img->channels(); ++c)
	    for (uint32 y=0; y<img->height(); ++y)
		  for (uint32 x=0; x<img->width(); ++x)
			(*image)(x, y, c) = (*img)(x, y, c);
  }

  void doStuff()
  {
    showImage(image);
  }
};


int main(int argc, char **argv)
{
	string fnSrc="/home/stud/kiess/Pictures/test/src/lenna_big.png";
	string fnDest="/home/stud/kiess/Pictures/test/lenna_big_sc_normal.png";

	cerr << "test LIBMOCA" << endl;
	boost::shared_ptr<Image8U> srcImage;//, destImage;
	try {
		cerr << "read image: " << fnSrc << endl;        
		srcImage = IO::loadImage(fnSrc);
	} catch (MocaException e) {
		std::cout << "read Image error: " << e.what() << std::endl;
		exit (-1);
	}
	int w = srcImage -> width();
	int h = srcImage -> height();
	int c = srcImage -> channels();
	unsigned int targetSize = w*0.75;
	cerr << "image size: " << w << "x" << h << endl;

	// modify image with seam carving
	Image8U destImage(targetSize, h, c);
	SeamCarvingImage::changeWidth(*srcImage, destImage, targetSize);

	try {
		cerr << "save image" << endl;         
		IO::saveImage(fnDest, destImage); 
	} catch (MocaException e) {
		std::cout << "save Image error: " << e.what() << std::endl;
		exit (-1);
	}  


/* // show image (use FLTK)
#ifdef HAVE_LIBFLTK
	FirstTest win;
	win.show(destImage);
    win.mainLoop();
#endif
*/
	return 0;
}


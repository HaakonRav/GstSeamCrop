#include <iostream>
#include "types/MocaException.h"
#include "io/DC1394Reader_Triggered.h"
#include "io/ImageFileWriter.h"


#ifdef HAVE_CAMERA


#define SPEED CameraReader::SPEED_800
#define COLOR CameraReader::MODE_MONO8


void captureSequence(DC1394Reader_Triggered& cam, std::vector<DC1394ReaderParameters> const& params)
{
  ImageFileWriter writer("sequence", "png");
  writer.start();
  
  std::cout << "\ncapturing sequence" << std::endl;
  cam.captureImages(params);
  for(uint32 i = 0; cam.getNumRemainingImages() > 0; i++)
  {
    std::cout << "retrieving image number " << (i+1) << std::endl;
    DC1394ReaderParameters curParams = cam.getImageParams();
    Image8U img(curParams.roi.w, curParams.roi.h);
    cam.getImage(img);
    writer.putImage(img);
  }

  writer.stop();
}


void recaptureSequence(DC1394Reader_Triggered& cam)
{
  ImageFileWriter writer("recapture", "png");
  writer.start();
  
  std::cout << "\ncapturing sequence again" << std::endl;  
  cam.captureImages();
  for(uint32 i = 0; cam.getNumRemainingImages() > 0; i++)
  {
    std::cout << "retrieving image number " << (i+1) << std::endl;
    DC1394ReaderParameters curParams = cam.getImageParams();
    Image8U img(curParams.roi.w, curParams.roi.h);
    cam.getImage(img);
    writer.putImage(img);
  }

  writer.stop();
}


int main(int argc, char** argv)
{
  try
  {
    std::vector<DC1394ReaderParameters> params;
    DC1394ReaderParameters curParams;
    
    for(uint32 i = 0; i < 8; i++)
    {
      curParams.roi = Rect(0, 0, 640, 480);
      curParams.shutter = 200 * (i+1);
      curParams.gain = -10034;
      params.push_back(curParams);
    }
    
    DC1394Reader_Triggered cam(SPEED, COLOR);
    cam.start();

    captureSequence(cam, params);
    recaptureSequence(cam);

    cam.stop();
  }
  catch(MocaException& e)
  {
    std::cerr << diagnostic_information(e);
  }

  return 0;
}


#else // HAVE_CAMERA


int main(int argc, char** argv)
{
  std::cout << "this example requires a camera." << std::endl;
  return 0;
}

#endif // HAVE_CAMERA


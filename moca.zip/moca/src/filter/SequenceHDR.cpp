#include "filter/SequenceHDR.h"

#ifdef HAVE_LIBDC1394

#include "filter/Filter.h"
#include "types/MocaException.h"
#include "tools/Timing.h"


SequenceHDR::SequenceHDR(boost::shared_ptr<CameraReader> reader, uint32 darkest, uint32 brightest, uint32 minInvalidPerLine, uint32 addDelThreshold)
  : HDR(reader, darkest, brightest, minInvalidPerLine),
    baseShutter(128), numExposures(4), addThreshold(addDelThreshold),
    removeThreshold(addDelThreshold), expFactor(3.0), sequenceChanged(true)
{
  if(addThreshold<removeThreshold)
    BOOST_THROW_EXCEPTION(ArgumentException("addThreshold has to be bigger or equal than removeThreshold."));
  
  seqReader = boost::dynamic_pointer_cast<DC1394Reader_Triggered, CameraReader>(reader);
  std::vector<Exposure> expSet;
  captureHDR(expSet);
}


void SequenceHDR::captureHDR(std::vector<Exposure>& exposures)
{
  Timing::start(7);

  Timing::start(8);
  std::vector<DC1394ReaderParameters> captureParams = createParameterSet(exposures);
  if (sequenceChanged)
    seqReader->captureImages(captureParams);
  else
    seqReader->captureImages();
  std::cout << "Triggering: " << Timing::stop(8) << std::endl;

  std::vector<uint32> tooDark(numExposures), tooBright(numExposures);
  Rect nextRoi = roi;
  
  Timing::reset(9); Timing::reset(10);
  for (uint32 i=0; i<numExposures; ++i)
    {
      // capture
      Timing::start(9);
      boost::shared_ptr<Image8U> tmp(new Image8U(roi.w, roi.h, 1));
      seqReader->getImage(*tmp);
      Timing::stop(9);

      // set ROIs
      Timing::start(10);
      Exposure& curExposure = exposures[i];
      curExposure.image = boost::shared_ptr<Image8U>(new Image8U(nextRoi.w, nextRoi.h, 1));
      Filter::copyImage(*tmp, *curExposure.image, nextRoi, Vector2D::create(0, 0));
      curExposure.topLeft = Vector2D::create(nextRoi.x, nextRoi.y);
      curExposure.parent = std::max<int32>(i-1, 0);
      // exp.shutter was set above
    
      std::vector<Rect> darkRois;
      nextExposureRoi(*curExposure.image, Exposure::TOO_DARK, darkRois, tooDark[i], tooBright[i]);
    
      if (darkRois.size()>=1) {
        nextRoi = darkRois[0];
        nextRoi.x += curExposure.topLeft(0);
        nextRoi.y += curExposure.topLeft(1);
      }
      Timing::stop(10);
    }
  std::cout << "Capturing: " << Timing::sum(9) << std::endl;
  std::cout << "Setting ROIs: " << Timing::sum(10) << std::endl;

  analyzeSeqLength(tooDark, tooBright);

  std::cout << "Entire HDR Capturing: " << Timing::stop(7) << std::endl;
}


std::vector<DC1394ReaderParameters> SequenceHDR::createParameterSet(std::vector<Exposure>& exposures)
{
  exposures.clear();
  exposures.resize(numExposures);
  std::vector<DC1394ReaderParameters> captureParams(numExposures);
  uint32 expValue = baseShutter;
  for (uint32 i=0; i<numExposures; ++i)
    {
      uint32 shutter;
      float gain;
      exposureToShutGain(expValue, shutter, gain, true);
      captureParams[i].roi = roi;
      captureParams[i].shutter = shutter;
      captureParams[i].gain = gain;
      exposures[i].shutter = expValue;
      expValue *= expFactor;
    }
  return captureParams;
}

  
void SequenceHDR::analyzeSeqLength(std::vector<uint32>const& tooDark, std::vector<uint32> const& tooBright)
{
  assert(tooDark.size() > 0 && tooBright.size() > 0);
  sequenceChanged = false;
  
  //analyze adding Images
  if (tooBright[0] > addThreshold && baseShutter > 1) {
    sequenceChanged = true;
    baseShutter /= expFactor;
    numExposures++;
  }
  
  if (tooDark[numExposures-1] > addThreshold &&
     baseShutter * pow(expFactor, numExposures) <= maxGainFact*maxShutter) {
    sequenceChanged = true;
    numExposures++;
  }
  
  //analyze removing Images
  if (numExposures > 1 && tooBright[1] < removeThreshold) {
    sequenceChanged = true;
    baseShutter *= expFactor;
    numExposures--;
  }

  if (numExposures > 1 && tooDark[numExposures-2] < removeThreshold) {
    sequenceChanged = true;
    numExposures--;
  }
}


#endif // HAVE_LIBDC1394


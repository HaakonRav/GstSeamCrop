#ifndef STEREOIO_H
#define STEREOIO_H

#include "types/MocaException.h"
#include "types/MocaTypes.h"
#include "types/Image8U.h"
#include "types/Image16S.h"
#include "types/Image32F.h"
#include "io/VideoReader.h"
#include <string>


class StereoIO
{
 public:
  StereoIO();

  virtual void start() = 0;
  virtual void stop() = 0;
  virtual void loadNext() = 0;
  virtual bool hasMore() = 0;

  uint32 getFrameIndex();
  Image8U getLeft();
  Image8U getRight();
  Image16S getDisparity(); // Right = Left - Disp

  void saveSBS(Image8U const& left, Image8U const& right, std::string const& dir, std::string const& name);
  void saveDisparity(Image16S const& disp, std::string const& dir, std::string const& name);
  void saveOcclusion(Image8U const& occlusion, std::string const& dir, std::string const& name);
  void saveEnergy(Image32F const& energy, std::string const& dir, std::string const& name);

 protected:
  static std::string makeFilename(std::string const& dir, std::string const& name,
                                  int index, int digits, std::string const& ext);

  Image8U left, right;
  Image16S disparity;
  uint32 frameIndex;
};


// Video file, left and right side by side, disparity from OpenCV
class SBSVideoIO : public StereoIO
{
 public:
  SBSVideoIO(std::string filename);

  void start();
  void stop();
  void loadNext();
  bool hasMore();

 private:
  VideoReader vr;
  Image8U frame;
};


// Left and right image files separate, disparity image file
class LRImageIO : public StereoIO
{
 public:
  LRImageIO(std::string dir, std::string leftname, std::string rightname,
            std::string dispname, int digits, std::string ext);

  void start();
  void stop();
  void loadNext();
  bool hasMore();
  
 private:
  std::string dir, leftname, rightname, dispname;
  int digits;
  std::string ext;
};


#endif

#include "io/VideoPPMReader.h"
#include "types/MocaException.h"





// ==================== VideoPPMWriter ====================
 
VideoPPMReader::VideoPPMReader(std::string const& fileName)
  : fileName(fileName), width(0), height(0), currentFrame(0), data(NULL), started(false), endOfVideo(false)
{

}


VideoPPMReader::~VideoPPMReader()
{
  stop();
}
  

void VideoPPMReader::start()
{
  if (started)
    BOOST_THROW_EXCEPTION(IOException(std::string("You have to call stop() before you start again.") + fileName + std::string("'.")));

  file.open(fileName.c_str(), std::ios::in | std::ios::binary);
  if (file.good())
  {
    char mNumber[2];
    int maxValue;

    rmWhiteSpace();
    file.read(mNumber, 2);
    if(mNumber[0] != 'P' || mNumber[1] != '6')
      BOOST_THROW_EXCEPTION(IOException(std::string("Wrong magic Number") + fileName + std::string("'.")));
    rmWhiteSpace();
    while (file.peek() == '#') {
        file.ignore(INT_MAX, '\n');
    }
    rmWhiteSpace();
    file >> width;
    rmWhiteSpace();
    file >> height;
    rmWhiteSpace();
    while (file.peek() == '#') {
        file.ignore(INT_MAX, '\n');
    }
    rmWhiteSpace();
    file >> maxValue;
    if(maxValue > 255)
      BOOST_THROW_EXCEPTION(IOException(std::string("No 8bit Image") + fileName + std::string("'.")));
    file.seekg(std::ios_base::beg);
    if(data == NULL)
      data = new char[width*height*3];
    started = true;
  }
  else
    BOOST_THROW_EXCEPTION(IOException(std::string("Couldn't open video file '") + fileName + std::string("'.")));

}


void VideoPPMReader::stop()
{
  if (file.good())
  {
    file.close();
  }
  if (data != NULL)
  {   
     delete []data;
     data=NULL;
  }
  started = false;
  endOfVideo =false;
  currentFrame = 0;
}


void VideoPPMReader::getImage(Image8U& image)
{
  if (!started)
    BOOST_THROW_EXCEPTION(IOException(std::string("You have to call start() first.") + fileName + std::string("'.")));

  if (file.good())
  { 
    rmHeader();
  
    file.read(data, (width*height*3));
    char *dataP=data;
    for (uint32 y=0; y<height; y++)
    {
      for (uint32 x=0; x<width; x++)
      {
        image(x, y, 2) = *dataP;
        dataP++;
        image(x, y, 1) = *dataP;
        dataP++;
        image(x, y, 0) = *dataP;
        dataP++;
      }
    }
    currentFrame++;
    if (file.eof())
      endOfVideo = true;
  }
}
  

sizeType VideoPPMReader::getImageWidth()
{
  return width;
}


sizeType VideoPPMReader::getImageHeight()
{
  return height;
}


Rect VideoPPMReader::getImageDimension()
{
  return Rect(0,0,width,height);
}

int32 VideoPPMReader::getImageChannels()
{
  return 3;
}

bool VideoPPMReader::getEndOfVideo()
{
  return endOfVideo;
}

void VideoPPMReader::setFileName(std::string const& newFileName)
{
  stop();
  fileName = fileName;
}

void VideoPPMReader::rmWhiteSpace()
{
	const char blank= 0x20;
	const char tab  = 0x09;
	const char CR   = 0x0d;
	const char LF   = 0x0a;

	char c=file.peek();
	bool isWs=false;
	if ((c == blank) || (c == tab) || (c == CR) || (c == LF)) isWs = true;

	while (isWs) {
		file.read(&c, 1);
		if (static_cast<int>(file.gcount()) != 1)
       BOOST_THROW_EXCEPTION(IOException(std::string("No enough pixels in image " + fileName +".") ));

		c=file.peek();
		isWs=false;
		if ((c == blank) || (c == tab) || (c == CR) || (c == LF)) isWs = true;
	}
}

void VideoPPMReader::rmHeader(){
  char c[1];
  int i;

  rmWhiteSpace();
  file.read(c, 1);
  file.read(c, 1);
  rmWhiteSpace();
  while (file.peek() == '#') 
  {
    file.ignore(INT_MAX, '\n');
  } 
  rmWhiteSpace();
  file >> i; 
  rmWhiteSpace();
  file >> i;
  rmWhiteSpace();
  while (file.peek() == '#') 
  {
    file.ignore(INT_MAX, '\n');
  } 
  rmWhiteSpace();
  file >> i;  
  file.read(c, 1);
}


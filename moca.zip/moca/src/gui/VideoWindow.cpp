#include "gui/VideoWindow.h"

#ifdef HAVE_LIBFLTK


VideoWindow::VideoWindow(Rect rect, std::string title, std::string fileName)
  : DisplayWindow(rect, title)
{
  reader = boost::shared_ptr<VideoReader>(new VideoReader(fileName));
  reader->start();
  image = boost::shared_ptr<Image8U>(new Image8U(reader->getImageWidth(), reader->getImageHeight(), reader->getImageChannels()));
}


VideoWindow::~VideoWindow()
{
  if (reader)
    reader->stop();
}

#endif // HAVE_LIBFLTK

 #include "filter/FrequencyTunedSaliency.h"
#include "io/IO.h"
#include "types/MocaException.h"
#include <iostream>

int main(int argc, char* argv[]){ 
  if (argc != 3) {
    std::cerr << "not enough arguements: \"source picture\" \"destination picture\"" << std::endl;
    return 1;
  }
  try {
    boost::shared_ptr<Image8U> srcImage;
    srcImage = IO::loadImage(argv[1]);
    
    Image32F result = Image32F(srcImage->width(), srcImage->height(), 1);
    
    FrequencyTunedSaliency::calculate(*srcImage, result);
    
    
    Image8U save = Image8U(result.width(), result.height(), 1);
    
    for(uint32 x=0; x<result.width(); x++)
      for(uint32 y=0; y<result.height(); y++)
        save(x,y,0) = result(x,y,0);
    
    IO::saveImage(argv[2], save);
  }  
  catch(MocaException& e)
  {
    std::cerr << diagnostic_information(e);
  }
}

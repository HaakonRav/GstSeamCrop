#include "io/DC1394CamFeature.h"
#include "types/MocaException.h"
#include <iostream>

#ifdef HAVE_LIBDC1394

std::map<CameraFeature::Type, dc1394feature_t> DC1394CamFeature::idMap;


void DC1394CamFeature::initIDMap()
{
  if (idMap.size() > 0)
    return;
    
  idMap[CameraFeature::FEATURE_Shutter] = DC1394_FEATURE_SHUTTER;
  idMap[CameraFeature::FEATURE_Brightness] = DC1394_FEATURE_BRIGHTNESS;
  idMap[CameraFeature::FEATURE_Exposure] = DC1394_FEATURE_EXPOSURE;
  idMap[CameraFeature::FEATURE_Gain] = DC1394_FEATURE_GAIN;
  idMap[CameraFeature::FEATURE_Gamma] = DC1394_FEATURE_GAMMA;
  idMap[CameraFeature::FEATURE_FrameRate] = DC1394_FEATURE_FRAME_RATE;
  idMap[CameraFeature::FEATURE_Sharpness] = DC1394_FEATURE_SHARPNESS;
  idMap[CameraFeature::FEATURE_Hue] = DC1394_FEATURE_HUE;
  idMap[CameraFeature::FEATURE_Saturation] = DC1394_FEATURE_SATURATION;
  idMap[CameraFeature::FEATURE_Iris] = DC1394_FEATURE_IRIS;
  idMap[CameraFeature::FEATURE_Focus] = DC1394_FEATURE_FOCUS;
  idMap[CameraFeature::FEATURE_Trigger] = DC1394_FEATURE_TRIGGER;
  idMap[CameraFeature::FEATURE_TriggerDelay] = DC1394_FEATURE_TRIGGER_DELAY;
  idMap[CameraFeature::FEATURE_WhiteBalanceUB] = DC1394_FEATURE_WHITE_BALANCE;
  idMap[CameraFeature::FEATURE_WhiteBalanceVR] = DC1394_FEATURE_WHITE_BALANCE;
  idMap[CameraFeature::FEATURE_WhiteShading] = DC1394_FEATURE_WHITE_SHADING;
  idMap[CameraFeature::FEATURE_Zoom] = DC1394_FEATURE_ZOOM;
  idMap[CameraFeature::FEATURE_Pan] = DC1394_FEATURE_PAN;
  idMap[CameraFeature::FEATURE_Tilt] = DC1394_FEATURE_TILT;
  idMap[CameraFeature::FEATURE_OpticalFilter] = DC1394_FEATURE_OPTICAL_FILTER;
  idMap[CameraFeature::FEATURE_CaptureSize] = DC1394_FEATURE_CAPTURE_SIZE;
  idMap[CameraFeature::FEATURE_CaptureQuality] = DC1394_FEATURE_CAPTURE_QUALITY;
}


DC1394CamFeature::DC1394CamFeature(dc1394camera_t *camera, Type feature)
 : CameraFeature(feature), camera(camera)
{
  if (idMap.size() == 0)
    initIDMap();

  std::map<CameraFeature::Type, dc1394feature_t>::iterator it = idMap.find(feature);
  if (it == idMap.end())
    BOOST_THROW_EXCEPTION(NotImplementedException("DC1394CamFeature::idMap is out of date!"));
  id = it->second;

  dc1394bool_t value;
  
  dc1394error_t error = dc1394_feature_is_present(camera, id, &value);
  if (error != DC1394_SUCCESS)
    BOOST_THROW_EXCEPTION(IOException("dc1394_feature_is_present() failed") << ErrCamFeature(*this));
  bIsPresent = (value == DC1394_TRUE ? true : false);
  
  if (!bIsPresent)
    return;
  
  error = dc1394_feature_is_readable(camera, id, &value);
  if (error != DC1394_SUCCESS)
    BOOST_THROW_EXCEPTION(IOException("dc1394_feature_is_readable() failed") << ErrCamFeature(*this));
  bIsReadable = (value == DC1394_TRUE ? true : false);
  
  error = dc1394_feature_is_switchable(camera, id, &value);
  if (error != DC1394_SUCCESS)
    BOOST_THROW_EXCEPTION(IOException("dc1394_feature_is_switchable() failed") << ErrCamFeature(*this));
  bIsSwitchable = (value == DC1394_TRUE ? true : false);

  dc1394feature_modes_t modes;
  error = dc1394_feature_get_modes(camera, id, &modes);
  if (error != DC1394_SUCCESS)
    BOOST_THROW_EXCEPTION(IOException("dc1394_feature_get_modes() failed") << ErrCamFeature(*this));
  for (indexType i = 0; i < modes.num; i++)
  {
    if (modes.modes[i] == DC1394_FEATURE_MODE_MANUAL)
      bHasManualMode = true;
    else if (modes.modes[i] == DC1394_FEATURE_MODE_AUTO)
      bHasAutoMode = true;
    else if (modes.modes[i] == DC1394_FEATURE_MODE_ONE_PUSH_AUTO)
      bHasOneShotAutoMode = true;
  }

  error = dc1394_feature_get_boundaries(camera, id, &uiMin, &uiMax);
  if (error != DC1394_SUCCESS)
  {
    if (error > 0) // check if it's a real error or just a warning
      BOOST_THROW_EXCEPTION(IOException("dc1394_feature_get_boundaries() failed") << ErrCamFeature(*this));
  }
  else
    bHasValue = true;

  error = dc1394_feature_has_absolute_control(camera, id, &value);
  if (error != DC1394_SUCCESS)
    BOOST_THROW_EXCEPTION(IOException("dc1394_feature_has_absolute_control() failed") << ErrCamFeature(*this));
  bHasAbsValue = (value == DC1394_TRUE ? true : false);
  if (bHasAbsValue)
    {
      error = dc1394_feature_get_absolute_boundaries(camera, id, &fMin, &fMax);
      if (error != DC1394_SUCCESS)
        BOOST_THROW_EXCEPTION(IOException("dc1394_feature_get_absolute_boundaries() failed") << ErrCamFeature(*this));
    }
}


void DC1394CamFeature::setPower(bool newPow)
{
  dc1394switch_t newPow2 = (newPow? DC1394_ON : DC1394_OFF);
  if(dc1394_feature_set_power(camera, id, newPow2) != DC1394_SUCCESS)
    BOOST_THROW_EXCEPTION(IOException("dc1394_feature_set_power() failed") << ErrCamFeature(*this));
}


bool DC1394CamFeature::getPower() const
{
  dc1394switch_t curPow;
  if(dc1394_feature_get_power(camera, id, &curPow) != DC1394_SUCCESS)
    BOOST_THROW_EXCEPTION(IOException("dc1394_feature_get_power() failed") << ErrCamFeature(*this));
  return (curPow == DC1394_ON? true : false);
}


void DC1394CamFeature::setValue(uint32 newVal)
{
  if(newVal < uiMin || newVal > uiMax)
  {
    newVal = (newVal < uiMin ? uiMin : uiMax);
    std::cout << "Warning: value for '" << getName() << "' has been clipped to " << newVal << "." << std::endl;
  }
  
  setAbsControl(false);
  
  // white balance has two parameters and requires a specific getter/setter
  if (feature == FEATURE_WhiteBalanceUB || feature == FEATURE_WhiteBalanceVR)
    {
      uint32 ub, vr;
      if (dc1394_feature_whitebalance_get_value(camera, &ub, &vr) != DC1394_SUCCESS)
        BOOST_THROW_EXCEPTION(IOException("dc1394_feature_set_value() failed") << ErrCamFeature(*this));
      if (feature == FEATURE_WhiteBalanceUB)
        ub = newVal;
      else
        vr = newVal;
      if (dc1394_feature_whitebalance_set_value(camera, ub, vr) != DC1394_SUCCESS)
        BOOST_THROW_EXCEPTION(IOException("dc1394_feature_set_value() failed") << ErrCamFeature(*this));
    }
  else
    if (dc1394_feature_set_value(camera, id, newVal) != DC1394_SUCCESS)
      BOOST_THROW_EXCEPTION(IOException("dc1394_feature_set_value() failed") << ErrCamFeature(*this));
}


uint32 DC1394CamFeature::getValue() const
{
  uint32 curVal, temp;
  dc1394error_t err;
  if (feature == FEATURE_WhiteBalanceUB)
    err = dc1394_feature_whitebalance_get_value(camera, &curVal, &temp);
  else if (feature == FEATURE_WhiteBalanceVR)
    err = dc1394_feature_whitebalance_get_value(camera, &temp, &curVal);
  else
    err = dc1394_feature_get_value(camera, id, &curVal);

  if (err != DC1394_SUCCESS)
    BOOST_THROW_EXCEPTION(IOException("dc1394_feature_get_value() failed") << ErrCamFeature(*this));
  
  return curVal;
}


void DC1394CamFeature::setAbsValue(float newVal)
{
  if(newVal < fMin || newVal > fMax)
  {
    newVal = (newVal < fMin ? fMin : fMax);
    std::cout << "Warning: value for '" << getName() << "' has been clipped to " << newVal << "." << std::endl;
  }
  setAbsControl(true);
  if (dc1394_feature_set_absolute_value(camera, id, newVal) != DC1394_SUCCESS)
    BOOST_THROW_EXCEPTION(IOException("dc1394_feature_set_absolute_value() failed") << ErrCamFeature(*this));
}


float DC1394CamFeature::getAbsValue() const
{
  float curVal;
  dc1394error_t err;
  err = dc1394_feature_get_absolute_value(camera, id, &curVal);
  if (err != DC1394_SUCCESS)
    BOOST_THROW_EXCEPTION(IOException("dc1394_feature_get_absolute_value() failed") << ErrCamFeature(*this));
  
  return curVal;
}


void DC1394CamFeature::setMode(Mode newMode)
{
  dc1394feature_mode_t newMode2;
  switch(newMode)
  {
  case MODE_Manual:
    newMode2 = DC1394_FEATURE_MODE_MANUAL;
    break;

  case MODE_Auto:
    newMode2 = DC1394_FEATURE_MODE_AUTO;
    break;

  default: // this default label here isn't needed. It's just used to avoid a compiler warning
  case MODE_OneShotAuto:
    newMode2 = DC1394_FEATURE_MODE_ONE_PUSH_AUTO;
    break;
  }
  if(dc1394_feature_set_mode(camera, id, newMode2) != DC1394_SUCCESS)
    BOOST_THROW_EXCEPTION(IOException("dc1394_feature_set_mode() failed") << ErrCamFeature(*this));
}


CameraFeature::Mode DC1394CamFeature::getMode() const
{
  dc1394feature_mode_t curMode;
  if(dc1394_feature_get_mode(camera, id, &curMode) != DC1394_SUCCESS)
    BOOST_THROW_EXCEPTION(IOException("dc1394_feature_get_mode() failed") << ErrCamFeature(*this));
  switch(curMode)
  {
  case DC1394_FEATURE_MODE_MANUAL:
    return MODE_Manual;
    
  case DC1394_FEATURE_MODE_AUTO:
    return MODE_Auto;
  
  case DC1394_FEATURE_MODE_ONE_PUSH_AUTO:
    return MODE_OneShotAuto;
  }
  return MODE_Manual; // this should never be reached it's just here to avoid a compiler warning
}


void DC1394CamFeature::setAbsControl(bool newCMode)
{
  dc1394switch_t newCMode2 = (newCMode ? DC1394_ON : DC1394_OFF);
  if(dc1394_feature_set_absolute_control(camera, id, newCMode2) != DC1394_SUCCESS)
    BOOST_THROW_EXCEPTION(IOException("dc1394_feature_set_absolute_control() failed") << ErrCamFeature(*this));  
}


bool DC1394CamFeature::getAbsControl() const
{
  dc1394switch_t curCMode;
  if(dc1394_feature_get_absolute_control(camera, id, &curCMode) != DC1394_SUCCESS)
    BOOST_THROW_EXCEPTION(IOException("dc1394_feature_get_absolute_control() failed") << ErrCamFeature(*this));
  return curCMode == DC1394_ON;
}

#else

// this code is only required to avoid linker warning in MSVC (LNK4221)
DC1394CamFeature::DC1394CamFeature () {}

#endif //HAVE_LIBDC1394

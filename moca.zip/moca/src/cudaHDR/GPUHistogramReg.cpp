#include "types/MocaTypes.h"

#ifdef HAVE_CUDA

#include "cudaHDR/GPUHistogramReg.h"

#include "feature/LineHistogram.h"
#include "types/Exposure.h"
#include "tools/Timing.h"
#include "types/MocaException.h"
#include "types/Rect.h"
#include "tools/Maths.h"
#include "tools/Timing.h"

#include <fstream>
#include <iostream>
//using namespace std;

int GPUHistogramReg::findMean(int* histo, int totalSum, int percentage)
{
	totalSum = (totalSum * percentage) / 100;
	int sum = 0;
	for (int i = 0; i < 256; i++)
	{
		sum += histo[i/4] / 4;
		if (sum >= totalSum)
			return i;
	}
	return 0;
}

void GPUHistogramReg::computeMeans(CudaExposureHandle const& exp1, 
								   CudaExposureHandle const& exp2, 
								   uint8& mean1, 
								   uint8& mean2)
{
  static CudaVectorHandle<int> hist_handle(64);
  unsigned int numpixels = CudaWrapper::histo64(exp2, hist_handle);

  int hist[64];
  hist_handle.getData(hist);

  mean2 = findMean(hist, numpixels, 50);
  float expRatio = exp1.getShutter() / exp2.getShutter();
  mean1 = (uint8)(mean2*expRatio);
  if (std::min<uint8>(mean1, mean2) < badMean)
    {
      mean2 = findMean(hist, numpixels, 50+nextMeanStep);
      mean1 = (uint8)(mean2*expRatio);
    }
  else if (std::max<uint8>(mean1, mean2) > 255-badMean)
    {
      mean2 = findMean(hist, numpixels, 50-nextMeanStep);
      mean1 = (uint8)(mean2*expRatio);
    }
}

void GPUHistogramReg::computeShift(CudaExposureHandle const& exp1, 
								   CudaExposureHandle const& exp2, 
								   VectorI& offset, 
								   Vector& confidence)
{
  offset.resize(2);
  confidence.resize(2);
  VectorI guess(offset);

  uint8 mean1, mean2;
  computeMeans(exp1, exp2, mean1, mean2);

  //two ROIs for the two exposures
  Rect roi1(exp1.getOffsetX(), exp1.getOffsetY(), exp1.getWidth(), exp1.getHeight());
  Rect roi2(exp2.getOffsetX(), exp2.getOffsetY(), exp2.getWidth(), exp2.getHeight());

  bool rows = startWithRows;
  for (uint32 i=0; i<nccIters; ++i)
    {
      // width and height of the intersecting ROI
      int32 interWidth  = std::min(roi1.x+roi1.w, roi2.x+roi2.w) - std::max(roi1.x, roi2.x);
      int32 interHeight = std::min(roi1.y+roi1.h, roi2.y+roi2.h) - std::max(roi1.y, roi2.y);
      if (interWidth <= 0 || interHeight <= 0)
        std::cout << "!!!NO INTERSECTION!!!" << std::endl;

      // build four histograms
      static CudaVectorHandle<unsigned int> hist_black1;
      static CudaVectorHandle<unsigned int> hist_white1;
      static CudaVectorHandle<unsigned int> hist_black2;
      static CudaVectorHandle<unsigned int> hist_white2;
	  Rect rect1 = Rect(std::max(roi2.x-roi1.x, 0), std::max(roi2.y-roi1.y, 0), interWidth, interHeight);
	  Rect rect2 = Rect(std::max(roi1.x-roi2.x, 0), std::max(roi1.y-roi2.y, 0), interWidth, interHeight);
	  CudaWrapper::lineHisto(exp1, hist_black1, hist_white1, 
		rect1, mean1, noiseThresh, rows);
	  CudaWrapper::lineHisto(exp2, hist_black2, hist_white2, 
	  rect2, mean2, noiseThresh, rows);

	  LineHist temp1;
	  hist_black1.getData(temp1.black);
	  hist_white1.getData(temp1.white);
	  LineHist temp2;
	  hist_black2.getData(temp2.black);
	  hist_white2.getData(temp2.white);

	  int32 off = temp1.corrOffset(temp2, rows ? guess[1] : guess[0], maxOffset);
	  //int32 off = CudaWrapper::corrOffset(hist_black1, hist_white1, hist_black2, hist_white2, rows ? guess[1] : guess[0], maxOffset);
      if (rows)
        {
          roi2.y += off;
          offset[1] += off;
        }
      else
        {
          roi2.x += off;
          offset[0] += off;
        }
      rows = !rows;
    }

  confidence = offset-guess;
  confidence[0] = abs(confidence[0]);
  confidence[1] = abs(confidence[1]);
}

#endif


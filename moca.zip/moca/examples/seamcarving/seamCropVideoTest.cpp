 // This code is meant as basis for a parallel CUDA implementation to achieve SeamCrop in realtime.

// MOCA headers 
#include "types/MocaTypes.h"
#include "types/Image8U.h"
#include "types/MocaException.h"
#include "io/IO.h"
#include "io/VideoReader.h"
#include "io/VideoWriter.h"
#include "tools/Timing.h"
#include "filter/Filter.h"
#include "feature/Feature.h"

// C++ headers 
#include <string>
#include <deque>
using namespace std;

// The class first calculates a cropping window of target size. It then adds x% to the borders and removes 
// them again through seam carving. For temporal coherence, more seams are searched in a next key frame 
// and the closest with the minimal costs are used.

struct seamPair{
 uint32 Nr1;
 uint32 Nr2;
 float cost;
};

struct extendedBorders{
  uint32 left;
  uint32 right;
};

#if 0
static void printImage32F(string const& destPath, Image32F const& frame)
{
    uint32 width = frame.width();
    uint32 height = frame.height();
    Image8U print(width, height,1);
    
    float max = 0;
    float min = 1000;
    for (uint32 x = 0; x < width; x++) 
      for (uint32 y = 0; y < height; y++)
      {
	if(frame(x,y) < min)
	 min = frame(x,y);
	 
	if(frame(x,y) > max)
	 max = frame(x,y);
      }
    
    
    cout << "PRINT min = " << min << ", max = " << max << endl;
    float v = 0;
    float factor = 255.0/(max - min);
    //if(factor > 10.0) 
	//factor = 10.0;
    
    for (uint32 x = 0; x < width; x++) 
      for (uint32 y = 0; y < height; y++)
      {
	v = frame(x,y);
	v -= min;
	v *= factor;
	print(x,y) = (int) ( v + 0.5);
      }
	
    try
      {
	    cerr << "save image" << endl; 
    	    IO::saveImage(destPath, print); 
      } 
    catch (MocaException e) 
      {
	    std::cout << "save Image error: " << e.what() << std::endl;
	    exit (-1);
   }    
}
#endif


// load the frames of the video in a deque list
static void loadVideo(string srcPath, deque<Image8U>& video)
{
  VideoReader reader(srcPath);
  reader.start();
  
  while(!reader.getEndOfVideo()) 
    {
      Image8U frame(reader.getImageWidth(), reader.getImageHeight(), 3);
      reader.getImage(frame); 
      video.push_back(frame);
    }
    
  reader.stop();  
}

// compute a gradient-based energy map
void computeGradient(Image8U const& image, Image32F& energy, int const& width)
{
  int height = image.height();
  int channels = image.channels();
  int borderTop, borderBottom, borderLeft, borderRight; // these values change the formula if the current position is close to image borders.
  int grad; // gradient: sum of absolute pixel values on all color channels -> grad = (x-1, y) + (x+1, y) + (x, y-1) + (x, y+1).
  
  for (int x=0; x < width; x++)
      for (int y = 0; y < height; y++)
        {
	  borderTop = 1;	// y-1 -> y
	  borderBottom = 1;	// y+1 -> y
	  borderLeft = 1;	// x-1 -> x
	  borderRight = 1; 	// x+1 -> x
	  grad = 0;
	  
	  if (x == 0) // left border: x-1 -> x
	    borderLeft = 0;
	  if (x == width-1) // right border: x+1 -> x
	    borderRight = 0;
	  if (y == 0) // top border: y-1 -> y
	    borderTop = 0; 
	  if (y == height-1) // bottom border: y+1 -> y
	    borderBottom = 0;
	  
	  for(int c = 0; c < channels; c++)
            grad += (abs(image(x + borderRight, y, c) - image(x - borderLeft, y, c))) + (abs(image(x, y + borderBottom, c) - image(x, y - borderTop, c)));
	 
          energy(x,y) = grad;
        }// for y
}


// substract the second from the first frame to find the positions of changing pixel values
void findMotionSaliency(Image8U const& firstFrame, Image8U const& secondFrame, Image8U& result)
{
  int width = firstFrame.width();
  int height = firstFrame.height();
  int channels = firstFrame.channels();
  
  uint8 min, max;
  float diff;
  float averageMax = 0.0f;
  
  for(int x = 0; x < width; x++)
  {
	min = 255;
	max = 0;
	for(int y = 0; y < height; y++)
	  {
	    diff = 0.0f;
	    for(int c = 0; c < channels; c++) 
		diff += abs(firstFrame(x,y,c) - secondFrame(x,y,c));
            diff = (uint8)(diff/channels); //TODO: change to calculating the max. difference of all channels instead?
	    
	    if(min > diff) min = diff;
	    if(max < diff) max = diff;
	    result(x,y) = diff;
	  }
	 averageMax += max;
  }
  
  averageMax = (averageMax/width)*0.25;  //*0.25 //TODO: change the factor because diff now has smaller values for RGB-images?
  
  for(int x=0; x < width; x++)
	for(int y=0; y < height; y++)
	  result(x,y) = result(x,y) > averageMax ? 255 : 0;
  
  Filter::smooth(result, result, 5); //smooth 15
}


// normalizes the values of an Image (with only 1 channel) into a range between 0 and 255
template <class T>
void normalize(T& frame)
{
    int width = frame.width();
    int height = frame.height();
    float max = 0;
    float min = frame(width-1, height-1);
    
    for (int x = 0; x < width; x++) 
      for (int y = 0; y < height; y++)
      {
	if(frame(x,y) < min)
	 min = frame(x,y);
	 
	if(frame(x,y) > max)
	 max = frame(x,y);
      }
    
    float factor = 255.0/(max - min);
    //if(factor > 10.0) 
	//factor = 10.0;
    
    for (int x = 0; x < width; x++) 
      for (int y = 0; y < height; y++)
      {
	frame(x,y) -= min;
	frame(x,y) *= factor;
      }
}


// the energy map is computed by combining per frame saliency with simple motion saliency
void computeSaliencyVideo(deque<Image8U>& video, deque<Image32F>& videoEnergyMap)
{
  deque<Image8U>::iterator it = video.begin();
  uint32 width = it->width();
  uint32 height = it->height();
  uint32 frameCount = video.size();
  
  Image32F gradient(width, height, 1);
//   Image8U saliency(width, height, 1);
  Image8U motionSaliency(width, height, 1);
  Image32F totalSaliency(width, height, 1);
  uint32 t = 0; 
  
  while (it != video.end())
  {
    computeGradient((*it), gradient, width);
//     Feature::saliencyMap((*it), saliency, 6, 3);
    
    if(t == 0)
	findMotionSaliency((*it), (*(it+1)), motionSaliency);
    else if (t < frameCount-1)
	findMotionSaliency((*(it-1)), (*(it+1)), motionSaliency);
    else
	findMotionSaliency((*(it-1)), (*it), motionSaliency);
      

    // motionSaliency is not normalized because its values are set to 0 or 255 before smoothing
    normalize(gradient);
//     normalize(saliency);

    for(uint32 x=0; x < width; x++)
	for(uint32 y=0; y < height; y++)
	    totalSaliency(x,y) = 2*motionSaliency(x,y) + 1*gradient(x,y); //  + 0*saliency(x,y);  // 3*motionS+gradient
 
    videoEnergyMap.push_back(totalSaliency);
    
#if 0
    if(t == 250)
    {
	printImage32F("/home/stud/kiess/Videos/big_bunny_250_Gesamt.png",  totalSaliency);
	exit(1);
    }
#endif
    
    t++;
    it++;
  }
}


// sums up the energy values of all pixels for each column in each frame.
void calculateCostColumTime(deque<Image32F>& videoEnergyMap, Image32F& costColumnTime)
{
  deque<Image32F>::iterator it = videoEnergyMap.begin();
  int width = it->width();
  int height = it->height();
  
  int t = 0;
  while (it != videoEnergyMap.end())
  {
    for (int x=0; x < width; x++)
        costColumnTime(x,t) = (*it)(x,0);

    for (int y=1; y < height; y++)
	for (int x=0; x < width; x++)
	  costColumnTime(x,t) += (*it)(x,y);
    t++;
    it++;
  }
}


// calculate the energy cost of each cropping window and store the value on the position of its left border.
void calculateCostCroppingWindowTime(Image32F const& costColumnTime, Image32F& costCroppingWindowTime)
{
  int width = costColumnTime.width();
  int frameCount = costColumnTime.height();
  int specialWidth = costCroppingWindowTime.width(); 	// rest of width outside the cropping window
  int targetWidth = width - specialWidth + 1;		// size of the cropping window
  
  for(int t=0; t < frameCount; t++)
  {
      // calculate cost of cropping frame on leftmost position
      costCroppingWindowTime(0,t) = 0;
      for (int i = 0; i < targetWidth; i++)
	costCroppingWindowTime(0,t) += costColumnTime(i,t);
      
      // move cropping window a step to the right at a time and recalculate the costs for each position
      for (int i = 1; i < specialWidth; i++)
      {
	costCroppingWindowTime(i,t) = costCroppingWindowTime(i-1,t); 
	costCroppingWindowTime(i,t) += costColumnTime(i+targetWidth-1, t) - costColumnTime(i-1, t);
      }
  }
}


// find the path of cropping windows with the maximum energy costs.
void calculateMaxEnergyPath(Image32F const& costCroppingWindowTime, vector<uint32>& cropLeft)
{
  int specialWidth = costCroppingWindowTime.width(); // specialWidth = width - targetWidth-1
  int frameCount = costCroppingWindowTime.height();
  Image32F optimalCost(specialWidth, frameCount, 1); // optimal summed costs
  Image32F predecessors(specialWidth, frameCount, 1); // saves position of max predecessor
  
  int v1 = 0; // predecessor up left (x-1, t-1)      |v1|v2|v3|   t-1
  int v2 = 0; // predecessor up middle (x, t-1)  ->  |--|--|--|
  int v3 = 0; // predecessor up right (x+1, t-1)     |  |x |  |    t

  // find maximum cost of a connected position in the previous line and store its x-position in predecessors.
  for (int t = 0; t < frameCount; t++) 
      for (int x = 0; x < specialWidth; x++)
          if (t == 0) // top border
              optimalCost(x,t) = costCroppingWindowTime(x,t);
          else if (x == 0) // left border
	    {
              v2 = optimalCost(x,t-1) + costCroppingWindowTime(x,t);
              v3 = optimalCost(x+1,t-1) + costCroppingWindowTime(x,t);
              if(v2 >= v3)
	        {
		  optimalCost(x,t) = v2;
		  predecessors(x,t) = x;
		}
	      else 
	        {
		  optimalCost(x,t) = v3;
		  predecessors(x,t) = x+1;
		}//if
	    }
	  else if (x == specialWidth-1) // right border
	    {
	      v1 = optimalCost(x-1,t-1) + costCroppingWindowTime(x,t);
	      v2 = optimalCost(x,t-1) + costCroppingWindowTime(x,t);
	      if(v2 >= v1)
	        {
		  optimalCost(x,t) = v2;
		  predecessors(x,t) = x;
		}
              else
	        {
		  optimalCost(x,t) = v1;
		  predecessors(x,t) = x-1;
	        }//if		
	    }
	  else // rest of the matix 
	    {
	      v1 = optimalCost(x-1,t-1) + costCroppingWindowTime(x,t);
	      v2 = optimalCost(x,t-1) + costCroppingWindowTime(x,t);
	      v3 = optimalCost(x+1,t-1) + costCroppingWindowTime(x,t);
	      if((v2 >= v1) && (v2 >= v3))
	        {
		  optimalCost(x,t) = v2;
		  predecessors(x,t) = x;
		}
	      else if((v1 >= v2) && (v1 >= v3))
	        {
		  optimalCost(x,t) = v1;
		  predecessors(x,t) = x-1;
		}
	      else
	        {
		  optimalCost(x,t) = v3;
		  predecessors(x,t) = x+1;
		}
	    }// if else (t==0)

  // find the maximum cost position in the last row (last frame of the shot)
  float max = optimalCost(specialWidth-1, frameCount-1);
  int maxPosition = specialWidth-1;
  for (int x = 0; x < specialWidth-1; x++) 
      if(optimalCost(x, frameCount-1) > max)
      {
	  max = optimalCost(x,frameCount-1);
	  maxPosition = x;
      } 
     
  // build optimal cropping window path by traversing back from maximum cost position in last row
  for(int t = frameCount-1; t > -1; t--) 
  {   
      cropLeft[t] = maxPosition;
      maxPosition = predecessors(maxPosition,t); // get x-position of maximum in line t-1.
  }
}


// smooth the path of the cropping windows to prevent shaking movement
void smoothSignal(vector<uint32>& cropLeft)
{
  uint32 size = cropLeft.size();

  float *next = new float[size];
  float *prev = new float[size];

  if(next == NULL || prev == NULL)
    BOOST_THROW_EXCEPTION(RuntimeException("Out of memory."));

  for(uint32 i = 0; i < size; ++i)
    prev[i] = cropLeft[i];
  
  // gauss-based average, repeated
  for(uint32 repeat = 0; repeat < 100; repeat++)
  {
      for(uint32 i = 0; i < size; i++)
	  if(i == 0)
	      next[i] = (prev[i] + prev[i+1])/2.0f; // (i + (i+1))/2
	  else if (i < size-1)  
	      next[i] = 0.25f*prev[i-1] + 0.5f*prev[i] + 0.25f*prev[i+1]; //(0.25 + 0.5 + 0.25)
	  else  
	      next[i] = (prev[i] + prev[i-1])/2.0f;
      
      float* tmp = prev;
      prev = next;
      next = tmp;
  }

  for(uint32 i = 0; i < size; ++i)
    cropLeft[i] = (uint32)(prev[i] + 0.5f);

  delete prev;
  delete next;
}


// define the positions of the extended bordes
void defineBorders(uint32 const& cropLeftPos, extendedBorders& border, uint32 const& width, uint32 const& extendedWidth, uint32 const& targetWidth)
{
   border.left = 0;
   border.right = extendedWidth-1;
   int extraSpace = (extendedWidth - targetWidth)/2;
 
   if( ((int) cropLeftPos) - extraSpace <= 0) 
     border.left = 0;
   else if( (cropLeftPos + targetWidth + extraSpace) >= width-1 )
     border.left = width - extendedWidth-1;
   else
     border.left = cropLeftPos - extraSpace;
   
   border.right = border.left + extendedWidth-1;
   
}


// define new extended borders of cropping window and crop the video to the extended window size
void cropExtendBorders(deque<Image8U>& video, deque<Image32F>& videoEnergyMap, deque<Image8U>& tmpVideo, deque<Image32F>& tmpVideoEnergyMap,vector<uint32>& cropLeft, vector<extendedBorders>& borders, uint32 const& extendedWidth, uint32 const& targetWidth)
{
  deque<Image8U>::iterator itVideo = video.begin();
  deque<Image32F>::iterator itEnergy = videoEnergyMap.begin();
  int width = itVideo->width();
  int height = itVideo->height();
  int channels = itVideo->channels();
  
  int t = 0;
  int resultX = 0;
  Image8U tmpImage(extendedWidth, height, channels);
  Image32F tmpEnergy(extendedWidth, height, 1);
  
  while (itVideo != video.end())
  {
    defineBorders(cropLeft[t], borders[t], width, extendedWidth, targetWidth);
    
    resultX = 0;
    for(uint32 x = borders[t].left; x < borders[t].right+1; x++)    
    {   
      for(int y = 0; y < height; y++) 
      {
	for(int c = 0; c < channels; c++)     
	    tmpImage(resultX, y, c) = (*itVideo)(x, y, c);
	tmpEnergy(resultX, y) = (*itEnergy)(x,y);
      }
      resultX += 1;
    }
    
    tmpVideo.push_back(tmpImage);
    tmpVideoEnergyMap.push_back(tmpEnergy);
    
    t++; 
    itVideo++;
    itEnergy++;
  }
}


// calculate temporal coherence cost and add them to a temp energy map. the temporal costs are based on
// gradients and the distance of the pixel that should be removed to the according seam pixel from the last frame.
static void addTemporalCoherenceCost(Image8U const& frame, Image32F const& energy, Image32F& tmpEnergy, Image32F const& seamsLastFrame, int const& cropOffset, uint32 const& seamID)
{
  int width = frame.width();
  int height = frame.height();
  
  Image32F temporalCoherenceCost(width, height,1);
  int prevSeamPos = 0;

  bool outside = false;
  int counter = 0; 			// counts how many seam pixels from a previous seam are outside of the extended borders 

      for(int y = 0; y < height; y++)
      {
	    prevSeamPos = seamsLastFrame(seamID,y) + cropOffset;
	    //cout << "prevSeamPos = " << prevSeamPos << ", offset = " << cropOffset << endl; 
	    
	    if( ( prevSeamPos >= 0) && (prevSeamPos < width) )
	      for(int i = 0; i < width; i++)
		 temporalCoherenceCost(i,y) = 30*abs(prevSeamPos-i) > 300 ? 300 : 30*abs(prevSeamPos-i); // 30, Grenze 300
	    else
	    {
	      for(int x = 0; x < width; x++)
		temporalCoherenceCost(x,y) = 300;
		
	      counter++;
	      if(counter > height*0.2)		// threshold: if too many pixels of the previous seam are outside of the border, the whole seam is not considered anymore
	      {
		for(int y = 0; y < height; y++)
		  for(int x = 0; x < width; x++)
		    temporalCoherenceCost(x,y) = 300;
		outside = true;
		//cout << "BREAK" << endl;
	      }
	    } 
	    if(outside)
	      break;
      }
      
  for (int x = 0; x < width; x++) 
      for (int y = 0; y < height; y++)
	  tmpEnergy(x,y) = energy(x,y) + temporalCoherenceCost(x,y); // 1*energy+ 1*temp

}


// mark the position of the pixels of the found seam
static void markSeamWidth(Image32F& costWidth, Image32F& energy, Image32F const& predecessors, Image32F& seamsPositions, uint32 const seamID)
{
  int width = costWidth.width();
  int height = costWidth.height();
  int min = costWidth(width-1, height-1);  // stores the minimum costs.
  int minPosition = width-1; 		   // stores the x-position of the minumum costs.

  for (int x = 0; x < width; x++) // Find the minimal seam cost min in the last row and store its x-position in minPosition
    if(min > costWidth(x,height-1)) 
      {
        min = costWidth(x,height-1);
        minPosition = x;
      }// if
  
  for(int y = height-1; y > -1; y--) // builds the seam backwards beginning in the starting point minPostion and marks the pixels
    { 
      energy(minPosition,y) = 99999999;		// high value prevents next iterations to pick the same pixel.
      seamsPositions(seamID, y) = minPosition;
      minPosition = predecessors(minPosition,y);// get x-position of minimum cost pixel in line y-1.
    }//for
    
}


// calculates the forward energy
void calculateForwardEnergy(Image8U const& image, Image32F& fwdEnergy)
{
  uint32 const w = image.width();
  uint32 const h = image.height();
  uint32 const chans = image.channels();

  float Cl, Cu, Cr;

  for(uint32 y = 1; y < h; ++y)
    for(uint32 x = 0; x < w; ++x)
    {
      uint32 xl = (x == 0 ? 0 : x-1);
      uint32 xr = (x == w-1 ? w-1 : x+1);

      Cl = Cu = Cr = 0.0f;

      for(uint32 c = 0; c < chans; ++c)
      {
        float left = image(xl, y, c);
        float right = image(xr, y, c);
        float top = image(x, y-1, c);
    
        float center = abs(right - left);

        Cu += center;
        Cl += center + abs(top - left);
        Cr += center + abs(top - right);
      }
      
      fwdEnergy(3*x  , y) = Cl / chans;
      fwdEnergy(3*x+1, y) = Cu / chans;
      fwdEnergy(3*x+2, y) = Cr / chans;
    }
}


// sum up the cheapest paths from top to bottom by dynamic programming. In this case,  in each position the cheapest value of the possible connected predecessors is added.
void computeCostWidth(Image32F const& fwdEnergy, Image32F& energy, Image32F& costWidth, Image32F& predecessors, int width)
{
  int height = energy.height();
  
  float v1 = 0; // predecessor (x-1, y-1)
  float v2 = 0; // predecessor (x, y-1)
  float v3 = 0; // predecessor (x+1, y-1)

  for (int y = 0; y < height; y++) // find minimum cost of a connected pixel in the previous line and store its x-position in predecessors.
      for (int x = 0; x < width; x++)
          if (y == 0) // top border
              costWidth(x,y) = energy(x,y);
          else if (x == 0) // left border
	    {
              v2 = costWidth(x,y-1) + energy(x,y) + fwdEnergy(3*x+1, y);
              v3 = costWidth(x+1,y-1) + energy(x,y) + fwdEnergy(3*x+2, y);
              if(v2 <= v3)
	        {
		  costWidth(x,y) = v2;
		  predecessors(x,y) = x;
		}
	      else 
	        {
		  costWidth(x,y) = v3;
		  predecessors(x,y) = x+1;
		}//if
	    }
	  else if (x == width-1) // right border
	    {
	      v1 = costWidth(x-1,y-1) + energy(x,y) + fwdEnergy(3*x, y);
	      v2 = costWidth(x,y-1) + energy(x,y) + fwdEnergy(3*x+1, y);
	      if(v2 <= v1)
	        {
		  costWidth(x,y) = v2;
		  predecessors(x,y) = x;
		}
              else
	        {
		  costWidth(x,y) = v1;
		  predecessors(x,y) = x-1;
	        }//if		
	    }
	  else // rest of the matix 
	    {
	      v1 = costWidth(x-1,y-1) + energy(x,y) + fwdEnergy(3*x, y);
	      v2 = costWidth(x,y-1) + energy(x,y) + fwdEnergy(3*x+1, y);
	      v3 = costWidth(x+1,y-1) + energy(x,y) + fwdEnergy(3*x+2, y);
	      if((v2 <= v1) && (v2 <= v3))
	        {
		  costWidth(x,y) = v2;
		  predecessors(x,y) = x;
		}
	      else if((v1 <= v2) && (v1 <= v3))
	        {
		  costWidth(x,y) = v1;
		  predecessors(x,y) = x-1;
		}
	      else if((v3 <= v1) && (v3 <= v2))
	        {
		  costWidth(x,y) = v3;
		  predecessors(x,y) = x+1;
		}
	      else
	          BOOST_THROW_EXCEPTION(ArgumentException("One of the image dimensions is not valid."));
	    }// if else (y==0)
}


void copyWidth (Image8U const& image, Image8U& result, int width)
{ 
  Filter::copyImage(image, result, Rect(0, 0, width,image.height()), Vector2D::create(0, 0));
}


// find seams to reduce the extended borders back to the target width
static void findSeamsFrame(Image8U const& frame, Image32F& energy, vector<Image32F>& allSeamsFinal, vector<extendedBorders>& borders, uint32 const& t)
{
  uint32 width = frame.width();
  uint32 height = frame.height();
  uint32 channels = frame.channels();
  uint32 specialWidth = allSeamsFinal[0].width();
  int cropOffset = 0;
  
  Image32F tmpEnergy(width, height); 		// temp energy for modification
  Image32F fwdEnergy(width*3, height);          // buffer for storing the forward energy
  Image32F costWidth(width, height); 		// stores the minimum summed up energy values for each position
  Image32F predecessors(width, height); 	// stores the x-position of the optimal predecessor for each position
  Image8U tmpImage(width, height, channels); 	// temporary image for computation
  
  calculateForwardEnergy(frame, fwdEnergy);
  //copyWidth(frame, tmpImage, width);
     
    for(uint32 seamID = 0; seamID < specialWidth; seamID++)
      {
	  tmpEnergy = energy;

	  if(t > 0)
	  {
	      cropOffset = (borders[t-1].left - borders[t].left);
	      addTemporalCoherenceCost(frame, energy, tmpEnergy, allSeamsFinal[t-1], cropOffset, seamID);
	  }
	  
	  computeCostWidth(fwdEnergy, tmpEnergy, costWidth, predecessors, width);
	  markSeamWidth(costWidth, energy, predecessors, allSeamsFinal[t], seamID); 
      }// for
 
}


// perform seam carving and save the modified frames into a video
static void seamCarvVideo(deque<Image8U>& video, deque<Image32F>& videoEnergyMap, vector<Image32F>& allSeamsFinal, string const& destPath, vector<extendedBorders>& borders, uint32 const& targetWidth)
{
  deque<Image8U>::iterator itVideo = video.begin();
  deque<Image32F>::iterator itEnergy = videoEnergyMap.begin();
  uint32 t = 0;
  
   while (itVideo != video.end())
  {
    findSeamsFrame(*itVideo, *itEnergy, allSeamsFinal, borders, t);
      
    t++;
    itVideo++;
    itEnergy++;
  }  
}


static void removeSeamsAndSave(deque<Image8U>& video, vector<Image32F>& allSeamsFinal, vector<uint32>& cropLeft, vector<extendedBorders>& borders, string const& destPath, uint32 const& targetWidth)
{
  deque<Image8U>::iterator it = video.begin();
  //uint32 const bs = 32;
  int width = targetWidth; // /bs*bs;
  int height = it->height();// /bs*bs;
  int channels = it->channels();
  int t = 0;			// cursor for frame in video
  
  Image8U cutImage(width, height, channels);

  VideoWriter writer(destPath, targetWidth, height);
  cout <<  "TargetWidth = " <<  targetWidth <<  endl;

  //writer.setCodec(CODEC_RAW);
  writer.start();
  
  int allSeamsWidth = allSeamsFinal[0].width();
  while (it != video.end())
  {
    for(int y = 0; y < height; ++y)
        for(uint32 x = 0; x < it->width(); ++x)
        {
            int offset = 0;
            for(int n = 0; n < allSeamsWidth; ++n)
            {
                uint32 seamPos = allSeamsFinal[t](n,y);
                if(seamPos == x)
                    offset = MOCA_INT32_MAX / 2;
                else if(seamPos < x)
                    offset -= 1;
            }

            int dstPos = x + offset;
            if(dstPos < width)
                for(int c = 0; c < channels; ++c)
                    cutImage(dstPos,y,c) = (*it)(x,y,c);
        } 

    writer.putImage(cutImage);
    t++;
    it++;
  }
  
  writer.stop();
}


void processVideo(string srcPath, string const& destPath, double const& retargetFactor)
{
  // load the video to a deque-list consisting of the frames
      cout << "1: load video" << endl;
      deque<Image8U> video;
      loadVideo(srcPath, video);
   
      Image8U frame = video[1];
      int width = frame.width();
      int height = frame.height();
      int targetWidth = retargetFactor * width;					// target width of the video
      uint32 specialWidth = width - targetWidth + 1; 				// rest of width outside target width
      uint32 extendedWidth = targetWidth + ( (width - targetWidth) * 0.2 ); 	// size of the extended window before seam carving
      int frameCount = video.size();
      
      cout << "frame size: " << width << "x" << height << ", target size: " << targetWidth;
      cout << "x" << height  << ", frame count: " << frameCount << ", extendedWidth = " << extendedWidth << endl;
      
      
      // compute energy and sum up column costs for each frame
      cout << "2: calculate energy and column costs" << endl;
      deque<Image32F> videoEnergyMap;
      computeSaliencyVideo(video, videoEnergyMap);
      
      Image32F costColumnTime(width, frameCount, 1); 
      calculateCostColumTime(videoEnergyMap, costColumnTime);

      // sum the costs in each frame so that each position represents a cropping window in the frame.
      cout << "3: calculate cropping window costs" << endl;
      Image32F costCroppingWindowTime(specialWidth, frameCount, 1);
      calculateCostCroppingWindowTime(costColumnTime, costCroppingWindowTime);
      
      // calculate the path with the maximum energy in the cropping windows over time based on seam carving
      cout << "4: build max energy paths" << endl;
      vector<uint32> cropLeft(frameCount);
      calculateMaxEnergyPath(costCroppingWindowTime, cropLeft);
      
      // smooth cropping window path
      cout << "5: smooth cropping window path" << endl;
      smoothSignal(cropLeft);

      // define borders for seam carving
      cout << "6: define new borders for seam carving" << endl;
      vector<extendedBorders> borders(frameCount); // extendedBorders is a struct!
      deque<Image8U> tmpVideo;
      deque<Image32F> tmpVideoEnergyMap;
      cropExtendBorders(video, videoEnergyMap, tmpVideo, tmpVideoEnergyMap, cropLeft, borders, extendedWidth, targetWidth);
      
      //seam carving part 1
      cout << "7: find seams" << endl;
      specialWidth = extendedWidth - targetWidth;
      Image32F seamsPerFrame(specialWidth, height);
      vector<Image32F> allSeamsFinal(video.size(), seamsPerFrame);
      seamCarvVideo(tmpVideo, tmpVideoEnergyMap, allSeamsFinal, destPath, borders, targetWidth);

      //seam carving part 2
      cout << "8: remove seams and save them as video" << endl;
      removeSeamsAndSave(tmpVideo, allSeamsFinal, cropLeft, borders, destPath, targetWidth);

      cout << "video finished" << endl;
}


  
//##################################################################################|
//main										    |
//##################################################################################|

int main(int argc, char* argv[])
{
  try 
    {
      Timing::start();
     
      string srcPath = "/home/stud/kiess/Videos/src/Performance_Test/big_bunny_small.mp4";
      string destPath = "/home/stud/kiess/Videos/big_bunny_small_done.avi";
      double retargetFactor = 0.75;
      
      processVideo(srcPath, destPath, retargetFactor);
      
      Timing::stopAndPrint();
    }
  catch(MocaException& e)
    {
      cerr << diagnostic_information(e);
    }
}


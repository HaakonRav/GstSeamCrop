#include "io/DC1394Reader.h"

#ifdef HAVE_LIBDC1394

#include "io/DC1394CamFeature.h"
#include "types/MocaException.h"

// ==================== DC1394Reader base class ====================

DC1394Reader::DC1394Reader(BusSpeed speed, ColorMode color, indexType selectedCamera)
  : CameraReader(color), camera(0) , contextPtr(dc1394_new()), selectedCamera(selectedCamera),
    speed(speed), initialized(false)
{
  colorCoding = color == MODE_RAW8 ? DC1394_COLOR_CODING_RAW8 : DC1394_COLOR_CODING_MONO8;
}


DC1394Reader::~DC1394Reader()
{
  if(camera)
    {
      dc1394_capture_stop(camera);
      dc1394_camera_free(camera);
    }
  dc1394_free(contextPtr);
}


void DC1394Reader::start()
{
  dc1394camera_list_t* cameras;
  dc1394error_t err;

  err = dc1394_camera_enumerate(contextPtr, &cameras);
  if (err != DC1394_SUCCESS)
  {
    BOOST_THROW_EXCEPTION(IOException("Enumerate cameras failed."));
  }	

  if (cameras->num <= selectedCamera)
    BOOST_THROW_EXCEPTION(ArgumentException("No camera with the requested ID found."));
    
  cameraId = cameras->ids[selectedCamera];
  dc1394_camera_free_list(cameras);

  camera = dc1394_camera_new(contextPtr, cameraId.guid);

  /*
  err=dc1394_camera_reset(camera);
  if (err != DC1394_SUCCESS)
    {
      //DC1394_ERR(err, "Camera reset failed.");
      BOOST_THROW_EXCEPTION(IOException("Camera reset failed."));
    }
  */

  err = dc1394_camera_print_info(camera, stdout);
  if (err != DC1394_SUCCESS)
    {
      //DC1394_ERR(err, "Print camera info failed.");
      BOOST_THROW_EXCEPTION(IOException("Print camera info failed."));
    }

  if (speed == SPEED_800)
    {
      err = dc1394_video_set_operation_mode(camera, DC1394_OPERATION_MODE_1394B);
      if (err != DC1394_SUCCESS)
	BOOST_THROW_EXCEPTION(IOException("Unable to set operation mode to 1394b."));
      err = dc1394_video_set_iso_speed(camera, DC1394_ISO_SPEED_800);
      if (err != DC1394_SUCCESS)
	BOOST_THROW_EXCEPTION(IOException("Unable to set iso speed to 800 MBit/s ."));
    }
  else
    {
      err = dc1394_video_set_operation_mode(camera, DC1394_OPERATION_MODE_LEGACY);
      if (err != DC1394_SUCCESS)
	BOOST_THROW_EXCEPTION(IOException("Unable to set operation mode to legacy."));
      err = dc1394_video_set_iso_speed(camera, DC1394_ISO_SPEED_400);
      if (err != DC1394_SUCCESS)
	BOOST_THROW_EXCEPTION(IOException("Unable to set iso speed to 400 MBit/s."));
    }

  err = dc1394_video_set_mode(camera, DC1394_VIDEO_MODE_FORMAT7_0);
  if (err != DC1394_SUCCESS)
    {
      //DC1394_ERR(err, "Unable to set video mode to format7.");	  	  
      BOOST_THROW_EXCEPTION(IOException("Unable to set video mode to format7."));
    }

  getUnitSize(unitX, unitY);
  getMaxImageSize(maxWidth, maxHeight);
  getUnitPos(unitPosX, unitPosY);
  setImageDimension(Rect(0, 0, 640, 480));

  for(indexType i = 0; i < CameraFeature::numFeatures; i++)
  {
/*		Win32CamFeature *ptr = new Win32CamFeature(&camera, (CameraFeature::Type)i);
		boost::shared_ptr<CameraFeature> feature(ptr);
		features.push_back(feature); */
    CameraFeature::Type featType = (CameraFeature::Type)i;
    DC1394CamFeature *ptr = new DC1394CamFeature(camera, featType);
    boost::shared_ptr<CameraFeature> feature(ptr);
    features.push_back(feature);
    featIndices[featType] = i;
    if (feature->hasManualMode())
      feature->setMode(CameraFeature::MODE_Manual);
  }    

  // set a few of the features to some default values
  CameraFeaturePtr exposure = getFeature(CameraFeature::FEATURE_Exposure);
  uint32 minExposure = exposure->getMin();
  exposure->setValue(minExposure);
  if (colorCoding == DC1394_COLOR_CODING_RAW8)
    {
      setFeatureValue(CameraFeature::FEATURE_WhiteBalanceUB, 284);
      setFeatureValue(CameraFeature::FEATURE_WhiteBalanceVR, 284);
    }

  //printCameraFeaturesInfo();
  //printFormat7Info();
}


void DC1394Reader::enumerateCameras(std::vector<std::string> &cameraList)
{
  dc1394camera_list_t* cameras;
  dc1394error_t err;
  dc1394_t* contextPtr = dc1394_new();

  err = dc1394_camera_enumerate(contextPtr, &cameras);
  if (err != DC1394_SUCCESS)
    {
      dc1394_free(contextPtr);
      BOOST_THROW_EXCEPTION(IOException("Enumerate cameras failed."));
    }	

  std::cout << cameras->num << " cameras found. libdc1394 2.0." << std::endl;

  cameraList.resize(cameras->num);

  for(indexType i = 0; i < cameras->num; i++)
  {
    const int32 bufferSize = 256;
    char name[bufferSize];
    CameraPtr camera = dc1394_camera_new(contextPtr, cameras->ids[i].guid);
    snprintf(name, bufferSize, "%d - %s %s", i, camera->vendor, camera->model);
    dc1394_camera_free(camera);
    cameraList[i] = std::string(name);
  }

  dc1394_camera_free_list(cameras);
  dc1394_free(contextPtr);
}


void DC1394Reader::resetBus(indexType cameraId)
{
  dc1394camera_list_t* cameras;
  dc1394error_t err;
  dc1394_t* contextPtr = dc1394_new();

  err = dc1394_camera_enumerate(contextPtr, &cameras);
  if (err != DC1394_SUCCESS)
    {
      dc1394_free(contextPtr);
      //DC1394_ERR(err, "Enumerate cameras failed.");
      BOOST_THROW_EXCEPTION(IOException("Enumerate cameras failed."));
    }	

  if (cameras->num < cameraId+1)
    {
      dc1394_camera_free_list(cameras);
      dc1394_free(contextPtr);
      BOOST_THROW_EXCEPTION(ArgumentException("Not enough cameras found."));
    }

  CameraPtr camera = dc1394_camera_new(contextPtr, cameras->ids[cameraId].guid);
  dc1394_camera_free_list(cameras);
  
  // reset the bus to free resources that had been allocated by a previously crashing process and start over
  //!!! it seems like resetting the bus requires an initialized camera object. But after resetting, the object becomes invalid.
  //!!! As a result, everything has to be done twice. Dat's ugleh!
  dc1394_reset_bus(camera);
  dc1394_camera_free(camera);
  dc1394_free(contextPtr);
  usleep(100);
}

  
sizeType DC1394Reader::getImageWidth()
{
  sizeType sizeX, sizeY;
  if (!initialized)
    BOOST_THROW_EXCEPTION(IOException("Camera is not initialized."));
  if (dc1394_format7_get_image_size(camera, DC1394_VIDEO_MODE_FORMAT7_0, &sizeX, &sizeY) != DC1394_SUCCESS)
    BOOST_THROW_EXCEPTION(IOException("Unable to query image size."));
  return sizeX;
}


sizeType DC1394Reader::getImageHeight()
{
  sizeType sizeX, sizeY;
  if (!initialized)
    BOOST_THROW_EXCEPTION(IOException("Camera is not initialized."));
  if (dc1394_format7_get_image_size(camera, DC1394_VIDEO_MODE_FORMAT7_0, &sizeX, &sizeY) != DC1394_SUCCESS)
    BOOST_THROW_EXCEPTION(IOException("Unable to query image size."));
  return sizeY;
}


Rect DC1394Reader::getImageDimension()
{
  Rect result;
  if (!initialized)
    BOOST_THROW_EXCEPTION(IOException("Cannot get image dimension. Camera is not initialized."));
  if (dc1394_format7_get_image_size(camera, DC1394_VIDEO_MODE_FORMAT7_0, (unsigned int*)&result.w, (unsigned int*)&result.h) != DC1394_SUCCESS)
    BOOST_THROW_EXCEPTION(IOException("Cannot get image dimension. Unable to query image size."));
  if (dc1394_format7_get_image_position(camera, DC1394_VIDEO_MODE_FORMAT7_0, (unsigned int*)&result.x, (unsigned int*)&result.y) != DC1394_SUCCESS)
    BOOST_THROW_EXCEPTION(IOException("Cannot get image dimension. Unable to query image position."));
  return result;
}


int32 DC1394Reader::getImageChannels()
{
  // Color images are returned as a single-channel bayer patterned image unless explicitly converted
  return 1;
}


void DC1394Reader::printFormat7Info()
{
  sizeType maxHorSize, maxVerSize;
  sizeType horUnit, verUnit;
  uint32 posH, posV;
  sizeType sizeH, sizeV;
  sizeType pixNum;
  sizeType dataDepth;
  uint64 totalBytes;
  uint32 unitPosH, unitPosV;
  sizeType packetBytes;
  float frameInter;

  if (dc1394_format7_get_max_image_size(camera, DC1394_VIDEO_MODE_FORMAT7_0, &maxHorSize, &maxVerSize) != DC1394_SUCCESS)
    return;
  if (dc1394_format7_get_unit_size(camera, DC1394_VIDEO_MODE_FORMAT7_0, &horUnit, &verUnit) != DC1394_SUCCESS)
    return;
  if (dc1394_format7_get_image_size(camera, DC1394_VIDEO_MODE_FORMAT7_0, &sizeH, &sizeV) != DC1394_SUCCESS)
    return;
  if (dc1394_format7_get_image_position(camera, DC1394_VIDEO_MODE_FORMAT7_0, &posH, &posV) != DC1394_SUCCESS)
    return;
  if (dc1394_format7_get_unit_position(camera, DC1394_VIDEO_MODE_FORMAT7_0, &unitPosH, &unitPosV) != DC1394_SUCCESS)
    return;
  if (dc1394_format7_get_pixel_number(camera, DC1394_VIDEO_MODE_FORMAT7_0, &pixNum) != DC1394_SUCCESS)
    return;
  if (dc1394_format7_get_total_bytes(camera, DC1394_VIDEO_MODE_FORMAT7_0, (uint64_t*)&totalBytes) != DC1394_SUCCESS)
    return;
  if (dc1394_format7_get_data_depth(camera, DC1394_VIDEO_MODE_FORMAT7_0, &dataDepth) != DC1394_SUCCESS)
    return;
  if (dc1394_format7_get_frame_interval(camera, DC1394_VIDEO_MODE_FORMAT7_0, &frameInter) != DC1394_SUCCESS)
    return;
  if (dc1394_format7_get_packet_size(camera, DC1394_VIDEO_MODE_FORMAT7_0, &packetBytes) != DC1394_SUCCESS)
    return;

  std::cout << "maximum image size: " << maxHorSize << "x" << maxVerSize << std::endl;
  std::cout << "current image size: " << sizeH << "x" << sizeV << std::endl;
  std::cout << "data depth        : " << dataDepth << std::endl;
  std::cout << "current image pos : " << posH << "x" << posV << std::endl;
  std::cout << "unit size         : " << horUnit << "x" << verUnit << std::endl; // step size of the image width and size
  std::cout << "unit position     : " << unitPosH << "x" << unitPosV << std::endl;
  std::cout << "pixel number      : " << pixNum << std::endl;
  std::cout << "total bytes       : " << totalBytes << std::endl;
  std::cout << "bytes per packet  : " << packetBytes << std::endl;
  std::cout << "frame interval    : " << frameInter << std::endl;
}


void DC1394Reader::printCameraFeaturesInfo()
{
  dc1394featureset_t features;
  dc1394error_t err = dc1394_feature_get_all(camera, &features);
  if (err != DC1394_SUCCESS)
    BOOST_THROW_EXCEPTION(IOException("Unable to query camera features."));
  dc1394_feature_print_all(&features, stdout);
}


void DC1394Reader::getMaxImageSize(sizeType& width, sizeType& height)
{
  if (camera==0 || (dc1394_format7_get_max_image_size(camera, DC1394_VIDEO_MODE_FORMAT7_0, &width, &height) != DC1394_SUCCESS))
    BOOST_THROW_EXCEPTION(IOException("Unable to get max image size."));
}


void DC1394Reader::getUnitSize(sizeType& unitSizeX, sizeType& unitSizeY)
{
  if (camera==0 || (dc1394_format7_get_unit_size(camera, DC1394_VIDEO_MODE_FORMAT7_0, &unitSizeX, &unitSizeY) != DC1394_SUCCESS))
    BOOST_THROW_EXCEPTION(IOException("Unable to get unit size."));
}


void DC1394Reader::getUnitPos(uint32& unitPosX, uint32& unitPosY)
{
  if (camera==0 || (dc1394_format7_get_unit_position(camera, DC1394_VIDEO_MODE_FORMAT7_0, &unitPosX, &unitPosY) != DC1394_SUCCESS))
    BOOST_THROW_EXCEPTION(IOException("Unable to get unit position."));
}


void DC1394Reader::setImageDimension(Rect roi, uint32 forcedBPP, uint32* usedBPP)
{
  assert(unitX > 0 && unitY > 0 && unitPosX > 0 && unitPosY > 0);
  assert(maxWidth >= unitX && maxHeight >= unitY);
  roi.w = roi.w/unitX*unitX;
  roi.h = roi.h/unitY*unitY;
  roi.x = roi.x/unitPosX*unitPosX;
  roi.y = roi.y/unitPosY*unitPosY;

  if (roi.w <= 0 || roi.h <= 0 || roi.w*roi.h < 4300)
    BOOST_THROW_EXCEPTION(ArgumentException("Image size too small.") << ErrRect(roi));
  if (roi.x < 0 || roi.y < 0 || roi.x > int(maxWidth-unitX) || roi.y > int(maxHeight-unitY))
    BOOST_THROW_EXCEPTION(ArgumentException("Image position must be inside the range of the sensor") << ErrRect(roi));
  
  // capping the image size to the camera's maximum resolution
  if (roi.x + roi.w > (int)maxWidth)
    roi.w = maxWidth - roi.x;
  if (roi.y + roi.h > (int)maxHeight)
    roi.h = maxHeight - roi.y;

  dc1394video_mode_t videoMode = DC1394_VIDEO_MODE_FORMAT7_0;
  uint32 bpp;
  bool succ = true;
  succ &= dc1394_format7_set_color_coding(camera, videoMode, colorCoding) == DC1394_SUCCESS;
  succ &= dc1394_format7_set_image_position(camera, videoMode, 0,0) == DC1394_SUCCESS;
  succ &= dc1394_format7_set_image_size(camera, videoMode, roi.w, roi.h) == DC1394_SUCCESS;
  succ &= dc1394_format7_set_image_position(camera, videoMode, roi.x, roi.y) == DC1394_SUCCESS;
  succ &= dc1394_format7_get_packet_parameters(camera, videoMode, &unitBPP, &bpp) == DC1394_SUCCESS;
  
  bpp = forcedBPP > 0 ? forcedBPP : std::min(bpp, 8088u);
  bpp = bpp / unitBPP * unitBPP;
  if (usedBPP != NULL)
    *usedBPP = bpp;
  
  succ &= dc1394_format7_set_packet_size(camera, videoMode, bpp) == DC1394_SUCCESS;
  if (!succ)
    BOOST_THROW_EXCEPTION(IOException("Unable set camera ROI parameters."));
  
  //unsigned int bpp;
  //dc1394_format7_get_packet_size(camera, DC1394_VIDEO_MODE_FORMAT7_0, &bpp);
  //std::cerr << roi.x << "\t" << roi.y << "\t" << roi.w << "\t" << roi.h << "\t" << roi.w*roi.h << "\t" << bpp << std::endl;
}


void DC1394Reader::getImage(Image8U& img)
{
  boost::shared_ptr<CameraImage> image = getImagePtr();

  try
  {
    img.copyFrom(*image);
  }
  catch(MocaException& e)
  {
    returnImagePtr(image);
    throw;
  }
  
  returnImagePtr(image);
}


boost::shared_ptr<CameraImage> DC1394Reader::getImagePtr()
{
  if(!initialized)
    BOOST_THROW_EXCEPTION(IOException("Unable to receive an image from the camera. Camera not initialized."));
  
  dc1394video_frame_t* frame_ptr = 0;
  dc1394error_t err;

  err = dc1394_capture_dequeue(camera, DC1394_CAPTURE_POLICY_WAIT, &frame_ptr);
  if(err != DC1394_SUCCESS)
  {
    //DC1394_ERR(err, "Unable to receive an image from the camera.");
    BOOST_THROW_EXCEPTION(IOException("Unable to receive an image from the camera."));
  }

  if(frame_ptr == NULL)
  {
    dc1394_capture_enqueue(camera, frame_ptr);
    BOOST_THROW_EXCEPTION(IOException("Couldn't get frame from camera."));    
  }
  
  return boost::shared_ptr<CameraImage>(new CameraImage(frame_ptr));
}


void DC1394Reader::returnImagePtr(boost::shared_ptr<CameraImage> image)
{
  if(!initialized)
    BOOST_THROW_EXCEPTION(IOException("Unable to return an image pointer to the camera. Camera not initialized."));
  
  if(image != NULL)
    dc1394_capture_enqueue(camera, image->frame);
}


void DC1394Reader::captureImage(Rect roi, uint32 shutter, float gain)
{
  BOOST_THROW_EXCEPTION(NotImplementedException("captureImage() is not implemented in this reader type."));
}
 

#endif // HAVE_LIBDC1394

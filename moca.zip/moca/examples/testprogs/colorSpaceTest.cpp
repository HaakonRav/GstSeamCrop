#include <iostream>
#include "filter/CvtColorSpace.h"
#include "io/IO.h"
#include "types/MocaException.h"


int main(int argc, char* argv[]){ 
  if (argc != 4) {
    std::cerr << "not enough arguments: \"source picture\" \"destination picture\" \"destination Color Space\"" << std::endl;
    std::cerr << "destination Color Space has to be: 1(RGB), 2(gray), 3(YCrCb), 4(Luv)" << std::endl;
    return 1;
  }
  
  ColorSpace destMode;
  switch(atoi(argv[3])){
    case 1:
      destMode = COLOR_RGB; break;
    case 2:
      destMode = COLOR_Y; break;
    case 3:
      destMode = COLOR_YCrCb; break;
    case 4:
      destMode = COLOR_Luv; break;
    default:
      std::cerr << "destination Color Space has to be: 1(RGB), 2(gray), 3(BGR), 4(YCrCb), 5(Luv)" << std::endl;
      exit(-1);
  }

  boost::shared_ptr<Image8U> srcImage;
  
  try {
    std::cerr << "read image" << std::endl;        
    srcImage = IO::loadImage(argv[1]);

  } catch (MocaException e) {
    std::cout << "read Image error: " << e.what() << std::endl;
    exit (-1);
  }

  boost::shared_ptr<Image8U> destImage; 
  
  if(destMode == COLOR_Y)
    destImage = boost::shared_ptr<Image8U>(new Image8U(srcImage->width(), srcImage->height(), 1));
  else
    destImage = boost::shared_ptr<Image8U>(new Image8U(srcImage->width(), srcImage->height(), 3));


  CvtColorSpace::convert(*srcImage, *destImage, COLOR_BGR, destMode);

  try {
    std::cerr << "save image" << std::endl;        
    IO::saveImage(argv[2], *destImage); 

  } catch (MocaException e) {
    std::cout << "save Image error: " << e.what() << std::endl;
    exit (-1);
  }  

}

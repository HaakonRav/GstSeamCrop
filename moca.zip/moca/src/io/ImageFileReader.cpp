#include "io/ImageFileReader.h"
#include "io/IO.h"


// ==================== ImageFileReader ====================

ImageFileReader::ImageFileReader(std::string fileName)
{
  loadImage(fileName);
}


ImageFileReader::~ImageFileReader()
{
  // go go gadgeto shared pointer! 8)
}


void ImageFileReader::start()
{
}


void ImageFileReader::stop()
{
}


boost::shared_ptr<Image8U> ImageFileReader::getImage()
{
  return theImage;
}


void ImageFileReader::getImage(Image8U& img)
{
  img.copyFrom(*theImage);
}


sizeType ImageFileReader::getImageWidth()
{
  return theImage->width();
}


sizeType ImageFileReader::getImageHeight()
{
  return theImage->height();
}


Rect ImageFileReader::getImageDimension()
{
  return Rect(0, 0, getImageWidth(), getImageHeight());
}


int32 ImageFileReader::getImageChannels()
{
  return theImage->channels();
}


void ImageFileReader::loadImage(std::string fileName)
{
  theImage = IO::loadImage(fileName);
}


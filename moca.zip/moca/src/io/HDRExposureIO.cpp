#include "io/HDRExposureIO.h"
#include "io/IO.h"
#include "tools/Maths.h"
#include "types/Exposure.h"
#include "types/MocaException.h"
#include <fstream>
#include <boost/algorithm/string.hpp>


HDRExposureIO::HDRExposureIO(std::string const& pathPrefix)
  : reading(false), writing(false), pathPrefix(pathPrefix)
{
  if(this->pathPrefix.length() == 0)
    this->pathPrefix.assign(".");
    
  IO::checkPath(this->pathPrefix);
  numExposures = 0;
  curPos = -1;
}


HDRExposureIO::~HDRExposureIO()
{
  // do not throw in destructor
  try {
    close();
  } catch (MocaException&) {}
}


boost::shared_ptr<HDRExposureIO> HDRExposureIO::createReader(std::string const& pathPrefix)
{
  boost::shared_ptr<HDRExposureIO> reader = boost::shared_ptr<HDRExposureIO>(new HDRExposureIO(pathPrefix));
  reader->reading = true;
  
  std::string indexFilename(reader->pathPrefix + std::string("index.txt"));
  std::ifstream indexFile(indexFilename.c_str());
  if(indexFile.good())
  {
    std::stringstream buffer("");
    indexFile >> buffer.rdbuf();
    indexFile.close();
    reader->numExposures = Maths::fromString<indexType>(buffer.str());
  }
  
  if(reader->numExposures < 1)
    reader->numExposures = 1; // assume there is at least one exposure available (but reading the real number failed)
    
  return reader;
}


void HDRExposureIO::getNext(std::vector<Exposure>& exposures)
{
  if(!reading)
    BOOST_THROW_EXCEPTION(RuntimeException("Tried to read from a writer."));
    
  curPos = (curPos + 1) % numExposures;
  std::stringstream path("");
  path << pathPrefix << "exposures" << curPos;
  loadVector(path.str(), exposures);
}

  
void HDRExposureIO::getPrev(std::vector<Exposure>& exposures)
{
  if(!reading)
    BOOST_THROW_EXCEPTION(RuntimeException("Tried to read from a writer."));
    
  curPos = (curPos - 1 + numExposures) % numExposures;
  std::stringstream path("");
  path << pathPrefix << "exposures" << curPos;
  loadVector(path.str(), exposures);
}

  
boost::shared_ptr<HDRExposureIO> HDRExposureIO::createWriter(std::string const& pathPrefix)
{
  boost::shared_ptr<HDRExposureIO> writer = boost::shared_ptr<HDRExposureIO>(new HDRExposureIO(pathPrefix));
  writer->writing = true;
  
  return writer;
}


void HDRExposureIO::putNext(std::vector<Exposure> const& exposures)
{
  if(!writing)
    BOOST_THROW_EXCEPTION(RuntimeException("Tried to write to a reader."));
  
  ++curPos;
  std::stringstream path("");
  path << pathPrefix << "exposures" << curPos;
  saveVector(path.str(), exposures);
  ++numExposures;
}


void HDRExposureIO::close()
{
  if(writing)
  {
    std::string indexFilename(pathPrefix + std::string("index.txt"));
    std::ofstream indexFile(indexFilename.c_str());
    if(indexFile.good())
      indexFile << numExposures << std::endl;
    else
      BOOST_THROW_EXCEPTION(IOException("Couldn't write index file containing the number of exposures."));
    indexFile.close();
  }
  
  reading = writing = false;
}


void HDRExposureIO::loadVector(std::string const& path, std::vector<Exposure>& exposures)
{
  if(path.length() == 0)
    BOOST_THROW_EXCEPTION(ArgumentException("destination path must not be empty."));

  std::string realPath(path);
  IO::checkPath(realPath);
  std::string indexFilename(realPath);
  indexFilename.append("index.txt");

  std::ifstream indexFile(indexFilename.c_str());
  if(!indexFile.good())
    BOOST_THROW_EXCEPTION(IOException(std::string("Can't open index file at '") + path + std::string("'.")));

  std::stringstream buffer("");
  indexFile >> buffer.rdbuf();
  std::string strBuffer(buffer.str());
  char const* ptr = strBuffer.c_str();

  std::vector<std::string> tokens;
  boost::split(tokens, ptr, boost::is_any_of("\n|"));

  uint32 numEntries = tokens.size() / 6;
  if(numEntries == 0 || tokens.size() % 6 > 1)
    BOOST_THROW_EXCEPTION(IOException(std::string("Invalid index file at '") + path + std::string("'.")));

  exposures.clear();
  exposures.reserve(numEntries);
  
  for(uint32 i = 0; i < numEntries; i++)
  {
    uint32 pos = i * 6;
    Exposure exposure;
    exposure.image = IO::loadImage(realPath + tokens[pos]);
    exposure.image->setTimestamp(Maths::fromString<uint64>(tokens[pos+1]));
    exposure.topLeft = Maths::fromString<VectorI>(tokens[pos+2]);
    exposure.shutter = Maths::fromString<float>(tokens[pos+3]);
    exposure.direction = (Exposure::CheckedInvalids)Maths::fromString<int32>(tokens[pos+4]);
    exposure.parent = Maths::fromString<uint32>(tokens[pos+5]);
    exposures.push_back(exposure);
  }
}


void HDRExposureIO::saveVector(std::string const& path, std::vector<Exposure> const& exposures)
{
  if(path.length() == 0)
    BOOST_THROW_EXCEPTION(ArgumentException("destination path must not be empty."));
  if(exposures.size() == 0)
    BOOST_THROW_EXCEPTION(ArgumentException("Exposure vector must not be empty."));

  std::string realPath(path);
  IO::checkPath(realPath);
  std::string indexFilename(realPath);
  indexFilename.append("index.txt");
  
  IO::createDirectories(indexFilename);
  std::ofstream indexFile(indexFilename.c_str());
  if(!indexFile.good())
    BOOST_THROW_EXCEPTION(IOException(std::string("Can't open index file at '") + path + std::string("'.")));
    
  for(uint32 i = 0; i < exposures.size(); i++)
  {
    std::stringstream imgFilename("");
    imgFilename << "exposure" << i << ".png";
    
    indexFile << imgFilename.str() << "|" << exposures[i].image->getTimestamp() << "|";
    indexFile << exposures[i].topLeft << "|" << exposures[i].shutter << "|";
    indexFile << (int32)exposures[i].direction << "|" << exposures[i].parent << std::endl;
    IO::saveImage(realPath + imgFilename.str(), *(exposures[i].image));
  }
  
  indexFile.close();
}


int32 HDRExposureIO::getCurPos()
{
  return curPos;
}


int32 HDRExposureIO::getNumExposures()
{
  return numExposures;
}

#include "FrameWriter.h"

#include "io/HDRExposureIO.h"


FrameWriter::FrameWriter()
{
  expSets.reserve(100);
}


void FrameWriter::putNext(std::vector<Exposure> const& expSet)
{
  expSets.push_back(expSet);
}


void FrameWriter::write(std::string const& path)
{
  boost::shared_ptr<HDRExposureIO> expWriter;
  expWriter = HDRExposureIO::createWriter(path);
  std::cout << "Saving " << expSets.size() << " HDR frames." << std::endl;
  for (uint32 i=0; i<expSets.size(); ++i)
    {
      std::cout << i << "  "; std::cout.flush();
      expWriter->putNext(expSets[i]);
    }
  std::cout << std::endl;
  expWriter->close();
}

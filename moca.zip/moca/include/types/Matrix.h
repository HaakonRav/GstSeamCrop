#ifndef TYPES_MATRIX_H
#define TYPES_MATRIX_H

#include <boost/numeric/ublas/matrix.hpp>

typedef boost::numeric::ublas::matrix<double> Matrix;

#endif

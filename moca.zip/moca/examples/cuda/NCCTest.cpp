#define BOOST_TEST_DYN_LINK
#include "boost/test/unit_test.hpp"

#include "testcases.h"

#include "cudaHDR/CudaImage8UHandle.h"
#include "cudaHDR/KernelFunctions.h"
#include "cudaHDR/CudaWrapper.h"
#include "cudaHDR/CudaVectorHandle.h"
#include "cudaHDR/DeviceManager.h"

#include "io/ImageFileReader.h"
#include "io/ImageFileWriter.h"
#include "types/MocaException.h"
#include "feature/HistogramReg.h"
#include "feature/LineHistogram.h"

//Initially load needed test exposure set
struct testDataNCC
{
	//Will be available in every test case
	LineHist histo1;
	LineHist histo2;

	//Initialize struct
	testDataNCC()
	{
		//Resize line histograms
		histo1.black.resize(530);
		histo1.white.resize(530);
		histo2.black.resize(530);
		histo2.white.resize(530);

		//Fill histograms with testdata
		for (unsigned int i = 0; i < histo1.black.size(); i++)
		{
			histo1.black[(i-5) % 530] = i;
			histo1.white[(i-5) % 530] = 530-i;
			histo2.black[i] = i;
			histo2.white[i] = 530-i;
		}
	}
};


BOOST_FIXTURE_TEST_SUITE(NCCTestSuite, testDataNCC)

BOOST_AUTO_TEST_CASE(LineHistoTest)
{
	//Calculate cross correlation on CPU
	int maxcorr_cpu = histo1.corrOffset(histo2, 5, 64);

	//Calculate cross correlation on GPU
	CudaVectorHandle<unsigned int> handle_b1;
	handle_b1.put(histo1.black);
	CudaVectorHandle<unsigned int> handle_w1;
	handle_w1.put(histo1.white);
	CudaVectorHandle<unsigned int> handle_b2;
	handle_b2.put(histo2.black);
	CudaVectorHandle<unsigned int> handle_w2;
	handle_w2.put(histo2.white);
	int maxcorr_gpu = CudaWrapper::corrOffset(handle_b1, handle_w1, handle_b2, handle_w2, 5, 64);
	BOOST_CHECK(maxcorr_gpu == maxcorr_cpu);
}

BOOST_AUTO_TEST_SUITE_END()
#include "gui/FeatureControl.h"

#ifdef HAVE_CAMERA
#ifdef HAVE_LIBFLTK

#include <iostream>
#include <sstream>


FeatureControl::FeatureControl(CameraFeaturePtr feature, Rect wndSize)
  : Fl_Double_Window(wndSize.x, wndSize.y, wndSize.w, wndSize.h), feature(feature)
{
  absoluteSwitch = enableSwitch = autoSwitch = NULL;
  valueLabel = NULL;
  slider = NULL;

  new Fl_Box(FL_BORDER_BOX, 0, 0, wndSize.w, wndSize.h, "");
  
  Fl_Output* featureLabel = new Fl_Output(1, 1, wndSize.w-2, 16);
  featureLabel->box(FL_NO_BOX);
  featureLabel->value(feature->getName().c_str());
  
  if(feature->isSwitchable())
  {
    enableSwitch = new Fl_Check_Button(160, 1, 76, 16, "enabled");
    enableSwitch->callback(enableSwitchCallback, this);
    enableSwitch->when(FL_WHEN_CHANGED);
  }

  if(feature->hasAbsValue())
  {
    absoluteSwitch = new Fl_Check_Button(240, 1, 80, 16, "absolute");
    absoluteSwitch->callback(absoluteSwitchCallback, this);
    absoluteSwitch->when(FL_WHEN_CHANGED);
  }

  if(feature->hasAutoMode())
  {
    autoSwitch = new Fl_Check_Button(324, 1, 50, 16, "auto");
    autoSwitch->callback(autoSwitchCallback, this);
    autoSwitch->when(FL_WHEN_CHANGED);
  }

  if(feature->hasOneShotAutoMode())
  {
    Fl_Button* oneShotButton = new Fl_Button(378, 1, 100, 16, "one shot auto");
    oneShotButton->callback(oneShotButtonCallback, this);
  }

  if(feature->hasValue())
  {
    minLabel = new Fl_Output(4, 24, 60, 16);
    minLabel->box(FL_NO_BOX);
    
    valueLabel = new Fl_Output((wndSize.w-62)/2, 24, 60, 16);
    valueLabel->box(FL_NO_BOX);
    
    maxLabel = new Fl_Output(wndSize.w-62, 24, 60, 16);
    maxLabel->box(FL_NO_BOX);
    
    slider = new Fl_Slider(4, 40, wndSize.w-8, 24);
    slider->type(FL_HORIZONTAL);
    slider->callback(sliderCallback, this);
    
    if(feature->getAbsControl())
    {
      float min, max;
      feature->getAbsBoundaries(min, max);
      setText(minLabel, min);
      setText(maxLabel, max);
      slider->bounds(min, max);
    }
    else
    {
      uint32 min, max;
      feature->getBoundaries(min, max);
      setText(minLabel, min);
      setText(maxLabel, max);
      slider->bounds(min, max);
    }
  } 

  update();

  end();
}


FeatureControl::~FeatureControl()
{
}


void FeatureControl::update()
{
  update(feature->getMode());
}


void FeatureControl::update(bool power)
{
  float value = 0;

  if(feature->hasValue())
  {
    if(feature->getAbsControl())
      value = feature->getAbsValue();
    else
      value = feature->getValue();
  }

  update(power, feature->getMode(), value);
}


void FeatureControl::update(CameraFeature::Mode mode)
{
  bool power = false;
  float value = 0;
  
  if(feature->isSwitchable())
    power = feature->getPower();
  if(feature->hasValue())
  {
    if(feature->getAbsControl())
      value = feature->getAbsValue();
    else
      value = feature->getValue();
  }

  update(power, mode, value);
}


void FeatureControl::update(float value)
{
  bool power = false;
  
  if(feature->isSwitchable())
    power = feature->getPower();

  update(power, feature->getMode(), value);
}


void FeatureControl::update(bool power, CameraFeature::Mode mode, float value)
{
  if(feature->isSwitchable())
  {
    if(power)
      enableSwitch->set();
    else
      enableSwitch->clear();
  }
  
  if(absoluteSwitch != NULL)
  {
    if(feature->getAbsControl())
      absoluteSwitch->set();
    else
      absoluteSwitch->clear();
  }

  if(autoSwitch != NULL)
  {
    if(mode == CameraFeature::MODE_Auto)
      autoSwitch->set();
    else
      autoSwitch->clear();
  }

  if(feature->hasValue())
    switch(mode)
    {
	case CameraFeature::MODE_Auto:
	  slider->deactivate();
	  valueLabel->value("Auto");
	  break;

	case CameraFeature::MODE_OneShotAuto:
	  slider->deactivate();
	  valueLabel->value("1xAuto");
	  break;

	default: // MODE_Manual
	  if(feature->isSwitchable() && enableSwitch->value() == 0)
	  {
	    slider->deactivate();
	    valueLabel->value("n/a");
	  }
	  else
	  {
	    slider->activate();
	    if(feature->getAbsControl())
	    {
	      slider->value(value);
	      setText(valueLabel, value);
	    }
	    else
	    {
	      uint32 _value = (uint32)value;
              slider->value(_value);
              setText(valueLabel, _value);
	    }
	  }
	  break;
    }
  
  redraw();
}


void FeatureControl::setText(Fl_Output* widget, uint32 value)
{
  std::stringstream sstr("");
  sstr << value;
  widget->value(sstr.str().c_str());
}


void FeatureControl::setText(Fl_Output* widget, float value)
{
  std::stringstream sstr("");
  sstr.setf(std::ios::fixed, std::ios::floatfield);
  sstr.precision(5);
  sstr << value;
  widget->value(sstr.str().c_str());
}


void FeatureControl::sliderCallback(Fl_Widget* _widget, void* _window)
{
  Fl_Slider* slider = (Fl_Slider*)_widget;
  FeatureControl* wnd = (FeatureControl*)_window;

  if(slider->active() == 0)
    return;
  
  if(wnd->feature->getAbsControl())
  {
    float newVal = (float)slider->value();
    wnd->feature->setAbsValue(newVal);
    wnd->update(newVal);
  }
  else
  {
    uint32 newVal = (uint32)slider->value();
    wnd->feature->setValue(newVal);
    wnd->update((float)newVal);
  }
}


void FeatureControl::enableSwitchCallback(Fl_Widget* _widget, void* _window)
{
  Fl_Check_Button* button = (Fl_Check_Button*)_widget;
  FeatureControl* wnd = (FeatureControl*)_window;
  
  if(button->value() == 0)
  {
    wnd->feature->setPower(false);
    wnd->update(false);
  }
  else
  {
    wnd->feature->setPower(true);
    wnd->update(true);
  }
}


void FeatureControl::absoluteSwitchCallback(Fl_Widget* _widget, void* _window)
{
  Fl_Check_Button* button = (Fl_Check_Button*)_widget;
  FeatureControl* wnd = (FeatureControl*)_window;
  
  if(button->value() == 0)
  {
    uint32 min, max;
    wnd->feature->setAbsControl(false);
    wnd->feature->getBoundaries(min, max);
    setText(wnd->minLabel, min);
    setText(wnd->maxLabel, max);
    wnd->slider->bounds(min, max);
    wnd->update(false);
  }
  else
  {
    float min, max;
    wnd->feature->setAbsControl(true);
    wnd->feature->getAbsBoundaries(min, max);
    setText(wnd->minLabel, min);
    setText(wnd->maxLabel, max);
    wnd->slider->bounds(min, max);
    wnd->update(true);
  }
}


void FeatureControl::autoSwitchCallback(Fl_Widget* _widget, void* _window)
{
  Fl_Check_Button* button = (Fl_Check_Button*)_widget;
  FeatureControl* wnd = (FeatureControl*)_window;
  
  if(button->value() == 0)
  {
    wnd->feature->setMode(CameraFeature::MODE_Manual);
    wnd->update(CameraFeature::MODE_Manual);
  }
  else
  {
    wnd->feature->setMode(CameraFeature::MODE_Auto);
    wnd->update(CameraFeature::MODE_Auto);
  }
}


void FeatureControl::oneShotButtonCallback(Fl_Widget*/*_widget*/, void* _window)
{
  //Fl_Check_Button* button = (Fl_Check_Button*)_widget;
  FeatureControl* wnd = (FeatureControl*)_window;
  
  wnd->feature->setMode(CameraFeature::MODE_OneShotAuto);
  wnd->update(CameraFeature::MODE_OneShotAuto);
}


#endif // HAVE_LIBFLTK
#endif // HAVE_CAMERA

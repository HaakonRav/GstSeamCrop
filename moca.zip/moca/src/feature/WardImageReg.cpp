#include "feature/WardImageReg.h"

#include "feature/Feature.h"
#include "tools/Timing.h"
#include "types/MocaException.h"
#include "types/Rect.h"
#include <algorithm>

WardImageReg::WardImageReg()
{
  computeCountLUT();
}


void WardImageReg::computeCountLUT()
{
  bitCount.resize(256);
  for (uint32 i=0; i<bitCount.size(); ++i)
    {
      uint8 count = 0;
      uint32 index = i;
      for (uint32 j=0; j<8; ++j)
        {
          count += index%2;
          index /= 2;
        }
      bitCount[i] = count;
    }
}


int32 WardImageReg::findMean(VectorI const& hist, int32 percentage)
{
  int32 totalSum = 0;
  for (uint32 i=0; i<hist.size(); ++i)
    totalSum += hist[i];
  totalSum = (totalSum * percentage) / 100;
  int32 sum = 0;
  for (uint32 i=0; i<hist.size(); ++i)
    {
      sum += hist[i];
      if (sum >= totalSum)
        return i;
    }
  std::cout << "totalSum:" << totalSum << " sum:" << sum << std::endl;
  BOOST_THROW_EXCEPTION(RuntimeException("Funky error..."));
  return 0;
}


void WardImageReg::createBinImagePyr(Image8U const& img, BinImagePyr& imgPyr, uint8 mean, int32 maxBits)
{
  imgPyr.resize(maxBits);
  for (int32 i=0; i<maxBits; ++i)
    createBinImage(img, imgPyr[i], mean, i);
}


void WardImageReg::createBinImage(Image8U const& img, BinImage& binimg, uint8 mean, int32 pyrLevel)
{
  int32 factor = 1 << pyrLevel;
  binimg.width = img.width() / factor;
  binimg.height = img.height() / factor;
  binimg.widthStep = (binimg.width + 63)/64;
  binimg.image.resize(binimg.widthStep*binimg.height, 0);
  binimg.exclusion.resize(binimg.widthStep*binimg.height, (uint64)-1);

  for (int32 y=0; y<binimg.height; ++y)
    for (int32 x=0; x<binimg.width; ++x)
      {
        uint8 pix = img(x*factor, y*factor);
        if (pix >= mean)
          {
            uint64& bit = binimg.image[y*binimg.widthStep + x/64];
            bit |= ((uint64)1) << (63 - x%64);
          }
        uint8 lowerMean = mean > 4 ? mean-4 : 0;
        uint8 upperMean = mean < 251 ? mean+4 : 255;
        if (pix >= lowerMean && pix <= upperMean)
          {
            uint64& bit = binimg.exclusion[y*binimg.widthStep + x/64];
            bit ^= ((uint64)1) << (63 - x%64);
          }
      }
}


void WardImageReg::createGreyImage(BinImage const& binimg, Image8U& img)
{
  for (int32 y=0; y<binimg.height; ++y)
    for (int32 x=0; x<binimg.width; ++x)
      {
        uint64 bit = binimg.image[y*binimg.widthStep + x/64];
        bit &= ((uint64)1) << (63 - x%64);
        uint8 pix = (bit == 0) ? 0 : 255;
        img(x, y) = pix;
      }
}


/*
void WardImageReg::shiftBinImageVer(BinImage const& binimg, BinImage& result, int32 offset)
{
  result.setParms(binimg);
  int32 lineShift = offset*result.widthStep;

  for (int32 i=0; i<(int32)result.image.size(); ++i)
    if (i-lineShift >= 0 && i-lineShift < (int32)result.image.size())
      {
        result.image[i] = binimg.image[i-lineShift];
        result.exclusion[i] = binimg.exclusion[i-lineShift];
      }
    else
      {
        result.image[i] = 0;
        result.exclusion[i] = 0;
      }
}
*/


// offset in [-63..63]
void WardImageReg::shiftBinImageHor(BinImage const& binimg, BinImage& result, int32 offset)
{
  result.setParms(binimg);
  bool rightShift = offset >= 0;
  int32 amount = (rightShift ? offset : -offset) % 64;
  int32 invAmount = 64 - amount;
  uint64 mask = (uint64)-1;
  mask = rightShift ? (mask >> invAmount) : (mask << invAmount);
  // shifting a number by 64 gives odd result... make sure mask is zero
  mask = offset != 0 ? mask : 0;

  for (int32 line=0; line<(int32)result.image.size(); line += result.widthStep)
    {
      uint64 prevImgBits = 0, prevExBits = 0;
      if (rightShift) // or no shift
        for (int32 i=line; i<line+result.widthStep; ++i)
          {
            result.image[i] = (binimg.image[i] >> amount) | prevImgBits;
            result.exclusion[i] = (binimg.exclusion[i] >> amount) | prevExBits;
            prevImgBits = (binimg.image[i] & mask) << invAmount;
            prevExBits = (binimg.exclusion[i] & mask) << invAmount;
          }
      else // left shift
        for (int32 i=line+result.widthStep-1; i>=line; --i)
          {
            result.image[i] = (binimg.image[i] << amount) | prevImgBits;
            result.exclusion[i] = (binimg.exclusion[i] << amount) | prevExBits;
            prevImgBits = (binimg.image[i] & mask) >> invAmount;
            prevExBits = (binimg.exclusion[i] & mask) >> invAmount;
          }
    }
}


void WardImageReg::binImageDiff(BinImage const& binimg1, BinImage const& binimg2, int32 verOff, BinImage& result)
{
  /*std::cout << binimg1 << std::endl;
  std::cout << binimg2 << std::endl;
  std::cout << verOff << std::endl;*/

  result.setParms(binimg2);
  result.image = std::vector<uint64>(binimg2.image.size(), 0);
  verOff *= binimg2.widthStep;
  int32 size1 = binimg1.image.size();
  int32 size2 = binimg2.image.size();
  int32 start = verOff >= 0 ? 0 : -verOff;
  int32 end = verOff <= size1-size2 ? size2 : size1-verOff;

  //std::cout << "verOff:" << verOff << " start:" << start;
  //std::cout << " end:" << end << " size:" << size2 << std::endl << std::endl;

  for (int32 i=start; i<end; ++i)
    {
      result.image[i]  = binimg1.image[i+verOff] ^ binimg2.image[i];
      result.image[i] &= binimg1.exclusion[i+verOff];
      result.image[i] &= binimg2.exclusion[i];
    }
}


int32 WardImageReg::countOnes(BinImage const& binimg)
{
  int32 result = 0;
  uint8* ptr = (uint8*)(&binimg.image[0]);
  for (uint32 i=0; i<binimg.image.size()*8; ++i)
    {
      result += bitCount[*ptr];
      ++ptr;
    }
  return result;
}


void WardImageReg::computeShift(Image8U const& img1, Image8U const& img2, int32 maxBits, VectorI& offset)
{
  if(img1.width() != img2.width())
    BOOST_THROW_EXCEPTION(ArgumentException("Image width must be identical.") << ErrImg1(img1) << ErrImg2(img2));
  if (maxBits < 1 || maxBits > 6)
    BOOST_THROW_EXCEPTION(ArgumentException("Maximum bit shift must be in [1..6]") << ErrInt(maxBits));
  if (offset.size() != 2)
    BOOST_THROW_EXCEPTION(ArgumentException("Offset must be a two-dimensional vector.") << ErrVectorI(offset));
  if (offset[0] != 0)
    BOOST_THROW_EXCEPTION(ArgumentException("x-offset must be zero (for now...).") << ErrVectorI(offset));

  // calculate the maximum pyramid height such that the smallest image side is still >= 4
  uint32 smallest = std::min<uint32>(img1.width(), img2.width());
  smallest = std::min<uint32>(smallest, img1.height());
  smallest = std::min<uint32>(smallest, img2.height());
  int32 maxPyr = (int32)(log((double)smallest)/log(2.0)) - 1; // change to "- 2" for >= 8
  maxPyr = std::max(1, maxPyr); // always at least one pyramid level, even for smallest==3
  maxBits = std::min(maxPyr, maxBits);

  // ROI can't be set for a const image. Bypass but remember the original state.
  Rect oldRoi(img1.getRoi());
  Rect newRoi(Rect(offset[0], offset[1], img2.width(), img2.height()));
  newRoi.y = std::max(newRoi.y, 0);
  newRoi.y = std::min(newRoi.y, (int32)img1.height()-1);
  ((Image8U&)img1).setRoi(newRoi);

  // compute the histogram for the given ROI and reset the ROI.
  VectorI hist1(256), hist2(256);
  Feature::computeHist(img1, hist1);
  Feature::computeHist(img2, hist2);
  ((Image8U&)img1).setRoi(oldRoi);

  // compute the threshold values from the histograms. Ajust if too high or low.
  uint8 mean1 = findMean(hist1, 50);
  uint8 mean2 = findMean(hist2, 50);
  //std::cout << "means: " << (int)mean1 << ", " << (int)mean2;
  if (std::min<uint8>(mean1, mean2) < 5)
    {
      mean1 = findMean(hist1, 80);
      mean2 = findMean(hist2, 80);
      //std::cout << " -> " << (int)mean1 << ", " << (int)mean2;
    }
  else if (std::max<uint8>(mean1, mean2) > 250)
    {
      mean1 = findMean(hist1, 20);
      mean2 = findMean(hist2, 20);
      //std::cout << " -> " << (int)mean1 << ", " << (int)mean2;
    }
  //std::cout << std::endl;

  BinImagePyr bin1, bin2;
  createBinImagePyr(img1, bin1, mean1, maxBits);
  createBinImagePyr(img2, bin2, mean2, maxBits);

  VectorI approx = offset;
  computeShiftRec(bin1, bin2, 0, approx, offset);
}


void WardImageReg::computeShiftRec(BinImagePyr const& img1, BinImagePyr const& img2,
                                   uint32 level, VectorI const& approx, VectorI& offset)
{
  // assert(level < img1.size());
  VectorI currOff = approx;
  if (level < img1.size()-1) // recursion
    {
      computeShiftRec(img1, img2, level+1, approx/2, currOff);
      currOff *= 2;
    }
  // initialize with maximum possible
  int32 minDiff = img1[level].width * img1[level].height;
  for (int32 i=-1; i<=1; ++i)
    for (int32 j=-1; j<=1; ++j)
      {
        VectorI trans(currOff);
        trans[0] += i;
        trans[1] += j;
        BinImage shiftHor, shifted, diffImg;
        shiftBinImageHor(img2[level], shifted, trans[0]);
        //shiftBinImageVer(shiftHor, shifted, trans[1]);
        binImageDiff(img1[level], shifted, trans[1], diffImg);
        int32 diff = countOnes(diffImg);
        if (diff < minDiff)
          {
            minDiff = diff;
            offset = trans;
          }
      }
}


// ==================== BinImage ====================

void BinImage::setParms(BinImage const& o)
{
  width = o.width; height = o.height; widthStep = o.widthStep;
  image.resize(o.image.size());
  exclusion.resize(o.exclusion.size());
}


std::ostream& operator<<(std::ostream& stream, BinImage const& img)
{
  stream << "width:" << img.width << " height:" << img.height;
  stream << " widthStep:" << img.widthStep << " image.size():";
  stream << img.image.size() << " exclusion.size():";
  stream << img.exclusion.size();
  return stream;
}

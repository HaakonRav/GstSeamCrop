#define BOOST_TEST_DYN_LINK
#include "boost/test/unit_test.hpp"

#include "testcases.h"

#include "cudaHDR/CudaImage8UHandle.h"
#include "cudaHDR/CudaWrapper.h"

#include "io/ImageFileReader.h"
#include "io/ImageFileWriter.h"
#include "types/MocaException.h"
#include "filter/CvtColorSpace.h"

//Initially load needed testdata
struct testDataChangeStride
{
	//Will be available in every test case
	Image8U srcimg_RGB;

	//Initialize struct via constructor
	testDataChangeStride() : srcimg_RGB(640, 480, 3)
	{
		//Load bayer pattern testimage from hdd
		ImageFileReader ifr_RGB(RGB_IMG);
		ifr_RGB.getImage(srcimg_RGB);
	}
};

BOOST_FIXTURE_TEST_SUITE(changeStrideTestSuite, testDataChangeStride)

BOOST_AUTO_TEST_CASE(changeStrideTest)
{	
	MOCA_TRY;
	//Upload data to device
	CudaImage8UHandle srchandle;
	srchandle.put(srcimg_RGB);

	//Allocate target memory
	CudaImage8UHandle tgthandle;
	tgthandle.allocate(640, 480, 3, 5);

	//Change stride, copy contnt of srchandle to tgthandle
	MOCA_TIC(RUNS);
	CudaWrapper::changeStride(srchandle, tgthandle);
	MOCA_TOC("Change Stride GPU");

	//Free srchandle and reallocate memory (so srchandle is empty now)
	srchandle.free();
	srchandle.allocate(640, 480, 3, 3);

	//Change stride, copy content of tgthandle to srchandle
	CudaWrapper::changeStride(tgthandle, srchandle);

	//Download content of srchandle to tgtimg
	Image8U tgtimg(640, 480, 3);
	srchandle.getImage8UData(tgtimg);

	//Compare results
	BOOST_CHECK(compareImage8U(tgtimg, srcimg_RGB) < 10.0f);
	MOCA_CATCH;
}

BOOST_AUTO_TEST_CASE(changeStrideTestVaryBoth)
{
	MOCA_TRY;
	//Crop sourceimg
	Image8U srcimg_RGB_crop(603, 413, 3);
	cropImage8U(srcimg_RGB, srcimg_RGB_crop);

	//Upload data to device
	CudaImage8UHandle srchandle;
	srchandle.put(srcimg_RGB_crop);

	//Allocate target memory
	CudaImage8UHandle tgthandle;
	tgthandle.allocate(603, 413, 3, 6);

	//Change stride, copy contnt of srchandle to tgthandle
	CudaWrapper::changeStride(srchandle, tgthandle);

	//Free srchandle and reallocate memory (so srchandle is empty now)
	srchandle.free();
	srchandle.allocate(603, 413, 3, 3);

	//Change stride, copy content of tgthandle to srchandle
	CudaWrapper::changeStride(tgthandle, srchandle);

	//Download content of srchandle to tgtimg
	Image8U tgtimg(603, 413, 3);
	srchandle.getImage8UData(tgtimg);
	MOCA_CATCH;
}

BOOST_AUTO_TEST_SUITE_END()
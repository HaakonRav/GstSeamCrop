#include "types/CameraImage.h"

#include "types/MocaException.h"


#ifdef HAVE_LIBDC1394

CameraImage::CameraImage(dc1394video_frame_t* frame)
  : ImageBase(frame->size[0], frame->size[1], 1, IPL_DEPTH_8U), frame(frame)
{
  image->origin = 0;
  image->widthStep = frame->stride;
  image->imageSize = image->height * image->widthStep;
  image->imageData = (int8*)frame->image;
  image->imageDataOrigin = image->imageData;
  timestamp = frame->timestamp / 1000; // this->timestamp is in milliseconds
}


#else // HAVE_LIDBC1394


CameraImage::CameraImage(void* ptr)
  : ImageBase(128, 128, 1, IPL_DEPTH_8U)
{
  BOOST_THROW_EXCEPTION(NotImplementedException("libdc1394 not installed."));
}


#endif // HAVE_LIBDC1394

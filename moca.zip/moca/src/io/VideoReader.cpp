#include "io/VideoReader.h"
#include "types/MocaException.h"

// ==================== VideoReader ====================

VideoReader::VideoReader(std::string const& fileName)
  : fileName(fileName), duration(0), frameRate(0), frameCount(0), width(0), height(0), currentFrame(0), started(false), endOfVideo(false), pFormatCtx(0)
{

}

VideoReader::~VideoReader()
{
  if(started)
    stop();
}

void VideoReader::start()
{
  if (started)
    BOOST_THROW_EXCEPTION(IOException(std::string("You have to call stop() before you start again.") + fileName + std::string("'.")));
  
  av_register_all();

  if (avformat_open_input(&pFormatCtx, fileName.c_str(), NULL, NULL)==0 && av_find_stream_info(pFormatCtx)>=0)
  { 
    videoStream=-1;
    for(uint32 i=0; i<pFormatCtx->nb_streams; i++)
        if(pFormatCtx->streams[i]->codec->codec_type==AVMEDIA_TYPE_VIDEO)
        {
            videoStream=i;
            break;
        }

    if(videoStream == -1)
      BOOST_THROW_EXCEPTION(IOException(std::string("No Video Stream found in file '") + fileName + std::string("'.")));

    pCodecCtx=pFormatCtx->streams[videoStream]->codec;
    AVCodec *pCodec;
    pCodec=avcodec_find_decoder(pCodecCtx->codec_id);   

    if(pCodec==NULL || avcodec_open(pCodecCtx, pCodec)<0)
      BOOST_THROW_EXCEPTION(IOException(std::string("No Codec found for file '") + fileName + std::string("'.")));

	AVRational avgFR = pFormatCtx->streams[videoStream]->avg_frame_rate;
	frameRate=25;
	if (avgFR.num!=0 && avgFR.den!=0)
		frameRate=avgFR.num/((double)avgFR.den);
	frameCount=pFormatCtx->streams[videoStream]->duration;
	duration=(sizeType)(frameCount/frameRate);

    pFrame=avcodec_alloc_frame();
    pFrameBGR=avcodec_alloc_frame();     
    int32 numBytes;
    numBytes = avpicture_get_size(PIX_FMT_RGB24, pCodecCtx->width, pCodecCtx->height);
    buffer = new uint8_t[numBytes];
    avpicture_fill((AVPicture *)pFrameBGR, buffer, PIX_FMT_RGB24, pCodecCtx->width, pCodecCtx->height);
    width = pCodecCtx->width;
    height = pCodecCtx->height;
    bool tmp = true;
    while(tmp) {
      if(av_read_frame(pFormatCtx, &packet)<0) {
        tmp = false;
        endOfVideo = true;
      }
      if(packet.stream_index == videoStream)
        tmp = false;
      else
        av_free_packet(&packet);
    }
    started = true;
  }
  else
    BOOST_THROW_EXCEPTION(IOException(std::string("Couldn't open video file '") + fileName + std::string("'.")));

}

void VideoReader::stop()
{
  delete [] buffer;
  av_free(pFrameBGR);
  av_free(pFrame);
  av_free_packet(&packet);
  avcodec_close(pCodecCtx);
  av_close_input_file(pFormatCtx);
  
  currentFrame = 0;
  started = false;
  endOfVideo =false;
  
}

void VideoReader::getImage(Image8U& image)
{

  if (!started)
    BOOST_THROW_EXCEPTION(IOException(std::string("You have to call start() first.") + fileName + std::string("'.")));

  if(endOfVideo)
    BOOST_THROW_EXCEPTION(IOException(std::string("You are at the end of file. ") + fileName + std::string("'.")));

  int frameFinished = 0;
  static struct SwsContext *img_convert_ctx;
  while(!frameFinished)
    avcodec_decode_video2(pCodecCtx, pFrame, &frameFinished, &packet);
  
  if(frameFinished)
  {
    img_convert_ctx = sws_getContext(pCodecCtx->width, pCodecCtx->height, pCodecCtx->pix_fmt, pCodecCtx->width, 
        pCodecCtx->height, PIX_FMT_BGR24, SWS_BICUBIC | SWS_CPU_CAPS_MMX, NULL, NULL, NULL);
    sws_scale(img_convert_ctx, pFrame->data, pFrame->linesize, 0, pCodecCtx->height, pFrameBGR->data, pFrameBGR->linesize);
    
    uint8_t* dataP = pFrameBGR->data[0];  
    for (uint32 y=0; y<height; y++)
    {
      for (uint32 x=0; x<width; x++)
      {
        image(x, y, 0) =*dataP++;
        image(x, y, 1) =*dataP++;
        image(x, y, 2) =*dataP++;
      }
    } 
  }
 
  bool tmp = true;
  while(tmp) {
    av_free_packet(&packet);
    if(av_read_frame(pFormatCtx, &packet)<0) {
      tmp = false;
      endOfVideo = true;
    }
    if(packet.stream_index == videoStream)
      tmp = false;
  }
  av_free(img_convert_ctx);
  currentFrame++;    
}
  
sizeType VideoReader::getDuration()
{
  return duration;
}

double VideoReader::getFrameRate()
{
  return frameRate;
}

int64_t VideoReader::getTotalFrameCount()
{
  return frameCount;
}

int64_t VideoReader::getCurrentFrameCount()
{
  return currentFrame;
}

sizeType VideoReader::getImageWidth()
{
  return width;
}

sizeType VideoReader::getImageHeight()
{
  return height;
}

Rect VideoReader::getImageDimension()
{
  return Rect(0,0,width,height);
}

int32 VideoReader::getImageChannels()
{
  return 3;
}

bool VideoReader::getEndOfVideo()
{
  return endOfVideo;
}

void VideoReader::setFileName(std::string const& newFileName)
{
  stop();
  fileName = newFileName;
}

#include "gui/ImageWindow.h"

#ifdef HAVE_LIBFLTK


ImageWindow::ImageWindow(Rect rect, std::string title, std::string fileName)
  : DisplayWindow(rect, title)
{
  reader = boost::shared_ptr<ImageFileReader>(new ImageFileReader(fileName));
  reader->start();
  image = boost::shared_ptr<Image8U>(new Image8U(reader->getImageWidth(), reader->getImageHeight(), reader->getImageChannels()));
}


ImageWindow::~ImageWindow()
{
  if (reader)
    reader->stop();
}

#endif // HAVE_LIBFLTK

#include "feature/Feature.h"

#include <algorithm>
#include "tools/Timing.h"
#include "types/MocaException.h"
#include "types/ImageBase.h"
#include "types/Image8U.h"
#include "types/Image16S.h"
#include "types/Image32F.h"
#include "types/CameraImage.h"
#include "types/Color.h"
#include "types/Rect.h"
#include "types/Vector.h"


void Feature::computeCoG(ImageBase const& image, double& x, double& y, Rect const area, int32 compColor)
{
  if (!((image.image->depth == IPL_DEPTH_8U)||(image.image->depth == IPL_DEPTH_32F)) || (image.channels() != 1))
    BOOST_THROW_EXCEPTION(ArgumentException("computeCoG(): Invalid image format") << ErrImg1(image));
  if ((area.x < 0) || (area.y < 0) || (area.x > (int)image.width()) || (area.y > (int)image.height())
      || (area.w < 0) || (area.h < 0) || (area.x+area.w > (int)image.width()) || (area.y+area.h > (int)image.height()))
    BOOST_THROW_EXCEPTION(ArgumentException("computeCoG(): Invalid image area."));

  x = y = 0;
  double weight = 0;
  for (int32 posy=area.y; posy<area.y+area.h; ++posy)
    for (int32 posx=area.x; posx<area.x+area.w; ++posx)
      {
	double val;
	if (image.image->depth == IPL_DEPTH_8U)
	{
	  Image8U const& img = *(static_cast<Image8U const*>(&image));
	  val = img(posx, posy);
	}
	else
	{
	  Image32F const& img = *(static_cast<Image32F const*>(&image));
	  val = img(posx, posy);
	}
	if (compColor < 0 || (int32)val == compColor)
	  {
	    x += posx*val;
	    y += posy*val;
	    weight += val;
	  }
      }
  if (weight != 0)
    {
      x /= weight;
      y /= weight;
    }
  else
    {
      x = area.x + area.w/2.0;
      y = area.y + area.h/2.0;
    }
}


void Feature::computeHist(ImageBase const& image, VectorI& hist, double normFactor)
{
  if (image.channels() == 1) // OpenCV can only compute single channel histograms
    {
      int32 bins = hist.size();
      CvHistogram* histogram = cvCreateHist(1, &bins, CV_HIST_ARRAY);
      cvCalcHist((IplImage**)&(image.image), histogram);
      if (normFactor > 0)
        cvNormalizeHist(histogram, normFactor);

      for (int32 bin=0; bin<bins; ++bin)
        hist[bin] = (int32)(cvQueryHistValue_1D(histogram, bin));

      cvReleaseHist(&histogram);
    }
  else if (typeid(image) == typeid(Image8U))
    {
      for (uint32 bin=0; bin<hist.size(); ++bin)
        hist[bin] = 0;
      Image8U const& img = (Image8U const&)image;
      assert((int)img.width()*3 == img.widthStep());
      uint8 const* ptr = &(img(0, 0));
      uint8 const* end = &(img(img.width()-1, img.height()-1));
      while (ptr <= end)
        {
          ++hist[*ptr];
          ptr += 3;
        }
    }
  else
    BOOST_THROW_EXCEPTION(ArgumentException("Histograms only computable on single channel images or Image8U."));
}


void Feature::goodFeatures(ImageBase const& image, std::vector<Vector>& features, double qualityLevel, double minDist, int maxFeatures)
{
  if(typeid(image) == typeid(CameraImage))
    BOOST_THROW_EXCEPTION(ArgumentException("CameraImages can't be passed to this OpenCV filter."));

  Image32F eigImage(image.width(), image.height(), image.channels());
  Image32F tmpImage(image.width(), image.height(), image.channels());
  std::vector<CvPoint2D32f> corners(maxFeatures);
  //cvGoodFeaturesToTrack(image.image, eigImage.image, tmpImage.image, &corners[0], &maxFeatures, qualityLevel, minDist);
  cvGoodFeaturesToTrack(image.image, eigImage.image, tmpImage.image, &corners[0], &maxFeatures, qualityLevel, minDist, NULL, 3, true);
  features.reserve(maxFeatures);
  for (int i=0; i<maxFeatures; ++i)
    {
      Vector v(2);
      v[0] = corners[i].x;
      v[1] = corners[i].y;
      features.push_back(v);
    }
}


void Feature::minMaxLoc(ImageBase const& image, double& minVal, double& maxVal, VectorI& minLoc, VectorI& maxLoc)
{
  if(image.channels() != 1)
    BOOST_THROW_EXCEPTION(ArgumentException("minMaxLoc(): Image must be single channel.") << ErrImg1(image));
  if(minLoc.size() != 2 || maxLoc.size() != 2)
    BOOST_THROW_EXCEPTION(ArgumentException("minMaxLoc(): Expected two-dimensional vectors as location vectors."));

  CvPoint cvMinLoc, cvMaxLoc;
  cvMinMaxLoc(image.image, &minVal, &maxVal, &cvMinLoc, &cvMaxLoc);
  minLoc[0] = cvMinLoc.x;
  minLoc[1] = cvMinLoc.y;
  maxLoc[0] = cvMaxLoc.x;
  maxLoc[1] = cvMaxLoc.y;
}


void Feature::convertHSVRGB(double h, double s, double v, Color& color)
{
  if(color.isGrayscale())
    color.convertToRGB();

  h = (h>=1)||(h<0) ? 0 : h;
  s = (s<0) ? 0 : s;
  s = (s>1) ? 1 : s;
  v = (v<0) ? 0 : v;
  v = (v>1) ? 1 : v;
  v *= 255;
  int32 r = ((int32)(h*360))/60;
  double f = h*6 - r;
  double p = v * (1-s);
  double q = v * (1-f*s);
  double t = v * (1-(1-f)*s);
  uint8 red, green, blue;
  switch(r)
    {
    case 0: red = (uint8)v; green = (uint8)t; blue = (uint8)p; break;
    case 1: red = (uint8)q; green = (uint8)v; blue = (uint8)p; break;
    case 2: red = (uint8)p; green = (uint8)v; blue = (uint8)t; break;
    case 3: red = (uint8)p; green = (uint8)q; blue = (uint8)v; break;
    case 4: red = (uint8)t; green = (uint8)p; blue = (uint8)v; break;
    case 5: red = (uint8)v; green = (uint8)p; blue = (uint8)q; break;
    default:
      red = green = blue = 0;
    }
    
  color[Color::RED] = red;
  color[Color::GREEN] = green;
  color[Color::BLUE] = blue;
}


template<class T> inline void pixelBilerpTemp(T const& image, double& value, double x, double y)
{
  if ((x < 0) || (x >= image.width()-1) || (y < 0) || (y >= image.height()-1))
    BOOST_THROW_EXCEPTION(ArgumentException(1, "pixelBilerp(): x or y values are outside the image or at the image border."));

  int32 x0 = (int32)x;
  int32 y0 = (int32)y;
  x -= x0;
  y -= y0;
  
  double f00 = image(x0  , y0  );
  double f10 = image(x0+1, y0  );
  double f01 = image(x0  , y0+1);
  double f11 = image(x0+1, y0+1);
  
  value = (f10-f00)*x + (f01-f00)*y + (f11-f10-f01+f00)*x*y + f00;
}


void Feature::pixelBilerp(Image8U const& image, double& value, double x, double y)
{
  pixelBilerpTemp<Image8U>(image, value, x, y);
}


void Feature::pixelBilerp(CameraImage const& image, double& value, double x, double y)
{
  pixelBilerpTemp<CameraImage>(image, value, x, y);
}


void Feature::pixelBilerp(Image16S const& image, double& value, double x, double y)
{
  pixelBilerpTemp<Image16S>(image, value, x, y);
}


void Feature::pixelBilerp(Image32F const& image, double& value, double x, double y)
{
  pixelBilerpTemp<Image32F>(image, value, x, y);
}


void Feature::pixel8UGauss(Image8U const& image, double& value, unsigned int x, unsigned int y)
{
  if (image.channels() != 1)
    BOOST_THROW_EXCEPTION(ArgumentException("pixel8UGauss(): Image must be 8 Bit one channel for gauss pixel access.") << ErrImg1(image));
  if ((x < 1) || (x > image.width()-2) || (y < 1) || (y > image.height()-2))
    BOOST_THROW_EXCEPTION(ArgumentException("pixel8UGauss(): Cannot compute gaussian mask at the image border."));

  // Gauss mask: 1/16
  // 1 2 1
  // 2 4 2
  // 1 2 1
  uint8* ptr = (uint8*)(&image(x-1,y-1));
  value = *ptr;
  ++ptr;
  value += 2 * (*ptr);
  ++ptr;
  value += *ptr;
  ptr += image.widthStep();
  value += 2 * (*ptr);
  --ptr;
  value += 4 * (*ptr);
  --ptr;
  value += 2 * (*ptr);
  ptr += image.widthStep();
  value += *ptr;
  ++ptr;
  value += 2 * (*ptr);
  ++ptr;
  value += *ptr;

  value /= 16.0;
}


void Feature::saliencyMap(Image8U const& image, Image8U& saliency, int radius, double sigma)
{
  uint32 w = image.width();
  uint32 h = image.height();

  for(uint32 y=0; y<h; y++)
    for(uint32 x=0; x<w; x++) {
      long c = 0;
      int pix1[3];
      pix1[0] = image(x, y, 0);
      pix1[1] = image(x, y, 1);
      pix1[2] = image(x, y, 2);
     
      Rect area(std::max<int>(x-radius, 0), std::max<int>(y-radius, 0),
                std::min<int>(x+radius, w-1), std::min<int>(y+radius, h-1));

      for(int dy=area.y; dy<=area.h; dy++)
        for(int dx=area.x; dx<area.w; dx++) {
          int pix2[3];
          pix2[0] = image(dx, dy, 0) - pix1[0];
          pix2[1] = image(dx, dy, 1) - pix1[1];
          pix2[2] = image(dx, dy, 2) - pix1[2];
          pix2[0] *= pix2[0];
          pix2[1] *= pix2[1];
          pix2[2] *= pix2[2];
          
          double gaussian = sqrt((double)pix2[0] + pix2[1] + pix2[2]);
          gaussian = 1 - exp(-gaussian/(2*sigma*sigma));
          c += (int)(255*gaussian);
	}
      c /= (area.w-area.x+1) * (area.h-area.y+1);
      saliency(x, y) = (uint8)std::min<long>(c, 255);
    }
}

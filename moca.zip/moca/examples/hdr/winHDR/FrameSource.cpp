#include "FrameSource.h"

#ifdef HAVE_LIBDC1394

#include "io/DC1394Reader_Triggered.h"
#include "io/HDRExposureIO.h"
#include "filter/CvtColorSpace.h"
#include "filter/Filter.h"
#include "filter/HDR.h"
#include "filter/OptHDR.h"
#include "filter/SequenceHDR.h"
#include "feature/OptimalShutter.h"
#include "tools/Timing.h"

extern boost::shared_ptr<WinHDRStatus> status;


HDRCamera::HDRCamera(CaptureMode mode)
  : mode(mode)
{
  std::vector<std::string> cameraList;
  DC1394Reader::enumerateCameras(cameraList);

  if(cameraList.size() > 0)
    {
      reader = boost::shared_ptr<DC1394Reader_Triggered>(new DC1394Reader_Triggered(CameraReader::SPEED_800, CameraReader::MODE_RAW8, 0));
      reader->start();

      switch (mode)
        {
        case TRIGGERED:
          hdr = boost::shared_ptr<HDR>(new HDR(reader, 10, 254, 10));
          break;
        case SEQUENCE:
          hdr = boost::shared_ptr<HDR>(new SequenceHDR(reader, 10, 254, 10, 70));
          break;
        case OPTSHUTTER:
          hdr = boost::shared_ptr<HDR>(new OptHDR(reader, 10, 254, 10));
          break;
        default: assert(!"Invalid HDR capture mode");
        }

      reader->getMaxImageSize(imgWidth, imgHeight);
 
      CameraFeaturePtr shutFeat = reader->getFeature(CameraFeature::FEATURE_Shutter);
      minShutter = shutFeat->getMin();
      maxShutter = shutFeat->getMax();
    }
}


void HDRCamera::getFrame(HDRFrame& frame)
{
  if (reader == 0)
    return;
    
  if (status->hdrSwitch)
    {
      hdr->captureHDR(frame.expSet);
      Timing::start(7);
      frame.convertBayerToBGR();
      //std::cout << "Debayering: " << Timing::stop(7) << std::endl;
    }
  else
    {
      reader->captureImage(Rect(0, 0, imgWidth, imgHeight), (uint32)256);
      reader->getImage(*frame.captureImage);
      CvtColorSpace::convert(*frame.captureImage, *frame.displayImage, COLOR_BayerGB, COLOR_BGR);
    }
}


boost::shared_ptr<HDRFrame> HDRCamera::createFrame()
{
  if (reader != 0)
#ifndef HAVE_CUDA
    return boost::shared_ptr<HDRFrame>(new HDRFrame(imgWidth, imgHeight));
#else
    return boost::shared_ptr<HDRFrame>(new CudaHDRFrame(imgWidth, imgHeight));
#endif  
  else
    return boost::shared_ptr<HDRFrame>(new HDRFrame(1, 1));
}


void HDRCamera::estimateNextShutter(HDRFrame& frame)
{
  frame.clear();
  if (mode == TRIGGERED)
    {
      double avg = frame.hist.avg();
      float nextShutter = exp(0.5 * log(10 * 254)); // darkest * brightest
      nextShutter /= exp(avg);
      nextShutter = std::min<float>(nextShutter, maxShutter);
      nextShutter = std::max<float>(nextShutter, minShutter);
      Exposure exp(boost::shared_ptr<Image8U>(new Image8U(imgWidth, imgHeight, 1)),
                   Vector2D::create(0, 0), nextShutter, Exposure::TOO_BOTH, 0);
      frame.expSet.push_back(exp);
    }
  else if (mode == OPTSHUTTER)
    {
      double maxCoverage = 0.9 * 307200; // 90% of the full histogram (VGA resolution)
      std::vector<double> shut(OptimalShutter::findBestShutters(frame.hist, 8, maxCoverage));
      frame.expSet.resize(shut.size());
      for (uint32 i=0; i<shut.size(); ++i)
        frame.expSet[i] = Exposure(boost::shared_ptr<Image8U>(new Image8U(imgWidth, imgHeight, 1)),
                                   Vector2D::create(0, 0), shut[i], Exposure::TOO_BOTH, 0);
    }
}


// ==================== ExposureLoader ====================

ExposureLoader::ExposureLoader(std::string path)
  : path(path)
{
  boost::shared_ptr<HDRExposureIO> reader = HDRExposureIO::createReader(path);
  expSets.resize(reader->getNumExposures());
  std::cout << "Loading " << expSets.size() << " exposures: ";
  for (uint32 i=0; i<expSets.size(); ++i)
    {
      std::cout << i << "  "; std::cout.flush();
      reader->getNext(expSets[i]);
    }
  std::cout << std::endl;
  reader->close();

  currentSet = 0;
  currentExp = 0;
}

void ExposureLoader::getFrame(HDRFrame& frame)
{
  frame.clear();
  frame.expSet = expSets[currentSet];
  Filter::set(*frame.displayImage, 192);
  if (expSets[currentSet][currentExp].image->channels() == 1)
    frame.convertBayerToBGR();
  Filter::copyImage(*frame.expSet[currentExp].image, *frame.displayImage, expSets[currentSet][currentExp].topLeft);
}


boost::shared_ptr<HDRFrame> ExposureLoader::createFrame()
{
  assert(expSets.size() > 0 && expSets[0].size() > 0);
  uint32 w = expSets[0][0].image->width();
  uint32 h = expSets[0][0].image->height();
#ifndef HAVE_CUDA
  return boost::shared_ptr<HDRFrame>(new HDRFrame(w, h));
#else
  return boost::shared_ptr<HDRFrame>(new CudaHDRFrame(w, h));
#endif
}


void ExposureLoader::nextSet()
{
  currentSet = (currentSet + 1) % expSets.size();
  std::cout << "Current Exposure Set: " << currentSet << std::endl;
  currentExp = 0;
}


void ExposureLoader::prevSet()
{
  currentSet = (currentSet + expSets.size() - 1) % expSets.size();
  std::cout << "Current Exposure Set: " << currentSet << std::endl;
  currentExp = 0;
}


void ExposureLoader::nextExp()
{
  std::vector<Exposure> const& exp = expSets[currentSet];
  currentExp = (currentExp + 1) % exp.size();
  std::cout << currentExp << ") " << exp[currentExp] << std::endl;
}


void ExposureLoader::prevExp()
{
  std::vector<Exposure> const& exp = expSets[currentSet];
  currentExp = (currentExp + exp.size() - 1) % exp.size();
  std::cout << currentExp << ") " << exp[currentExp] << std::endl;
}


#endif // HAVE_LIBDC1394


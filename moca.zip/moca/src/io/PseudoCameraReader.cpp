#include "io/PseudoCameraReader.h"
#include "io/PseudoCameraFeature.h"
#include "io/IO.h"
#include "filter/Filter.h"
#include "types/MocaException.h"



// ==================== PseudoCameraReader ====================

PseudoCameraReader::PseudoCameraReader(std::string fileName)
  : CameraReader(CameraReader::MODE_MONO8), fileName(fileName),
    unitSizeX(4), unitSizeY(2), unitPosX(2), unitPosY(2)
{
  for(indexType i = 0; i < CameraFeature::numFeatures; i++)
  {
    CameraFeature::Type featType = (CameraFeature::Type)i;
    boost::shared_ptr<CameraFeature> feature(new PseudoCameraFeature(featType));
    features.push_back(feature);
    featIndices[featType] = i;
  }

  if(fileName.size() == 0)
  {
    loadImages = false;
    imageWidth = 640;
    imageHeight = 480;
    imageChannels = 1;
    return;
  }
  loadImages = true;
  
  std::stringstream ss;
  ss << fileName << "000.png";
  // load the first image to see if they exist at all and to determine the image sizes
  capturedImage = IO::loadImage(ss.str());
  imageWidth = capturedImage->width();
  imageHeight = capturedImage->height();
  imageChannels = capturedImage->channels();
}


PseudoCameraReader::~PseudoCameraReader()
{
}

 
void PseudoCameraReader::start()
{
}


void PseudoCameraReader::stop()
{
}


boost::shared_ptr<CameraImage> PseudoCameraReader::getImagePtr()
{
  BOOST_THROW_EXCEPTION(NotImplementedException("PseudoCameraReader doesn't support getImagePtr()"));
  return boost::shared_ptr<CameraImage>(new CameraImage(NULL));
}

void PseudoCameraReader::captureImage(Rect roi, uint32 shutter, float gain)
{
  if (shutter > 4096)
    BOOST_THROW_EXCEPTION(ArgumentException("captureImage(): Shutter too high."));
  if (!loadImages)
    return;
    
  indexType imgNr = 0;
  while ((shutter = (shutter >> 1)) > 0)
    ++imgNr;

  std::stringstream ss;
  ss << fileName;
  if (imgNr < 100)
    ss << "0";
  if (imgNr < 10)
    ss << "0";
  ss << imgNr << ".png";

  boost::shared_ptr<Image8U> fullImage = IO::loadImage(ss.str());
  capturedImage = boost::shared_ptr<Image8U>(new Image8U(roi.w, roi.h, 1));
  VectorI point(2);
  point[0] = 0;
  point[1] = 0;
  Filter::copyImage(*fullImage, *capturedImage, roi, point);
}


void PseudoCameraReader::getImage(Image8U& img)
{
  if (!loadImages)
    return;
  if (img.width() < capturedImage->width() || img.height() < capturedImage->height())
    BOOST_THROW_EXCEPTION(ArgumentException("getImage(): Image buffer too small.") << ErrImg1(img));
  img.copyFrom(*capturedImage);
}


sizeType PseudoCameraReader::getImageWidth()
{
  return imageWidth;
}


sizeType PseudoCameraReader::getImageHeight()
{
  return imageHeight;
}


Rect PseudoCameraReader::getImageDimension()
{
  return Rect(0, 0, imageWidth, imageHeight);
}


void PseudoCameraReader::getMaxImageSize(sizeType& imageWidth, sizeType& imageHeight)
{
  imageWidth = this->imageWidth;
  imageHeight = this->imageHeight;
}


int32 PseudoCameraReader::getImageChannels()
{
  return imageChannels;
}


void PseudoCameraReader::getUnitSize(sizeType& unitSizeX, sizeType& unitSizeY)
{
  unitSizeX = this->unitSizeX;
  unitSizeY = this->unitSizeY;
}


void PseudoCameraReader::getUnitPos(uint32& unitPosX, uint32& unitPosY)
{
  unitPosX = this->unitPosX;
  unitPosY = this->unitPosY;
}


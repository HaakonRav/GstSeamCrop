#define BOOST_TEST_DYN_LINK
#include "boost/test/unit_test.hpp"

#include "testcases.h"

#include "cudaHDR/CudaImage8UHandle.h"
#include "cudaHDR/CudaImage32FHandle.h"
#include "cudaHDR/CudaExposureHandle.h"
#include "cudaHDR/CudaWrapper.h"
#include "cudaHDR/CudaVectorHandle.h"
#include "cudaHDR/DeviceManager.h"

#include "io/HDRExposureIO.h"
#include "io/ImageFileWriter.h"
#include "filter/HDRStitching.h"
#include "filter/CvtColorSpace.h"
#include "types/MocaException.h"

//Initially load needed test exposure set
struct testDataHDRStitch
{
	//Will be available in every test case
	std::vector<Exposure> srcexp;

	//Initialize struct
	testDataHDRStitch()
	{
		//Load test exposure from hdd
		HDRExposureIO::loadVector(STDEXP, srcexp);

		//Color convert exposure set
		for (unsigned int i = 0; i < srcexp.size(); i++)
			CvtColorSpace::convert(*(srcexp[i].image), *(srcexp[i].image), COLOR_BGR, COLOR_Yxy);
	}
};

BOOST_FIXTURE_TEST_SUITE(HDRStitchTestSuite, testDataHDRStitch)

BOOST_AUTO_TEST_CASE(HDRStitchTest)
{
	//Stitch on CPU
	Image32F target_cpu(640, 480, 3);
	MOCA_TIC(RUNS);
	HDRStitching::weighted(srcexp, target_cpu);
	MOCA_TOC("Stitching CPU");

	//Stitch on GPU
	std::vector<CudaExposureHandle> srcexphandle(srcexp.size());
	for (unsigned int i = 0; i < srcexphandle.size(); i++)
		srcexphandle[i].put(srcexp[i]);

	CudaImage32FHandle targethandle;
	targethandle.allocate(640, 480, 3, 3);
	MOCA_TIC(RUNS);
	CudaWrapper::stitchHDR(srcexphandle, targethandle);
	MOCA_TOC("Stitching GPU");
	Image32F target_gpu(640, 480, 3);
	targethandle.getImage32FData(target_gpu);

	//Compare images
	BOOST_CHECK(compareImage32F(target_cpu, target_gpu) < 10.0f);
}

BOOST_AUTO_TEST_SUITE_END()
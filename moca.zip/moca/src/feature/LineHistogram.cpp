#include "feature/LineHistogram.h"

#include <fstream>

#include "types/Exposure.h"
#include "feature/Feature.h"
#include "tools/Timing.h"
#include "types/MocaException.h"
#include "types/Rect.h"
#include "tools/Maths.h"
#include "tools/Timing.h"

#include <fstream>
#include <iostream>
using namespace std;

LineHist::LineHist()
{
}

LineHist::LineHist(Rect roi)
  : white(0), black(0), roi(roi)
{
}

void LineHist::create(Image8U const& image, uint8 mean, uint8 noiseThresh, bool rows)
{
  int size = rows ? roi.h : roi.w;
  white.clear(); black.clear();
  white.resize(size, 0);
  black.resize(size, 0);

  uint8 upperMean = std::min<uint8>(255, mean+noiseThresh);
  uint8 lowerMean = std::max<uint8>(0, mean-noiseThresh);
  int32 w=roi.x+roi.w, h=roi.y+roi.h;
  for (int32 y=roi.y; y<h; ++y)
    for (int32 x=roi.x; x<w; ++x)
      {
        int32 index = rows ? y-roi.y : x-roi.x;
        if (image(x, y) > upperMean)
          ++white[index];
        else if (image(x, y) < lowerMean)
          ++black[index];
      }
  
  /*for (uint32 i=0; i<hist.size(); ++i)
    std::cout << hist[i] << ", ";
    std::cout << std::endl;*/
}

int32 LineHist::corrOffset(LineHist const& other, int32 guess, int32 maxOffset)
{
  double maxCorr = -INFINITY;
  int32 result = 0;
  int32 start=-maxOffset+guess, end=maxOffset+guess;
  for (int32 off=start; off <= end; ++off)
    {
      double sum1 = 0, sum2 = 0; // sum of the squares
      double xcorr = 0;
      for (int32 i=end; i<(int32)white.size()+start; ++i)
        {
          sum1 += white[i]*white[i] + black[i]*black[i];
          sum2 += other.white[i-off]*other.white[i-off] + other.black[i-off]*other.black[i-off];

          xcorr += white[i] * other.white[i-off];
          xcorr += black[i] * other.black[i-off];
        }
      double norm = sqrt(sum1*sum2);
      xcorr /= norm;
      if (xcorr > maxCorr)
        {
          maxCorr = xcorr;
          result = off;
        }
    }

  return result;
}
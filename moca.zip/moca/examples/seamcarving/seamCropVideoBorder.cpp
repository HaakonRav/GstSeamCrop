// AKTUELLE VERSION <---


// MOCA headers 
#include "types/MocaTypes.h"
#include "types/Image8U.h"
#include "types/Image32F.h"
#include "types/MocaException.h"
#include "feature/Feature.h"
#include "feature/OpticalFlow.h"
#include "filter/Filter.h"
#include "filter/SeamCropImage.h"
#include "filter/SeamCarvingImage.h"
#include "filter/FrequencyTunedSaliency.h"
#include "io/IO.h"
#include "io/VideoReader.h"
#include "io/VideoWriter.h"
#include <sstream>

#include "tools/Timing.h"
 
// C++ headers 
#include <string>
#include <math.h>
#include <iostream>
#include <deque>
#include <algorithm>
using namespace std;

// The class first calculates a cropping window of target size. It then adds x% to the borders and removes 
// them again through seam carving. For temporal coherence, more seams are searched in a next key frame 
// and the closest with the minimal costs are used.


struct seamPair{
 uint32 Nr1;
 uint32 Nr2;
 float cost;
};

struct extendedBorders{
  uint32 left;
  uint32 right;
};

#if 0
static void printImage32F(string const& destPath, Image32F const& frame)
{
    uint32 width = frame.width();
    uint32 height = frame.height();
    Image8U print(width, height,1);
    
    float max = 0;
    float min = 1000;
    for (uint32 x = 0; x < width; x++) 
      for (uint32 y = 0; y < height; y++)
      {
	if(frame(x,y) < min)
	 min = frame(x,y);
	 
	if(frame(x,y) > max)
	 max = frame(x,y);
      }
    
    
    cout << "PRINT min = " << min << ", max = " << max << endl;
    float v = 0;
    float factor = 255.0/(max - min);
    //if(factor > 10.0) 
	//factor = 10.0;
    
    for (uint32 x = 0; x < width; x++) 
      for (uint32 y = 0; y < height; y++)
      {
	v = frame(x,y);
	v -= min;
	v *= factor;
	print(x,y) = (int) ( v + 0.5);
      }
	
    try
      {
	    cerr << "save image" << endl; 
    	    IO::saveImage(destPath, print); 
      } 
    catch (MocaException e) 
      {
	    std::cout << "save Image error: " << e.what() << std::endl;
	    exit (-1);
   }    
}
#endif

#if 0
static void drawSeams(Image8U& drawImage, Image32F& allSeams, uint32 const& cropLeftPos, extendedBorders const& border, uint32 const& targetWidth)
{
  uint32 width = drawImage.width();
  uint32 height = drawImage.height();
  uint32 specialWidth = allSeams.width();
  uint32 cropRightPos = cropLeftPos + targetWidth;
  
      
   for (uint32 n = 0; n < specialWidth; n++) 
	for(uint32 y = 0; y < height; y++)
	{
	      drawImage( border.left +(allSeams(n,y)), y, 0) = 0;
	      drawImage( border.left +(allSeams(n,y)), y, 1) = 0;
	      drawImage( border.left +(allSeams(n,y)), y, 2) = 255;
	      
	      
	}
	
    for (uint32 x = 0; x < width; x++) 
	for(uint32 y = 0; y < height; y++)
	{
	if(x == cropLeftPos)
	      {
	        drawImage(x,y,0) = 0;
		drawImage(x,y,1) = 255;
		drawImage(x,y,2) = 0;
		
		if(cropLeftPos > 0)
		{
		  drawImage(x-1,y,0) = 0;
		  drawImage(x-1,y,1) = 255;
		  drawImage(x-1,y,2) = 0;
		}
		else
		  drawImage(x+1,y,0) = 0;
		  drawImage(x+1,y,1) = 255;
		  drawImage(x+1,y,2) = 0;
	      }
	if(x == cropRightPos)
	      {
	        drawImage(x,y,0) = 0;
		drawImage(x,y,1) = 255;
		drawImage(x,y,2) = 0;
		
		if(cropRightPos < width-1)
		{
		  drawImage(x+1,y,0) = 0;
		  drawImage(x+1,y,1) = 255;
		  drawImage(x+1,y,2) = 0;
		}
		else
		  drawImage(x-1,y,0) = 0;
		  drawImage(x-1,y,1) = 255;
		  drawImage(x-1,y,2) = 0;
	      }
	if(x == border.left)
	      {
	        drawImage(x,y,0) = 255;
		drawImage(x,y,1) = 0;
		drawImage(x,y,2) = 0;
		
		if(border.left > 0)
		{
		  drawImage(x-1,y,0) = 255;
		  drawImage(x-1,y,1) = 0;
		  drawImage(x-1,y,2) = 0;
		}
		else
		  drawImage(x+1,y,0) = 255;
		  drawImage(x+1,y,1) = 0;
		  drawImage(x+1,y,2) = 0;
	      }
	if(x == border.right)
	      {
	        drawImage(x,y,0) = 255;
		drawImage(x,y,1) = 0;
		drawImage(x,y,2) = 0;
		
		if(border.right < width-1)
		{
		  drawImage(x+1,y,0) = 255;
		  drawImage(x+1,y,1) = 0;
		  drawImage(x+1,y,2) = 0;
		}
		else
		  drawImage(x-1,y,0) = 255;
		  drawImage(x-1,y,1) = 0;
		  drawImage(x-1,y,2) = 0;
	      }
	}
}
#endif


#if 0
static void drawCropWindowPath(vector<uint32>& cropLeft, uint32 const& specialWidth)
{
  uint32 frameCount = cropLeft.size();
  Image8U result(specialWidth, frameCount, 3);
	
  for (uint32 t = 0; t < frameCount; t++) 
  {
      for(uint32 x = 0; x < specialWidth; x++)
	for(uint32 c = 0; c < 3; c++)
	   result(x,t,c) = 255;
	
    result(cropLeft[t], t, 0) = 0;
    result(cropLeft[t], t, 2) = 0;
  }
  IO::saveImage("/home/stud/kiess/Videos/result/cropping_seamBorder.png", result); 
}
#endif


#if 1
// normalizes the values of an Image32F (with only 1 channel) into a range between 0 and 255
static void normalize32F(Image32F& frame)
{
    uint32 width = frame.width();
    uint32 height = frame.height();

    float max = 0;
    float min = frame(width-1, height-1);
    for (uint32 x = 0; x < width; x++) 
      for (uint32 y = 0; y < height; y++)
      {
	if(frame(x,y) < min)
	 min = frame(x,y);
	 
	if(frame(x,y) > max)
	 max = frame(x,y);
      }
    
    float factor = 255.0/(max - min);
    //if(factor > 10.0) 
	//factor = 10.0;
    
    for (uint32 x = 0; x < width; x++) 
      for (uint32 y = 0; y < height; y++)
      {
	frame(x,y) -= min;
	frame(x,y) *= factor;
      }
}
#endif


// load the frames of the video in a deque list
void loadVideo(string const& videoPath, deque<Image8U>& video)
{
  VideoReader reader(videoPath);
  reader.start();
  cout << "CHECK" << endl;
  Image8U frame(reader.getImageWidth(), reader.getImageHeight(), 3);
  
  while(!reader.getEndOfVideo()) 
    {
      reader.getImage(frame); 
      video.push_back(frame);
    }
    
  reader.stop();  
}


// substract the second from the first frame to find the positions of changing pixel values
static void findMotionSaliency(Image8U const& firstFrame, Image8U const& secondFrame, Image8U& result )
{
  uint32 width = firstFrame.width();
  uint32 height = firstFrame.height();
  uint32 channels = firstFrame.channels();
  
  float min = 1000.0;
  float max = 0.0;
  float diff = 0.0;
  float averageMax = 0.0;
  
  for(uint32 x=0; x < width; x++)
  {
	min = 1000.0;
	max = 0.0;
	for(uint32 y=0; y < height; y++)
	  {
	    diff = 0.0;
	    for(uint32 c=0; c < channels; c++) 
		diff += abs(firstFrame(x,y,c) - secondFrame(x,y,c));
	    
	    if(min > diff) min = diff;
	    if(max < diff) max = diff;
	    result(x,y) = diff;
	  }
	 averageMax += max;
	// cout << "x = " << x << ", min = " << min << ", max = " << max << endl;
  }
  
  averageMax = (averageMax/width)*0.25;  //*0.25
  //cout << "averageMax = " << averageMax << endl;
  
  for(uint32 x=0; x < width; x++)
	for(uint32 y=0; y < height; y++)
	  result(x,y) = result(x,y) > averageMax ? 255 : 0;
  
  Filter::smooth(result, result, 5); //smooth 15
}


// the energy map is computed by combining per frame saliency with simple motion saliency
static void computeSaliencyVideo(deque<Image8U>& video, deque<Image32F>& videoEnergyMap)
{
  deque<Image8U>::iterator it = video.begin();
  uint32 width = it->width();
  uint32 height = it->height();
  uint32 frameCount = video.size();
  
  //Image32F saliency(width, height, 1);
  Image32F gradient(width, height, 1);
  Image8U motionSaliency(width, height, 1);
  Image32F totalSaliency(width, height, 1);
  uint32 t = 0; 
  
#if 0
    VideoWriter writer("/home/stud/kiess/Videos/result/basketball_motionSaliency.avi", width, height);
    writer.setCodec(CODEC_MPEG4);
    writer.start();
    Image8U print(width, height,1);
#endif
  
  while (it != video.end())
  {
    //FrequencyTunedSaliency::calculate((*it), saliency);
    SeamCarvingImage::computeEnergy((*it), gradient, width);
    
    if(t == 0)
	findMotionSaliency((*it), (*(it+1)), motionSaliency);
    else if (t < frameCount-1)
	findMotionSaliency((*(it-1)), (*(it+1)), motionSaliency);
    else
	findMotionSaliency((*(it-1)), (*it), motionSaliency);
      

    // motionSaliency is not normalized because its values are set to 0 or 255 before smoothing
    normalize32F(gradient);
    //normalize32F(saliency);
    
#if 0
    if(t == 50) 
    {
	//printImage32F(gradient, "/home/stud/kiess/Videos/result/2_50_gradient.png");
	IO::saveImage("/home/stud/kiess/Videos/result/3_50_motionSaliency.png", motionSaliency);
	//printImage32F(saliency, "/home/stud/kiess/Videos/result/0_50_frequencySaliency.png");
	//IO::saveImage("/home/stud/kiess/Videos/result/0_59_saliency.png", saliency); 
	IO::saveImage("/home/stud/kiess/Videos/result/3_50_frame.png", (*it));
	exit(1);
      
    }
#endif
    
#if 0 
    for (uint32 x = 0; x < width; x++) 
      for (uint32 y = 0; y < height; y++)
	print(x,y) = motionSaliency(x,y);
      
    writer.putImage(print);
#endif

    for(uint32 x=0; x < width; x++)
	for(uint32 y=0; y < height; y++)
	    totalSaliency(x,y) = 3*motionSaliency(x,y) + 1*gradient(x,y);// + 0*saliency(x,y);  // 3*motionS+gradient
 
    videoEnergyMap.push_back(totalSaliency);
    
#if 0 
    for (uint32 x = 0; x < width; x++) 
      for (uint32 y = 0; y < height; y++)
	print(x,y) = totalSaliency(x,y);
      
    writer.putImage(print);
#endif
    
#if 0
    if(t == 50)
    {
	printImage32F(totalSaliency, "/home/stud/kiess/Videos/result/1_50_Gesamt.png");
	exit(1);
    }
#endif
    
    t++;
    it++;
  }
  
#if 0
  writer.stop();
  exit(1);
#endif

}


// sums up the energy values of all pixels for each column in each frame.
static void calculateCostColumTime(deque<Image32F>& videoEnergyMap, Image32F& costColumnTime)
{
  deque<Image32F>::iterator it = videoEnergyMap.begin();
  uint32 width = it->width();
  uint32 height = it->height();
  
  uint32 t = 0;
  while (it != videoEnergyMap.end())
  {
    for (uint32 y=0; y < height; y++)
	for (uint32 x=0; x < width; x++)
	  costColumnTime(x,t) += (*it)(x,y);
    t++;
    it++;
  }
}


// calculate the energy cost of each cropping window and store the value on the position of its left border.
static void calculateCostCroppingWindowTime(Image32F const& costColumnTime, Image32F& costCroppingWindowTime)
{
  uint32 width = costColumnTime.width();
  uint32 frameCount = costColumnTime.height();
  uint32 specialWidth = costCroppingWindowTime.width();
  uint32 targetWidth = width - specialWidth + 1;
  
  for(uint32 t=0; t < frameCount; t++)
  {
      // calculate cost of cropping frame on leftmost position
      costCroppingWindowTime(0,t) = 0;
      for (uint32 i = 0; i < targetWidth; i++)
	costCroppingWindowTime(0,t) += costColumnTime(i,t);
      
      // move cropping window a step to the right at a time and recalculate the costs for each position
      for (uint32 i = 1; i < specialWidth; i++)
      {
	costCroppingWindowTime(i,t) = costCroppingWindowTime(i-1,t);  // comment out for old version
	costCroppingWindowTime(i,t) += costColumnTime(i+targetWidth-1, t) - costColumnTime(i-1, t);
      }
  }
}



// find the path of cropping windows with the maximum energy costs.
static void calculateMaxEnergyPath(Image32F const& costCroppingWindowTime, vector<uint32>& cropLeft)
{
  uint32 specialWidth = costCroppingWindowTime.width(); // specialWidth = width - targetWidth-1
  uint32 frameCount = costCroppingWindowTime.height();
  Image32F optimalCost(specialWidth, frameCount, 1); // optimal summed costs
  Image8U predecessors(specialWidth, frameCount, 1); // saves position of max predecessor
  
  uint32 v1 = 0; // predecessor up left (x-1, t-1)      |v1|v2|v3|   t-1
  uint32 v2 = 0; // predecessor up middle (x, t-1)  ->  |--|--|--|
  uint32 v3 = 0; // predecessor up right (x+1, t-1)     |  |x |  |    t

  // find maximum cost of a connected position in the previous line and store its x-position in predecessors.
  for (uint32 t = 0; t < frameCount; t++) 
      for (uint32 x = 0; x < specialWidth; x++)
          if (t == 0) // top border
              optimalCost(x,t) = costCroppingWindowTime(x,t);
          else if (x == 0) // left border
	    {
              v2 = optimalCost(x,t-1) + costCroppingWindowTime(x,t);
              v3 = optimalCost(x+1,t-1) + costCroppingWindowTime(x,t);
              if(v2 >= v3)
	        {
		  optimalCost(x,t) = v2;
		  predecessors(x,t) = x;
		}
	      else 
	        {
		  optimalCost(x,t) = v3;
		  predecessors(x,t) = x+1;
		}//if
	    }
	  else if (x == specialWidth-1) // right border
	    {
	      v1 = optimalCost(x-1,t-1) + costCroppingWindowTime(x,t);
	      v2 = optimalCost(x,t-1) + costCroppingWindowTime(x,t);
	      if(v2 >= v1)
	        {
		  optimalCost(x,t) = v2;
		  predecessors(x,t) = x;
		}
              else
	        {
		  optimalCost(x,t) = v1;
		  predecessors(x,t) = x-1;
	        }//if		
	    }
	  else // rest of the matix 
	    {
	      v1 = optimalCost(x-1,t-1) + costCroppingWindowTime(x,t);
	      v2 = optimalCost(x,t-1) + costCroppingWindowTime(x,t);
	      v3 = optimalCost(x+1,t-1) + costCroppingWindowTime(x,t);
	      if((v2 >= v1) && (v2 >= v3))
	        {
		  optimalCost(x,t) = v2;
		  predecessors(x,t) = x;
		}
	      else if((v1 >= v2) && (v1 >= v3))
	        {
		  optimalCost(x,t) = v1;
		  predecessors(x,t) = x-1;
		}
	      else
	        {
		  optimalCost(x,t) = v3;
		  predecessors(x,t) = x+1;
		}
	    }// if else (t==0)

  // find the maximum cost position in the last row (last frame of the shot)
  float max = optimalCost(specialWidth-1, frameCount-1);
  uint32 maxPosition = specialWidth-1;
  for (uint32 x = 0; x < specialWidth-1; x++) 
      if(optimalCost(x, frameCount-1) > max)
      {
	  max = optimalCost(x,frameCount-1);
	  maxPosition = x;
      } 
     
  // build optimal cropping window path by traversing back from maximum cost position in last row
  for(int t = frameCount-1; t > -1; t--) 
  {   
      cropLeft[t] = maxPosition;
      maxPosition = predecessors(maxPosition,t); // get x-position of maximum in line t-1.
  }
}


// smooth the path of the cropping windows to prevent shaking movement
static void smoothSignal(vector<uint32>& cropLeft)
{
  uint32 size = cropLeft.size();
  
  // gauss-based average, repeated
  for(uint32 repeat = 0; repeat < 50; repeat++)
      for(uint32 i = 0; i < size; i++)
	  if(i == 0)
	      cropLeft[i] = (cropLeft[i] + cropLeft[i+1])/2; // (i + (i+1))/2
	  else if (i < size-1)  
	      cropLeft[i] = 0.25*cropLeft[i-1] + 0.5*cropLeft[i] + 0.25*cropLeft[i+1]; //(0.25 + 0.5 + 0.25)
	  else  
	      cropLeft[i] = (cropLeft[i] + cropLeft[i-1])/2;
}


static void defineBorders(uint32 const& cropLeftPos, extendedBorders& border, uint32 const& width, uint32 const& extendedWidth, uint32 const& targetWidth)
{
   border.left = 0;
   border.right = extendedWidth-1;
   int extraSpace = (extendedWidth - targetWidth)/2;
 
   if( ((int) cropLeftPos) - extraSpace <= 0) 
     border.left = 0;
   else if( (cropLeftPos + targetWidth + extraSpace) >= width-1 )
     border.left = width - extendedWidth-1;
   else
     border.left = cropLeftPos - extraSpace;
   
   border.right = border.left + extendedWidth-1;
   
}


// define new extended borders of cropping window and crop the video
static void cropVideo(deque<Image8U>& video, deque<Image32F>& videoEnergyMap, deque<Image8U>& tmpVideo, deque<Image32F>& tmpVideoEnergyMap,vector<uint32>& cropLeft, vector<extendedBorders>& borders, uint32 const& extendedWidth, uint32 const& targetWidth)
{
  deque<Image8U>::iterator itVideo = video.begin();
  deque<Image32F>::iterator itEnergy = videoEnergyMap.begin();
  uint32 width = itVideo->width();
  uint32 height = itVideo->height();
  uint32 channels = itVideo->channels();
  
  uint32 t = 0;
  uint32 resultX = 0;
  Image8U tmpImage(extendedWidth, height, channels);
  Image32F tmpEnergy(extendedWidth, height, 1);
  
  while (itVideo != video.end())
  {
    defineBorders(cropLeft[t], borders[t], width, extendedWidth, targetWidth);
    
    resultX = 0;
    for(uint32 x = borders[t].left; x < borders[t].right+1; x++)    
    {   
      for(uint32 y = 0; y < height; y++) 
      {
	for(uint32 c = 0; c < channels; c++)     
	    tmpImage(resultX, y, c) = (*itVideo)(x, y, c);
	tmpEnergy(resultX, y) = (*itEnergy)(x,y);
      }
      resultX += 1;
    }
    
    tmpVideo.push_back(tmpImage);
    tmpVideoEnergyMap.push_back(tmpEnergy);
    
    t++; 
    itVideo++;
    itEnergy++;
  }
}


// calculate temporal coherence cost and add them to a temp energy map. the temporal costs are based on
// gradients and the distance of the pixel that should be removed to the according seam pixel from the last frame.
static void addTemporalCoherenceCost(Image8U const& frame, Image32F const& energy, Image32F& tmpEnergy, Image32F const& seamsLastFrame, int const& cropOffset, uint32 const& seamID)
{
  int width = frame.width();
  uint32 height = frame.height();
  
  Image32F temporalCoherenceCost(width, height,1);
  int prevSeamPos = 0;
#if 0
  for(uint32 y = 0; y < height; y++)
  {
	prevSeamPos = seamsLastFrame(seamID,y) + cropOffset;
	//cout << "prevSeamPos = " << prevSeamPos << ", offset = " << cropOffset << endl; 
	
	if( ( prevSeamPos >= 0) && (prevSeamPos < width) )
	{
	    temporalCoherenceCost(prevSeamPos, y) = 0;
	    
	    // go from previous seam pixel to the left side, recursively calculate costs for each pixel to be removed 
	    for(int l = prevSeamPos-1; l > -1; l--)
		temporalCoherenceCost(l,y) = 30*(prevSeamPos-l) > 300 ? 300 : 30*(prevSeamPos-l); // 30, Grenze 300

		
	    // go from seam pixel to the right side
	    for(int r = prevSeamPos+1; r < width; r++)
		temporalCoherenceCost(r,y) = 30*(r-prevSeamPos) > 300 ? 300 : 30*(r-prevSeamPos); // aktuell: *10
	}
	else
	    for(int x = 0; x < width; x++)
		temporalCoherenceCost(x,y) = 300;
  }
#endif

#if 1
      bool outside = false;
      uint32 counter = 0;

      for(uint32 y = 0; y < height; y++)
      {
	    prevSeamPos = seamsLastFrame(seamID,y) + cropOffset;
	    //cout << "prevSeamPos = " << prevSeamPos << ", offset = " << cropOffset << endl; 
	    
	    if( ( prevSeamPos >= 0) && (prevSeamPos < width) )
	    {
		temporalCoherenceCost(prevSeamPos, y) = 0;
		
		// go from previous seam pixel to the left side, recursively calculate costs for each pixel to be removed 
		for(int l = prevSeamPos-1; l > -1; l--)
		    temporalCoherenceCost(l,y) = 30*(prevSeamPos-l) > 300 ? 300 : 30*(prevSeamPos-l); // 30, Grenze 300

		    
		// go from seam pixel to the right side
		for(int r = prevSeamPos+1; r < width; r++)
		    temporalCoherenceCost(r,y) = 30*(r-prevSeamPos) > 300 ? 300 : 30*(r-prevSeamPos); // aktuell: *10
	    }
	    else
	    {
	      for(int x = 0; x < width; x++)
		temporalCoherenceCost(x,y) = 300;
		
	      counter++;
	      if(counter > height*0.2)
	      {
		for(uint32 y = 0; y < height; y++)
		  for(int x = 0; x < width; x++)
		    temporalCoherenceCost(x,y) = 300;
		outside = true;
		cout << "BREAK" << endl;
	      }
	    } 
	    if(outside)
	      break;
      }
#endif

  for (int x = 0; x < width; x++) 
      for (uint32 y = 0; y < height; y++)
	  tmpEnergy(x,y) = energy(x,y) + temporalCoherenceCost(x,y); // 1*energy+ 1*temp

}


// mark the position of the pixels of the found seam
static void markSeamWidth(Image32F& costWidth, Image32F& energy, Image32F const& predecessors, Image32F& seams, Image32F& seamsPositions, uint32 const seamID)
{
  int width = costWidth.width();
  int height = costWidth.height();
  int min = costWidth(width-1, height-1);  // stores the minimum costs.
  int minPosition = width-1; 		   // stores the x-position of the minumum costs.

  SeamCarvingImage::getMinCostWidth(costWidth, min, minPosition, width);
  
  for(int y = height-1; y > -1; y--) // builds the seam backwards beginning in the starting point minPostion and marks the pixels
    { 
      seams(minPosition,y) = -1;     		// -1 marks the seam in seams.
      energy(minPosition,y) = 99999999;		// high value prevents next iterations to pick the same pixel.
      seamsPositions(seamID, y) = minPosition;
      minPosition = predecessors(minPosition,y);// get x-position of minimum cost pixel in line y-1.
    }//for
    
}


static void findSeamsFrame(Image8U const& frame, Image32F& energy, vector<Image32F>& allSeamsFinal, vector<extendedBorders>& borders, uint32 const& t)
{
  uint32 width = frame.width();
  uint32 height = frame.height();
  uint32 channels = frame.channels();
  uint32 specialWidth = allSeamsFinal[0].width();
  int cropOffset = 0;
  
  Image32F tmpEnergy(width, height); 		// temp energy for modification
  Image32F costWidth(width, height); 		// stores the minimum summed up energy values for each position
  Image32F predecessors(width, height); 	// stores the x-position of the optimal predecessor for each position
  Image32F seams(width, height); 		// stores the positions of the seams (value = -1)
  Image8U tmpImage(width, height, channels); 	// temporal image for computation
  
  SeamCarvingImage::copyWidth(frame, tmpImage, width);
     
    for(uint32 seamID = 0; seamID < specialWidth; seamID++)
      {
	  tmpEnergy = energy;

	  if(t > 0)
	  {
	      cropOffset = (borders[t-1].left - borders[t].left);
	      addTemporalCoherenceCost(frame, energy, tmpEnergy, allSeamsFinal[t-1], cropOffset, seamID);
	  }
	  
	  SeamCarvingImage::computeCostWidth(tmpImage, tmpEnergy, costWidth, predecessors, width);
	  markSeamWidth(costWidth, energy, predecessors, seams, allSeamsFinal[t], seamID); 
      }// for
 
}


#if 1
// perform seam carving and save the modified frames into a video
static void seamCarvVideo(deque<Image8U>& video, deque<Image32F>& videoEnergyMap, vector<Image32F>& allSeamsFinal, string const& destPath, vector<extendedBorders>& borders, uint32 const& targetWidth)
{
  deque<Image8U>::iterator itVideo = video.begin();
  deque<Image32F>::iterator itEnergy = videoEnergyMap.begin();
  uint32 t = 0;
  
   while (itVideo != video.end())
  {
    //cout << "############### frame = " << t << endl;
    findSeamsFrame(*itVideo, *itEnergy, allSeamsFinal, borders, t);
      
    t++;
    itVideo++;
    itEnergy++;
  }  
}
#endif 


#if 1
static void removeSeamsAndSave(deque<Image8U>& video, vector<Image32F>& allSeamsFinal, vector<uint32>& cropLeft, vector<extendedBorders>& borders, string const& destPath, uint32 const& targetWidth)
{
  deque<Image8U>::iterator it = video.begin();
  //uint32 const bs = 32;
  uint32 width = targetWidth; // /bs*bs;
  uint32 height = it->height();// /bs*bs;
  uint32 channels = it->channels();
  uint32 t = 0;			// cursor for frame in video
  
  VideoWriter writer(destPath, targetWidth, height);

  writer.setCodec(CODEC_RAW);
  writer.start();
  
  uint32 allSeamsWidth = allSeamsFinal[0].width();
  while (it != video.end())
  {
    for(uint32 n = 0; n < allSeamsWidth; n++)
	for(uint32 y = 0; y < it->height(); y++) // removes seams by copying all normal pixels while skipping seam pixels.
	    for(uint32 x = allSeamsFinal[t](n,y); x < it->width()-1; x++)
		for(uint32 c = 0; c < channels; c++)
		    (*it)(x,y,c) = (*it)(x+1,y,c);

    Image8U cutImage(width, height, channels);
    Filter::copyImage(*it, cutImage, Rect(0, 0, width, height), Vector2D::create(0, 0));
      
    //writer.putImage(cutImage);
    writer.putImage(*it);
    t++;
    it++;
  }
  
  writer.stop();
}
#endif


#if 0  
static void drawSeamsAndSave(deque<Image8U>& video, vector<Image32F>& allSeamsFinal, vector<uint32>& cropLeft, vector<extendedBorders>& borders, string const& destPath, uint32 const& extendedWidth, uint32 const& targetWidth)
{
  deque<Image8U>::iterator it = video.begin();
  uint32 width = it->width();
  uint32 height = it->height();
  uint32 t = 0;			// cursor for frame in video
  
  VideoWriter writer(destPath, width, height);
  
  writer.setCodec(CODEC_RAW);
  writer.start();
  
  while (it != video.end())
  {
    drawSeams((*it), allSeamsFinal[t], cropLeft[t], borders[t], targetWidth);
    writer.putImage((*it));
   
    t++;
    it++;
  }
  
  writer.stop();
}
#endif



//##################################################################################|
//main										    |
//##################################################################################|

int main(int argc, char* argv[])
{
  if (argc != 4) 
    {
      std::cerr << "not enough arguments: \"Video Source\" \"Destination Path\" \"Retarget Factor\" " << std::endl;
      return 1;
    }
  
  try 
    {
      Timing::start();
      
      string srcPath = argv[1]; 
      string destPath = argv[2];
      double retargetFactor = atof (argv[3]);
      
      // load the video to a deque-list consisting of the frames
      cout << "1: load video" << endl;
      deque<Image8U> video;
      loadVideo(srcPath, video);
   
       Image8U frame = video[1];
      int width = frame.width();
      int height = frame.height();
      int targetWidth = retargetFactor * width;
      uint32 specialWidth = width - targetWidth + 1;
      uint32 extendedWidth = targetWidth + ( (width - targetWidth) * 0.2 ); //*0.2
      int frameCount = video.size();
      
      cout << "frame size: " << width << "x" << height << ", target size: " << targetWidth;
      cout << "x" << height  << ", frame count: " << frameCount << ", extendedWidth = " << extendedWidth << endl;
      
      // compute energy and sum up column costs for each frame
      cout << "2: calculate energy and column costs" << endl;
      deque<Image32F> videoEnergyMap;
      computeSaliencyVideo(video, videoEnergyMap);
      
      Image32F costColumnTime(width, frameCount, 1); 
      calculateCostColumTime(videoEnergyMap, costColumnTime);

      // sum the costs in each frame so that each position represents a cropping window in the frame.
      cout << "3: calculate cropping window costs" << endl;
      Image32F costCroppingWindowTime(specialWidth, frameCount, 1);
      calculateCostCroppingWindowTime(costColumnTime, costCroppingWindowTime);
      //printImage32F("/home/stud/kiess/Videos/result/croppingWindowTime.png", costCroppingWindowTime);
      
      // calculate the path with the maximum energy in the cropping windows over time based on seam carving
      cout << "4: build max energy paths" << endl;
      vector<uint32> cropLeft(frameCount);
      calculateMaxEnergyPath(costCroppingWindowTime, cropLeft);
      
      // smooth cropping window path
      cout << "5: smooth cropping window path" << endl;
      smoothSignal(cropLeft);

      // define borders for seam carving
      cout << "6: define new borders for seam carving" << endl;
      vector<extendedBorders> borders(frameCount); // extendedBorders is a struct!
      deque<Image8U> tmpVideo;
      deque<Image32F> tmpVideoEnergyMap;
      cropVideo(video, videoEnergyMap, tmpVideo, tmpVideoEnergyMap, cropLeft, borders, extendedWidth, targetWidth);
      
      //seam carving part
      cout << "7: find seams" << endl;
      specialWidth = extendedWidth - targetWidth;
      Image32F seamsPerFrame(specialWidth, height);
      vector<Image32F> allSeamsFinal(video.size(), seamsPerFrame);
      seamCarvVideo(tmpVideo, tmpVideoEnergyMap, allSeamsFinal, destPath, borders, targetWidth);

      //seam carving part
      cout << "8: remove seams and save them as video" << endl;
      removeSeamsAndSave(tmpVideo, allSeamsFinal, cropLeft, borders, destPath, targetWidth);
      //drawSeamsAndSave(video, allSeamsFinal, cropLeft, borders, destPath, extendedWidth, targetWidth);
      
      //drawCropWindowPath(cropLeft, specialWidth);
      
      cout << "video finished" << endl;
      Timing::stopAndPrint();
    }
  catch(MocaException& e)
    {
      cerr << diagnostic_information(e);
    }
}

#include <iostream>
#include "types/MocaTypes.h"

#ifdef HAVE_CAMERA
#ifdef HAVE_LIBFLTK

#include <fstream>
#include <boost/archive/text_oarchive.hpp>
#include <boost/serialization/vector.hpp>

#include "filter/Filter.h"
#include "filter/HDR.h"
#include "gui/CameraWindow.h"
#include "gui/GUIutils.h"
#include "tools/Maths.h"
#include "tools/Timing.h"
#include "types/Color.h"
#include "types/Exposure.h"
#include "types/MocaException.h"

typedef boost::shared_ptr<Image8U> ImagePtr;

int32 const pixRange = 256;


class TestWindow : public CameraWindow
{
public:
  TestWindow(Rect dim, std::string title, CameraReader::ColorMode mode)
    : CameraWindow(dim, title, Rect(0, 0, dim.w, dim.h), CameraReader::SPEED_400, mode, -1, false),
      color(mode == CameraReader::MODE_RAW8), chan(Color::RED), state(CAMERA),
      hist8(pixRange, pixRange, 1), hist32(pixRange, pixRange, 1), resFunc(color?3:1)
  {
    assert(Color::RED == 0);
    for (uint32 i=0; i<resFunc.size(); ++i)
      resFunc[i] = std::vector<double>(pixRange);

    addMenuEntry("Response/set exposures", 'a', addCB);
    addMenuEntry("Response/clear all", 's', clearCB);
    addMenuEntry("Response/live image", 'd', cameraCB);
    addMenuEntry("Response/response histogram", 'f', histCB);
    addMenuEntry("Response/estimate response", 'g', respCB);
    addMenuEntry("Response/display response", 'k', disprespCB);
    addMenuEntry("Response/save response", 'j', saveCB);

    CameraFeaturePtr gainSetting = reader->getFeature(CameraFeature::FEATURE_Gain);
    gainSetting->setMode(CameraFeature::MODE_Manual);
    gainSetting->setValue(gainSetting->getMin());
  }

  static void addCB(DisplayWindow* dWnd)
  {
    TestWindow* wnd = static_cast<TestWindow*>(dWnd);
    float startShut = GUIutils::showInputTempl<float>("Start shutter", 0.5);
    float endShut   = GUIutils::showInputTempl<float>("End shutter", 200.0);
    int32 steps     = GUIutils::showInputTempl<int32>("Number of exposures", 10);
    wnd->getExposures(startShut, endShut, steps);
  }

  void getExposures(float startShut, float endShut, int32 steps)
  {
    float inc = (endShut - startShut) / (double)(steps-1);
    Exposure exp;
    float realShut = startShut;
    for (int i=0; i<steps; ++i)
      {
        exp.shutter = realShut;
        reader->captureImage(Rect(0, 0, image->width(), image->height()), exp.shutter);
        exp.image = ImagePtr(new Image8U(image->width(), image->height(), image->channels()));
        reader->getImage(*image);
        exp.image->copyFrom(*image);
        exposures.push_back(exp);
        std::cout << "Exposure added. (shutter:" << exp.shutter << ")" << std::endl;
        realShut += inc;
      }
  }

  static void clearCB(DisplayWindow* dWnd)
  {
    TestWindow* wnd = static_cast<TestWindow*>(dWnd);
    wnd->exposures.clear();
    wnd->points.clear();
    wnd->state = CAMERA;
    std::cout << "Deleted all points and exposures." << std::endl;
  }

  static void cameraCB(DisplayWindow* dWnd)
  {
    TestWindow* wnd = static_cast<TestWindow*>(dWnd);
    wnd->state = CAMERA;
  }

  static void histCB(DisplayWindow* dWnd)
  {
    TestWindow* wnd = static_cast<TestWindow*>(dWnd);
    if (wnd->exposures.size() >= 2)
      wnd->state = HIST;
    else
      std::cout << "Set at least two exposures." << std::endl;
  }

  static void respCB(DisplayWindow* dWnd)
  {
    TestWindow* wnd = static_cast<TestWindow*>(dWnd);
    if (wnd->points.size() == 0)
      {
        std::cout << "Set image points first (left-click into the image)." << std::endl;
        return;
      }
    if (wnd->exposures.size() == 0)
      {
        std::cout << "Set at least one exposure." << std::endl;
        return;
      }

    wnd->estimateResponse(Color::RED);
    if (wnd->color)
      {
        wnd->estimateResponse(Color::GREEN);
        wnd->estimateResponse(Color::BLUE);
      }
    std::cout << "Response function(s) calculated." << std::endl;
  }

  static void disprespCB(DisplayWindow* dWnd)
  {
    TestWindow* wnd = static_cast<TestWindow*>(dWnd);
    if (wnd->color)
      {
        int32 chan = GUIutils::showInputTempl<int32>("Color channel", 1);
        if (chan < 0 || chan > 2)
          {
            std::cout << "Channel must be either 0, 1 or 2" << std::endl;
            return;
          }
        wnd->chan = (Color::Channel)chan;
      }
    wnd->state = RESP;
  }

  static void saveCB(DisplayWindow* dWnd)
  {
    TestWindow* wnd = static_cast<TestWindow*>(dWnd);
    std::string filename;
    GUIutils::showFileChooser("Pick a file", "", filename);
    if (filename.empty()) // cancel?
      return;
    std::ofstream fs(filename.c_str());
    boost::archive::text_oarchive archive(fs);
    archive << wnd->resFunc;
    std::cout << "Response function saved in: " << filename << std::endl;
  }

  void clickedPoint(VectorI pos)
  {
    Vector pix;
    if (color)
      pix = Vector2D::create((double)(pos[0]/2*2), (double)(pos[1]/2*2)); // even green pixel
    else
      pix = Vector2D::create((double)pos[0], (double)pos[1]);
    points.push_back(pix);
    std::cout << points.size() << ") " << pix << std::endl;
  }

protected:
  void doStuff()
  {
    switch (state)
      {
      case HIST: responseHist(); break;
      case RESP: displayResponse(); break;
      case CAMERA:
        uint32 shutter = reader->getFeatureValue(CameraFeature::FEATURE_Shutter);
        reader->captureImage(Rect(0, 0, image->width(), image->height()), shutter);
        reader->getImage(*image);
        break;
      }

    showImage(image);
  }

  void displayHist8()
  {
    Filter::set(*image, 192);
    VectorI target(2);
    target[0] = (image->width() - hist8.width()) / 2;
    target[1] = (image->height() - hist8.height()) / 2;
    Filter::copyImage(hist8, *image, target);
  }

  void responseHist()
  {
    assert(exposures.size() >= 2);
    Filter::set(hist32, 0);
    for (uint32 y=0; y<image->height(); ++y)
      for (uint32 x=0; x<image->width(); ++x)
        hist32((*exposures[0].image)(x, y), pixRange - (*exposures[1].image)(x, y)) += 1;
    Filter::convertScale(hist32, hist8);
    displayHist8();
  }

  void displayResponse()
  {
    double zero = 0;
    double min = 1/zero, max = -1/zero;
    for (int32 i=0; i<pixRange; ++i)
      {
        min = std::min(min, resFunc[chan][i]);
        max = std::max(max, resFunc[chan][i]);
      }
    Filter::set(hist8, 0);
    for (int32 i=0; i<pixRange; ++i)
      hist8(i, 255 - (int)((resFunc[chan][i]-min)/(max-min)*255)) = 255;
    displayHist8();
  }

  void estimateResponse(Color::Channel chan)
  {
    assert(exposures.size() >= 1);
    double const lambda = 25.0;
    int32 const numPoints = points.size();
    uint32 const numExps = exposures.size();
    std::vector<int32> weight(pixRange);
    for (uint32 i=0; i<weight.size(); ++i)
      weight[i] = (i <= (pixRange-1)/2) ? i : pixRange-i;

    std::vector<Vector> points(numPoints);
    for (uint32 i=0; i<points.size(); ++i)
      {
        points[i] = this->points[i];
        switch (chan)
          {
            //!!! potential segfault at the image border ignored
          case Color::RED: points[i][0]++; break;
          case Color::BLUE: points[i][1]++; break;
          default: break;
          }
      }

    Matrix A(numPoints*numExps+pixRange+1, pixRange+numPoints);
    for (uint32 y=0; y<A.size2(); ++y)
      for (uint32 x=0; x<A.size1(); ++x)
        A(x, y) = 0;
    Vector b(A.size1());
    for (uint32 y=0; y<b.size(); ++y)
      b(y) = 0;

    int k = 0;
    for (int32 i=0; i<numPoints; ++i)
      for (uint32 j=0; j<numExps; ++j)
        {
          uint8 val = (*exposures[j].image)(points[i][0], points[i][1]);
          A(k, val) = weight[val];
          A(k, pixRange+i) = -weight[val];
          b(k) = weight[val] * log(exposures[j].shutter)/log(2);
          ++k;
        }

    A(k++, 128) = 1;

    for (int32 i=0; i<pixRange-2; ++i)
      {
        A(k, i)   =      lambda * weight[i+1];
        A(k, i+1) = -2 * lambda * weight[i+1];
        A(k, i+2) =      lambda * weight[i+1];
        ++k;
      }

    Vector result(A.size2());
    Maths::linSolveQR(A, b, result);

    for (int32 i=0; i<pixRange; ++i)
      resFunc[chan][i] = pow(2, result[i]);
  }

  enum State {CAMERA, HIST, RESP};

  std::vector<Exposure> exposures;
  std::vector<Vector> points;
  bool color;
  Color::Channel chan;
  State state;
  Image8U hist8;
  Image32F hist32;
  std::vector<std::vector<double> > resFunc;
};


int main(int argc, char **argv)
{
  srand(time(0));
  try
  {
    TestWindow wnd(Rect(0, 0, 640, 480), std::string("Camera Response"), CameraReader::MODE_RAW8);
    wnd.mainLoop();
  }
  catch(MocaException& e)
  {
    std::cerr << diagnostic_information(e);
  }
  
  return 0;
}

#else // HAVE_LIBFLTK

int main(int argc, char **argv)
{
  std::cout << "MoCA has been compiled without FLTK support on your system." << std::endl;
}

#endif
#else // HAVE_CAMERA

int main(int argc, char **argv)
{
  std::cout << "MoCA has been compiled without camera support on your system." << std::endl;
}

#endif // HAVE_CAMERA

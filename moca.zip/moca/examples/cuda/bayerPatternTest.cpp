#define BOOST_TEST_DYN_LINK
#include "boost/test/unit_test.hpp"

#include "testcases.h"

#include "cudaHDR/CudaImage8UHandle.h"
#include "cudaHDR/CudaWrapper.h"

#include "io/ImageFileReader.h"
#include "io/ImageFileWriter.h"
#include "types/MocaException.h"
#include "filter/CvtColorSpace.h"

//Initially load needed testdata
struct testDataBayPatt
{
	//Will be available in every test case
	Image8U srcimg;

	//Initialize struct via constructor
	testDataBayPatt() : srcimg(640, 480, 1)
	{
		//Load bayer pattern testimage from hdd
		ImageFileReader ifr(BAYPATT_IMG);
		ifr.getImage(srcimg);
	}
};

BOOST_FIXTURE_TEST_SUITE(bayerPatternTestSuite, testDataBayPatt)

BOOST_AUTO_TEST_CASE(bayerPatternTest)
{
	//Perform interpolation on CPU
	Image8U tgtimg_cpu(640, 480, 3);
	MOCA_TIC(RUNS);
	CvtColorSpace::convert(srcimg, tgtimg_cpu, COLOR_BayerGB, COLOR_BGR);
	MOCA_TOC("Bayer Pattern interpolation CPU");

	//Allocate sourcehandle and targethandle
	CudaImage8UHandle srchandle;
	srchandle.put(srcimg);
	CudaImage8UHandle tgthandle;
	tgthandle.allocate(640, 480, 3, 3);

	//Execute interpolation on GPU
	MOCA_TIC(RUNS);
	CudaWrapper::BayerBilinear(srchandle, tgthandle); 
	MOCA_TOC("Bayer Pattern interpolation GPU");

	//Download content result
	Image8U tgtimg_gpu(640, 480, 3);
	tgthandle.getImage8UData(tgtimg_gpu);

	//Compare results
	BOOST_CHECK(compareImage8U(tgtimg_cpu, tgtimg_gpu) < 10.0f);
}

BOOST_AUTO_TEST_CASE(bayerPatternTestVaryHeight)
{
	//Crop sourceimg
	Image8U srcimg_crop(640, 470, 1);
	cropImage8U(srcimg, srcimg_crop);

	//Perform interpolation on CPU
	Image8U tgtimg_cpu_crop(640, 470, 3);
	CvtColorSpace::convert(srcimg_crop, tgtimg_cpu_crop, COLOR_BayerGB, COLOR_BGR);

	//Upload srcimg to device and perform interpolation on GPU
	CudaImage8UHandle srchandle;
	srchandle.put(srcimg_crop);
	CudaImage8UHandle tgthandle;
	tgthandle.allocate(640, 470, 3, 3);
	CudaWrapper::BayerBilinear(srchandle, tgthandle); 
	Image8U tgtimg_gpu_crop(640, 470, 3);
	tgthandle.getImage8UData(tgtimg_gpu_crop);

	//Compare results
	BOOST_CHECK(compareImage8U(tgtimg_cpu_crop, tgtimg_gpu_crop) < 10.0f);
}

BOOST_AUTO_TEST_CASE(bayerPatternTestVaryWidth)
{
	//Crop sourceimg
	Image8U srcimg_crop(624, 480, 1);
	cropImage8U(srcimg, srcimg_crop);

	//Perform interpolation on CPU
	Image8U tgtimg_cpu_crop(624, 480, 3);
	CvtColorSpace::convert(srcimg_crop, tgtimg_cpu_crop, COLOR_BayerGB, COLOR_BGR);

	//Upload srcimg to device and perform interpolation on GPU
	CudaImage8UHandle srchandle;
	srchandle.put(srcimg_crop);
	CudaImage8UHandle tgthandle;
	tgthandle.allocate(624, 480, 3, 3);
	CudaWrapper::BayerBilinear(srchandle, tgthandle); 
	Image8U tgtimg_gpu_crop(624, 480, 3);
	tgthandle.getImage8UData(tgtimg_gpu_crop);

	//Compare results
	BOOST_CHECK(compareImage8U(tgtimg_cpu_crop, tgtimg_gpu_crop) < 10.0f);
}

BOOST_AUTO_TEST_CASE(bayerPatternTestVaryBoth)
{
	//Crop sourceimg
	Image8U srcimg_crop(624, 470, 1);
	cropImage8U(srcimg, srcimg_crop);

	//Perform interpolation on CPU
	Image8U tgtimg_cpu_crop(624, 470, 3);
	CvtColorSpace::convert(srcimg_crop, tgtimg_cpu_crop, COLOR_BayerGB, COLOR_BGR);

	//Upload srcimg to device and perform interpolation on GPU
	CudaImage8UHandle srchandle;
	srchandle.put(srcimg_crop);
	CudaImage8UHandle tgthandle;
	tgthandle.allocate(624, 470, 3, 3);
	CudaWrapper::BayerBilinear(srchandle, tgthandle); 
	Image8U tgtimg_gpu_crop(624, 470, 3);
	tgthandle.getImage8UData(tgtimg_gpu_crop);

	//Compare results
	BOOST_CHECK(compareImage8U(tgtimg_cpu_crop, tgtimg_gpu_crop) < 10.0f);
}

BOOST_AUTO_TEST_SUITE_END()
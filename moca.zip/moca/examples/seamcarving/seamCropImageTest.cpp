
// MOCA headers 
#include "types/MocaTypes.h"
#include "types/Image8U.h"
#include "types/Image32F.h"
#include "io/IO.h"
#include "types/MocaException.h"
#include "gui/FLTKHeaders.h"
#include "gui/DisplayWindow.h"
#include "feature/Feature.h"

#include "filter/SeamCropImage.h"

#include "tools/Timing.h"
 
// C++ headers 
#include <string>
#include <math.h>
using namespace std;

/*
// This part can be ignored
class FirstTest : public DisplayWindow
{
public:
  FirstTest()
    : DisplayWindow(Rect(0, 0, 1024, 1024), "Cropping for Images test")
  {
    for (uint32 y=0; y<image->height(); ++y)
      for (uint32 x=0; x<image->width(); ++x)
        (*image)(x, y) = 0;
  }

  void clickedRect(Rect rect)
  {
    for (int y=rect.y; y<rect.h+rect.y; ++y)
      for (int x=rect.x; x<rect.w+rect.x; ++x)
        (*image)(x, y) = 255;
  }
  void show(boost::shared_ptr<Image8U const> img)
  {
    for (int32 c=0; c<img->channels(); ++c)
	    for (uint32 y=0; y<img->height(); ++y)
		  for (uint32 x=0; x<img->width(); ++x)
			(*image)(x, y, c) = (*img)(x, y, c);
  }

  void doStuff()
  {
    showImage(image);
  }
};


// --------------------------------------------------------------------
// SEAM
// --------------------------------------------------------------------

// computes the energy of an image based on the Feature saliencyMap
static void computeEnergy(Image8U image, Image32F& energy, int tmpWidth)
{
  int height = image.height();
  int channels = image.channels();
  
  int totalWidth = image.width();
  Image8U saliency(totalWidth, height, channels); 
  double rad = 4;
  double sigma = 12;
  
  // makeBlackWidth
  for (int x = tmpWidth-1; x < totalWidth; x++)
    for (int y=0; y < height; y++)
      for (int c=0; c < channels; c++)
        image(x, y, c) = 0;
      
  Feature::saliencyMap(image, saliency, rad, sigma);
  
  // convert
  for (int x=0; x < tmpWidth; x++)
    for (int y=0; y < height; y++)
      energy(x,y) = saliency(x, y);
}


// summarizes the energy values to form the end of a possible seam in each pixel of the last row. 
// The formed seams are are minimum-energy seams.
static void computeCostWidth(Image8U const& image, Image32F& energy, Image32F& costWidth, Image32F& predecessors, int width)
{
  int height = energy.height();
  
  unsigned int v1 = 0; // predecessor (x-1, y-1)
  unsigned int v2 = 0; // predecessor (x, y-1)
  unsigned int v3 = 0; // predecessor (x+1, y-1)

  //Forward Energy
  int Cl = 0; // predecessor cost left -> Cl = abs( image(x+1, y) - image(x-1,y) ) + abs( image(x, y-1) - image(x-1,y) );
  int Cu = 0; // predecessor cost up -> Cu = abs( image(x+1, y) - image(x-1,y) );
  int Cr = 0; // predecessor cost right ->  Cr = abs( image(x+1, y) - image(x-1,y) ) + abs( image(x, y-1) - image(x+1,y) );


  for (int y = 0; y < height; y++) // find minimum cost of a connected pixel in the previous line and store its x-position in predecessors.
      for (int x = 0; x < width; x++)
          if (y == 0) // top border
              costWidth(x,y) = energy(x,y);
          else if (x == 0) // left border
	    {
	      Cu = abs( image(x+1, y) - image(x,y) );
              Cr = abs( image(x+1, y) - image(x,y) ) + abs( image(x, y-1) - image(x+1,y) );
              v2 = costWidth(x,y-1) + Cu + energy(x,y);
              v3 = costWidth(x+1,y-1) + Cr + energy(x,y);
              if(v2 <= v3)
	        {
		  costWidth(x,y) = v2;
		  predecessors(x,y) = x;
		}
	      else 
	        {
		  costWidth(x,y) = v3;
		  predecessors(x,y) = x+1;
		}//if
	    }
	  else if (x == width-1) // right border
	    {
	      Cl = abs( image(x, y) - image(x-1,y) ) + abs( image(x, y-1) - image(x-1,y) );
              Cu = abs( image(x, y) - image(x-1,y) );
	      v1 = costWidth(x-1,y-1) + Cl + energy(x,y);
	      v2 = costWidth(x,y-1) + Cu + energy(x,y);
	      if(v2 <= v1)
	        {
		  costWidth(x,y) = v2;
		  predecessors(x,y) = x;
		}
              else
	        {
		  costWidth(x,y) = v1;
		  predecessors(x,y) = x-1;
	        }//if		
	    }
	  else // rest of the matix 
	    {
	      Cl = abs( image(x+1, y) - image(x-1,y) ) + abs( image(x, y-1) - image(x-1,y) );
              Cu = abs( image(x+1, y) - image(x-1,y) );
              Cr = abs( image(x+1, y) - image(x-1,y) ) + abs( image(x, y-1) - image(x+1,y) );
	      v1 = costWidth(x-1,y-1) + Cl + energy(x,y);
	      v2 = costWidth(x,y-1) + Cu + energy(x,y);
	      v3 = costWidth(x+1,y-1) + Cr + energy(x,y);
	      if((v2 <= v1) && (v2 <= v3))
	        {
		  costWidth(x,y) = v2;
		  predecessors(x,y) = x;
		}
	      else if((v1 <= v2) && (v1 <= v3))
	        {
		  costWidth(x,y) = v1;
		  predecessors(x,y) = x-1;
		}
	      else if((v3 <= v1) && (v3 <= v2))
	        {
		  costWidth(x,y) = v3;
		  predecessors(x,y) = x+1;
		}
	      else
	          BOOST_THROW_EXCEPTION(ArgumentException("One of the image dimensions is not valid."));
	    }// if else (y==0)
}


static void getMinCostWidth(Image32F& costWidth, int& min, int& minPosition, int width)
{
  int height = costWidth.height();

  for (int x = 0; x < width; x++) // Find the minimal seam cost min in the last row and store its x-position in minPosition
    if(min > costWidth(x,height-1)) 
      {
        min = costWidth(x,height-1);
        minPosition = x;
      }// if
}


static void markSeamWidth(Image32F& costWidth, Image32F& energy, Image32F& predecessors, Image32F& seams, int width)
{
  int height = costWidth.height();
  int min = costWidth(width-1, height-1); // stores the minimum costs.
  int minPosition = width-1; 		   // stores the x-position of the minumum costs.

  getMinCostWidth(costWidth, min, minPosition, width);
 
  for(int y = height-1; y > -1; y--) // builds the seam backwards beginning in the starting point minPostion and marks the pixels
    {   
      seams(minPosition,y) = -1;     		// -1 marks the seam in seams.
      energy(minPosition,y) = 999999;		// high value prevents next iterations to pick the same pixel.
      minPosition = predecessors(minPosition,y);// get x-position of minimum cost pixel in line y-1.
    }//for
}


static void removeSeamsWidth(Image8U& image, Image32F& energy, Image32F& seams, int width)
{
  int height = image.height();
  int channels = image.channels();
  int resultX = 0;		// cursor for x-value in image.

  for (int y = 0; y < height; y++) // removes seams by copying all normal pixels while skipping seam pixels.
    {
      for(int x = 0; x < width; x++)
          if(seams(x,y) != -1)
	    {
              for(int c = 0; c < channels; c++)
                  image(resultX,y,c) = image (x,y,c);
//  	      energy(resultX,y) =  energy (x,y);
              resultX += 1;
            }//if
      resultX = 0;
    }//for y
}

static void getMaxCostWidth(Image32F& costWidth, int& max, int width)
{
  int height = costWidth.height();
  max = costWidth(width-1, height-1);

  for (int x = 0; x < width; x++) // Find the maximum seam cost max in the last row
    if(max < costWidth(x,height-1)) 
      max = costWidth(x,height-1);
}

// write the value 0 in all positions of an image
static void clearImage(Image32F& image)
{
  unsigned int width = image.width();
  unsigned int height = image.height();
  
  for (unsigned int y = 0; y < height; y++)
    for(unsigned int x = 0; x < width; x++)
        image(x,y) = 0;
}

// draws seams into an image by coloring the pixels of the seam in the assigned image
static void drawSeams(Image8U& image, Image32F& seams, int width)
{
  int height = image.height();
  int channels = image.channels();
  Image8U drawImage(width, height, channels);

  for (int y = 0; y < height; y++) // Changes the color of each seam pixel
      for(int x = 0; x < width; x++)
          if(seams(x,y) != -1)
            for(int c = 0; c < channels; c++)
		drawImage(x,y,c) = image(x,y,c);
            else
	      {
	        drawImage(x,y,0) = 0; 	// blue
		drawImage(x,y,1) = 58;	// green
		drawImage(x,y,2) = 255;	// red
	      }

// ----------------------------------------------------
// Debug -> direct saving to disk
// ----------------------------------------------------
  try 
    {
      std::cerr << "save draw image" << std::endl;        
      IO::saveImage("/home/stud/kiess/Pictures/2011_ACM_MM/Test/Test_draw.png", drawImage); 
    } 
  catch (MocaException e) 
    {
      std::cout << "save Image error: " << e.what() << std::endl;
      exit (-1);
    }  
// ----------------------------------------------------
}




// --------------------------------------------------------------------
// CROP
// --------------------------------------------------------------------

// sums up the energy values downward each column 
static void computeCostCropWidth(Image32F& costCrop, int width)
{ 
  int height = costCrop.height();

  for (int x=0; x < width; x++)
      for (int y = 0; y < height; y++)
	  if(y != 0)
	    costCrop(x,y) = costCrop(x,y-1) + costCrop(x,y);
}

// find the best cropping window. First, reduce the window in size by 1 and search the best position. Repeat the 
// step with size minus one until the threshold is reached. If more than 75% of the total energy lie in the 
// cropping window when 15% or more of the image are removed (or the threshold wasn´t reached), the crop is 
// done. Otherwise, no crop is done in this iteration.
static void cropImage(Image8U& image, Image32F& energy, Image32F& costCrop, int& tmpWidth, int& targetWidth)
{  
  int height= image.height();
  int channels = image.channels();
  long double totalEnergy = 0;		// Summed up energy of all pixels
  long double tmpEnergy = 0;		// Summed up energy of all pixels in the cropping window
  long double energyArray [tmpWidth];   // energy values summed up from left to right (rightmost position = total energy)
  
  int resultX = 0;
  int cropLeft, cropRight, tmpLeft, tmpRight;
  
  //double averageCost = 0;
  int maxCost = 1;	// maximum cost of a seam in the current image (with initial value).
  int minCost = 100000;	// minimum cost of a seam in the current image (with initial value).
  int minPosition = 1;	// x-position of the minimal cost (with initial value).
  bool noThresholdReached = true;
	
  cropLeft = 0;
  cropRight = tmpWidth-1;
  tmpLeft = cropLeft;
  tmpRight = cropRight;

  energyArray[0] = costCrop(0, height-1);
  for (int x=1; x < tmpWidth; x++)
    energyArray[x] = costCrop(x, height-1) + energyArray[x-1];

  totalEnergy = energyArray[tmpWidth-1];
  //averageCost = totalEnergy/tmpWidth;
  getMinCostWidth(energy, minCost, minPosition, tmpWidth);
  getMaxCostWidth(energy, maxCost, tmpWidth);
  
//   cerr << "Cropping: Total energy = " << totalEnergy << ", min = " << minCost;
//   cerr << ", max = " << maxCost << ", average = " << averageCost << ", factor = " << averageCost/maxCost << endl;
  
  for (int i=1; i < tmpWidth-targetWidth; i++)
     { 
       for (int j=0; j < i+1; j++)
         {
	   cropLeft = j;
	   cropRight = (tmpWidth-1)-i+j;	// rightmost position - reducement of window size + shifting
	   if(j==0) // initialize values
	     {
	       tmpLeft = cropLeft;
	       tmpRight = cropRight;
	       tmpEnergy = energyArray[cropRight];
	     }
	   else if( (energyArray[cropRight]-energyArray[cropLeft-1]) > tmpEnergy ) // store values when energy in window is higher than tmpEnergy
	     {
	       tmpLeft = cropLeft;
	       tmpRight = cropRight;
	       tmpEnergy = energyArray[cropRight]-energyArray[cropLeft-1];
	     }
	 }// for j
       
       if ((tmpEnergy < 0.25*totalEnergy)) 
	{
	  noThresholdReached = false;
	  break;
	}
       else
	   tmpEnergy = 0;
     }// for i
      
  if( (cropRight - cropLeft) <= 0.85*tmpWidth || noThresholdReached )
    {
      cropLeft = tmpLeft;
      cropRight = tmpRight;
      cerr << "Cropped " << tmpWidth - (cropRight - cropLeft) << " column(s)";
      tmpWidth = cropRight - cropLeft;
      cerr << ", tmpWidth = " << tmpWidth << endl;
	  
      for(int x = cropLeft; x < cropRight+1; x++)
	{
	  for(int y = 0; y < height; y++)  
	      for(int c = 0; c < channels; c++)
		image(resultX, y, c) = image(x, y, c);
//  	      energy(resultX,y) = energy (x,y);
	  resultX += 1;
	}
    }
    else
      cerr << "No suitable crop found this iteration" << endl;
}
*/

// -------------------------------------------------------------------------------
// FILTER
// -------------------------------------------------------------------------------

/*
static void statisticFilter(Image32F cost, double& averageCost, double& variance, int width)
{
  double totalCost = 0;
  double totalVariance = 0;
  
  int h = cost.height();
  
  for (int x=0; x < width; x++)
    totalCost += cost(x, h-1);
  averageCost = totalCost/width;
  
  for (int x=0; x < width; x++)
    totalVariance += pow((cost(x, h-1) - averageCost), 2);
  variance = totalVariance/width;
}
*/

/*
// copy the values from one image into the other, which might also be of smaller width
static void copyWidth (Image8U const& image, Image8U& result, int width)
{
  int height = image.height();
  int channels = image.channels();
  
  for (int y = 0; y < height; y++)
    for(int x = 0; x < width; x++)
      for(int c = 0; c < channels; c++)
        result(x,y,c) = image(x,y,c);
}
*/

/*
static void copyWidth (Image8U const& image, Image32F& result, int width)
{
  int height = image.height();
  int channels = image.channels();
  
  for (int y = 0; y < height; y++)
    for(int x = 0; x < width; x++)
      for(int c = 0; c < channels; c++)
        result(x,y,c) = image(x,y,c);
}
*/

/*
// summarizes the costs
static void summarize(Image32F cost, int& totalCost, int width)
{
  int h = cost.height();
  for (int x=0; x < width; x++)
    for (int y=0; y < h; y++)
      totalCost += cost(x, y);
}
*/

// ###############################################################################################
// main
// ###############################################################################################

int main(int argc, char **argv)
{
  Timing::start();
	string fnSrc="/home/stud/kiess/Pictures/test/src/Evaluation/Woman.png";
// 	string fnSal="/home/stud/kiess/Pictures/2011_ACM_MM/Evaluation/50%/23_saliency.jpg";
	string fnDest="/home/stud/kiess/Pictures/test/result/Woman_0.75_scrop.png";
// 	string fnDest2="/home/stud/kiess/Pictures/2011_ACM_MM/Evaluation/50%/10_energy.png";

	cerr << "test LIBMOCA Cropping" << endl;
	boost::shared_ptr<Image8U> srcImage;
	boost::shared_ptr<Image8U> saliencyImage;
	
	try {
		cerr << "read image: " << fnSrc << endl;        
		srcImage = IO::loadImage(fnSrc);
// 		cerr << "read saliency: " << fnSal << endl;        
// 		saliencyImage = IO::loadImage(fnSal);
	} catch (MocaException e) {
		std::cout << "read Image error: " << e.what() << std::endl;
		exit (-1);
	}
	
	
	int w=srcImage->width();
	int h=srcImage->height();
	int c=srcImage->channels();
 	int targetWidth = 0.75*w;
	cerr << "image size: " << w << "x" << h << endl;

	
	//------------------------------------------------------------------
	// seamCrop image (width)
	//------------------------------------------------------------------
	
	// variables 
	Image8U destImage(targetWidth, h, c);
	SeamCropImage::reduceWidth(*srcImage, destImage, targetWidth);
	//Image32F energy(w, h, 1);
	
	/*
	int tmpWidth = w;	// temporary width during computation.
	int maxCost = 1;	// maximum cost of a seam in the current image (with initial value).
	int minCost = 100000;	// minimum cost of a seam in the current image (with initial value).
	int minPosition = 1;	// x-position of the minimal cost (with initial value).
	int storeX = 0;
	int numberOfSeams = 0;
	int numberCroppedLines = 0;
	
// 	double averageCost;
// 	double variance;
	int totalEnergy = 0; 	// totalEnergy for the calculated seams
	int tmpEnergy = 0;	// tmp Energy = totalEnergy - current seam
	bool noThresholdReached = true;
	
	
	Image32F costWidth(w, h); 	// stores the minimum summed up energy values for each position
	Image32F costCrop(w, h); 	// stores the minimum summed up energy values for each position
	Image32F predecessors(w, h); 	// stores the x-position of the optimal predecessor for each position
	Image32F seams(w, h); 		// stores the positions of the seams (value = -1)
	Image8U tmpImage(w, h, c); 	// temporal image for computation

	copyWidth(*srcImage, tmpImage, w);
	//copyWidth(*saliencyImage, energy, w);
	
	// algorithm
	while(tmpWidth > targetWidth)
	  {
	    cerr << "####################################################" << endl;
	    cout << "New Iteration: tmpWidth = " << tmpWidth << ", targetWidth = " << targetWidth << endl;
	   
  	    computeEnergy(tmpImage, energy, tmpWidth);
	    computeCostWidth(tmpImage, energy, costWidth, predecessors, tmpWidth);
	    getMaxCostWidth(costWidth, maxCost, tmpWidth);
	    getMinCostWidth(costWidth, minCost, minPosition, tmpWidth); 

// 	    averageCost = 0;
// 	    variance = 0;
// 	    statisticFilter(costWidth, averageCost, variance, tmpWidth);
	    summarize(energy, totalEnergy, tmpWidth);
	    tmpEnergy = totalEnergy;
	    noThresholdReached = true;
	    
// 	    cerr << "Energy Seams: min = " << minCost << ", max = " << maxCost; 
// 	    cerr << ", average = " << averageCost;
// 	    cerr << ", sd = " << sqrt(variance) << ", factor = " << averageCost/maxCost << endl;
	    
	    // seam carving similar to the crop: seams are allowed to remove up to 1% of the total energy but 
	    // must at the same time discard more than 1% of image width.
	    for(int x = tmpWidth-1; x > targetWidth-1; x--) // Seam Carving
	      {
		storeX = x;
		getMinCostWidth(costWidth, minCost, minPosition, tmpWidth);  
		if( (tmpEnergy-minCost) > 0.99*totalEnergy )
		  {
		    markSeamWidth(costWidth, energy, predecessors, seams, tmpWidth);
		    tmpEnergy -= minCost;
		  }
		else
		  {
		    noThresholdReached = false;
		    break;
		  }
		minCost = costWidth(tmpWidth-1, h-1);   // Initialisierung nächste Iteration
		computeCostWidth(tmpImage, energy, costWidth, predecessors, tmpWidth);
	      }// for
	      
	    if(storeX <= 0.99*tmpWidth || noThresholdReached) 
	      {
  		drawSeams(tmpImage, seams, tmpWidth); // ++++++++++++++++++
		removeSeamsWidth(tmpImage, energy, seams, tmpWidth);
		cerr << "Found " << tmpWidth-storeX << " seam(s), tmpWidth = " << storeX << endl;
		numberOfSeams += tmpWidth-storeX;
		tmpWidth = storeX; 
	      }
	    else
	      cerr << "No seams found in this iteration" << endl;
	    clearImage(seams);
	    
	    if (tmpWidth <= targetWidth)
	      break;
	    
	    // crop part
	    storeX = tmpWidth;
	   
   	    computeEnergy(tmpImage, energy, tmpWidth);
// 	    dilatedEnergy = energy;
 	    costCrop = energy;
	    computeCostCropWidth(costCrop, tmpWidth);
	    cropImage(tmpImage, energy, costCrop, tmpWidth, targetWidth);
	    numberCroppedLines += storeX-tmpWidth;
	    
	  }
	
	copyWidth(tmpImage, destImage, targetWidth);
	
	cerr << "new size: " << tmpWidth << "x" << h << endl;
	cerr << "Total: removed " << numberOfSeams << " seams, cropped " << numberCroppedLines << " lines." << endl;
	
	//------------------------------------------------------------------
	*/
	
	try {
		cerr << "save image" << endl;        
// 		IO::saveImage(fnDest2, energy); 
		IO::saveImage(fnDest, destImage); 
	} catch (MocaException e) {
		std::cout << "save Image error: " << e.what() << std::endl;
		exit (-1);
	}  

	Timing::stopAndPrint();

/* // show image (use FLTK)
#ifdef HAVE_LIBFLTK
	FirstTest win;
	win.show(destImage);
    win.mainLoop();
#endif
*/
	return 0;
}


#include "types/Size.h"

std::ostream& operator<<(std::ostream& stream, Size const& s)
{
  return stream << "w:" << s.w << " h:" << s.h;
}

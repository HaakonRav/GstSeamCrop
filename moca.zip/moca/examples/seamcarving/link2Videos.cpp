// MOCA headers 
#include "types/Image8U.h"
#include "types/Vector.h"
#include "types/MocaException.h"
#include "filter/Filter.h"
#include "io/IO.h"
#include "io/VideoReader.h"
#include "io/VideoWriter.h"
#include "tools/Timing.h"
 
// C++ headers 
#include <string>
//#include <math.h>
#include <iostream>
#include <deque>

using namespace std;

string fileNames[] = {"akiyo", "big_bunny", "cars", "flamingo", 
                      "football", "highway", "ice", "meerkat", 
                      "news", "soccer", "soda", "su_sy", 
                      "train", "walking"};
string alg1 = "seamCrop";
string alg2 = "multiOp";


// load the frames of the video in a deque list
static void loadVideo(string const& videoPath, deque<Image8U>& video)
{
  VideoReader reader(videoPath);
  reader.start();
  Image8U frame(reader.getImageWidth(), reader.getImageHeight(), 3);
  
  while(!reader.getEndOfVideo()) 
    {
      reader.getImage(frame); 
      video.push_back(frame);
    }
    
  reader.stop();  
}


// position all corresponding frames of the video side by side and save them in videoResult
static void linkVideos(deque<Image8U>& video1, deque<Image8U>& video2, deque<Image8U>& videoResult)
{
  deque<Image8U>::iterator it1 = video1.begin();
  deque<Image8U>::iterator it2 = video2.begin();
  
  uint32 const bs = 8; // block size
  uint32 const border = 20;
  uint8 const bgBright = 128; // background color (grey value)

  uint32 width1 = it1->width()/bs*bs; // make sure width is divisible by block size
  uint32 height1 = it1->height()/bs*bs;
  uint32 width2 = it2->width()/bs*bs;
  uint32 height2 = it2->height()/bs*bs;

  uint32 maxWidth = max(width1, width2);
  uint32 maxHeight = max(height1, height2);

  uint32 newWidth = maxWidth*2 + 4*border;  // border, frame1, 2*border, frame2, border
  uint32 newHeight = maxHeight + 2*border; // border, frames, border


  VectorI pos1 =  Vector2D::create((int32)(border + (maxWidth-width1)/2),
                                   (int32)(border + (maxHeight-height1)/2));
  Rect area1(0, 0, width1, height1);
  VectorI pos2 =  Vector2D::create((int32)(newWidth/2+border + (maxWidth-width2)/2),
                                   (int32)(border + (maxHeight-height2)/2));
  Rect area2(0, 0, width2, height2);

  Image8U result(newWidth, newHeight, it1->channels());
  
  cout << "width1 = " << width1 << ", width2 = " << width2 << endl;
  cout << "newWidth = " << newWidth << ", newHeight = " << newHeight << endl;
  
  while(it1 != video1.end() && it2 != video2.end()) 
    {
      Filter::set(result, bgBright);
      Filter::copyImage(*it1, result, area1, pos1);
      Filter::copyImage(*it2, result, area2, pos2);
      videoResult.push_back(result);
      it1++;
      it2++;
    }
}


// save the frames from the deque list as a video
static void saveVideo(string const& destPath, deque<Image8U>& video)
{
  deque<Image8U>::iterator it = video.begin();
  
  IO::saveImage(destPath+".jpg", *it);

  VideoWriter writer(destPath+".avi", it->width(), it->height());
  std::cout << it->width() << "x" << it->height() << std::endl;
  writer.setCodec(CODEC_MPEG4);
  writer.setBitRate(1400000);
  writer.start();
  
  while(it != video.end()) 
    {
      writer.putImage(*it);
      it++;
    }
    
  writer.stop();  
}


//##################################################################################|
//main										    |
//##################################################################################|

int main(int argc, char* argv[])
{
  if (argc != 3) 
    {
      std::cerr << "not enough arguments: \"input directory\" \"output directory\"" << std::endl;
      return 1;
    }
  
  try 
    {
      Timing::start();
      
      string srcPath = argv[1]; 
      string destPath = argv[2];
      
      for (uint32 i=0; i<14; ++i) {
        // load the video to a deque-list consisting of the frames
        cout << "video " << fileNames[i] << endl;
        deque<Image8U> video1, video2, videoResult;

        string fileName = srcPath+"/"+fileNames[i]+"_"+alg1+".avi";
        loadVideo(fileName, video1);
        fileName = srcPath+"/"+fileNames[i]+"_"+alg2+".avi";
        loadVideo(fileName, video2);
      
        // link the two videos so that the frames are displayed side by side in the resulting video
        bool flip = rand() % 2;
        if (flip)
          linkVideos(video2, video1, videoResult);
        else
          linkVideos(video1, video2, videoResult);
      
        // saves the created video
        saveVideo(destPath+"/"+fileNames[i]+"_result"+(flip?"F":""), videoResult);
      }
      cout << "videos finished" << endl;
      Timing::stopAndPrint();
    }
  catch(MocaException& e)
    {
      cerr << diagnostic_information(e);
    }
}

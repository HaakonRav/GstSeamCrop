#include "types/MocaTypes.h"

#ifdef HAVE_CUDA

#include "cudaHDR/CudaWrapper.h"
#include "cudaHDR/KernelFunctions.h"
#include "cudaHDR/DataStructures.h"
#include "cudaHDR/CudaVectorHandle.h"

#include <limits>


void CudaWrapper::checkErrorCode(cudaErrorCode err)
{
	switch(err)
	{
		case (kernelLaunchFailure):
			BOOST_THROW_EXCEPTION(ArgumentException("Could not launch kernel!"));
			break;
		case (dimMismatch):
			BOOST_THROW_EXCEPTION(ArgumentException("Image dimensions do not match kernel requirements!"));
			break;
		case (chMismatch):
			BOOST_THROW_EXCEPTION(ArgumentException("Image channels do not match kernel requirements!"));
			break;
		case (vecMismatch):
			BOOST_THROW_EXCEPTION(ArgumentException("Vector size or type does not match kernel requirements!"));
		case (success):
			break;
	}
}

void CudaWrapper::changeStride(CudaImage8UHandle const& source, CudaImage8UHandle& target)
{
	checkErrorCode(KernelFunctions::changeStride(source.getDataDescPtr(), target.getDataDescPtr()));
}

void CudaWrapper::BayerBilinear(CudaImage8UHandle const& source, CudaImage8UHandle& target)
{
	checkErrorCode(KernelFunctions::BayerBilinear(source.getDataDescPtr(), target.getDataDescPtr()));
}

void CudaWrapper::BGRYxy(CudaImage8UHandle const& source, CudaImage8UHandle& target)
{
	checkErrorCode(KernelFunctions::BGRYxy(source.getDataDescPtr(), target.getDataDescPtr()));
}

void CudaWrapper::BGRYxy(CudaImage8UHandle& desc)
{
	checkErrorCode(KernelFunctions::BGRYxy(desc.getDataDescPtr()));
}

void CudaWrapper::YxyBGR(CudaImage8UHandle const& source, CudaImage8UHandle& target)
{
	checkErrorCode(KernelFunctions::YxyBGR(source.getDataDescPtr(), target.getDataDescPtr()));
}

void CudaWrapper::YxyBGR(CudaImage8UHandle& desc)
{
	checkErrorCode(KernelFunctions::YxyBGR(desc.getDataDescPtr()));
}

unsigned int CudaWrapper::histo64(CudaImage8UHandle const& desc, 
	CudaVectorHandle<int>& histo,
	unsigned int channel, 
	float scale)
{
	histo.resize(64);
	histo.clear();
	unsigned int numpixels;
	checkErrorCode(KernelFunctions::histo64(desc.getDataDescPtr(), 
		histo.getDataDescPtr(),
		channel,
		scale,
		&numpixels));
	return numpixels;
}

void CudaWrapper::lineHisto(CudaImage8UHandle const& source, 
		CudaVectorHandle<unsigned int>& blackhisto, 
		CudaVectorHandle<unsigned int>& whitehisto, 
		unsigned int mean,
		unsigned int noiseThreshold,
		bool rows,
		unsigned int channel)
{
	//Resize histograms
	unsigned int histosize = (rows ? source.getHeight() : source.getWidth());
	blackhisto.resize(histosize);
	whitehisto.resize(histosize);
	blackhisto.clear();
	whitehisto.clear();

	//Call kernel
	checkErrorCode(KernelFunctions::lineHisto(source.getDataDescPtr(), 
		blackhisto.getDataDescPtr(),
		whitehisto.getDataDescPtr(),
		mean,
		noiseThreshold,
		rows,
		channel,
		0, 0, 0, 0));
}

void CudaWrapper::lineHisto(CudaImage8UHandle const& source, 
		CudaVectorHandle<unsigned int>& blackhisto, 
		CudaVectorHandle<unsigned int>& whitehisto, 
		Rect& roi,
		unsigned int mean,
		unsigned int noiseThreshold,
		bool rows,
		unsigned int channel)
{
	//Resize histograms
	unsigned int histosize = (rows ? roi.h : roi.w);
	blackhisto.resize(histosize);
	whitehisto.resize(histosize);
	blackhisto.clear();
	whitehisto.clear();

	//Start kernel
	checkErrorCode(KernelFunctions::lineHisto(source.getDataDescPtr(), 
		blackhisto.getDataDescPtr(),
		whitehisto.getDataDescPtr(),
		mean,
		noiseThreshold,
		rows,
		channel,
		roi.x, roi.y, roi.w, roi.h));
}

void CudaWrapper::stitchHDR(std::vector<CudaExposureHandle> const& expset, 
		CudaImage32FHandle& target)
{
	CudaExposureHandleDataDescriptor* tmp = new CudaExposureHandleDataDescriptor[expset.size()];
	for (unsigned int i = 0; i < expset.size(); i++)
	{
		tmp[i] = *(expset[i].getDataDescPtr());
		if (tmp[i].channels != 3)
			BOOST_THROW_EXCEPTION(ArgumentException("Image channels do not match kernel requirements!"));
	}

	//Upload data
	static CudaVectorHandle<CudaExposureHandleDataDescriptor> handle;
	handle.put(tmp, expset.size());

	//Start the kernel
	checkErrorCode(KernelFunctions::stitchHDR(handle.getDataDescPtr(),
		target.getDataDescPtr()));

	//Free array
	delete[] tmp;
}

int CudaWrapper::corrOffset(CudaVectorHandle<unsigned int> const& bt_vector,
		CudaVectorHandle<unsigned int> const& wt_vector,
		CudaVectorHandle<unsigned int> const& bp_vector,
		CudaVectorHandle<unsigned int> const& wp_vector,
		int guess,
		int maxOffset)
{
	//Instantiate result vector
	unsigned int reslength = 2 * maxOffset;
	static CudaVectorHandle<float> result(reslength);
	
	//Call kernel function
	checkErrorCode(KernelFunctions::advancedNcc(bt_vector.getDataDescPtr(),
		wt_vector.getDataDescPtr(),
		bp_vector.getDataDescPtr(),
		wp_vector.getDataDescPtr(),
		result.getDataDescPtr(),
		-maxOffset+guess));
	float* tmp = new float[reslength];
	result.getData(tmp);

	//Find maximum
	float currMax = -std::numeric_limits<float>::infinity();
	unsigned int index = 0;
	for (unsigned int i = 0; i < reslength; i++)
	{
		if (tmp[i] > currMax)
		{
			currMax = tmp[i];
			index   = i;
		}
	}

	//Return maximum correlation value
	return (index - maxOffset + guess);
}
#endif

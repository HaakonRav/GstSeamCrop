#include "io/CameraReader.h"
#include "types/MocaException.h"


// ==================== CameraReader ====================

CameraReader::CameraReader(ColorMode colorMode)
  : colorMode(colorMode)
{
}


void CameraReader::getFeatureBoundaries(CameraFeature::Type feature, uint32 &min, uint32 &max)
{
  CameraFeaturePtr camFeature = getFeature(feature);
  camFeature->getBoundaries(min, max);
}


uint32 CameraReader::getFeatureValue(CameraFeature::Type feature)
{
  CameraFeaturePtr camFeature = getFeature(feature);
  return camFeature->getValue();
}


void CameraReader::setFeatureValue(CameraFeature::Type feature, uint32 newVal)
{
  CameraFeaturePtr camFeature = getFeature(feature);
  camFeature->setValue(newVal);
}


CameraFeaturePtr CameraReader::getFeature(indexType index)
{
  if(index >= CameraFeature::numFeatures || index >= (indexType)features.size())
    BOOST_THROW_EXCEPTION(ArgumentException("invalid index for camera feature request"));

  return features[index];
}


CameraFeaturePtr CameraReader::getFeature(CameraFeature::Type feature)
{
  std::map<CameraFeature::Type, int>::iterator it = featIndices.find(feature);
  if (it == featIndices.end())
    BOOST_THROW_EXCEPTION(RuntimeException("featIndices isn't filled properly"));
  
  return features[it->second];
}


CameraReader::ColorMode CameraReader::getColorMode()
{
  return colorMode;
}

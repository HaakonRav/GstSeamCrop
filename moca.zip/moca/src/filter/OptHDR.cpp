#include "filter/OptHDR.h"

#ifdef HAVE_LIBDC1394

#include "io/DC1394Reader_Triggered.h"


OptHDR::OptHDR(boost::shared_ptr<CameraReader> reader, uint32 darkest, uint32 brightest, uint32 minInvalidPerLine)
  : HDR(reader, darkest, brightest, minInvalidPerLine), sequenceChanged(true), diffSequence(0)
{
  seqReader = boost::dynamic_pointer_cast<DC1394Reader_Triggered, CameraReader>(reader);
}


void OptHDR::captureHDR(std::vector<Exposure>& exposures)
{
  bool firstFrame = exposures.size() == 0; // bootstrapping

  if (firstFrame)
    createDefSeq(exposures, 16, 2.0, 6);
  else if (isSimilarParams(exposures)) { // similar parameters stop change state
    sequenceChanged = false;
    diffSequence = 0;
  } else { // differing parameters keep change state or change into it after [maxdifseq] frames
    ++diffSequence;
    sequenceChanged = sequenceChanged ? true : diffSequence >= maxDiffSequence;
  }

  if (sequenceChanged) {
    captureParams.clear();
    captureParams.resize(exposures.size());
    
    // create parameter list
    for (uint32 i=0; i<exposures.size(); ++i) {
      Exposure& e = exposures[i];
      uint32 shutter;
      float gain;
      exposureToShutGain(e.shutter, shutter, gain);
      captureParams[i].roi = Rect(e.topLeft[0], e.topLeft[1], e.image->width(), e.image->height());
      captureParams[i].shutter = shutter;
      captureParams[i].gain = gain;
    }

    seqReader->captureImages(captureParams);
  }
  else
    seqReader->captureImages();

  exposures.clear();
  for (uint32 i=0; i<captureParams.size(); ++i) {
    Rect& roi = captureParams[i].roi;
    Exposure exp(boost::shared_ptr<Image8U>(new Image8U(roi.w, roi.h, 1)),
                 Vector2D::create(0, 0), captureParams[i].shutter, Exposure::TOO_BOTH, i>0 ? i-1 : 0);
    seqReader->getImage(*exp.image);
    exposures.push_back(exp);
  }
}


bool OptHDR::isSimilarParams(std::vector<Exposure> const& exposures)
{
  if (captureParams.size() != exposures.size())
    return false;
  // find closest shutter match. average percentual difference
  float avgDiff = 0;
  for (uint32 i=0; i<exposures.size(); ++i) {
    float minDiff = INFINITY;
    for (uint32 j=0; j<captureParams.size(); ++j) {
      float diff = abs(exposures[i].shutter - captureParams[j].shutter) / exposures[i].shutter;
      minDiff = std::min(minDiff, diff);
    }
    avgDiff += minDiff;
  }
  avgDiff /= exposures.size();
  return avgDiff < maxShutterDiff;
}


void OptHDR::createDefSeq(std::vector<Exposure>& exposures, float startShut, float incFact, uint32 numExps)
{
  exposures.resize(numExps);
  for (uint32 i=0; i<numExps; ++i)
    {
      exposures[i] = Exposure(boost::shared_ptr<Image8U>(new Image8U(roi.w, roi.h, 1)),
                              Vector2D::create(0, 0), startShut, Exposure::TOO_BOTH, 0);
      startShut *= incFact;
    }
  sequenceChanged = true;
}


#endif // HAVE_LIBDC1394


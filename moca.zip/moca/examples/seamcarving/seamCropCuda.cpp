#include "types/MocaTypes.h"
#include "types/Image8U.h"
#include "types/MocaException.h"
#include "filter/Filter.h"
#include "io/VideoReader.h"
#include "io/VideoWriter.h"
#include "tools/Timing.h"
#include "tools/Thread.h"
#include "tools/Maths.h"

#include <algorithm>
#include <string>
#include <vector>

#include "cudaHDR/CudaImage8UHandle.h"
#include "cudaHDR/CudaImage32FHandle.h"
#include "cudaHDR/CudaVectorHandle.h"
#include "seamCropCuda_Kernels.h"

#define SIGMA 5.0 // smoothing
#define NUM_THREADS 8 // must be at least set to 2! A single thread will wait forever for the next frame.
// the maximum number of threads is currently 8. This is limited by the need for global texture memory references (see seamCropCuda_KernelsTex.cu included several times by seamCropCuda_Kernels.cu)


class SeamCrop;


// stores all the information about each frame
struct FrameInfo
{
  uint32 vWidth; // source frame width
  uint32 tWidth; // target frame width
  uint32 eWidth; // size of the extended window before seam carving
  uint32 oWidth; // rest of width outside target width
  uint32 numSeams; // number of seams to carve out
  uint32 height; // frame height
  uint32 channels; // number of source frame channels
  uint32 frameCount; // number of frames
};


class Parameters
{
public:
  // parameters configurable via command-line
  std::string inFilename; // -i <filename>
  std::string outFilename; // -o <filename>
  float retargetingFactor; // -r <float>
  float extendBorderFactor; // -e <float>
  bool printTiming; // -t <True/False>
  bool measurementMode; // -m <testNum>
  int testNum;
  bool writeVideos;

  void parseCommandLine(int argc, char** argv);
};

Parameters params;


//##################################################################################|
// SeamCropPipeline							            |
//##################################################################################|

// repeatedly reads a frame and processes it. Supports two passes:
// 1st - calculate energy and prepare croppind window path computation
// 2st - calculate energy, crop frame, compute and carve out seams, store result in a file
// all objects of this class stay in first pass mode until nextPass() is called which switches
// all threads to second pass mode
class SeamCropPipeline : public Thread
{
public:
  SeamCropPipeline(uint32 threadID); //Note: setFrameInfo(...) must be called before creating objects of this class
  ~SeamCropPipeline();

  // setter methods for the static members
  static void setFrameInfo(FrameInfo const& fi);
  static void setVideoReader(boost::shared_ptr<VideoReader> reader);
  static void setVideoWriter(boost::shared_ptr<VideoWriter> writer);
  static void setColumnCost(boost::shared_ptr<CudaImage32FHandle> columnCost);
  static void setCropLeft(std::vector<uint32>* cropLeft);

  // Waits for at least one thread to finish
  static void wait();
  // switches all threads to second pass mode
  static void nextPass();

  float getTime(); // returns the estimated time addColumnCost (the only kernel specific to the first pass) ran

  static std::vector<boost::shared_ptr<Image8U> > originalVideo; // preloaded video for measurement mode

protected:
  // repeatedly reads a single frame and processes it. After all frames are processed it waits
  // for the thread to be stopped
  void doStuff();

private:
  // reads the next frame in frameCPU and returns its frame number [1..fi.frameCount] (thread-safe)
  uint32 readNextFrame();

  // performs all steps necessary for the first pass
  void processImage_pass1(uint32 t);
  // calculates the energy (gradient + motion)
  void calculateEnergy(uint32 t);

  // performs all steps necessary for the second pass
  void processImage_pass2(uint32 t);

  static FrameInfo fi;
  static bool firstPass;
  static uint32 lastFrameNumber;
  static boost::shared_ptr<VideoReader> reader; // used by readNextFrame
  static boost::shared_ptr<VideoWriter> writer; // used to store the result of the second pass

  static std::vector<boost::shared_ptr<CudaImage8UHandle> > imgBuffer; // stores all frames uploaded to the GPU
  static std::vector<bool> imgAvailable; // imgAvailable[t] == true iff frame number t has previously been uploaded to the GPU this pass
  static std::vector<bool> imgDone; // imgDone[t] == true iff frame number t has been fully processed this pass

  static boost::shared_ptr<CudaImage32FHandle> columnCost;
  static std::vector<uint32>* cropLeft;

  // these buffers are similar to imgBuffer and imgDone except they concern themselves with seams
  static std::vector<boost::shared_ptr<CudaImage32FHandle> > seams;
  static std::vector<uint32> seamsDone; // seamsDone[t] == n means the first n seams of frame t have been computed

  static boost::mutex mutex;
  static boost::condition_variable cond;

  cudaStream_t stream;
  boost::shared_ptr<SeamCropCuda> cuda;
  uint32 threadID;

  // pass 1 (calculate energy) buffers
  float time; // used to estimate the extra time pass 2 would take if a single pass implementation was used instead
  boost::shared_ptr<Image8U> frameCPU;
  boost::shared_ptr<CudaImage32FHandle> gradient;
  boost::shared_ptr<CudaImage8UHandle> motionSaliency;
  boost::shared_ptr<CudaImage32FHandle> totalSaliency;

  // pass 2 (crop/seam carve) buffers
  boost::shared_ptr<CudaImage8UHandle> frame;
  boost::shared_ptr<CudaImage32FHandle> energy;
  boost::shared_ptr<CudaImage32FHandle> tmpEnergy;
  boost::shared_ptr<CudaImage32FHandle> fwdEnergy;
  boost::shared_ptr<CudaImage32FHandle> optimalCost;
  boost::shared_ptr<CudaImage32FHandle> predecessors;
  boost::shared_ptr<CudaImage8UHandle> finalFrame;
  boost::shared_ptr<Image8U> finalFrameCPU;
};


// static members of SeamCropCuda - BEGIN
std::map<uint32, SeamCropCuda::computeGradientFuncPtr> SeamCropCuda::computeGradientFuncPtrMap;
std::map<uint32, SeamCropCuda::computeFwdEnergyFuncPtr> SeamCropCuda::computeFwdEnergyFuncPtrMap;

uint32 SeamCropCuda::gaussKernelSize_CPU;

unsigned int* SeamCropCuda::staticBlockCnt;
// static members of SeamCropCuda - END


SeamCropCuda::SeamCropCuda(uint32 threadID, uint32 w, uint32 ew, uint32 h, double sigma, cudaStream_t* stream)
{
  static bool doOnce = true;
  if(doOnce)
  {
    setupFunctionPointerMaps();

    uint32 kSize = cvRound(sigma*6 + 1)|1; // imitates behavior of OpenCV 2.4.5
    cv::Mat cvGaussKernel = cv::getGaussianKernel(kSize, sigma, CV_32F);
    if(!uploadGaussKernel((float*)cvGaussKernel.ptr(), kSize))
      BOOST_THROW_EXCEPTION(ArgumentException("Gaussian kernel for smoothing is too large."));

    cudaMalloc(&staticBlockCnt, sizeof(unsigned int));

    doOnce = false;
  }

  if(computeGradientFuncPtrMap.size() <= threadID)
    BOOST_THROW_EXCEPTION(RuntimeException(std::string("Invalid thread ID ") + Maths::toString<uint32>(threadID)));

  computeGradientFunc = computeGradientFuncPtrMap[threadID];
  computeFwdEnergyFunc = computeFwdEnergyFuncPtrMap[threadID];

  this->stream = stream;

  smoothTmp = boost::shared_ptr<CudaImage8UHandle>(new CudaImage8UHandle);
  smoothTmp->allocate(h, w, 1, 1);
  smoothTmpData = smoothTmp->getDataDescPtr();

  cudaMalloc(&d_min, sizeof(unsigned int));
  cudaMalloc(&d_max, sizeof(unsigned int));
  cudaMalloc(&averageMax, sizeof(float));

  cudaMallocHost(&count, sizeof(unsigned int));
  cudaMalloc(&blockCnt, sizeof(unsigned int));
}


SeamCropCuda::~SeamCropCuda()
{
  cudaFree(blockCnt);
  cudaFreeHost(count);

  cudaFree(averageMax);
  cudaFree(d_max);
  cudaFree(d_min);

  static bool doOnce = true;
  if(doOnce)
  {
    cudaFree(staticBlockCnt);

    doOnce = false;
  }
}


// static members of SeamCropPipeline - BEGIN
FrameInfo SeamCropPipeline::fi;
bool SeamCropPipeline::firstPass;
uint32 SeamCropPipeline::lastFrameNumber;
boost::shared_ptr<VideoReader> SeamCropPipeline::reader;
boost::shared_ptr<VideoWriter> SeamCropPipeline::writer;
std::vector<boost::shared_ptr<Image8U> > SeamCropPipeline::originalVideo;

std::vector<boost::shared_ptr<CudaImage8UHandle> > SeamCropPipeline::imgBuffer;
std::vector<bool> SeamCropPipeline::imgAvailable;
std::vector<bool> SeamCropPipeline::imgDone;

boost::shared_ptr<CudaImage32FHandle> SeamCropPipeline::columnCost;
std::vector<uint32>* SeamCropPipeline::cropLeft;

std::vector<boost::shared_ptr<CudaImage32FHandle> > SeamCropPipeline::seams;
std::vector<uint32> SeamCropPipeline::seamsDone;

boost::mutex SeamCropPipeline::mutex;
boost::condition_variable SeamCropPipeline::cond;
// static members of SeamCropPipeline - END


SeamCropPipeline::SeamCropPipeline(uint32 threadID)
  : threadID(threadID)
{
  cudaStreamCreate(&stream);
  cuda = boost::shared_ptr<SeamCropCuda>(new SeamCropCuda(threadID, fi.vWidth, fi.eWidth, fi.height, SIGMA, &stream));

  this->time = 0.0f;

  frameCPU = boost::shared_ptr<Image8U>(new Image8U(fi.vWidth, fi.height, fi.channels));

  gradient = boost::shared_ptr<CudaImage32FHandle>(new CudaImage32FHandle);
  gradient->allocate(fi.vWidth, fi.height, 1, 1);

  motionSaliency = boost::shared_ptr<CudaImage8UHandle>(new CudaImage8UHandle);
  motionSaliency->allocate(fi.vWidth, fi.height, 1, 1);

  totalSaliency = boost::shared_ptr<CudaImage32FHandle>(new CudaImage32FHandle);
  totalSaliency->allocate(fi.vWidth, fi.height, 1, 1);

  frame = boost::shared_ptr<CudaImage8UHandle>(new CudaImage8UHandle);
  frame->allocate(fi.eWidth, fi.height, fi.channels, fi.channels);

  energy = boost::shared_ptr<CudaImage32FHandle>(new CudaImage32FHandle);
  energy->allocate(fi.eWidth, fi.height, 1, 1);

  tmpEnergy = boost::shared_ptr<CudaImage32FHandle>(new CudaImage32FHandle);
  tmpEnergy->allocate(fi.eWidth, fi.height, 1, 1);

  fwdEnergy = boost::shared_ptr<CudaImage32FHandle>(new CudaImage32FHandle);
  //fwdEnergy->allocate(fi.eWidth, fi.height, 3, 3); // multi-channel float images seem not be handled correctly
  fwdEnergy->allocate(fi.eWidth*3, fi.height, 1, 1);

  optimalCost = boost::shared_ptr<CudaImage32FHandle>(new CudaImage32FHandle);
  optimalCost->allocate(fi.eWidth, fi.height, 1, 1);

  predecessors = boost::shared_ptr<CudaImage32FHandle>(new CudaImage32FHandle);
  predecessors->allocate(fi.eWidth, fi.height, 1, 1);

  finalFrame = boost::shared_ptr<CudaImage8UHandle>(new CudaImage8UHandle);
  finalFrame->allocate(fi.tWidth, fi.height, fi.channels, fi.channels);

  finalFrameCPU = boost::shared_ptr<Image8U>(new Image8U(fi.tWidth, fi.height, fi.channels));
}


SeamCropPipeline::~SeamCropPipeline()
{
  cudaStreamDestroy(stream);
}


void SeamCropPipeline::setFrameInfo(FrameInfo const& fi)
{
  SeamCropPipeline::fi = fi;
  firstPass = true;
  lastFrameNumber = 0;

  imgBuffer.resize(fi.frameCount+2);
  imgAvailable.resize(fi.frameCount+2);
  imgDone.resize(fi.frameCount+2);
  
  seams.resize(fi.frameCount+2);
  seamsDone.resize(fi.frameCount+2);

  imgAvailable[0] = true;
  imgDone[0] = true;
  seams[0] = boost::shared_ptr<CudaImage32FHandle>(new CudaImage32FHandle);
  seams[0]->allocate(1, 1, 1, 1);
  seamsDone[0] = fi.numSeams;
  for(uint32 i = 1; i <= fi.frameCount; ++i)
  {
    imgAvailable[i] = false;
    imgDone[i] = false;
    seamsDone[i] = 0;
  }
  imgAvailable[fi.frameCount+1] = true;
  imgDone[fi.frameCount+1] = true;
  seamsDone[fi.frameCount+1] = fi.numSeams;
}


void SeamCropPipeline::setVideoReader(boost::shared_ptr<VideoReader> reader)
{
  SeamCropPipeline::reader = reader;
}


void SeamCropPipeline::setVideoWriter(boost::shared_ptr<VideoWriter> writer)
{
  SeamCropPipeline::writer = writer;
}


void SeamCropPipeline::setColumnCost(boost::shared_ptr<CudaImage32FHandle> columnCost)
{
  SeamCropPipeline::columnCost = columnCost;
}


void SeamCropPipeline::setCropLeft(std::vector<uint32>* cropLeft)
{
  SeamCropPipeline::cropLeft = cropLeft;
}


void SeamCropPipeline::wait()
{
  boost::unique_lock<boost::mutex> lock(mutex);
  cond.wait(lock);
}


void SeamCropPipeline::nextPass()
{
  firstPass = false;
  lastFrameNumber = 0;

  for(uint32 i = 1; i <= fi.frameCount; ++i)
  {
    imgAvailable[i] = false;
    imgDone[i] = false;
  }
}


float SeamCropPipeline::getTime()
{
  return time;
}


void SeamCropPipeline::doStuff()
{
  if(imgDone[1])
  {
    cond.notify_one();
    boost::this_thread::yield();
    return;
  }

  uint32 const fc = fi.frameCount;

  while(true)
  {
    uint32 t = readNextFrame();
    if(t == 0)
      break;

    imgBuffer[t] = boost::shared_ptr<CudaImage8UHandle>(new CudaImage8UHandle);
    imgBuffer[t]->put(*frameCPU, stream);
    cudaStreamSynchronize(stream);
    imgAvailable[t] = true;

    while(!(imgAvailable[t-1] && imgAvailable[t] && imgAvailable[t+1]))
      boost::this_thread::yield();
    
    if(firstPass)
      processImage_pass1(t);
    else
      processImage_pass2(t);

    imgDone[t] = true;

    for(uint32 i = 1; i <= fc; ++i)
      if(imgDone[i-1] && imgDone[i] && imgDone[i+1])
        imgBuffer[i] = boost::shared_ptr<CudaImage8UHandle>();
  }
}


uint32 SeamCropPipeline::readNextFrame()
{
  boost::unique_lock<boost::mutex> lock(mutex);

  if (params.measurementMode)
    {
      if (lastFrameNumber >= originalVideo.size())
        return 0;
      frameCPU = originalVideo[lastFrameNumber];
    }
  else
    {
      std::cout << lastFrameNumber*100/(fi.frameCount-1) << "%\r";
      std::cout.flush();
      if(reader->getEndOfVideo())
        return 0;
      reader->getImage(*frameCPU);
    }
  
  lastFrameNumber += 1;
  return lastFrameNumber;
}


void SeamCropPipeline::processImage_pass1(uint32 t)
{
  calculateEnergy(t);

  cudaEvent_t begin, end;
  float kernelTime;

  cudaEventCreate(&begin);
  cudaEventCreate(&end);

  cudaEventRecord(begin, 0);
  cuda->addColumnCost(*totalSaliency->getDataDescPtr(), *columnCost->getDataDescPtr(), t-1);
  cudaEventRecord(end, 0);
  cudaEventSynchronize(end);

  cudaEventElapsedTime(&kernelTime, begin, end);

  cudaEventDestroy(begin);
  cudaEventDestroy(end);

  time += kernelTime;
}


void SeamCropPipeline::calculateEnergy(uint32 t)
{
  CudaImage8UDataDescriptor const* prevFrame = imgBuffer[t]->getDataDescPtr();
  cuda->computeGradient(*prevFrame, *gradient->getDataDescPtr());

  CudaImage8UDataDescriptor const* nextFrame = prevFrame;
  if(t < fi.frameCount)
    nextFrame = imgBuffer[t+1]->getDataDescPtr();

  if(t > 1)
    prevFrame = imgBuffer[t-1]->getDataDescPtr();

  cuda->findMotionSaliency(*prevFrame, *nextFrame, *motionSaliency->getDataDescPtr());
  cuda->smooth(*motionSaliency->getDataDescPtr());

  cuda->mergeSaliency(*motionSaliency->getDataDescPtr(), *gradient->getDataDescPtr(), *totalSaliency->getDataDescPtr());
}


void SeamCropPipeline::processImage_pass2(uint32 t)
{
  uint32 const numSeams = fi.numSeams;

  seams[t] = boost::shared_ptr<CudaImage32FHandle>(new CudaImage32FHandle);
  seams[t]->allocate(fi.numSeams, fi.height, 1, 1);

  CudaImage8UDataDescriptor const& origFrame = *imgBuffer[t]->getDataDescPtr();
  CudaImage8UDataDescriptor const& frameData = *frame->getDataDescPtr();
  CudaImage32FDataDescriptor const& energyData = *energy->getDataDescPtr();
  CudaImage32FDataDescriptor const& tmpEnergyData = *tmpEnergy->getDataDescPtr();
  CudaImage32FDataDescriptor const& fwdEnergyData = *fwdEnergy->getDataDescPtr();
  CudaImage32FDataDescriptor const& optimalCostData = *optimalCost->getDataDescPtr();
  CudaImage32FDataDescriptor const& predecessorsData = *predecessors->getDataDescPtr();
  CudaImage32FDataDescriptor const& seamsData = *seams[t]->getDataDescPtr();

  while(seamsDone[t-1] == 0)
    boost::this_thread::yield();

  CudaImage32FDataDescriptor const& prevSeamsData = *seams[t-1]->getDataDescPtr();

  calculateEnergy(t);

  unsigned int& curCropLeft = (*cropLeft)[t-1];
  cuda->cropImage8U(origFrame, frameData, curCropLeft);
  cuda->cropImage32F(*totalSaliency->getDataDescPtr(), energyData, curCropLeft);

  cuda->computeForwardEnergy(frameData, fwdEnergyData);

  int32 cropOffset = 0;
  if(t > 1)
    cropOffset = ((*cropLeft)[t-2] - curCropLeft);

  for(uint32 seamID = 0; seamID < numSeams; ++seamID)
  {
    bool copyEnergy = true;

    while(seamsDone[t-1] <= seamID)
      boost::this_thread::yield();

    if(t > 1)
      copyEnergy = cuda->addTemporalCoherenceCost(energyData, tmpEnergyData, prevSeamsData, seamID, cropOffset);

    if(copyEnergy)
      *tmpEnergy = *energy;

    cuda->computeCostWidth(tmpEnergyData, fwdEnergyData, optimalCostData, predecessorsData);
    cuda->markSeamWidth(optimalCostData, energyData, predecessorsData, seamsData, seamID);

    cudaStreamSynchronize(stream); // necessary to prevent the next thread from trying to read the seam info too soon
    seamsDone[t] = seamID+1;
  }

  cuda->removeSeams(frameData, *finalFrame->getDataDescPtr(), seamsData);
  finalFrame->getImage8UData(*finalFrameCPU, stream);
 
  while(!imgDone[t-1])
    boost::this_thread::yield();

  seams[t-1] = boost::shared_ptr<CudaImage32FHandle>();

  if (params.writeVideos)
    writer->putImage(*finalFrameCPU);
}


void Parameters::parseCommandLine(int argc, char** argv)
{
  inFilename = "";
  outFilename = "";
  retargetingFactor = .75f;
  extendBorderFactor = .2f;
  printTiming = true;
  measurementMode = false;
  writeVideos = true;

  int32 i = 1;
  while(i < argc)
  {
    if(i+1 == argc || strlen(argv[i]) != 2 || argv[i][0] != '-')
      BOOST_THROW_EXCEPTION(ArgumentException(std::string("Invalid parameter '") + std::string(argv[i]) + std::string("'.")));

    std::string tmp;
    switch(argv[i][1])
    {
    case 'm':
    case 'M':
      measurementMode = true;
      testNum = atoi(argv[i+1]);
      i = argc; // scripted measurement mode overrides all parameters
      break;
    case 'i':
    case 'I':
      inFilename = std::string(argv[i+1]);
      break;

    case 'o':
    case 'O':
      outFilename = std::string(argv[i+1]);
      break;

    case 'r':
    case 'R':
      retargetingFactor = fabs(strtof(argv[i+1], NULL));
      retargetingFactor = retargetingFactor > 1.0f ? 1.0f : retargetingFactor;
      break;

    case 'e':
    case 'E':
      extendBorderFactor = fabs(strtof(argv[i+1], NULL));
      extendBorderFactor = extendBorderFactor > 1.0f ? 1.0f : extendBorderFactor;
      break;

    case 't':
    case 'T':
      tmp = argv[i+1];
      std::transform(tmp.begin(), tmp.end(), tmp.begin(), ::tolower);
      if(!tmp.compare("y") || !tmp.compare("yes") || !tmp.compare("on") || !tmp.compare("enable") || !tmp.compare("true") || strtol(argv[i+1], NULL, 10) != 0)
        printTiming = true;
      else
        printTiming = false;
      break;

    default:
      BOOST_THROW_EXCEPTION(ArgumentException(std::string("Invalid parameter '") + std::string(argv[i]) + std::string("'.")));
    }

    i += 2;
  }

  if(!measurementMode && (inFilename.length() == 0 || outFilename.length() == 0))
    BOOST_THROW_EXCEPTION(ArgumentException(std::string("Both an input and an output filename have to be specified.")));
}


//##################################################################################|
// SeamCrop								            |
//##################################################################################|

// The class first calculates a cropping window of target size. It then adds x% to the borders and removes 
// them again through seam carving. For temporal coherence, more seams are searched in a next key frame 
// and the closest with the minimal costs are used.
class SeamCrop
{
public:
  // changes the video to match these parameters. Only used in measurement mode
  SeamCrop(uint32 scaleWidth, uint32 scaleHeight, uint32 numFrames);
  ~SeamCrop();

  // perform all steps
  void run();

private:
  void preloadVideo();
  // load the frames of the video and calculate the energy
  void run_pass1();
  // starts all threads and waits for them to finish
  void run_threads();
  // smooth the path of the cropping windows to prevent shaking movement
  void smoothSignal();
  // define the positions of the extended borders
  uint32 defineBorders(uint32 cropLeft);
  // crop, seam carve and save the frames as video
  void run_pass2();
  // prints the collected timing information to std::cout
  void printTimingInfo();

  FrameInfo fi;
  boost::shared_ptr<SeamCropPipeline> scp[NUM_THREADS];

  boost::shared_ptr<CudaImage32FHandle> columnCost;
  boost::shared_ptr<CudaImage32FHandle> croppingWindowCost;
  boost::shared_ptr<CudaImage32FHandle> predecessors;
  boost::shared_ptr<CudaVectorHandle<unsigned int> > cropLeftGPU;
  std::vector<uint32> cropLeft;
};


SeamCrop::SeamCrop(uint32 scaleWidth, uint32 scaleHeight, uint32 numFrames)
{
  VideoReader reader(params.inFilename);
  reader.start();

  uint32 w = reader.getImageWidth();
  uint32 h = reader.getImageHeight();
  uint32 c = reader.getImageChannels();
  uint32 fc = reader.getTotalFrameCount();

  reader.stop();

  if (params.measurementMode) {
    w = scaleWidth;
    h = scaleHeight;
    fc = numFrames < fc ? numFrames : fc;
  }

  fi.vWidth = w;
  fi.tWidth = w * params.retargetingFactor; 
  fi.eWidth = fi.tWidth + ((w - fi.tWidth) * params.extendBorderFactor);
  fi.oWidth = w - fi.tWidth + 1;
  fi.numSeams = fi.eWidth - fi.tWidth;
  fi.height = h;
  fi.channels = c;
  fi.frameCount = fc;

  std::cout << params.inFilename << " " << w << " " << h << " " << fi.tWidth << " " << fc << " ";
  std::cout << params.extendBorderFactor << " " << fi.numSeams << " ";

  SeamCropPipeline::setFrameInfo(fi);
  for(uint32 i = 0; i < NUM_THREADS; ++i)
    scp[i] = boost::shared_ptr<SeamCropPipeline>(new SeamCropPipeline(i));

  columnCost = boost::shared_ptr<CudaImage32FHandle>(new CudaImage32FHandle);
  columnCost->allocate(fi.vWidth, fi.frameCount, 1, 1);

  croppingWindowCost = boost::shared_ptr<CudaImage32FHandle>(new CudaImage32FHandle);
  croppingWindowCost->allocate(fi.oWidth, fc, 1, 1);

  predecessors = boost::shared_ptr<CudaImage32FHandle>(new CudaImage32FHandle);
  predecessors->allocate(fi.oWidth, fc, 1, 1);

  cropLeftGPU = boost::shared_ptr<CudaVectorHandle<unsigned int> >(new CudaVectorHandle<unsigned int>);
  cropLeftGPU->resize(fc);

  cropLeft.resize(fc);

  SeamCropPipeline::setColumnCost(columnCost);
  SeamCropPipeline::setCropLeft(&cropLeft);
}


SeamCrop::~SeamCrop()
{
}


void SeamCrop::run()
{
  Timing::start(0); // TIME: total time

  Timing::start(1); // TIME: preloading video
  if (params.measurementMode)
    preloadVideo();
  Timing::stop(1);

  Timing::start(2); // TIME: calculate energy, addcolumncost
  run_pass1();
  Timing::stop(2);
   
  Timing::start(3); // TIME: calculate cropping window path
  SeamCropCuda::calculateCostCroppingWindowTime(*columnCost->getDataDescPtr(), *croppingWindowCost->getDataDescPtr(), fi.tWidth);
  SeamCropCuda::calculateMaxEnergyPath(*croppingWindowCost->getDataDescPtr(), *predecessors->getDataDescPtr(), *cropLeftGPU->getDataDescPtr());
  cropLeftGPU->getData(cropLeft);
  smoothSignal();
  Timing::stop(3);

  Timing::start(4); // TIME: seam carving
  SeamCropPipeline::nextPass();
  run_pass2();
  Timing::stop(4);

  Timing::stop(0);

  if(params.printTiming)
    printTimingInfo();
}


void SeamCrop::preloadVideo()
{
  boost::shared_ptr<VideoReader> reader = boost::shared_ptr<VideoReader>(new VideoReader(params.inFilename));
  reader->start();
  uint32 videoWidth = reader->getImageWidth();
  uint32 videoHeight = reader->getImageHeight();
  boost::shared_ptr<Image8U> frame(new Image8U(videoWidth, videoHeight, fi.channels));
  SeamCropPipeline::originalVideo.resize(fi.frameCount);

  for (unsigned int i=0; i<fi.frameCount; ++i)
    {
      reader->getImage(*frame);
      SeamCropPipeline::originalVideo[i] = boost::shared_ptr<Image8U>(new Image8U(fi.vWidth, fi.height, fi.channels));
      Filter::resize(*frame, *SeamCropPipeline::originalVideo[i]);
    }

  reader->stop();
}


void SeamCrop::run_pass1()
{
  boost::shared_ptr<VideoReader> reader;
  if (!params.measurementMode) {
    reader = boost::shared_ptr<VideoReader>(new VideoReader(params.inFilename));
    SeamCropPipeline::setVideoReader(reader);
    reader->start();
  }

  run_threads();

  if (!params.measurementMode)
    reader->stop();
}


void SeamCrop::run_threads()
{
  for(uint32 i = 0; i < NUM_THREADS; ++i)
    scp[i]->start();

  SeamCropPipeline::wait();

  for(uint32 i = 0; i < NUM_THREADS; ++i)
    scp[i]->stop();
}


void SeamCrop::smoothSignal()
{
  uint32 const fc = fi.frameCount;

  float *next = new float[fc];
  float *prev = new float[fc];

  if(next == NULL || prev == NULL)
    BOOST_THROW_EXCEPTION(RuntimeException("Out of memory."));

  for(uint32 i = 0; i < fc; ++i)
    prev[i] = cropLeft[i];
  
  // gauss-based average, repeated;
  for(uint32 repeat = 0; repeat < 100; repeat++)
  {
    for(uint32 i = 0; i < fc; ++i)
      if(i == 0)
        next[i] = (prev[i] + prev[i+1])/2.0f; // (i + (i+1))/2
      else if (i < fc-1)
        next[i] = 0.25f*prev[i-1] + 0.5f*prev[i] + 0.25f*prev[i+1]; //(0.25 + 0.5 + 0.25)
      else  
        next[i] = (prev[i] + prev[i-1])/2.0f;

    float* tmp = prev;
    prev = next;
    next = tmp;
  }

  for(uint32 i = 0; i < fc; ++i)
    cropLeft[i] = defineBorders((uint32)(prev[i] + 0.5f));

  delete prev;
  delete next;
}


uint32 SeamCrop::defineBorders(uint32 cropLeft)
{
   uint32 const w = fi.vWidth;
   uint32 const ew = fi.eWidth;
   uint32 const tw = fi.tWidth;

   int extraSpace = (ew - tw)/2;
 
   if(((int)cropLeft) - extraSpace <= 0) 
     cropLeft = 0;
   else if((cropLeft + tw + extraSpace) >= w-1)
     cropLeft = w - ew - 1;
   else
     cropLeft = cropLeft - extraSpace;

   return cropLeft;
}


void SeamCrop::run_pass2()
{
  boost::shared_ptr<VideoWriter> writer;
  boost::shared_ptr<VideoReader> reader;
  if (params.writeVideos) {
    writer = boost::shared_ptr<VideoWriter>(new VideoWriter(params.outFilename, fi.tWidth, fi.height));
    SeamCropPipeline::setVideoWriter(writer);
    writer->setCodec(CODEC_RAW);
    writer->start();
  }
  if (!params.measurementMode) {
    reader = boost::shared_ptr<VideoReader>(new VideoReader(params.inFilename));
    SeamCropPipeline::setVideoReader(reader);
    reader->start();
  }

  run_threads();

  if (!params.measurementMode)
    reader->stop();
  if (params.writeVideos)
    writer->stop();
}


void SeamCrop::printTimingInfo()
{
  std::cout << Timing::sum(0) << " " << Timing::sum(1) << " " << Timing::sum(2) << " ";
  std::cout << Timing::sum(3) << " " << Timing::sum(4) << std::endl;
  for (int i=0; i<5; ++i)
    Timing::reset(i);
}


//##################################################################################|
//main										    |
//##################################################################################|

void doMeasurement1()
{
  std::string filenames[] = {"big_bunny_HD", "flamingo_HD", "highway_HD", "meerkat_HD", "train_HD", "walking_HD"};
  int widths[] = {480, 960, 1440, 1920}; // full-HD, 75%, 50%, 25%
  int heights[] = {270, 540, 810, 1080}; // full-HD, 75%, 50%, 25%
  float retFacts[] = {0.9f, 0.5f};

  for (int fn=0; fn<6; ++fn)
    for (int sn=0; sn<2; ++sn)
      for (int rn=0; rn<2; ++rn)
        {
          std::stringstream ss;
          ss << "/usr/local/kiess/src/" << filenames[fn] << ".avi";
          params.inFilename = ss.str();
          params.retargetingFactor = retFacts[rn];
          SeamCrop sc(widths[sn], heights[sn], 183); // length of the shortest video (meerkat)
          sc.run();
        }
}

void doMeasurement2()
{
  params.inFilename = "/usr/local/kiess/src/big_bunny_HD.avi";
  int width = 480, height = 270, numFrames = 488;

  for (int retarget=50; retarget<=90; retarget+=10) {
    params.retargetingFactor = retarget / 100.0f;
    SeamCrop sc(width, height, numFrames);
    sc.run();
  }
}

void doMeasurement3()
{
  params.inFilename = "/usr/local/kiess/src/big_bunny_HD.avi";
  int width = 960, height = 540, numFrames = 488;
  params.retargetingFactor = 0.8f;

  for (int size=10; size<=100; size+=10) {
    int w = width*size/100;
    int h = height*size/100;
    SeamCrop sc(w, h, numFrames);
    sc.run();
  }
}

void doMeasurement4()
{
  params.inFilename = "/usr/local/kiess/src/big_bunny_HD.avi";
  int width = 480, height = 270, numFrames = 488;
  params.retargetingFactor = 0.8f;

  for (int frames=10; frames<=100; frames+=10) {
    int f = numFrames*frames/100;
    SeamCrop sc(width, height, f);
    sc.run();
  }
}

void doMeasurements()
{
  params.printTiming = true;
  params.writeVideos = false;
  params.extendBorderFactor = 0.2f;
  params.outFilename = "/usr/local/bguthier/output.avi";

  std::cout << "filename width height target_width frame_count extend_border_factor seam_count ";
  std::cout << "total_time preloading energy cropping_window seam_carving" << std::endl;

  switch (params.testNum)
    {
    case 1: doMeasurement1(); break;
    case 2: doMeasurement2(); break;
    case 3: doMeasurement3(); break;
    case 4: doMeasurement4(); break;
    }
}


int main(int argc, char* argv[])
{
  try 
  {
    params.parseCommandLine(argc, argv);
    if (params.measurementMode)
      doMeasurements();
    else {
      SeamCrop sc(0, 0, 0);
      sc.run();
    }
  }
  catch(MocaException& e)
  {
    std::cerr << diagnostic_information(e);
    std::cerr << "Cuda LastError: " << cudaGetErrorString(cudaGetLastError()) << std::endl;
  }
}

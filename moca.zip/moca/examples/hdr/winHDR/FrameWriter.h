#ifndef WINHDR_FRAME_WRITER_H
#define WINHDR_FRAME_WRITER_H

#include "types/Exposure.h"
#include <vector>
#include <string>


class FrameWriter
{
 public:
  FrameWriter();

  void putNext(std::vector<Exposure> const& expSet);
  void write(std::string const& path);

 private:
  std::vector<std::vector<Exposure> > expSets;
};


#endif

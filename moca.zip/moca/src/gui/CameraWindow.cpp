#include "gui/CameraWindow.h"

#ifdef HAVE_CAMERA
#ifdef HAVE_LIBDC1394
#ifdef HAVE_LIBFLTK

#include "gui/CamSelect.h"
#include "gui/CamControl.h"
#include "io/DC1394Reader.h"
#include "io/DC1394Reader_Triggered.h"
#include "io/DC1394Reader_FreeRunning.h"
#include "io/PseudoCameraReader.h"
#include "types/MocaException.h"


CameraWindow::CameraWindow(Rect rect, std::string title, Rect camera, CameraReader::BusSpeed speed,
                           CameraReader::ColorMode color, int selectedCamera, bool freeRunning)
  : DisplayWindow(rect, title)
{
  if (selectedCamera < 0)
  {
    hide(); // hide the main window while the user chooses a camera
    CamSelect wnd(Rect(rect.x, rect.y, 600, 200), &selectedCamera);
    while(wnd.shown()); // wait until the user chose a camera
    show();
  }

#ifdef HAVE_LIBDC1394
  //DC1394Reader::resetBus(selectedCamera);
  if(selectedCamera < 0) // if selectedCamera still is < 0 there is no camera connected to system
  {
    reader = boost::shared_ptr<PseudoCameraReader>(new PseudoCameraReader(""));
  }
  else
  {
    if(freeRunning)
      reader = boost::shared_ptr<DC1394Reader_FreeRunning>(new DC1394Reader_FreeRunning(camera, speed, color, selectedCamera));
    else
      reader = boost::shared_ptr<DC1394Reader_Triggered>(new DC1394Reader_Triggered(speed, color, selectedCamera));    
  }  
#elif WIN32
  //reader = boost::shared_ptr<Win32CamReader>(new Win32CamReader(camera, selectedCamera));
#endif

  try{
    reader->start();
  }catch(MocaException&){
    fl_alert("Couldn't start camera!");
    throw;
  }

  addMenuEntry("Camera/Controls", 'c', camControlsCB);

  camControl = boost::shared_ptr<CamControl>(new CamControl(reader, Rect(50, 50, 500, 0)));
  //writer = boost::shared_ptr<VideoFileWriter>(new VideoFileWriter("output.vid", reader->getImageWidth(), reader->getImageHeight(), DEPTH_8U, LUMINANCE));
  image = boost::shared_ptr<Image8U>(new Image8U(camera.w, camera.h, 1));
}


CameraWindow::~CameraWindow()
{
  if (reader)
    reader->stop();
}


void CameraWindow::mainLoopFunc()
{
  DisplayWindow::mainLoopFunc();

  if(camControl->shown())
    camControl->redraw();
}


void CameraWindow::camControlsCB(DisplayWindow* wnd)
{
  CameraWindow* cWnd = static_cast<CameraWindow*>(wnd);
  cWnd->camControl->show();
}


#endif // HAVE_LIBFLTK
#endif // HAVE_LIBDC1394
#endif // HAVE_CAMERA


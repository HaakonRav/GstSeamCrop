#include "types/Image8U.h"
#include "types/MocaException.h"


Image8U::Image8U()
  : ImageBase(1, 1, 1, IPL_DEPTH_8U)
{
  cvCreateData(image);
}


Image8U::Image8U(sizeType width, sizeType height, int32 channels)
  : ImageBase(width, height, channels, IPL_DEPTH_8U)
{
  cvCreateData(image);
}


Image8U::Image8U(IplImage* image)
  : ImageBase(image)
{
  if(depth() != IPL_DEPTH_8U)
    BOOST_THROW_EXCEPTION(ArgumentException("IplImage has invalid depth"));
}


Image8U::Image8U(Image8U const& other)
  : ImageBase(other.width(), other.height(), other.channels(), IPL_DEPTH_8U)
{
  cvCreateData(image); // ensures that the created object is in a valid (means: usable) state
  copyFrom(other); // throws an exception if other.depth() isn't IPL_DEPTH_8U!
}


Image8U::~Image8U()
{
  cvReleaseData(image);
}


Image8U& Image8U::operator=(Image8U const& other)
{
  cvReleaseImage(&image);
  image = cvCreateImage(cvSize(other.width(), other.height()), IPL_DEPTH_8U, other.channels());
  copyFrom(other);
  return *this;
}

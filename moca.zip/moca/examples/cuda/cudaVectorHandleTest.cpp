#define BOOST_TEST_DYN_LINK
#include <boost/test/unit_test.hpp>
#include "cudaHDR/KernelFunctions.h"
#include "cudaHDR/CudaVectorHandle.h"
#include "types/MocaException.h"
#include "types/Exposure.h"
#include "io/HDRExposureIO.h"
#include "cudaHDR/CudaExposureHandle.h"
#include "testcases.h"

BOOST_AUTO_TEST_SUITE(CudaVectorHandleTest)

BOOST_AUTO_TEST_CASE(standardConstructorTest)
{
	//Most simple constructor
	CudaVectorHandle<unsigned int> handle(10);

	//Get data descriptor and do some tests
	const CudaVectorHandleDataDescriptor<unsigned int>* desc = handle.getDataDescPtr();
	handle.clear();
	BOOST_CHECK(desc->numelements == 10);

	//Download histogram data
	unsigned int h_histo[10] = {1};
	handle.getData(h_histo);
	for (int i = 0; i < 10; i++) BOOST_CHECK(h_histo[i] == 0);
}

BOOST_AUTO_TEST_CASE(PointerConstructorTest)
{
	//Download histogram data
	unsigned int h_histo[3] = {0, 1, 2};
	CudaVectorHandle<unsigned int> handle;
	handle.put(h_histo, 3);

	//Get data descriptor and do some tests
	BOOST_CHECK(handle.getDataDescPtr()->numelements == 3);

	//Redownload image data
	unsigned int h_histo_copy[3];
	handle.getData(h_histo_copy);
	BOOST_CHECK(h_histo_copy[0] == 0);
	BOOST_CHECK(h_histo_copy[1] == 1);
	BOOST_CHECK(h_histo_copy[2] == 2);
}

BOOST_AUTO_TEST_CASE(CopyConstructorTest)
{
	//Create histogram data handler
	unsigned int h_histo[3] = {0, 1, 2};
	unsigned int h_histo_copy[3] = {3};

	//Most simple constructor
	CudaVectorHandle<unsigned int> handle;
	handle.put(h_histo, 3);
	CudaVectorHandle<unsigned int> handlecopy(handle);

	//Get data from handlecopy
	handlecopy.getData(h_histo_copy);
	BOOST_CHECK(h_histo_copy[0] == h_histo[0]);
	BOOST_CHECK(h_histo_copy[1] == h_histo[1]);
	BOOST_CHECK(h_histo_copy[2] == h_histo[2]);
}

BOOST_AUTO_TEST_SUITE_END()
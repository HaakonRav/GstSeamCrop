
// MOCA headers 
#include "types/MocaTypes.h"
#include "types/Image8U.h"
#include "types/Image32F.h"
#include "types/MocaException.h"
#include "feature/Feature.h"
#include "feature/OpticalFlow.h"
#include "filter/Filter.h"
#include "filter/SeamCropImage.h"
#include "filter/SeamCarvingImage.h"
#include "filter/FrequencyTunedSaliency.h"
#include "io/IO.h"
#include "io/VideoReader.h"
#include "io/VideoWriter.h"
#include <sstream>

#include "tools/Timing.h"
 
// C++ headers 
#include <string>
#include <math.h>
#include <iostream>
#include <deque>
using namespace std;

// This version loads the hole video and optimizes a cropping window path based on the principle of seam carving
#if 1


#if 1
static void drawCropBorders(Image8U& drawImage, uint32 const& cropLeftPos, uint32 const& targetWidth)
{
  uint32 width = drawImage.width();
  uint32 height = drawImage.height();
  uint32 cropRightPos = cropLeftPos + targetWidth;

	
  for (uint32 x = 0; x < width; x++) 
      for(uint32 y = 0; y < height; y++)
	{
	if(x == cropLeftPos)
	      {
	        drawImage(x,y,0) = 0;
		drawImage(x,y,1) = 255;
		drawImage(x,y,2) = 0;
		
		if(cropLeftPos > 0)
		{
		  drawImage(x-1,y,0) = 0;
		  drawImage(x-1,y,1) = 255;
		  drawImage(x-1,y,2) = 0;
		}
		else
		  drawImage(x+1,y,0) = 0;
		  drawImage(x+1,y,1) = 255;
		  drawImage(x+1,y,2) = 0;
	      }
	  if(x == cropRightPos)
	      {
	        drawImage(x,y,0) = 0;
		drawImage(x,y,1) = 255;
		drawImage(x,y,2) = 0;
		
		if(cropRightPos < width-1)
		{
		  drawImage(x+1,y,0) = 0;
		  drawImage(x+1,y,1) = 255;
		  drawImage(x+1,y,2) = 0;
		}
		else
		  drawImage(x-1,y,0) = 0;
		  drawImage(x-1,y,1) = 255;
		  drawImage(x-1,y,2) = 0;
	      }
	}
}
#endif


#if 1
static void drawCropWindowPath(vector<uint32>& cropLeft, uint32 const& specialWidth)
{
  uint32 frameCount = cropLeft.size();
  Image8U result(specialWidth, frameCount, 3);
	
  for (uint32 t = 0; t < frameCount; t++) 
  {
      for(uint32 x = 0; x < specialWidth; x++)
	for(uint32 c = 0; c < 3; c++)
	   result(x,t,c) = 255;
	
    result(cropLeft[t], t, 0) = 0;
    result(cropLeft[t], t, 2) = 0;
  }
  IO::saveImage("/home/stud/kiess/Videos/result/croppingWindowPath.png", result); 
}
#endif


// normalizes the values of an Image32F (with only 1 channel) into a range between 0 and 255
static void normalize32F(Image32F& frame)
{
    uint32 width = frame.width();
    uint32 height = frame.height();

    float max = 0;
    float min = frame(width-1, height-1);
    for (uint32 x = 0; x < width; x++) 
      for (uint32 y = 0; y < height; y++)
      {
	if(frame(x,y) < min)
	 min = frame(x,y);
	 
	if(frame(x,y) > max)
	 max = frame(x,y);
      }
    
    float factor = 255.0/(max - min);
    //if(factor > 10.0) 
	//factor = 10.0;
    
    for (uint32 x = 0; x < width; x++) 
      for (uint32 y = 0; y < height; y++)
      {
	frame(x,y) -= min;
	frame(x,y) *= factor;
      }
}


// load the frames of the video in a deque list
static void loadVideo(string const& videoPath, deque<Image8U>& video)
{
  VideoReader reader(videoPath);
  reader.start();
  Image8U frame(reader.getImageWidth(), reader.getImageHeight(), 3);
  
  while(!reader.getEndOfVideo()) 
    {
      reader.getImage(frame); 
      video.push_back(frame);
    }
    
  reader.stop();  
}


// substract the second from the first frame to find the positions of changing pixel values
static void findMotionSaliency(Image8U const& firstFrame, Image8U const& secondFrame, Image8U& result )
{
  uint32 width = firstFrame.width();
  uint32 height = firstFrame.height();
  uint32 channels = firstFrame.channels();
  
  float min = 1000.0;
  float max = 0.0;
  float diff = 0.0;
  float averageMax = 0.0;
  
  for(uint32 x=0; x < width; x++)
  {
	min = 1000.0;
	max = 0.0;
	for(uint32 y=0; y < height; y++)
	  {
	    diff = 0.0;
	    for(uint32 c=0; c < channels; c++) 
		diff += abs(firstFrame(x,y,c) - secondFrame(x,y,c));
	    
	    if(min > diff) min = diff;
	    if(max < diff) max = diff;
	    result(x,y) = diff;
	  }
	 averageMax += max;
	// cout << "x = " << x << ", min = " << min << ", max = " << max << endl;
  }
  
  averageMax = (averageMax/width)*0.25;  //*0.25
  //cout << "averageMax = " << averageMax << endl;
  
  for(uint32 x=0; x < width; x++)
	for(uint32 y=0; y < height; y++)
	  result(x,y) = result(x,y) > averageMax ? 255 : 0;
  
  Filter::smooth(result, result, 5); //smooth 15
}


// the energy map is computed by combining per frame saliency with simple motion saliency
static void computeSaliencyVideo(deque<Image8U>& video, deque<Image32F>& videoEnergyMap)
{
  deque<Image8U>::iterator it = video.begin();
  uint32 width = it->width();
  uint32 height = it->height();
  uint32 frameCount = video.size();
  
  Image32F saliency(width, height, 1);
  Image32F gradient(width, height, 1);
  Image8U motionSaliency(width, height, 1);
  Image32F totalSaliency(width, height, 1);
  uint32 t = 0; 
  
#if 0
    VideoWriter writer("/home/stud/kiess/Videos/result/basketball_motionSaliency.avi", width, height);
    writer.setCodec(CODEC_MPEG4);
    writer.start();
    Image8U print(width, height,1);
#endif
  
  while (it != video.end())
  {
    FrequencyTunedSaliency::calculate((*it), saliency);
    SeamCarvingImage::computeEnergy((*it), gradient, width);
    
    if(t == 0)
	findMotionSaliency((*it), (*(it+1)), motionSaliency);
    else if (t < frameCount-1)
	findMotionSaliency((*(it-1)), (*(it+1)), motionSaliency);
    else
	findMotionSaliency((*(it-1)), (*it), motionSaliency);
      

    // motionSaliency is not normalized because its values are set to 0 or 255 before smoothing
    normalize32F(gradient);
    normalize32F(saliency);
    
#if 0
    if(t == 50) 
    {
	//printImage32F(gradient, "/home/stud/kiess/Videos/result/2_50_gradient.png");
	IO::saveImage("/home/stud/kiess/Videos/result/3_50_motionSaliency.png", motionSaliency);
	//printImage32F(saliency, "/home/stud/kiess/Videos/result/0_50_frequencySaliency.png");
	//IO::saveImage("/home/stud/kiess/Videos/result/0_59_saliency.png", saliency); 
	IO::saveImage("/home/stud/kiess/Videos/result/3_50_frame.png", (*it));
	exit(1);
      
    }
#endif
    
#if 0 
    for (uint32 x = 0; x < width; x++) 
      for (uint32 y = 0; y < height; y++)
	print(x,y) = motionSaliency(x,y);
      
    writer.putImage(print);
#endif

    for(uint32 x=0; x < width; x++)
	for(uint32 y=0; y < height; y++)
	    totalSaliency(x,y) = 3*motionSaliency(x,y) + 1*gradient(x,y) + 0*saliency(x,y);  // 3*motionS+gradient
 
    videoEnergyMap.push_back(totalSaliency);
    
#if 0 
    for (uint32 x = 0; x < width; x++) 
      for (uint32 y = 0; y < height; y++)
	print(x,y) = totalSaliency(x,y);
      
    writer.putImage(print);
#endif
    
#if 0
    if(t == 50)
    {
	printImage32F(totalSaliency, "/home/stud/kiess/Videos/result/1_50_Gesamt.png");
	exit(1);
    }
#endif
    
    t++;
    it++;
  }
  
#if 0
  writer.stop();
  exit(1);
#endif

}


// sums up the energy values of all pixels for each column in each frame.
static void calculateCostColumTime(deque<Image32F>& videoEnergyMap, Image32F& costColumnTime)
{
  deque<Image32F>::iterator it = videoEnergyMap.begin();
  uint32 width = it->width();
  uint32 height = it->height();
  
  uint32 t = 0;
  while (it != videoEnergyMap.end())
  {
    for (uint32 y=0; y < height; y++)
	for (uint32 x=0; x < width; x++)
	  costColumnTime(x,t) += (*it)(x,y);
    t++;
    it++;
  }
}


// calculate the energy cost of each cropping window and store the value on the position of its left border.
static void calculateCostCroppingWindowTime(Image32F const& costColumnTime, Image32F& costCroppingWindowTime)
{
  uint32 width = costColumnTime.width();
  uint32 frameCount = costColumnTime.height();
  uint32 specialWidth = costCroppingWindowTime.width();
  uint32 targetWidth = width - specialWidth + 1;
  
  for(uint32 t=0; t < frameCount; t++)
  {
      // calculate cost of cropping frame on leftmost position
      costCroppingWindowTime(0,t) = 0;
      for (uint32 i = 0; i < targetWidth; i++)
	costCroppingWindowTime(0,t) += costColumnTime(i,t);
      
      // move cropping window a step to the right at a time and recalculate the costs for each position
      for (uint32 i = 1; i < specialWidth; i++)
      {
	costCroppingWindowTime(i,t) = costCroppingWindowTime(i-1,t);
	costCroppingWindowTime(i,t) += costColumnTime(i+targetWidth-1, t) - costColumnTime(i-1, t);
      }
  }
}



// find the path of cropping windows with the maximum energy costs.
static void calculateMaxEnergyPath(Image32F const& costCroppingWindowTime, vector<uint32>& cropLeft)
{
  uint32 specialWidth = costCroppingWindowTime.width(); // specialWidth = width - targetWidth-1
  uint32 frameCount = costCroppingWindowTime.height();
  Image32F optimalCost(specialWidth, frameCount, 1); // optimal summed costs
  Image8U predecessors(specialWidth, frameCount, 1); // saves position of max predecessor
  
  uint32 v1 = 0; // predecessor up left (x-1, t-1)      |v1|v2|v3|   t-1
  uint32 v2 = 0; // predecessor up middle (x, t-1)  ->  |--|--|--|
  uint32 v3 = 0; // predecessor up right (x+1, t-1)     |  |x |  |    t

  // find maximum cost of a connected position in the previous line and store its x-position in predecessors.
  for (uint32 t = 0; t < frameCount; t++) 
      for (uint32 x = 0; x < specialWidth; x++)
          if (t == 0) // top border
              optimalCost(x,t) = costCroppingWindowTime(x,t);
          else if (x == 0) // left border
	    {
              v2 = optimalCost(x,t-1) + costCroppingWindowTime(x,t);
              v3 = optimalCost(x+1,t-1) + costCroppingWindowTime(x,t);
              if(v2 >= v3)
	        {
		  optimalCost(x,t) = v2;
		  predecessors(x,t) = x;
		}
	      else 
	        {
		  optimalCost(x,t) = v3;
		  predecessors(x,t) = x+1;
		}//if
	    }
	  else if (x == specialWidth-1) // right border
	    {
	      v1 = optimalCost(x-1,t-1) + costCroppingWindowTime(x,t);
	      v2 = optimalCost(x,t-1) + costCroppingWindowTime(x,t);
	      if(v2 >= v1)
	        {
		  optimalCost(x,t) = v2;
		  predecessors(x,t) = x;
		}
              else
	        {
		  optimalCost(x,t) = v1;
		  predecessors(x,t) = x-1;
	        }//if		
	    }
	  else // rest of the matix 
	    {
	      v1 = optimalCost(x-1,t-1) + costCroppingWindowTime(x,t);
	      v2 = optimalCost(x,t-1) + costCroppingWindowTime(x,t);
	      v3 = optimalCost(x+1,t-1) + costCroppingWindowTime(x,t);
	      if((v2 >= v1) && (v2 >= v3))
	        {
		  optimalCost(x,t) = v2;
		  predecessors(x,t) = x;
		}
	      else if((v1 >= v2) && (v1 >= v3))
	        {
		  optimalCost(x,t) = v1;
		  predecessors(x,t) = x-1;
		}
	      else
	        {
		  optimalCost(x,t) = v3;
		  predecessors(x,t) = x+1;
		}
	    }// if else (t==0)

  // find the maximum cost position in the last row (last frame of the shot)
  float max = optimalCost(specialWidth-1, frameCount-1);
  uint32 maxPosition = specialWidth-1;
  for (uint32 x = 0; x < specialWidth-1; x++) 
      if(optimalCost(x, frameCount-1) > max)
      {
	  max = optimalCost(x,frameCount-1);
	  maxPosition = x;
      } 
     
  // build optimal cropping window path by traversing back from maximum cost position in last row
  for(int t = frameCount-1; t > -1; t--) 
  {   
      cropLeft[t] = maxPosition;
      maxPosition = predecessors(maxPosition,t); // get x-position of maximum in line t-1.
  }
}


// smooth the path of the cropping windows to prevent shaking movement
static void smoothSignal(vector<uint32>& cropLeft)
{
  uint32 size = cropLeft.size();
  
  // gauss-based average, repeated
  for(uint32 repeat = 0; repeat < 50; repeat++)
      for(uint32 i = 0; i < size; i++)
	  if(i == 0)
	      cropLeft[i] = (cropLeft[i] + cropLeft[i+1])/2; // (i + (i+1))/2
	  else if (i < size-1)  
	      cropLeft[i] = 0.25*cropLeft[i-1] + 0.5*cropLeft[i] + 0.25*cropLeft[i+1]; //(0.25 + 0.5 + 0.25)
	  else  
	      cropLeft[i] = (cropLeft[i] + cropLeft[i-1])/2;
}


static void cropAndSaveVideo(deque<Image8U>& video, string const& destPath, vector<uint32>& cropLeft, uint32 const& targetWidth)
{
  deque<Image8U>::iterator it = video.begin();
  uint32 width = it->width();
  uint32 height = it->height();
  uint32 channels = it->channels();
      
#if 1
  VideoWriter writer(destPath, targetWidth, height);  
  uint32 resultX = 0;
#endif
  
#if 0
  Image8U drawImage(width, height, channels);
  VideoWriter writer(destPath, width, height);
#endif
  
  writer.setCodec(CODEC_RAW);
  writer.start();
  uint32 t = 0;
  while (it != video.end())
  {
#if 1
    resultX = 0;
    for(uint32 x = cropLeft[t]; x < cropLeft[t]+targetWidth; x++)    
    {   
      for(uint32 y = 0; y < height; y++)   
	for(uint32 c = 0; c < channels; c++)     
	  (*it)(resultX, y, c) = (*it)(x, y, c);
	resultX += 1;
    }
    writer.putImage(*it);
#endif
    
#if 0
    drawImage = (*it);
    drawCropBorders(drawImage, cropLeft[t], targetWidth);
    writer.putImage(drawImage);
#endif
    
    t++; 
    it++;
  }

  writer.stop();
}


  
//##################################################################################|
//main										    |
//##################################################################################|

int main(int argc, char* argv[])
{
  if (argc != 4) 
    {
      std::cerr << "not enough arguments: \"Video Source\" \"Destination Path\" \"Retarget Factor\" " << std::endl;
      return 1;
    }
  
  try 
    {
      string srcPath = argv[1]; 
      string destPath = argv[2];
      double retargetFactor = atof (argv[3]);
      
      // load the video to a deque-list consisting of the frames
      cout << "1: load video" << endl;
      deque<Image8U> video;
      loadVideo(srcPath, video);
   
      Image8U frame = video[1];
      int width = frame.width();
      int height = frame.height();
      int targetWidth = retargetFactor * width;
      uint32 specialWidth = width - targetWidth + 1;
      int frameCount = video.size();
      
      cout << "frame size: " << width << "x" << height << ", target size: " << targetWidth;
      cout << "x" << height  << ", frame count: " << frameCount << endl;
      
      // compute energy and sum up column costs for each frame
      cout << "2: calculate energy and column costs" << endl;
      deque<Image32F> videoEnergyMap;
      computeSaliencyVideo(video, videoEnergyMap);
      
      Image32F costColumnTime(width, frameCount, 1); 
      calculateCostColumTime(videoEnergyMap, costColumnTime);

      // sum the costs in each frame so that each position represents a cropping window in the frame.
      cout << "3: calculate cropping window costs" << endl;
      Image32F costCroppingWindowTime(specialWidth, frameCount, 1);
      calculateCostCroppingWindowTime(costColumnTime, costCroppingWindowTime);
      
      // calculate the path with the maximum energy in the cropping windows over time based on seam carving
      cout << "4: build max energy paths" << endl;
      vector<uint32> cropLeft(frameCount);
      calculateMaxEnergyPath(costCroppingWindowTime, cropLeft);
      
      // smooth cropping window path
      cout << "5: smooth cropping window path" << endl;
      smoothSignal(cropLeft);
      
      for(int t = 0; t < frameCount; t++)
	  cout << "t = " << t << ", cropLeft Position = " << cropLeft[t] << endl;
      
      // crop the frames and save them as video
      cout << "6: crop and save the frames as video" << endl;
      cropAndSaveVideo(video, destPath, cropLeft, targetWidth);
      
      // crop the frames and save them as video
      cout << "7: visualize cropping window path" << endl;
      drawCropWindowPath(cropLeft, specialWidth);
      
      cout << "video finished" << endl; 
    }
  catch(MocaException& e)
    {
      cerr << diagnostic_information(e);
    }
}
#endif

#if 0
static void cropInitialFrame(Image8U& tmpImage, Image32F& energy, int& cropLeft, int& cropRight, int& targetWidth)
{  
#if 1
    int width = tmpImage.width();
    int height= tmpImage.height();
    int channels = tmpImage.channels();
    float *cost =new float[width];
    for (int i=0; i<width; i++) cost[i]=0;
    
    for (int y=0; y < height; y++)
      for (int x=0; x < width; x++)
	cost[x] += energy (x,y);

    //for (int i=0; i<width; i++) 
      //cout << cost[i] << endl;

    float v = 0.0;
    for (int i=0; i<targetWidth; i++) 
      v += cost[i];
    
    int pmin = 0;
    float vmin = v;
    for (int i=1; i<width-targetWidth; i++) 
    {
      v += +cost[i+targetWidth-1]-cost[i-1];
      if (vmin<v)
      {
	vmin = v;
	pmin = i;
      }
    }
    
    cropLeft = pmin;
    cropRight = pmin + targetWidth-1;
    cout << "STEPHAN cropLeft = " << cropLeft << ", cropRight = " << cropRight << endl;
    
    int resultX = 0;
    for(int x = cropLeft; x < cropRight+1; x++)
    {
	for(int y = 0; y < height; y++)  
	for(int c = 0; c < channels; c++)
	tmpImage(resultX, y, c) = tmpImage(x, y, c);
	resultX += 1;	    
    }

#endif
}


static void cropImage(Image8U& tmpImage, Image32F& energy, int& cropLeft, int& cropRight, int& targetWidth)
{  
    int width = tmpImage.width();
    int height= tmpImage.height();
    int channels = tmpImage.channels();
    float *cost =new float[width];
    for (int i=0; i<width; i++) cost[i]=0;
    
    for (int y=0; y < height; y++)
      for (int x=0; x < width; x++)
	cost[x] += energy (x,y);
      
    float v=0.0;
    for (int i=cropLeft; i < cropRight + 1; i++) 
      v += cost[i];
    
    int pmin=0;
    float vmin=v;
    bool moved = false;
    
    // move croppping window to the right side
    if(cropRight < targetWidth-1) 
    {
	  v += +cost[cropLeft+targetWidth-1]-cost[cropLeft-1];
	  if (vmin<v)
	  {
	    vmin = v;
	    pmin = cropLeft+1;
	    moved = true;
	    cout << "Move to right: ";
	  }
    }
       
    // move croppping window to the left side
    if(cropLeft > 0) 
    {
	  v += -cost[cropLeft+targetWidth-1]+cost[cropLeft-1];
	  if (vmin<v)
	  {
	    vmin = v;
	    pmin = cropLeft-1;
	    moved = true;
	    cout << "Move to left: ";
	  }
    }
 
    if(moved)
    {
	cropLeft = pmin;
	cropRight = pmin + targetWidth-1;
	cout << "cropLeft = " << cropLeft << ", cropRight = " << cropRight << endl;
    }
       
    int resultX = 0;
    for(int x = cropLeft; x < cropRight+1; x++)
    {
	for(int y = 0; y < height; y++)  
	for(int c = 0; c < channels; c++)
	tmpImage(resultX, y, c) = tmpImage(x, y, c);
	resultX += 1;	    
    }
}


//##################################################################################|
//main										    |
//##################################################################################|

int main(int argc, char* argv[])
{
  if (argc != 4) {
    std::cerr << "not enough arguements: \"Video Source\" \"Destination Path\" \"Retarget Factor\" " << std::endl;
    return 1;
  }
  
  string srcPath = argv[1]; //"/home/stud/kiess/Videos/src/football_CIF.mp4";
  string destPath = argv[2]; //"/home/stud/kiess/Videos/result/football_result.mp4";
  double retargetFactor = atof (argv[3]); // 0.7;
 
  VideoReader reader(srcPath);
  reader.start();
  cerr << "video started..." << endl;
  
  Image8U image = Image8U(reader.getImageWidth(), reader.getImageHeight(), 3);
  reader.getImage(image);  
  reader.getImage(image);  
 
  int w = image.width();
  int h = image.height();
  int c = image.channels();
  int targetWidth = retargetFactor * w;
  cerr << "frame size: " << w << "x" << h << ", target size: " << targetWidth << "x" << h << endl;
  
  Image8U result(targetWidth, h, c);
  Image32F energy(w, h, 1);	// energy map
  
  int cropLeft, cropRight;   // Marks the borders of the cropping frame.
  int x=0;
  cropLeft = 0;
  cropRight = targetWidth-1;
  
  VideoWriter writer(destPath, targetWidth, h);
  writer.start();

  cerr << "video processing..." << endl;
  while(!reader.getEndOfVideo()) 
    {
      cerr << "#################################" << endl;
      cerr << "Frame " << x << endl;
      reader.getImage(image);  
      
      SeamCarvingImage::clearImage(energy);
      SeamCropImage::computeEnergy(image, energy, w);
      
      if(x==0) 
	cropInitialFrame(image, energy, cropLeft, cropRight, targetWidth);
      else
	cropImage(image, energy, cropLeft, cropRight, targetWidth);
	
      writer.putImage(image);
      x++;
    }
  reader.stop();
  writer.stop();
  cerr << "video finished" << endl;
}
#endif

#include "io/VideoPPMWriter.h"
#include "types/MocaException.h"
#include <sstream>
#include <string>





// ==================== VideoPPMWriter ====================
 
VideoPPMWriter::VideoPPMWriter(std::string const& fileName, sizeType const& width, sizeType const& height)
  : fileName(fileName), width(width), height(height), currentFrame(0), started(false)
{

}


VideoPPMWriter::~VideoPPMWriter()
{
  stop();
}
  

void VideoPPMWriter::start()
{
  if (started)
      BOOST_THROW_EXCEPTION(IOException(std::string("You have to call stop() before you start again.") + fileName + std::string("'.")));

  file.open(fileName.c_str(), std::ios::out | std::ios::binary);
  started = true;
  currentFrame = 0;
  if (!file.good())
    BOOST_THROW_EXCEPTION(IOException(std::string("Couldn't open video file '") + fileName + std::string("'.")));
}


void VideoPPMWriter::stop()
{
  if (file.good())
  {
    file.close();
    started = false;
    currentFrame = 0;
  }
}


void VideoPPMWriter::putImage(Image8U const& image)
{
  if (!started)
    BOOST_THROW_EXCEPTION(IOException(std::string("You have to call start() first.") + fileName + std::string("'.")));
  if (file.good())
  {
    const char LF   = 0x0a;
    file << "P6" << LF
            << "#Frame: " << ++currentFrame << LF
            << width << " " << height << LF
            << "255" << LF;
    for (uint32 y=0; y < height; ++y)
    {
      for (uint32 x=0; x < width; ++x)
      {  
        file << image(x, y, 2);
        file << image(x, y, 1);
        file << image(x, y, 0);
      }
    }
    file << std::endl << std::flush;
  }
}
  

sizeType VideoPPMWriter::getImageWidth()
{
  return width;
}


sizeType VideoPPMWriter::getImageHeight()
{
  return height;
}


Rect VideoPPMWriter::getImageDimension()
{
  return Rect(0,0,width,height);
}

int32 VideoPPMWriter::getCurrentFrame()
{
  return currentFrame;
}

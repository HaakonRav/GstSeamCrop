#include "io/ImageFileWriter.h"
#include "io/IO.h"
#include <cstdio>


ImageFileWriter::ImageFileWriter(std::string fileName, std::string ext)
  : fileName(fileName), ext(ext), count(0)
{
}

ImageFileWriter::~ImageFileWriter()
{
}


void ImageFileWriter::start()
{
}


void ImageFileWriter::stop()
{
}


void ImageFileWriter::putImage(Image8U const& image)
{
  char countStr[7];
  sprintf(countStr, ".%04i.", count);
  IO::saveImage(fileName + std::string(countStr) + ext, image);
  count = (count + 1) % 10000; // you need to adjust countStr aswell if you change the limit (10000)!
}



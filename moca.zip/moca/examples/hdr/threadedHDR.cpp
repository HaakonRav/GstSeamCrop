#include "types/MocaTypes.h"
#include <iostream>

#ifdef HAVE_CAMERA
#ifdef HAVE_LIBFLTK

#include "threadedHDR.h"

#include "filter/CvtColorSpace.h"
#include "filter/Filter.h"
#include "filter/HDRStitching.h"
#include "filter/ToneMapping.h"
#include "io/HDRExposureIO.h"
#include "gui/GUIutils.h"
#include "tools/Maths.h"
#include "tools/Timing.h"
#include "types/MocaException.h"

#include <fstream>
#include <boost/archive/text_oarchive.hpp>
#include <boost/archive/text_iarchive.hpp>
#include <boost/serialization/vector.hpp>
#include <boost/thread/locks.hpp>


void CaptureThread::closeBuffer()
{
  boost::unique_lock<boost::mutex> lock(mutex);
  availableBuffers -= 1;
}


void CaptureThread::openBuffer()
{
  boost::unique_lock<boost::mutex> lock(mutex);
  availableBuffers += 1;
}


void CaptureThread::doStuff()
{
  if(availableBuffers == 0)
  {
    boost::thread::yield(); // to avoid checking the same condition multiple times before another thread has the time to
                            // process data we give up our current available CPU time here and hand it over to another thread
    return;
  }

  Exposure baseExposure(wnd->exposure);
  boost::shared_ptr<std::vector<Exposure> > expSet = boost::shared_ptr<std::vector<Exposure> >(new std::vector<Exposure>());
  expSet->push_back(baseExposure);

  wnd->hdr.captureHDR(*expSet);

  wnd->imgPrepThread->queue.push(expSet);
  
  closeBuffer();
}


void CaptureThread::cleanup()
{
  wnd->imgPrepThread->stop();
}


void ImagePreperationThread::doStuff()
{
  boost::shared_ptr<std::vector<Exposure> > expSet = queue.pop();

  // Convert all exposures to BGR if color
  for (uint32 i=0; wnd->color && i<expSet->size(); ++i)
    {
      Exposure& e = (*expSet)[i];
      boost::shared_ptr<Image8U> colImg(new Image8U(e.image->width(), e.image->height(), 3));
      colImg->setTimestamp(e.image->getTimestamp());
      CvtColorSpace::convert(*e.image, *colImg, COLOR_BayerGB, COLOR_BGR);

      // now convert to Yxy
      e.image = boost::shared_ptr<Image8U>(new Image8U(e.image->width(), e.image->height(), 3));
      CvtColorSpace::convert(*colImg, *e.image, COLOR_BGR, COLOR_Yxy);
    }

  if (wnd->regSwitch && !wnd->sequenceMode)
    wnd->registerImages(*expSet);
    
  wnd->stitchThread->queue.push(expSet);
}


void ImagePreperationThread::cleanup()
{
  while(!queue.empty())
    doStuff();
    
  wnd->stitchThread->stop();
}


void StitchingThread::doStuff()
{
  boost::shared_ptr<std::vector<Exposure> > expSet = queue.pop();
  
  Exposure& baseExp = (*expSet)[0];
  sizeType imgWidth = baseExp.image->width();
  sizeType imgHeight = baseExp.image->height();
  int32 imgChannels = baseExp.image->channels();

  boost::shared_ptr<Result> result = boost::shared_ptr<Result>(new Result);
  result->hdrImg = boost::shared_ptr<Image32F>(new Image32F(imgWidth,imgHeight,imgChannels));
  result->ldrImg = boost::shared_ptr<Image8U>(new Image8U(imgWidth,imgHeight,imgChannels));

  double avg = wnd->stitchHDR(*expSet, *result);

  result->nextShutter = wnd->estimateNextShutter(avg, 10, 254);
  
  if (wnd->printSwitch && wnd->hdrSwitch)
    wnd->print(*expSet);  
  
  wnd->hdrImages.push(result);
}


void StitchingThread::cleanup()
{
  while(!queue.empty())
    doStuff();
    
  // this clears the results queue so that it doesn't contain old data when the entire
  // capturing process is started again (HDRWindow isn't interested in the results once
  // capturing is stopped but if this behaviour shall change in the future this is the
  // only part which has to be changed in the current threading model)
  while(!wnd->hdrImages.empty())
    wnd->hdrImages.pop();
}


HDRWindow::HDRWindow(bool sequenceMode)
  : CameraWindow(Rect(0, 0, imgWidth, imgHeight), "Threaded HDR", Rect(0, 0, imgWidth, imgHeight), CameraReader::SPEED_400, colorMode, -1, false),
    hdr(reader, 10, 254, 10),
    exposure(image, Vector2D::create(0, 0), 400, Exposure::TOO_BOTH, 0),
    hdrSwitch(false), regSwitch(true), ghostRemovalSwitch(true), ghostSegmentSwitch(false), printSwitch(false), useMultiThreading(true), sequenceMode(sequenceMode)
{
  createImages(imgWidth, imgHeight);
  color = colorMode == CameraReader::MODE_RAW8;

  addMenuEntry("HDR/print info", 'a', printCB);
  addMenuEntry("HDR/register HDR", 's', wardCB);
  addMenuEntry("HDR/capture HDR", 'd', hdrCB);
  addMenuEntry("HDR/toggle ghost removal", 'g', ghostRemovalCB);
  addMenuEntry("HDR/show ghost segments", 'v', ghostSegmentCB);

  CameraFeaturePtr shutFeat = reader->getFeature(CameraFeature::FEATURE_Shutter);
  //minShutter = shutFeat->getAbsMin();
  //maxShutter = shutFeat->getAbsMax();
  minShutter = shutFeat->getMin();
  maxShutter = shutFeat->getMax();
    
  if (useMultiThreading)
  {
    captThread = boost::shared_ptr<CaptureThread>(new CaptureThread(this, 20));
    imgPrepThread = boost::shared_ptr<ImagePreperationThread>(new ImagePreperationThread(this));
    stitchThread = boost::shared_ptr<StitchingThread>(new StitchingThread(this));
  }
}


void HDRWindow::doStuff()
{
  if (hdrSwitch)
    if (useMultiThreading)
      cameraModeHDR_MT();
    else
      cameraModeHDR();      
  else
    cameraModeLDR();

  if (color)
    showImage(colorImage);
  else
    showImage(image);
}


void HDRWindow::cameraModeHDR()
{
  Timing::start(19);
  
  std::vector<Exposure> expSet;
  expSet.push_back(exposure);

  hdr.captureHDR(expSet);

  // Convert all exposures to BGR if color
  for (uint32 i=0; color && i<expSet.size(); ++i)
    {
      Exposure& e = expSet[i];
      boost::shared_ptr<Image8U> colImg(new Image8U(e.image->width(), e.image->height(), 3));
      colImg->setTimestamp(e.image->getTimestamp());
      CvtColorSpace::convert(*e.image, *colImg, COLOR_BayerGB, COLOR_BGR);
      e.image = colImg;
    }

  // now convert to Yxy if color
  for (uint32 i=0; color && i<expSet.size(); ++i)
    CvtColorSpace::convert(*expSet[i].image, *expSet[i].image, COLOR_BGR, COLOR_Yxy);

  if (regSwitch && !sequenceMode)
    registerImages(expSet);

  double avg = stitchHDR(expSet);

  exposure.shutter = estimateNextShutter(avg, 10, 254);

  if (printSwitch && hdrSwitch)
    print(expSet);
    
  std::cout << "processing time for current frame: " << Timing::stop(19) << "ms" << std::endl;
}

  
void HDRWindow::cameraModeHDR_MT()
{
  boost::shared_ptr<Result> result = hdrImages.pop(200);
  if(result != NULL)
  {
    std::cout << "time since last completed frame: " << Timing::stop(19) << "ms" << std::endl;

    if(color)
    {
      hdrImageCol = result->hdrImg;
      colorImage = result->ldrImg;
    }
    else
    {
      hdrImage = result->hdrImg;
      image = result->ldrImg;
    }
    exposure.shutter = result->nextShutter;
     
    Timing::start(19);
    
    captThread->openBuffer();
  }
}


void HDRWindow::cameraModeLDR()
{
  reader->captureImage(Rect(0, 0, imgWidth, imgHeight), (uint32)400);
  reader->getImage(*image);
  if (color)
    CvtColorSpace::convert(*image, *colorImage, COLOR_BayerGB, COLOR_BGR);
}


float HDRWindow::estimateNextShutter(double avg, uint32 darkest, uint32 brightest)
{
  float shutter = exp(0.5 * log(darkest * brightest));
  shutter /= exp(avg);
  shutter = std::min<float>(shutter, maxShutter);
  shutter = std::max<float>(shutter, minShutter);
  return shutter;
}


void HDRWindow::registerImages(std::vector<Exposure>& expSet)
{
  // stores the original topLeft vectors before stitching
  std::vector<VectorI> unmodTL(expSet.size());
  unmodTL[0] = Vector2D::create(0, 0);

  for (uint32 i=1; i<expSet.size(); ++i)
    {
      unmodTL[i] = expSet[i].topLeft;
      Exposure& exp = expSet[i];
      Exposure& parent = expSet[exp.parent];

      //std::cout << i << ") " << (gTruth[set][i] - exp.topLeft) << std::endl;
      exp.topLeft -= unmodTL[exp.parent];
      ward.computeShift(*parent.image, *exp.image, 6, exp.topLeft);
      exp.topLeft += parent.topLeft;

      /*
      if (loadSwitch)
        {
          double distX = exp.topLeft[0] - gTruth[set][i][0];
          double distY = exp.topLeft[1] - gTruth[set][i][1];
          double dist = sqrt(distX*distX + distY*distY);
          std::cout << i << ") " << dist << std::endl;
          //std::cout << i << ") " << distX << ", " << distY << std::endl;
        }
      */
    }
}


// stitches exposures in expSets[currentSet] which are either Yxy or gray
// result will be in either colorImage or image
double HDRWindow::stitchHDR(std::vector<Exposure>& expSet, Result& result)
{
  if(ghostRemovalSwitch)
    HDRStitching::weightedNoGhosts(expSet, *result.hdrImg, 200, .12);
  else
    HDRStitching::weighted(expSet, *result.hdrImg);
  double avg = ToneMapping::simpleLog(*result.hdrImg, *result.ldrImg);
  if (color)
  {
    CvtColorSpace::convert(*result.ldrImg, *result.ldrImg, COLOR_Yxy, COLOR_BGR);
    if(ghostRemovalSwitch && ghostSegmentSwitch)
    {
      boost::shared_ptr<Image8U> ghostSegments = HDRStitching::getGhostSegments();
      int32 const& reductionFactor = HDRStitching::reductionFactor;
      for(uint32 y = 0; y < result.ldrImg->height(); y++)
        for(uint32 x = 0; x < result.ldrImg->width(); x++)
          if((*ghostSegments)(x/reductionFactor,y/reductionFactor) > 127)
          {
            (*result.ldrImg)(x, y, 0) = 255; (*result.ldrImg)(x, y, 1) = 0; (*result.ldrImg)(x, y, 2) = 255;
          }
    }
  }
  return avg;
}


double HDRWindow::stitchHDR(std::vector<Exposure>& expSet)
{
  Result result;
  result.hdrImg = color ? hdrImageCol : hdrImage;
  result.ldrImg = color ? colorImage : image;
  
  return stitchHDR(expSet, result);
}


void HDRWindow::print(std::vector<Exposure>& expSet)
{
  for (int i=0; i<(int)expSet.size(); ++i)
    std::cout << i << ") " << expSet[i] << std::endl;
  std::cout << std::endl;
}


void HDRWindow::createImages(uint32 width, uint32 height)
{
  image = boost::shared_ptr<Image8U>(new Image8U(width, height, 1));
  colorImage = boost::shared_ptr<Image8U>(new Image8U(width, height, 3));
  hdrImage = boost::shared_ptr<Image32F>(new Image32F(width, height, 1));
  hdrImageCol = boost::shared_ptr<Image32F>(new Image32F(width, height, 3));
}


// ==================== callbacks ====================
#define SWITCH_CALLBACK(switchVar, switchString) \
  HDRWindow* wnd = static_cast<HDRWindow*>(dWnd); \
  wnd->switchVar ^= true; \
  std::cout << switchString << (wnd->switchVar?"ON":"OFF") << std::endl;


void HDRWindow::printCB(DisplayWindow* dWnd)
{
  SWITCH_CALLBACK(printSwitch, "Parameter printing is ");
}


void HDRWindow::wardCB(DisplayWindow* dWnd)
{
  SWITCH_CALLBACK(regSwitch, "Image Registration is ");
}


void HDRWindow::hdrCB(DisplayWindow* dWnd)
{
  SWITCH_CALLBACK(hdrSwitch, "HDR is ");
  if (wnd->useMultiThreading)
  {
    if (wnd->hdrSwitch)
    {
      wnd->captThread->start();
      wnd->imgPrepThread->start();
      wnd->stitchThread->start();
      Timing::start(19);
    }
    else
    {
      Timing::stop(19);
      wnd->captThread->stop();
    }
  }
}
  
  
void HDRWindow::ghostRemovalCB(DisplayWindow* dWnd)
{
  SWITCH_CALLBACK(ghostRemovalSwitch, "Ghost Removal is ");
}
  
  
void HDRWindow::ghostSegmentCB(DisplayWindow* dWnd)
{
  SWITCH_CALLBACK(ghostSegmentSwitch, "Ghost Segment Showing is ");
}


int main(int argc, char** argv)
{
  try
    {
      bool sequenceMode = false;
      if(argc > 1)
          sequenceMode = true;
          
      HDRWindow hdr(sequenceMode);
      hdr.mainLoop();
    }
  catch(MocaException& e)
    {
      std::cerr << diagnostic_information(e);
    }
  
  return 0;
}


#else // HAVE_LIBFLTK


int main(int argc, char** argv)
{
  std::cout << "this example requires FLTK." << std::endl;
  return 0;
}


#endif // HAVE_LIBFLTK
#else // HAVE_CAMERA


int main(int argc, char** argv)
{
  std::cout << "this example requires a supported camera." << std::endl;
  return 0;
}


#endif // HAVE_CAMERA


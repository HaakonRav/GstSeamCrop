#include "types/Color.h"


Color::Color(uint8 r, uint8 g, uint8 b)
{
  c[RED] = r;
  c[GREEN] = g;
  c[BLUE] = b;
  isGray = false;
}


Color::Color(uint8 lumi)
{
  c[LUMINANCE] = lumi;
  isGray = true;
}


Color::Color(Color const& other)
{
  c[0] = other.c[0];
  c[1] = other.c[1];
  c[2] = other.c[2];
  isGray = other.isGray;
}


Color& Color::operator=(const Color &other)
{
  if (this != &other)
  {
    c[0] = other.c[0];
    c[1] = other.c[1];
    c[2] = other.c[2];
    isGray = other.isGray;
  }
  return *this;
}


uint8& Color::operator[](Channel i)
{
  return c[i];
}


const uint8& Color::operator[](Channel i) const
{	
  return c[i];
}
  

void Color::convertToGrayscale()
{
  if(!isGray)
  {
     uint16 lumi = 54*c[RED] + 183*c[GREEN] + 19*c[BLUE];
     lumi >>= 8;
     c[LUMINANCE] = (uint8)lumi;
     isGray = true;
  }
}


void Color::convertToRGB()
{
  if(isGray)
  {
    c[RED] = c[GREEN] = c[BLUE] = c[LUMINANCE];
    isGray = false;
  }
}


bool Color::isGrayscale() const
{
  return isGray;
}


bool Color::isRGB() const
{
  return !isGray;
}


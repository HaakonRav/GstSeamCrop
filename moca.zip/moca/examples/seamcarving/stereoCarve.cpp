#include "types/MocaException.h"
#include "types/MocaTypes.h"
#include "filter/Filter.h"
#include "tools/Timing.h"
#include "StereoIO.h"

#include <algorithm>

class StereoCarve
{
public:
  typedef std::vector<int> Seam;

  StereoCarve();
  StereoCarve(double w3d, double wAppear, double wTemp);

  void processVideo(StereoIO* sio, std::string const& outputDir, uint32 toFrame,
                    uint32 numSeams, bool saveVideo, bool saveDisp, bool saveOcc, bool saveEnergy);

  void occlusionMap();
  void temporalEnergy(uint32 seamIndex);
  double totalEnergy(int x, int y, int xup, bool temporal);
  void accumulateEnergy(Image32F& energy, Image16S& predec, uint32 frameIndex, uint32 seamIndex);
  void findSeams(Image32F const& energy, Image16S const& predec,
                 Seam& leftSeam, Seam& rightSeam);
  Image8U removeSeam(Seam const& seam, Image8U const& image);
  void updateDisparity(Seam const& leftSeam, Seam const& rightSeam);

  double disparityScore();

private:
  Image8U left, right;
  Image16S disp;
  Image8U occlusion;
  Image32F tempEnergyL, tempEnergyR;
  
  std::vector<Seam> prevSeamsL, prevSeamsR;

  double const W_3D; // weighting factor for 3D energy
  double const W_APPEAR; // weighting for apperance energy
  double const W_CONF; // weighting for confidence
  double const W_DIST; // weighting for distance energy
  double const W_TEMP; // weighting for temporal energy
  int const maxStep; // maximum distance for a discontinuous seam
};


StereoCarve::StereoCarve()
  : left(1, 1, 1), right(1, 1, 1), disp(1, 1, 1), occlusion(1, 1, 1), tempEnergyL(1, 1, 1), tempEnergyR(1, 1, 1),
    W_3D(1), W_APPEAR(1), W_CONF(0.5), W_DIST(0.1), W_TEMP(1), maxStep(10)
{
}


StereoCarve::StereoCarve(double w3d, double wAppear, double wTemp)
  : left(1, 1, 1), right(1, 1, 1), disp(1, 1, 1), occlusion(1, 1, 1), tempEnergyL(1, 1, 1), tempEnergyR(1, 1, 1),
    W_3D(w3d), W_APPEAR(wAppear), W_CONF(0.5), W_DIST(0.2), W_TEMP(wTemp), maxStep(10)
{
}


void StereoCarve::processVideo(StereoIO* sio, std::string const& outputDir, uint32 toFrame,
                               uint32 numSeams, bool saveVideo, bool saveDisp, bool saveOcc, bool saveEnergy)
{
  sio->start();

  prevSeamsL.resize(numSeams);
  prevSeamsR.resize(numSeams);
  
  while (sio->hasMore() && sio->getFrameIndex() < toFrame) {
    std::cout << "frame " << sio->getFrameIndex() << std::endl;
    sio->loadNext();
    left = sio->getLeft();
    right = sio->getRight();
    disp = sio->getDisparity();
    
    for (uint32 i=0; i<numSeams; ++i) {
      std::cout << "\r" << (i*100)/(numSeams-1) << "%  "; std::cout.flush();

      occlusionMap();
      if (saveOcc && i==numSeams-1)
        sio->saveOcclusion(occlusion, outputDir, "occ");

      Image32F energy(left.width(), left.height(), 1);
      Image16S predec(left.width(), left.height(), 1);
      accumulateEnergy(energy, predec, sio->getFrameIndex(), i);
      if (saveEnergy && i==numSeams-1)
        sio->saveEnergy(energy, outputDir, "energy");

      Seam leftSeam, rightSeam;
      findSeams(energy, predec, leftSeam, rightSeam);

      left = removeSeam(leftSeam, left);
      right = removeSeam(rightSeam, right);

      updateDisparity(leftSeam, rightSeam);

      prevSeamsL[i] = leftSeam;
      prevSeamsR[i] = rightSeam;
    }
    std::cout << std::endl;

    if (saveVideo)
      sio->saveSBS(left, right, outputDir, "");

    if (saveDisp)
      sio->saveDisparity(disp, outputDir, "disp");
  }

  sio->stop();
}


bool sortFunc(std::pair<int, int> i, std::pair<int, int> j) { return i.second < j.second; }

// occ(x, y) = 1 means occluded/occluding/invalid
void StereoCarve::occlusionMap()
{
  occlusion = Image8U(disp.width(), disp.height(), 1);
  Filter::set(occlusion, 0);
  if (W_3D == 0)
    return;

  uint32 width = disp.width();
  uint32 height = disp.height();
  for (uint32 y=0; y<height; ++y) {
    // sort pixels by increasing disparity (far pixels first)
    std::vector<std::pair<int, int> > pixels(width);
    for (uint32 i=0; i<width; ++i) { // initialize
      pixels[i].first = i;
      pixels[i].second = disp(i, y);
    }
    sort(pixels.begin(), pixels.end(), sortFunc);

    std::vector<int> zBuffer(width, -1); // depth of each pixel
    for (uint32 i=0; i<width; ++i) {
      if (pixels[i].second < 0) { // invalid disparity
        occlusion(pixels[i].first, y) = 1;
        continue;
      }
      int rightPos = pixels[i].first - pixels[i].second; // map pixel into z buffer
      if (rightPos < 0 || rightPos >= (int)width)
        continue;
      if (zBuffer[rightPos] != -1) { // if there already was a pixel (further away)
        occlusion(rightPos+zBuffer[rightPos], y) = 1; // previous pixel is occluded
        occlusion(pixels[i].first, y) = 1; // current pixel occludes
      }
      zBuffer[rightPos] = pixels[i].second; // store depth in z buffer
    }
  }
}


void StereoCarve::temporalEnergy(uint32 seamIndex)
{
  // current frame seam carved with previous seam
  Image8U unmodL(removeSeam(prevSeamsL[seamIndex], left));
  Image8U unmodR(removeSeam(prevSeamsR[seamIndex], right));
  int32 w = left.width();
  std::vector<float> intLPlus(w), intLMinus(w), intRPlus(w), intRMinus(w);

  // compute difference between current frame with previous seam and current frame with seam position in (x, y)
  for (uint32 y=0; y<left.height(); ++y) {
    intLMinus[0] = intLPlus[w-1] = 0;
    intRMinus[0] = intRPlus[w-1] = 0;
    for (int32 x=0; x<w-1; ++x) {
      intLMinus[x+1] = intLMinus[x] + abs(left(x, y)  - unmodL(x, y));
      intRMinus[x+1] = intRMinus[x] + abs(right(x, y) - unmodR(x, y));
      intLPlus[w-x-2] = intLPlus[w-x-1] + abs(left(w-x-1, y)  - unmodL(w-x-2, y));
      intRPlus[w-x-2] = intRPlus[w-x-1] + abs(right(w-x-1, y) - unmodR(w-x-2, y));
    }
    for (uint32 x=0; x<left.width(); ++x) {
      tempEnergyL(x, y) = (intLMinus[x] + intLPlus[x]) / 255.0;
      tempEnergyR(x, y) = (intRMinus[x] + intRPlus[x]) / 255.0;
    }
  }
}


// E_intensity for the left or the right image
// multiply by factor 1/255.0 for left and right image
// multiply by factor 1/32.0 for disparity
template <class T>
double appearanceOne(T const& image, int x, int y, int xup)
{
  double eHor = 0;
  int xMinus = x > 0 ? x-1 : 0;
  int xPlus = x < (int)image.width()-1 ? x+1 : 0;
  for (int32 c=0; c<image.channels(); ++c)
    eHor += abs(image(xMinus, y, c) - image(xPlus, y, c)) / image.channels();

  double eVer = 0;
  if (xup < x)
    for (int i=xup+1; i<=x; ++i)
      for (int32 c=0; c<image.channels(); ++c)
        eVer += abs(image(i, y-1, c) - image(i-1, y, c)) / image.channels();
  else if (xup > x)
    for (int i=x+1; i<=xup; ++i)
      for (int32 c=0; c<image.channels(); ++c)
        eVer += abs(image(i-1, y-1, c) - image(i, y, c)) / image.channels();

  return eHor + eVer;
}


double StereoCarve::totalEnergy(int x, int y, int xup, bool temporal)
{
  if (disp(x, y) < 0 || disp(xup, y) < 0)
    return MOCA_FLOAT_MAX;

  int rightX = x - disp(x, y);
  int rightXup = xup - disp(xup, y);
  if (rightX < 0 || rightXup < 0)
    return MOCA_FLOAT_MAX;

  double eLeft = appearanceOne<Image8U>(left, x, y, xup);
  double eRight = appearanceOne<Image8U>(right, rightX, y, rightXup);
  double appearanceEnergy = (eLeft + eRight) / 255.0;

  double eDisp = appearanceOne<Image16S>(disp, x, y, xup) / 32.0;
  double eDistance = disp(x, y) / 32.0;
  double eConfidence = abs(left(x, y) - right(rightX, y)) / 255.0; // hack: nur blau!
  double energy3D = eDisp + W_DIST * eDistance + W_CONF * eConfidence;
  
  double temporalEnergy = temporal ? tempEnergyL(x, y) + tempEnergyR(x, y) : 0;

  return W_APPEAR * appearanceEnergy + W_3D * energy3D + W_TEMP * temporalEnergy;
}


void StereoCarve::accumulateEnergy(Image32F& energy, Image16S& predec, uint32 frameIndex, uint32 seamIndex)
{
  Timing::reset(1);
  Timing::reset(2);
  assert(left.height() > 0);
  for (uint32 x=0; x<left.width(); ++x)
    energy(x, 0) = predec(x, 0) = 0;

  if (frameIndex > 1) {
    tempEnergyL = Image32F(left.width(), left.height(), 1);
    tempEnergyR = Image32F(right.width(), right.height(), 1);
    temporalEnergy(seamIndex);
  }

  for (uint32 y=1; y<left.height(); ++y)
    for (uint32 x=0; x<left.width(); ++x)
      {
        if (occlusion(x, y) == 1) {
          energy(x, y) = MOCA_FLOAT_MAX;
          predec(x, y) = x;
          continue;
        }

        // blocked if all three pixels above are occluded
        bool blocked = occlusion(x, y-1) == 1 || energy(x, y-1) == MOCA_FLOAT_MAX;
        if (x > 0)
          blocked &= occlusion(x-1, y-1) == 1 || energy(x-1, y-1) == MOCA_FLOAT_MAX;
        if (x < left.width()-1)
          blocked &= occlusion(x+1, y-1) == 1 || energy(x+1, y-1) == MOCA_FLOAT_MAX;

        // !!!!!!!!!!!!!!!!!!!! HACK !!!!!!!!!!!!!!!!!!!!
        blocked = true;

        // consider only three pixels if not blocked
        // consider entire row (-maxStep -> maxStep) if blocked
        int startX = x - (blocked ? maxStep : 1);
        int stopX  = x + (blocked ? maxStep : 1);
        startX = startX < 0 ? 0 : startX;
        stopX = stopX > (int)left.width()-1 ? left.width()-1 : stopX;

        double minEnergy = MOCA_FLOAT_MAX;
        int minXup = x;
        for (int xup = startX; xup<=stopX; ++xup) {
          double energ = energy(xup, y-1) + totalEnergy(x, y, xup, frameIndex>1);
          if (energ < minEnergy) {
            minEnergy = energ;
            minXup = xup;
          }
        }
        energy(x, y) = minEnergy;
        predec(x, y) = minXup;
      }
}


// finds seam from accumulated energy map and list of predecessors
// result is vector of X indices
void StereoCarve::findSeams(Image32F const& energy, Image16S const& predec,
                            Seam& leftSeam, Seam& rightSeam)
{
  double minEnergy = MOCA_FLOAT_MAX;
  uint32 minPos = 0;
  for (uint32 x=0; x<energy.width(); ++x)
    {
      double value = energy(x, energy.height()-1);
      if (value < minEnergy) {
        minEnergy = value;
        minPos = x;
      }
    }

  leftSeam.resize(energy.height());
  rightSeam.resize(energy.height());
  for (int y=energy.height()-1; y>=0; --y) {
    assert(minPos >= 0 && minPos < energy.width());
    leftSeam[y] = minPos;
    uint32 rightX = minPos - disp(minPos, y);
    assert(rightX >= 0 && rightX < energy.width());
    rightSeam[y] = rightX;
    minPos = predec(minPos, y);
  }

  /*
  // START: Visualize detected seam
  Image8U seamL(energy.width(), energy.height(), 1);
  Image8U seamR(energy.width(), energy.height(), 1);
  Filter::set(seamL, 255);
  Filter::set(seamR, 0);
  for (uint32 y=0; y<seamL.height(); ++y) {
    seamL(leftSeam[y], y) = 0;
    seamR(rightSeam[y], y) = 1;
  }
  visualizeStuff(seamL, seamR);
  // END: Visualize detected seam
  */
}

// removes the seam from the image. result.width() == image.width()-1
Image8U StereoCarve::removeSeam(Seam const& seam, Image8U const& image)
{
  Image8U result(image.width()-1, image.height(), image.channels());
  for (uint32 y=0; y<image.height(); ++y) {
    for (int x=0; x<seam[y]; ++x)
      for (int32 c=0; c<image.channels(); ++c)
        result(x, y, c) = image(x, y, c);
    for (int x=seam[y]+1; x<(int)image.width(); ++x)
      for (int32 c=0; c<image.channels(); ++c)
        result(x-1, y, c) = image(x, y, c);
  }
  return result;
}

// removes the seam from the disparity map and updates the shifts
void StereoCarve::updateDisparity(Seam const& leftSeam, Seam const& rightSeam)
{
  Image16S result(disp.width()-1, disp.height(), disp.channels());
  for (uint32 y=0; y<disp.height(); ++y)
    for (int x=0; x<(int)disp.width()-1; ++x) { // all OUTPUT pixels
      int leftX = x<leftSeam[y] ? x : x+1; // original X value in the uncarved left image
      int rightX = leftX - disp(leftX, y); // original X value in the uncarved right image
      rightX = rightX<rightSeam[y] ? rightX : rightX-1; // X value in right image after carving
      result(x, y) = x - rightX; // X_left after carving - X_right after carving
    }
  disp = result;
}


double StereoCarve::disparityScore()
{
  double result = 0;
  double numPix = 0;
  for (uint32 y=0; y<left.height(); ++y)
    for (uint32 x=0; x<left.width(); ++x) {
      int rightX = x - disp(x, y);
      if (rightX < 0 || rightX >= (int)right.width())
        continue;
      for (int32 c=0; c<left.channels(); ++c)
        result += abs(left(x, y, c) - right(rightX, y, c)) / 3.0;
      numPix += 1;
    }
  return result / numPix;
}


int main()
{
  try {
    std::string inDir[] = {"in_stereo/book/",
                           "in_stereo/street/",
                           "in_stereo/tanks/",
                           "in_stereo/temple/",
                           "in_stereo/tunnel/"};
    std::string inExt = ".png";
    std::string outDir[] = {"output/book",
                            "output/street",
                            "output/tanks",
                            "output/temple",
                            "output/tunnel"};

    uint32 stopFrame = 20000;
    uint32 iterations = 60;

    double params[][3] = {{0, 5, 0}, // 3D, Appearance, Temp
                          {0, 5, 0.1},
                          {1, 5, 0},
                          {1, 5, 0.1}};
    std::string algo[] = {"MF", "MV", "SF", "SV"};

    for (uint32 j=0; j<5; ++j)
      //uint32 j=0;
      {
      std::cout << inDir[j] << std::endl;
      //for (uint32 i=0; i<4; i+=1)
      uint32 i=3;
        {
          std::cout << algo[i] << std::endl;
          StereoCarve st(params[i][0], params[i][1], params[i][2]);
          LRImageIO sio(inDir[j], "L", "R", "TL", 4, ".png");
          std::string outFile = outDir[j] + algo[i];
          st.processVideo(&sio, outFile, stopFrame, iterations, true, false, false, false); // save: Frame, Disp, Occ, Energy
        }
    }
  }
  catch(MocaException& e) {
    std::cerr << diagnostic_information(e);
  }

  return 0;
}

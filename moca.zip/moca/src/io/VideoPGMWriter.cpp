#include "io/VideoPGMWriter.h"
#include "types/MocaException.h"
#include <sstream>
#include <string>





// ==================== VideoPGMWriter ====================
 
VideoPGMWriter::VideoPGMWriter(std::string const& fileName, sizeType const& width, sizeType const& height)
  : fileName(fileName), width(width), height(height), currentFrame(0), started(false)
{

}


VideoPGMWriter::~VideoPGMWriter()
{
  stop();
}
  

void VideoPGMWriter::start()
{
  if (started)
      BOOST_THROW_EXCEPTION(IOException(std::string("You have to call stop() before you start again.") + fileName + std::string("'.")));

  file.open(fileName.c_str(), std::ios::out | std::ios::binary);
  started = true;
  currentFrame = 0;
  if (!file.good())
    BOOST_THROW_EXCEPTION(IOException(std::string("Couldn't open video file '") + fileName + std::string("'.")));
}


void VideoPGMWriter::stop()
{
  if (file.good())
  {
    file.close();
    started = false;
    currentFrame = 0;
  }
}


void VideoPGMWriter::putImage(Image8U const& image)
{
  if (!started)
    BOOST_THROW_EXCEPTION(IOException(std::string("You have to call start() first.") + fileName + std::string("'.")));
  if (file.good())
  {
    const char LF   = 0x0a;
    file << "P5" << LF
            << "#Frame: " << ++currentFrame << LF
            << width << " " << height << LF
            << "255" << LF;
    for (uint32 y=0; y < height; ++y)
    {
      for (uint32 x=0; x < width; ++x)
      {    
        file << image(x, y, 0);
      }
    }
    file << std::endl << std::flush;
  }
}
  

sizeType VideoPGMWriter::getImageWidth()
{
  return width;
}


sizeType VideoPGMWriter::getImageHeight()
{
  return height;
}


Rect VideoPGMWriter::getImageDimension()
{
  return Rect(0,0,width,height);
}

int32 VideoPGMWriter::getCurrentFrame()
{
  return currentFrame;
}

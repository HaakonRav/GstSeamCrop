#ifndef TESTCASES_H
#define TESTCASES_H

//////////////////////////////
// Define path to test data //
//////////////////////////////
#ifdef WIN32
#define TESTDATAPATH "..\\libtest\\testdata\\"
#define STDEXP       TESTDATAPATH "turn\\exposures0\\"
#else
#define TESTDATAPATH "testdata/"
#define STDEXP       TESTDATAPATH "turn/exposures0/"
#endif
#define BAYPATT_IMG  TESTDATAPATH "bayer.png"
#define RGB_IMG      TESTDATAPATH "RGB.png"
#define Yxy_IMG      TESTDATAPATH "Yxy.png"
#define LENA_IMG     TESTDATAPATH "lena.bmp"

/////////////////////////////////////////////////////////
// Hardware dependent values for devie management test //
/////////////////////////////////////////////////////////
//#ifdef WIN32
#define NUMBER_OF_DEVICES		1
#define MAX_GFLOPS_DEVICE_INDEX		0
#define DEVICE_ZEROES_NAME		"GeForce 9400M G"
//#else
//TODO: Catch other hosts here
//#endif

////////////////////////////////////
// Macros for simple Benchmarking //
////////////////////////////////////
#include "tools/Timing.h"

// Defines the number of runs when using MOCA_TIC or MOCA_TOC. Can be passed as macro parameter.
#define RUNS						1
// Sets up timing, must be used with MOCA_TOC. The variable runs defines the number of runs used for measuring.
#define MOCA_TIC(runs)				Timing::reset(); for (int runid = 0; runid < (runs); runid++) { Timing::start();
// Like MOCA_TIC, but allows to reset a data structure before every run by executing a given method call res.
#define MOCA_TIC_RESET(runs, res)	Timing::reset(); for (int runid = 0; runid < (runs); runid++) { (res); Timing::start();
// MOCA_TOC finishes measurement started with MOCA_TIC. Label is used for printing to command line (e.g. "label: 28.00 ms")
#define MOCA_TOC(label)				Timing::stop(); } std::cout << (label) << ": " << Timing::avg() << "ms" << std::endl;
// Like MOCA_TIC, but waits for keystroke.
#define MOCA_TOC_WAIT(label)		Timing::stop(); } std::cout << (label) << ": " << Timing::avg() << "ms" << std::endl; std::cin.get();

///////////////////////////////////
// Macro for catching exceptions //
///////////////////////////////////
#include "types/MocaException.h"

// Catches all moca exceptions exceptions, must be used in combination with MOCA_CATCH or MOCA_CATCH_WAIT
#define MOCA_TRY			try {
#define MOCA_CATCH			} catch (boost::exception& e) { std::cout << diagnostic_information(e); }
// Like MOCA_CATCH, but waits for keystroke
#define MOCA_CATCH_WAIT		} catch (boost::exception& e) { std::cout << diagnostic_information(e); std::cin.get(); }

///////////////////////////////////////////////////////////////
// Helper functions for testcases, e.g. for comparing images //
///////////////////////////////////////////////////////////////
#include "types/Image8U.h"
#include "types/Image32F.h"

float compareImage8U(Image8U& img1, Image8U& img2, int channel = -1);
float compareImage32F(Image32F& img1, Image32F& img2, int channel = -1);
void cropImage8U(Image8U& src, Image8U& tgt);
void cropImage32F(Image32F& src, Image32F& tgt);
void randFillImage(Image32F& src, float max, float min);

#endif

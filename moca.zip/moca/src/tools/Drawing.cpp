#include "tools/Drawing.h"
#include "types/CameraImage.h"
#include "types/MocaException.h"
#include "tools/Maths.h"


void Drawing::drawCross(ImageBase& image, VectorI const& pos, int32 const size, int32 const width, Color color)
{
  if(pos.size() != 2)
    BOOST_THROW_EXCEPTION(ArgumentException("Expected a two-dimensional vector as position"));
  if ((pos[0] < 0) || (pos[1] < 0) || (pos[0] >= (int)image.width()) || (pos[1] >= (int)image.height()))
    BOOST_THROW_EXCEPTION(ArgumentException("Invalid position."));
  if ((size <= 0) || (width <= 0))
    BOOST_THROW_EXCEPTION(ArgumentException("Invalid size."));

  int const rad = size/2;

  VectorI pos1(2);
  VectorI pos2(2);
  
  pos1[0] = pos[0]-rad;
  pos1[1] = pos[1];
  pos2[0] = pos[0]+rad;
  pos2[1] = pos[1];
  drawLine(image, pos1, pos2, width, color);
  
  pos1[0] = pos[0];
  pos1[1] = pos[1]-rad;
  pos2[0] = pos[0];
  pos2[1] = pos[1]+rad;
  drawLine(image, pos1, pos2, width, color);
}


void Drawing::drawLine(ImageBase& image, VectorI const& pos1, VectorI const& pos2, int32 width, Color color)
{
  if(pos1.size() != 2 || pos2.size() != 2)
    BOOST_THROW_EXCEPTION(ArgumentException("Expected two-dimensional vectors as positions"));
  if(width <= 0)
    BOOST_THROW_EXCEPTION(ArgumentException("Invalid size"));
  if(typeid(image) == typeid(CameraImage))
    BOOST_THROW_EXCEPTION(ArgumentException("Can't write to CameraImages"));
  if(color.isGrayscale())
    color.convertToRGB();
    
  cvLine(image.image, cvPoint(pos1[0], pos1[1]), cvPoint(pos2[0], pos2[1]), CV_RGB(color[Color::RED], color[Color::GREEN], color[Color::BLUE]), width);
}


void Drawing::drawRect(ImageBase& image, Rect const& rect, Color color, int thickness)
{
  if(typeid(image) == typeid(CameraImage))
    BOOST_THROW_EXCEPTION(ArgumentException("Can't write to CameraImages"));
  if(color.isGrayscale())
    color.convertToRGB();

  cvRectangle(image.image, cvPoint(rect.x, rect.y), cvPoint(rect.x+rect.w, rect.y+rect.h), CV_RGB(color[Color::RED], color[Color::GREEN], color[Color::BLUE]), thickness);
}

/**
* Function draws a Circle into an image. Default thickness=1
*/
void Drawing::drawCircle(ImageBase &image, Vector const& pos, int32 const radius, Color &color, int thickness){
  if(pos.size() != 2)
    BOOST_THROW_EXCEPTION(ArgumentException("Expected two-dimensional vectors as positions"));
  if(typeid(image) == typeid(CameraImage))
    BOOST_THROW_EXCEPTION(ArgumentException("Can't write to CameraImages"));
  if(radius <= 0)
    BOOST_THROW_EXCEPTION(ArgumentException("Invalid radius"));
  if(color.isGrayscale())
    color.convertToRGB();

  cvCircle(image.image, cvPoint((int)pos[0], (int)pos[1]), radius, CV_RGB(color[Color::RED], color[Color::GREEN], color[Color::BLUE]), thickness);

}

void Drawing::drawArrow(ImageBase& image, VectorI const& pos1, VectorI const& pos2, int32 width, Color color)
{
  if(pos1.size() != 2 || pos2.size() != 2)
    BOOST_THROW_EXCEPTION(ArgumentException("Expected two-dimensional vectors as positions"));
  if(width <= 0)
    BOOST_THROW_EXCEPTION(ArgumentException("Invalid size"));
  if(typeid(image) == typeid(CameraImage))
    BOOST_THROW_EXCEPTION(ArgumentException("Can't write to CameraImages"));
  if(color.isGrayscale())
    color.convertToRGB();
    
  cvLine(image.image, cvPoint(pos1[0], pos1[1]), cvPoint(pos2[0], pos2[1]), CV_RGB(color[Color::RED], color[Color::GREEN], color[Color::BLUE]), width);


  double angle;		angle = atan2( (double) pos1[1] - pos2[1], (double) pos1[0] - pos2[0] );

  VectorI apex = pos1;
  uint32 apex_length = (uint32) (Maths::distance(pos1, pos2) / 2);

  apex[0] = (int) (pos2[0] + apex_length * cos(angle + M_PI / 8));
	apex[1] = (int) (pos2[1] + apex_length * sin(angle + M_PI / 8));
	cvLine(image.image, cvPoint(apex[0], apex[1]), cvPoint(pos2[0], pos2[1]), CV_RGB(color[Color::RED], color[Color::GREEN], color[Color::BLUE]), width);

  apex[0] = (int) (pos2[0] + apex_length * cos(angle - M_PI / 8));
	apex[1] = (int) (pos2[1] + apex_length * sin(angle - M_PI / 8));
	cvLine(image.image, cvPoint(apex[0], apex[1]), cvPoint(pos2[0], pos2[1]), CV_RGB(color[Color::RED], color[Color::GREEN], color[Color::BLUE]), width);
}


/**
* Function draws a Dot into an image.
*/
void Drawing::drawDot(ImageBase &image, Vector const& pos, int32 const radius, Color &color){
  if(pos.size() != 2)
    BOOST_THROW_EXCEPTION(ArgumentException("Expected two-dimensional vectors as positions"));
  if(typeid(image) == typeid(CameraImage))
    BOOST_THROW_EXCEPTION(ArgumentException("Can't write to CameraImages"));
  if(radius <= 0)
    BOOST_THROW_EXCEPTION(ArgumentException("Invalid radius"));
  if(color.isGrayscale())
    color.convertToRGB();

  cvCircle(image.image, cvPoint((int)pos[0], (int)pos[1]), radius, CV_RGB(color[Color::RED], color[Color::GREEN], color[Color::BLUE]), -1);
}


/**
* Function draws a Text into an image. Default size=1.0f, font_face=CV_FONT_HERSHEY_SIMPLEX
* Possible Font Faces are:
* CV_FONT_HERSHEY_SIMPLEX - normal size sans-serif font
* CV_FONT_HERSHEY_PLAIN - small size sans-serif font
* CV_FONT_HERSHEY_DUPLEX - normal size sans-serif font (more complex than CV_FONT_HERSHEY_SIMPLEX)
* CV_FONT_HERSHEY_COMPLEX - normal size serif font
* CV_FONT_HERSHEY_TRIPLEX - normal size serif font (more complex than CV_FONT_HERSHEY_COMPLEX)
* CV_FONT_HERSHEY_COMPLEX_SMALL - smaller version of CV_FONT_HERSHEY_COMPLEX
* CV_FONT_HERSHEY_SCRIPT_SIMPLEX - hand-writing style font
* CV_FONT_HERSHEY_SCRIPT_COMPLEX - more complex variant of CV_FONT_HERSHEY_SCRIPT_SIMPLEX
*/
void Drawing::drawText(ImageBase &image, Vector const& pos, char const* text, Color &color, float const size, int font_face){
  if(pos.size() != 2)
    BOOST_THROW_EXCEPTION(ArgumentException("Expected two-dimensional vectors as positions"));
  if(typeid(image) == typeid(CameraImage))
    BOOST_THROW_EXCEPTION(ArgumentException("Can't write to CameraImages"));
  if(color.isGrayscale())
    color.convertToRGB();

  CvFont font;
  cvInitFont(&font, font_face, size, size);
  cvPutText(image.image, text, cvPoint((int)pos[0], (int)pos[1]), &font, CV_RGB(color[Color::RED], color[Color::GREEN], color[Color::BLUE]));
}


/**
* Function draws a Number into an image. Default size=1.0f, font_face=CV_FONT_HERSHEY_SIMPLEX
* Possible Font Faces are:
* CV_FONT_HERSHEY_SIMPLEX - normal size sans-serif font
* CV_FONT_HERSHEY_PLAIN - small size sans-serif font
* CV_FONT_HERSHEY_DUPLEX - normal size sans-serif font (more complex than CV_FONT_HERSHEY_SIMPLEX)
* CV_FONT_HERSHEY_COMPLEX - normal size serif font
* CV_FONT_HERSHEY_TRIPLEX - normal size serif font (more complex than CV_FONT_HERSHEY_COMPLEX)
* CV_FONT_HERSHEY_COMPLEX_SMALL - smaller version of CV_FONT_HERSHEY_COMPLEX
* CV_FONT_HERSHEY_SCRIPT_SIMPLEX - hand-writing style font
* CV_FONT_HERSHEY_SCRIPT_COMPLEX - more complex variant of CV_FONT_HERSHEY_SCRIPT_SIMPLEX
*/
void Drawing::drawNumber(ImageBase &image, Vector const& pos, int const number, Color &color, float const size, int font_face){
  std::string s = Maths::toString<int>(number);
  char const* text = s.c_str();

  Drawing::drawText(image,pos, text,color,size,font_face);
}


void Drawing::arrayToImage(ImageBase& image, std::vector<double> const& array)
{
  uint32 imgWidth = image.width();
  double max = -INFINITY;
  for (uint32 i=0; i<array.size(); ++i)
    if (array[i] > max)
      max = array[i];

  for (uint32 x=0; x<imgWidth; ++x)
    {
      uint32 bin = x / (double)imgWidth * array.size();
      int32 value = array[bin] / max * (image.height()-1);
      Drawing::drawLine(image, Vector2D::create(x, 0), Vector2D::create(x, (int32)image.height()-1), 1, Color(255));
      Drawing::drawLine(image, Vector2D::create(x, (int32)image.height()-1), Vector2D::create(x, (int32)image.height()-value-1), 1, Color(0));
    }
}

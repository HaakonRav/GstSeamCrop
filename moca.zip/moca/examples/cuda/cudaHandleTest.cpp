#define BOOST_TEST_DYN_LINK
#include <boost/test/unit_test.hpp>
#include "cudaHDR/KernelFunctions.h"
#include "cudaHDR/Cuda2DPitchedMemoryHandle.h"
#include "cudaHDR/CudaImageHandle.h"
#include "cudaHDR/CudaImage8UHandle.h"
#include "cudaHDR/CudaImage32FHandle.h"
#include "cudaHDR/CudaExposureHandle.h"
#include "types/Image8U.h"
#include "types/Exposure.h"
#include "types/MocaException.h"
#include "io/ImageFileReader.h"
#include "io/ImageFileWriter.h"
#include "testcases.h"

BOOST_AUTO_TEST_SUITE(CudaImageHandleTest)

BOOST_AUTO_TEST_CASE(cuda2DPitchedMemorySimpleConstructorTest)
{
	//Do simple constructor test
	Cuda2DPitchedMemoryHandle<float> handle;

	//Get data descriptor and do some checks
	BOOST_CHECK_THROW(handle.getDataDescPtr(), MocaException);
}

BOOST_AUTO_TEST_CASE(cuda2DPitchedAllocationFreeTest)
{
	//Do simple constructor test
	Cuda2DPitchedMemoryHandle<float> handle;

	//Allocate Memory
	handle.allocate(640, 480);
	const Cuda2DPitchedMemoryDataDescriptor<float> desc1 = *(handle.getDataDescPtr());
	BOOST_CHECK(desc1.d_pointer != NULL);
	BOOST_CHECK(desc1.d_width == 2560);
	BOOST_CHECK(desc1.d_height == 480);

	//Reallocate Memory, changed height only
	handle.allocate(640, 320);
	const Cuda2DPitchedMemoryDataDescriptor<float> desc2 = *(handle.getDataDescPtr());
	BOOST_CHECK(desc2.d_pointer == desc1.d_pointer);
	BOOST_CHECK(desc2.d_width == 2560);
	BOOST_CHECK(desc2.d_height == 320);

	//Reallocate changed width
	handle.allocate(680, 320);
	const Cuda2DPitchedMemoryDataDescriptor<float> desc3 = *(handle.getDataDescPtr());
	
	//Should be inequal, but is not a mandatory, depending on the hardware, so only a warning here
	BOOST_WARN(desc3.d_pointer != desc2.d_pointer);
	BOOST_CHECK(desc3.d_width == 2720);
	BOOST_CHECK(desc3.d_height == 320);

	//Free memory
	handle.free();
	BOOST_CHECK_THROW(handle.getDataDescPtr(), MocaException);
}

BOOST_AUTO_TEST_CASE(cuda2DPitchedMemoryPutTest)
{
	//Simple constructor test
	Cuda2DPitchedMemoryHandle<unsigned int> handle;

	//Allocate an array
	unsigned int arr[100] = {0};
	arr[45] = 134;
	unsigned int arrcopy[100] = {0};

	//Upload to device
	handle.put(arr, 10, 10, 10);
	handle.getData(arrcopy, 10);

	//Do some checks
	BOOST_CHECK(arrcopy[45] == 134);
}

BOOST_AUTO_TEST_CASE(cuda2DPitchedMemoryCopyCtorTest)
{
	//Simple constructor test
	Cuda2DPitchedMemoryHandle<unsigned int> handle;

	//Allocate an array
	unsigned int arr[100] = {0};
	arr[45] = 134;
	unsigned int arrcopy[100] = {0};

	//Upload to device
	handle.put(arr, 10, 10, 10);

	//Copy handle
	Cuda2DPitchedMemoryHandle<unsigned int> handlecopy(handle);
	handlecopy.getData(arrcopy, 10);

	//Do some checks
	BOOST_CHECK(arrcopy[45] == 134);
}

BOOST_AUTO_TEST_CASE(cuda2DPitchedMemoryAssignmentTest)
{
	//Simple constructor test
	Cuda2DPitchedMemoryHandle<unsigned int> handle;

	//Allocate an array
	unsigned int arr[100] = {0};
	arr[45] = 134;
	unsigned int arrcopy[100] = {0};

	//Upload to device
	handle.put(arr, 10, 10, 10);

	//Copy handle
	Cuda2DPitchedMemoryHandle<unsigned int> handlecopy = handle;
	handlecopy.getData(arrcopy, 10);

	//Do some checks
	BOOST_CHECK(arrcopy[45] == 134);
}

BOOST_AUTO_TEST_CASE(cudaImageAllocationFreeTest)
{
	//Do simple constructor test
	CudaImageHandle<float> handle;

	//Allocate Memory
	handle.allocate(640, 480, 3, 3);
	const CudaImageHandleDataDescriptor<float> desc1 = *(handle.getDataDescPtr());
	BOOST_CHECK(desc1.d_pointer != NULL);
	BOOST_CHECK(desc1.d_width == 7680);
	BOOST_CHECK(desc1.d_height == 480);
	BOOST_CHECK(desc1.channels == 3);
	BOOST_CHECK(desc1.d_stride == 3);

	//Reallocate Memory, changed height only
	handle.allocate(640, 320, 3, 3);
	const CudaImageHandleDataDescriptor<float> desc2 = *(handle.getDataDescPtr());
	BOOST_CHECK(desc2.d_pointer == desc1.d_pointer);
	BOOST_CHECK(desc2.d_width == 7680);
	BOOST_CHECK(desc2.d_height == 320);
	BOOST_CHECK(desc2.channels == 3);
	BOOST_CHECK(desc2.d_stride == 3);

	//Reallocate changed channels and padding
	handle.allocate(680, 320, 4, 5);
	const CudaImageHandleDataDescriptor<float> desc3 = *(handle.getDataDescPtr());
	//Should be inequal, but is not a mandatory, depending on the hardware, so only a warning here
	BOOST_WARN(desc3.d_pointer != desc2.d_pointer);
	BOOST_CHECK(desc3.d_width == 13600);
	BOOST_CHECK(desc3.d_height == 320);
	BOOST_CHECK(desc3.channels == 4);
	BOOST_CHECK(desc3.d_stride == 5);

	//Free memory
	handle.free();
	BOOST_CHECK_THROW(handle.getDataDescPtr(), MocaException);
}

BOOST_AUTO_TEST_CASE(CudaImageHandlePutTest)
{
	//Simple constructor test
	CudaImageHandle<unsigned int> handle;

	//Allocate an array
	unsigned int arr[300] = {0};
	arr[45] = 134;
	unsigned int arrcopy[300] = {0};

	//Upload to device
	handle.put(arr, 10, 10, 10, 3, 3);
	handle.getData(arrcopy, 10);

	//Do some checks
	BOOST_CHECK(arrcopy[45] == 134);
}

BOOST_AUTO_TEST_CASE(CudaImageHandleAssignmentTest)
{
	//Simple constructor test
	CudaImageHandle<unsigned int> handle;

	//Allocate an array
	unsigned int arr[400] = {0};
	arr[45] = 134;
	unsigned int arrcopy[400] = {0};

	//Upload to device
	handle.put(arr, 10, 10, 10, 3, 4);

	//Copy handle
	Cuda2DPitchedMemoryHandle<unsigned int> handlecopy = handle;
	handlecopy.getData(arrcopy, 10);

	//Do some checks
	BOOST_CHECK(arrcopy[45] == 134);
}

BOOST_AUTO_TEST_CASE(cudaImagehandleCopyCtorTest)
{
	//Simple constructor test
	CudaImageHandle<unsigned int> handle;

	//Allocate an array
	unsigned int arr[500] = {0};
	arr[45] = 134;
	unsigned int arrcopy[500] = {0};

	//Upload to device
	handle.put(arr, 10, 10, 10, 3, 5);

	//Copy handle
	CudaImageHandle<unsigned int> handlecopy(handle);
	handlecopy.getData(arrcopy, 10);

	//Do some checks
	BOOST_CHECK(arrcopy[45] == 134);

	//compare descriptors
	BOOST_CHECK(handle.getDataDescPtr()->d_pointer != handlecopy.getDataDescPtr()->d_pointer);
	BOOST_CHECK(handle.getDataDescPtr()->d_width == handlecopy.getDataDescPtr()->d_width);
	BOOST_CHECK(handle.getDataDescPtr()->channels == handlecopy.getDataDescPtr()->channels);
}

BOOST_AUTO_TEST_CASE(cudaImage8UTest)
{
	//simple constructor test
	CudaImage8UHandle handle;

	//load image from hdd
	boost::shared_ptr<Image8U>	srcimg;

	//Read lena test image from hdd
	ImageFileReader ifr(LENA_IMG);
	srcimg = ifr.getImage();

	//Most simple constructor
	handle.put(*srcimg);

	//Check descriptor
	BOOST_CHECK(handle.getDataDescPtr()->d_pointer != NULL);
	BOOST_CHECK(handle.getDataDescPtr()->d_width == 1536);
	BOOST_CHECK(handle.getDataDescPtr()->channels == 3);

	//Copy constructor test
	CudaImage8UHandle handlecopy(handle);

	//Compare constructors
	BOOST_CHECK(handle.getDataDescPtr()->d_pointer != handlecopy.getDataDescPtr()->d_pointer);
	BOOST_CHECK(handlecopy.getDataDescPtr()->d_height == handlecopy.getDataDescPtr()->d_height);
	BOOST_CHECK(handlecopy.getDataDescPtr()->channels == handlecopy.getDataDescPtr()->channels);

	//Assignment operator test
	handlecopy = handle;

	//Compare constructors
	BOOST_CHECK(handle.getDataDescPtr()->d_pointer != handlecopy.getDataDescPtr()->d_pointer);
	BOOST_CHECK(handlecopy.getDataDescPtr()->d_height == handlecopy.getDataDescPtr()->d_height);
	BOOST_CHECK(handlecopy.getDataDescPtr()->channels == handlecopy.getDataDescPtr()->channels);

	//Download into not fitting Image8U
	Image8U testnofit(640, 320, 3);
	BOOST_CHECK_THROW(handlecopy.getImage8UData(testnofit), MocaException);

	//Download into fitting image
	Image8U testfit(512, 512, 3);
	handlecopy.getImage8UData(testfit);

	//Compare pixels
	BOOST_CHECK((*srcimg)(15, 12) == testfit(15, 12));
}

BOOST_AUTO_TEST_CASE(CudaImage32FHandleTest)
{
	//sample image
	Image32F srcimg(640, 480, 3);
	randFillImage(srcimg, 10000.0f, 5000.0f);

	//simple constructor test
	CudaImage32FHandle handle;
	handle.put(srcimg);

	//Check descriptor
	BOOST_CHECK(handle.getDataDescPtr()->d_pointer != NULL);
	BOOST_CHECK(handle.getDataDescPtr()->d_width == 7680);
	BOOST_CHECK(handle.getDataDescPtr()->channels == 3);

	//Copy constructor test
	CudaImage32FHandle handlecopy(handle);

	//Compare constructors
	BOOST_CHECK(handle.getDataDescPtr()->d_pointer != handlecopy.getDataDescPtr()->d_pointer);
	BOOST_CHECK(handlecopy.getDataDescPtr()->d_height == handlecopy.getDataDescPtr()->d_height);
	BOOST_CHECK(handlecopy.getDataDescPtr()->channels == handlecopy.getDataDescPtr()->channels);

	//Assignment operator test
	handlecopy = handle;

	//Compare constructors
	BOOST_CHECK(handle.getDataDescPtr()->d_pointer != handlecopy.getDataDescPtr()->d_pointer);
	BOOST_CHECK(handlecopy.getDataDescPtr()->d_height == handlecopy.getDataDescPtr()->d_height);
	BOOST_CHECK(handlecopy.getDataDescPtr()->channels == handlecopy.getDataDescPtr()->channels);

	//Download into not fitting Image8U
	Image32F testnofit(640, 320, 3);
	BOOST_CHECK_THROW(handlecopy.getImage32FData(testnofit), MocaException);

	//Download into fitting image
	Image32F testfit(640, 480, 3);
	handlecopy.getImage32FData(testfit);

	//Compare pixels
	BOOST_CHECK(compareImage32F(srcimg, testfit) < 1.0f);
}

BOOST_AUTO_TEST_CASE(CudaExposureHandleTest)
{
	//simple constructor test
	CudaExposureHandle handle;

	//load image from hdd
	boost::shared_ptr<Image8U>	srcimg;

	//Read lena test image from hdd
	ImageFileReader ifr(LENA_IMG);
	srcimg = ifr.getImage();

	//Most simple constructor
	handle.put(*srcimg, 12, 12, 0.5f, 0);

	//Check descriptor
	BOOST_CHECK(handle.getDataDescPtr()->d_pointer != NULL);
	BOOST_CHECK(handle.getDataDescPtr()->d_width == 1536);
	BOOST_CHECK(handle.getDataDescPtr()->channels == 3);
	BOOST_CHECK(handle.getDataDescPtr()->x_offset == 12);
	BOOST_CHECK(handle.getDataDescPtr()->shutter == 0.5f);

	//Copy constructor test
	CudaExposureHandle handlecopy(handle);

	//Compare constructors
	BOOST_CHECK(handle.getDataDescPtr()->d_pointer != handlecopy.getDataDescPtr()->d_pointer);
	BOOST_CHECK(handlecopy.getDataDescPtr()->d_height == handlecopy.getDataDescPtr()->d_height);
	BOOST_CHECK(handlecopy.getDataDescPtr()->channels == handlecopy.getDataDescPtr()->channels);
	BOOST_CHECK(handle.getDataDescPtr()->x_offset == handlecopy.getDataDescPtr()->x_offset);
	BOOST_CHECK(handle.getDataDescPtr()->shutter == handlecopy.getDataDescPtr()->shutter);

	//Assignment operator test
	handlecopy = handle;

	//Compare constructors
	BOOST_CHECK(handle.getDataDescPtr()->d_pointer != handlecopy.getDataDescPtr()->d_pointer);
	BOOST_CHECK(handlecopy.getDataDescPtr()->d_height == handlecopy.getDataDescPtr()->d_height);
	BOOST_CHECK(handlecopy.getDataDescPtr()->channels == handlecopy.getDataDescPtr()->channels);
	BOOST_CHECK(handlecopy.getDataDescPtr()->x_offset == handlecopy.getDataDescPtr()->x_offset);
	BOOST_CHECK(handlecopy.getDataDescPtr()->shutter == handlecopy.getDataDescPtr()->shutter);

	//Download into non fitting Image8U
	Image8U testimg(640, 320, 3);
	BOOST_CHECK_THROW(handlecopy.getImage8UData(testimg), MocaException);

	//Download into fitting image
	Image8U testfit(512, 512, 3);
	handlecopy.getImage8UData(testfit);

	//Compare pixels
	BOOST_CHECK((*srcimg)(17, 32) == testfit(17, 32));
}

BOOST_AUTO_TEST_SUITE_END()

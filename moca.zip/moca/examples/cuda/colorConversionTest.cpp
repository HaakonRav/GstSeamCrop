#define BOOST_TEST_DYN_LINK
#include "boost/test/unit_test.hpp"

#include "testcases.h"

#include "cudaHDR/CudaImage8UHandle.h"
#include "cudaHDR/CudaWrapper.h"

#include "io/ImageFileReader.h"
#include "io/ImageFileWriter.h"
#include "types/MocaException.h"
#include "filter/CvtColorSpace.h"

//Initially load needed testdata
struct testDataColConv
{
	//Will be available in every test case
	Image8U srcimg_RGB;
	Image8U srcimg_Yxy;

	//Initialize struct via constructor
	testDataColConv() : srcimg_RGB(640, 480, 3), srcimg_Yxy(640, 480, 3)
	{
		//Load bayer pattern testimage from hdd
		ImageFileReader ifr_RGB(RGB_IMG);
		ImageFileReader ifr_Yxy(Yxy_IMG);
		ifr_RGB.getImage(srcimg_RGB);
		ifr_Yxy.getImage(srcimg_Yxy);
	}
};

BOOST_FIXTURE_TEST_SUITE(colorConversionTestSuite, testDataColConv)

BOOST_AUTO_TEST_CASE(colorConversionTest)
{
	//Perform conversion to Yxy on CPU
	Image8U tgtimg_cpu(640, 480, 3);
	MOCA_TIC(RUNS);
	CvtColorSpace::convert(srcimg_RGB, tgtimg_cpu, COLOR_BGR, COLOR_Yxy);
	MOCA_TOC("Color conversion CPU");
	
	//Perform conversion to Yxy on GPU
	CudaImage8UHandle handle;
	CudaImage8UHandle result;
	handle.put(srcimg_RGB);
	result.allocate(handle.getWidth(), handle.getHeight(), handle.getChannels(), 3);
	MOCA_TIC(RUNS);
	CudaWrapper::BGRYxy(handle, result);
	MOCA_TOC("Color Conversion GPU");
	Image8U tgtimg_gpu(640, 480, 3);
	result.getImage8UData(tgtimg_gpu);

	//Compare results
	BOOST_CHECK(compareImage8U(tgtimg_cpu, tgtimg_gpu) < 10.0f);

	//Perform conversion to RGB on CPU
	CvtColorSpace::convert(tgtimg_cpu, srcimg_RGB, COLOR_Yxy, COLOR_BGR);
	
	//Perform conversion to Yxy on GPU
	CudaWrapper::YxyBGR(result);
	result.getImage8UData(srcimg_Yxy);

	//Compare results
	BOOST_CHECK(compareImage8U(srcimg_RGB, srcimg_Yxy) < 10.0f);
}

BOOST_AUTO_TEST_CASE(ColorConversionTestVaryBoth)
{
	//Crop sourceimg
	Image8U srcimg_RGB_crop(635, 470, 3);
	Image8U srcimg_Yxy_crop(635, 470, 3);
	cropImage8U(srcimg_RGB, srcimg_RGB_crop);
	cropImage8U(srcimg_Yxy, srcimg_Yxy_crop);

	//Perform conversion to Yxy on CPU
	Image8U tgtimg_cpu(635, 470, 3);
	CvtColorSpace::convert(srcimg_RGB_crop, tgtimg_cpu, COLOR_BGR, COLOR_Yxy);
	
	//Perform conversion to Yxy on GPU
	CudaImage8UHandle handle;
	handle.put(srcimg_RGB_crop);
	CudaWrapper::BGRYxy(handle);
	Image8U tgtimg_gpu(635, 470, 3);
	handle.getImage8UData(tgtimg_gpu);

	//Compare results
	BOOST_CHECK(compareImage8U(tgtimg_cpu, tgtimg_gpu) < 10.0f);

	//Perform conversion to Yxy on CPU
	CvtColorSpace::convert(tgtimg_cpu, srcimg_RGB_crop, COLOR_Yxy, COLOR_BGR);
	
	//Perform conversion to Yxy on GPU
	CudaWrapper::YxyBGR(handle);
	handle.getImage8UData(srcimg_Yxy_crop);

	//Compare results
	BOOST_CHECK(compareImage8U(srcimg_RGB_crop, srcimg_Yxy_crop) < 10.0f);
}

BOOST_AUTO_TEST_CASE(colorConversionTestNotInPlace)
{
	//Perform conversion to Yxy on GPU with changed stride
	CudaImage8UHandle srchandle;
	srchandle.put(srcimg_RGB);
	CudaImage8UHandle tgthandle;
	tgthandle.allocate(640, 480, 3, 4);
	CudaWrapper::BGRYxy(srchandle, tgthandle);
	CudaWrapper::YxyBGR(tgthandle, srchandle);
}

BOOST_AUTO_TEST_SUITE_END()
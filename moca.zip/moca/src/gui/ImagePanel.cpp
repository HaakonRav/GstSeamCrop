#include "gui/ImagePanel.h"

#ifdef HAVE_LIBFLTK

#include "gui/DisplayWindow.h"
#include "types/Image8U.h"
#include "io/ImageFileWriter.h"


ImagePanel::ImagePanel(int32 x, int32 y, int32 w, int32 h, const char* title)
  : Fl_Double_Window(x, y, w, h, title)
{
  Fl::visual(FL_DOUBLE|FL_INDEX);
  imgWriter = boost::shared_ptr<ImageFileWriter>(new ImageFileWriter("image", "png"));
}


void ImagePanel::draw()
{
  if (image == 0)
    return;
  
  int32 spaceWidth = w();
  int32 spaceHeight = h();
  int32 imageWidth = image->width();
  int32 imageHeight = image->height();
  int32 drawWidth = (imageWidth < spaceWidth ? imageWidth : spaceWidth);
  int32 drawHeight = (imageHeight < spaceHeight ? imageHeight : spaceHeight);
  
  if(drawWidth != spaceWidth || drawHeight != spaceHeight)
    fl_draw_box(FL_FLAT_BOX, 0, 0, spaceWidth, spaceHeight, FL_BACKGROUND_COLOR);

  fl_draw_image(drawRGB, this, 0, 0, drawWidth, drawHeight);
  
  fl_color(0, 128, 255);
  if (leftButton)
    fl_line(rectL.x, rectL.y, rectL.w, rectL.h);
  if (rightButton)
  {
    Rect rect(rectR);
    if(rect.w < 0)
    {
      rect.w = abs(rect.w);
      rect.x -= rect.w;
    }
    if(rect.h < 0)
    {
      rect.h = abs(rect.h);
      rect.y -= rect.h;
    }
    fl_rect(rect.x, rect.y, rect.w, rect.h); // doesn't work with negative width and/or height
  }
}


void ImagePanel::showImage(boost::shared_ptr<Image8U const> image)
{
  this->image = image;
  this->redraw();
}


void ImagePanel::captureImage()
{
  imgWriter->start();
  imgWriter->putImage(*image);
  imgWriter->stop();
}


int32 ImagePanel::handle(int32 event)
{
  DisplayWindow *mainWindow = (DisplayWindow *)parent();
  int32 offsetX = mainWindow->hScrollbar->value();
  int32 offsetY = mainWindow->vScrollbar->value();
  int32 x = Fl::event_x();
  int32 y = Fl::event_y();
  int32 button = Fl::event_button();

  if(image != 0 && (x+offsetX > int32(image->width()) || y+offsetY > int32(image->height())))
  {
    switch(event)
    {
    case FL_PUSH:
      leftButton = rightButton = false;
    case FL_DRAG:
      return 1;
    }
  }
  
  switch(event)
    {
    case FL_PUSH:
      {
	if (button == 1)
	  {
	    leftButton = true;
	    rectL.x = x;
	    rectL.w = x;
	    rectL.y = y;
	    rectL.h = y;
	  }
	if (button == 3)
	  {
	    rightButton = true;
	    rectR.x = x;
	    rectR.w = 0;
	    rectR.y = y;
	    rectR.h = 0;
	  }
	break;
      }
    case FL_RELEASE:
      {
	if (button == 1 && leftButton)
	  {
	    leftButton = false;
	    
	    VectorI p1(2), p2(2);
            p1(0) = rectL.x+offsetX; p1(1) = rectL.y+offsetY;
	    p2(0) = rectL.w+offsetX; p2(1) = rectL.h+offsetY;

	    if(p1(0) == p2(0) && p1(1) == p2(1))
	      mainWindow->clickedPoint(p1);
	    else
              mainWindow->clickedLine(p1, p2);
	  }
	if (button == 3 && rightButton)
	  {
	    rightButton = false;

	    Rect rect(rectR);
	    rect.x += offsetX;
	    rect.y += offsetY;
	    
	    if(rect.w < 0)
	    {
	      rect.w = abs(rect.w);
	      rect.x -= rect.w;
	    }
	    if(rect.h < 0)
	    {
	      rect.h = abs(rect.h);
	      rect.y -= rect.h;
	    }
	    // the width and height of rect is now always non-negative
	    
	    mainWindow->clickedRect(rect);
	  }
      }
    case FL_DRAG:
      {
	if (button == 1)
	  {
	    rectL.w = x;
	    rectL.h = y;
	  }
	if (button == 3)
	  {
	    rectR.w = x-rectR.x;
	    rectR.h = y-rectR.y;
	  }
	break;
      }
    default: return Fl_Double_Window::handle(event);
    }

  return 1;
}


void ImagePanel::drawRGB(void* panel, int32 x, int32 y, int32 w, uint8* dst)
{
  ImagePanel* _panel = (ImagePanel*)panel;
  boost::shared_ptr<const Image8U>& image = _panel->image;
  DisplayWindow* mainWindow = (DisplayWindow*)_panel->parent();
  int channels = image->channels();

  uint8 const* ptr = image->ptr();
  ptr += (mainWindow->hScrollbar->value() + x) * channels;
  ptr += (mainWindow->vScrollbar->value() + y) * image->widthStep();

  for(int32 pixel = 0; pixel < w; pixel++)
  {
    int32 pos = pixel * channels;
    for (int32 i=0; i<3; ++i)
      dst[pixel*3+i] = channels == 3 ? ptr[pos+2-i] : ptr[pos];
  }
}


#endif // HAVE_LIBFLTK

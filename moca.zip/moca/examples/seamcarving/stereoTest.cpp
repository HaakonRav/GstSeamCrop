
// MOCA headers 
#include "types/MocaTypes.h"
#include "types/Image8U.h"
#include "types/MocaException.h"
#include "io/IO.h"
#include "io/VideoReader.h"
#include "io/VideoWriter.h"
#include "tools/Timing.h"
#include "filter/SeamCarvingImage.h"
#include "filter/Filter.h"
#include "filter/FrequencyTunedSaliency.h"
 
// C++ headers 
#include <string>
using namespace std;

#if 0
static void printImage32F(string const& destPath, Image32F const& frame)
{
    uint32 width = frame.width();
    uint32 height = frame.height();
    Image8U print(width, height,1);
    
    float max = 0;
    float min = 1000;
    for (uint32 x = 0; x < width; x++) 
      for (uint32 y = 0; y < height; y++)
      {
	if(frame(x,y) < min)
	 min = frame(x,y);
	 
	if(frame(x,y) > max)
	 max = frame(x,y);
      }
    
    
    cout << "PRINT min = " << min << ", max = " << max << endl;
    float v = 0;
    float factor = 255.0/(max - min);
    //if(factor > 10.0) 
	//factor = 10.0;
    
    for (uint32 x = 0; x < width; x++) 
      for (uint32 y = 0; y < height; y++)
      {
	v = frame(x,y);
	v -= min;
	v *= factor;
	print(x,y) = (int) ( v + 0.5);
      }
	
    try
      {
	    cerr << "save energy image" << endl; 
    	    IO::saveImage(destPath, print); 
      } 
    catch (MocaException e) 
      {
	    std::cout << "save Image error: " << e.what() << std::endl;
	    exit (-1);
   }    
}
#endif


#if 0
// load the frames of the video in a deque list
static void loadVideo(string const& videoPath, deque<Image8U>& video)
{
  VideoReader reader(videoPath);
  reader.start();
  Image8U frame(reader.getImageWidth(), reader.getImageHeight(), 3);
  
  while(!reader.getEndOfVideo()) 
    {
      reader.getImage(frame); 
      video.push_back(frame);
    }
    
  reader.stop();  
}
#endif

static void extractViews(Image8U const& frame, Image8U& left, Image8U& right)
{
  Filter::copyImage(frame, left, Rect(0, 0, left.width(), left.height()),Vector2D::create(0, 0));
  Filter::copyImage(frame, right, Rect(left.width(), 0, right.width(),right.height()), Vector2D::create(0, 0)); 
  /*
  try 
  {
    cerr << "save frames" << endl;     
    IO::saveImage("/home/stud/kiess/Videos/3D_Stereo_Videos/left.png", left); 
    IO::saveImage("/home/stud/kiess/Videos/3D_Stereo_Videos/right.png", right);
  } 
  catch (MocaException e) 
  {
    cout << "save Image error: " << e.what() << endl;
    exit (-1);
  } 
  */
}

#if 0
static void drawSeamsStereo(Image8U const& left, Image32F const& seamsLeft, Image8U const& right, Image32F const& seamsRight, int const& width)
{
  int height = left.height();
  int channels = left.channels();
  int countLeft = 0;
  int countRight = 0;
  
  Image8U drawLeft(width, height, channels);
  Image8U drawRight(width, height, channels);

  for (int y = 0; y < height; y++) // Changes the color of each seam pixel
      for(int x = 0; x < width; x++)
      {
          if(seamsLeft(x,y) < 1) // normally, seams are -1!!!
            for(int c = 0; c < channels; c++)
		drawLeft(x,y,c) = left(x,y,c);
          else
	      {
	        drawLeft(x,y,0) = 0;
		drawLeft(x,y,1) = 0;
		drawLeft(x,y,2) = 255;
		countLeft++;
		//cout << seamsLeft(x,y) << " ";
	      }
	      
	  if(seamsRight(x,y) < 1)
          for(int c = 0; c < channels; c++)
		drawRight(x,y,c) = right(x,y,c);
          else
	      {
	        drawRight(x,y,0) = 0;
		drawRight(x,y,1) = 0;
		drawRight(x,y,2) = 255;
		countRight++;
	      }
	      
      }
      
//   cout << "countLeft = " << countLeft/height << ", countRight = " << countRight/height << endl;
	  
// ----------------------------------------------------
// Debug -> direct saving to disk
// ----------------------------------------------------
  try 
    {
      //cerr << "draw seams and save images" << endl;        
      IO::saveImage("/home/stud/kiess/Videos/3D_Stereo_Videos/drawLeft.png", drawLeft);
      IO::saveImage("/home/stud/kiess/Videos/3D_Stereo_Videos/drawRight.png", drawRight);
    } 
  catch (MocaException e) 
    {
      cout << "save Image error: " << e.what() << endl;
      exit (-1);
    }  
// ----------------------------------------------------
}


//computes the saliency based on a method from the Feature class
static void computeSaliency(Image8U const& frame, Image32F& saliency, int const& width)
{
//   uint32 width = saliency.width();
  int height = frame.height();
  // int channels = frame.channels();
  
  //set tmp images (used because image size is not changed in other methods, only x indice)
  Image8U tmpFrame(width, height, 3);
  Image32F tmpSaliency(width, height, 1);
  Image32F tmpGradient(width, height, 1);
  
//   for(int x = 0; x < width; x++)
//     for(int y = 0; y < height; y++)
//       for(int z = 0; z < channels; z++)
// 	tmpFrame(x,y,z) = frame(x,y,z);
      
  SeamCarvingImage::copyWidth(frame, tmpFrame, width);
  
  //use method from Feature to compute saliency
  FrequencyTunedSaliency freqSal;
  freqSal.calculate(tmpFrame, tmpSaliency);
  SeamCarvingImage::computeEnergy(frame, tmpGradient, width);
  
  
  
  //copy values into saliency (Image8U -> Image32F) 
  for(int x = 0; x < width; x++)
    for(int y = 0; y < height; y++)
      saliency(x,y) = 1*tmpSaliency(x,y) + 4*tmpGradient(x,y);
    
}
#endif



static void addTemporalMatchingCost(Image8U const& frame, Image8U const& prevLeftFrame, Image32F const& energy, Image32F& tmpEnergy, Image32F const& seamsLastFrame, uint32 const& seamID)
{
  int width = frame.width();
  int height = frame.height();
  
  Image32F temporalMatchingCost(width, height,1);
//   int prevSeamPos = 0;
  
#if 1
  int seamPos = 0;
  
  for(int y = 0; y < height; y++)
  {
    seamPos = seamsLastFrame(seamID,y);
    for(int i = 0; i < width; i++)
    {
	temporalMatchingCost(i,y) = 2*abs(prevLeftFrame(seamPos,y,0) - frame(i,y,0) + prevLeftFrame(seamPos,y,1) - frame(i,y,1) + prevLeftFrame(seamPos,y,2) - frame(i,y,2)) + 10*abs(seamPos-i);
    }
  }
	
  for (int x = 0; x < width; x++) 
      for (int y = 0; y < height; y++)
      {
	tmpEnergy(x,y) = 1*energy(x,y) + 1*temporalMatchingCost(x,y);
// 	cout << "tmpEnergy = " << tmpEnergy(x,y) << ", energy = " << energy(x,y) << ", temporalMatchingCost = " << temporalMatchingCost(x,y) << endl; 
      }
  //printImage32F("/home/stud/kiess/Videos/3D_Stereo_Videos/tempMatching.png", temporalMatchingCost);
#endif


#if 0	
  float tmpCosts = 0;
  int channels = frame.channels();
  
  for(int y=0; y < height; y++)
  {
	prevSeamPos = seamsLastFrame(seamID,y);
	temporalMatchingCost(prevSeamPos, y) = 0;
	
	// go from previous seam pixel to the left side, recursively calculate costs for each pixel to be removed 
	for(int l = prevSeamPos-1; l > -1; l--)
	{
	    tmpCosts = 0;
	    for(int c = 0; c < channels; c++)
		tmpCosts += sqrt( frame(l,y,c) - frame(l+1, y,c) )*( frame(l,y,c) - frame(l+1, y,c) );
	    
	    temporalMatchingCost(l,y) = temporalMatchingCost(l+1,y) + (int) (tmpCosts + 0.5);
	}
	    
	// go from seam pixel to the right side
	for(int r = prevSeamPos+1; r < width; r++)
	{
	    tmpCosts = 0;
	    for(int c = 0; c < channels; c++)
		tmpCosts += sqrt( frame(r,y,c) - frame(r-1, y,c) ) * ( frame(r,y,c) - frame(r-1, y,c) );
	    
	    temporalMatchingCost(r,y) = temporalMatchingCost(r-1,y) + (int) (tmpCosts + 0.5);
	}  
  }
  
  //normalize32F(temporalCoherenceCost);
  
  for (int x = 0; x < width; x++) 
      for (uint32 y = 0; y < height; y++)
	tmpEnergy(x,y) = energy(x,y) + 3*temporalMatchingCost(x,y);
#endif

#if 0
  for(int y=0; y < height; y++)
  {
	prevSeamPos = seamsLastFrame(seamID,y);
	temporalCoherenceCost(prevSeamPos, y) = 0;
	
	// go from previous seam pixel to the left side, recursively calculate costs for each pixel to be removed 
	for(int l = prevSeamPos-1; l > -1; l--)
	{
	    temporalCoherenceCost(l,y) = 15*(prevSeamPos-l) > 1500 ? 1500 : 11*(prevSeamPos-l); // 15, Grenze 300
	}
	    
	// go from seam pixel to the right side
	for(int r = prevSeamPos+1; r < width; r++)
	{
	    temporalCoherenceCost(r,y) = 15*(r-prevSeamPos) > 1500 ? 1500 : 11*(r-prevSeamPos);
	}  
  }
    
  for (int x = 0; x < width; x++) 
      for (int y = 0; y < height; y++)
	tmpEnergy(x,y) = 3*energy(x,y) + temporalCoherenceCost(x,y); // 1*energy+ 1*temp
      
#endif
	
}


// change to SeamCarvingImage: no forward energy is used.
static void computeCostWidth(Image8U const& image, Image32F const& energy, Image32F& costWidth, Image32F& predecessors, int const& width)
{
  int height = energy.height();
  
  unsigned int v1 = 0; // predecessor (x-1, y-1)
  unsigned int v2 = 0; // predecessor (x, y-1)
  unsigned int v3 = 0; // predecessor (x+1, y-1)

  for (int y = 0; y < height; y++) // find minimum cost of a connected pixel in the previous line and store its x-position in predecessors.
      for (int x = 0; x < width; x++)
          if (y == 0) // top border
              costWidth(x,y) = energy(x,y);
          else if (x == 0) // left border
	    {
              v2 = costWidth(x,y-1) + energy(x,y);
              v3 = costWidth(x+1,y-1) + energy(x,y);
              if(v2 <= v3)
	        {
		  costWidth(x,y) = v2;
		  predecessors(x,y) = x;
		}
	      else 
	        {
		  costWidth(x,y) = v3;
		  predecessors(x,y) = x+1;
		}//if
	    }
	  else if (x == width-1) // right border
	    {
	      v1 = costWidth(x-1,y-1) + energy(x,y);
	      v2 = costWidth(x,y-1) + energy(x,y);
	      if(v2 <= v1)
	        {
		  costWidth(x,y) = v2;
		  predecessors(x,y) = x;
		}
              else
	        {
		  costWidth(x,y) = v1;
		  predecessors(x,y) = x-1;
	        }//if		
	    }
	  else // rest of the matix 
	    {
	      v1 = costWidth(x-1,y-1) + energy(x,y);
	      v2 = costWidth(x,y-1) + energy(x,y);
	      v3 = costWidth(x+1,y-1) + energy(x,y);
	      if((v2 <= v1) && (v2 <= v3))
	        {
		  costWidth(x,y) = v2;
		  predecessors(x,y) = x;
		}
	      else if((v1 <= v2) && (v1 <= v3))
	        {
		  costWidth(x,y) = v1;
		  predecessors(x,y) = x-1;
		}
	      else if((v3 <= v1) && (v3 <= v2))
	        {
		  costWidth(x,y) = v3;
		  predecessors(x,y) = x+1;
		}
	      else
	          BOOST_THROW_EXCEPTION(ArgumentException("One of the image dimensions is not valid."));
	    }// if else (y==0)
}


// change to SeamCarvingImage: Seams are stored in an image that has width = number of seams 
static void markSeamWidth(Image32F& costWidth, Image32F& energy, Image32F const& predecessors, Image32F& seams, int const& seamID, int& width)
{
  int height = costWidth.height();
  int min = costWidth(width-1, height-1); 	// stores the minimum costs.
  int minPosition = width-1; 		   	// stores the x-position of the minumum costs.

  SeamCarvingImage::getMinCostWidth(costWidth, min, minPosition, width);
 
  for(int y = height-1; y > -1; y--) 		// builds the seam backwards beginning in the starting point minPostion and marks the pixels
    {   
      seams(seamID,y) = minPosition;     	// the x-position of the seam is stored in the seam array at the seamID position in line y
      energy(minPosition,y) = 999999;		// high value prevents next iterations to pick the same pixel.
      minPosition = predecessors(minPosition,y);// get x-position of minimum cost pixel in line y-1.
    }//for
    
}


// change to SeamCarvingImage: method had to be adapted to new seam data -> array with width = number of seams
static void removeSeamsWidth(Image8U& image, Image32F const& seams, int const& seamID, int const& width)
{
  int height = image.height();
  int channels = image.channels();

  for (int y = 0; y < height; y++) 
      for(int x = seams(seamID, y); x < width-1; x++)
          for(int c = 0; c < channels; c++)
                  image(x,y,c) = image (x+1,y,c);
}


#if 0
static void checkMissingSeams(Image32F const& seamsLeft, Image32F const& seamsRight, int const& seamID, int const& width)
{
  int height = seamsLeft.height();
  bool all = true;
  bool linesLeft = false;
  bool linesRight = false;
  bool missingLeft = false;
  bool missingRight = false;
  
  for(int y = 0; y < height; y++)
  {
    for(int x = 0; x < width; x++)
    {
      if(seamsLeft(x,y) == seamID) linesLeft = true;
      if(seamsRight(x,y) == seamID) linesRight = true;
    }
    
    if(!linesLeft)
    {
      all = false;
      missingLeft = true;
//       cout << "Missing LEFT " << seamID << ", line " << y << endl;
    } 
    if(!linesRight)
    {
      all = false;
      missingRight = true;
//       cout << "Missing RIGHT " << seamID << ", line " << y << endl;
    }
    
    linesLeft = false;
    linesRight = false;
  }
  
  if(!all) 
  {
    if(missingLeft) cout << "LEFT ";
    if(missingRight) cout << "RIGHT ";
    cout << "Missing: " << seamID << endl;
  }
}

#endif

//############################ START
static void calculateTransferEnergyRight(Image8U const& left, Image32F const& seamsLeft, Image8U const& right, Image32F const& seamsRight, Image32F& energyRight, int const& seamID, int const& width)
{
  int height = left.height();
  int seamPos = 0;

  for(int y = 0; y < height; y++)
  {
    seamPos = seamsLeft(seamID,y);
    for(int i = 0; i < width; i++)
	energyRight(i,y) = 7*(abs(left(seamPos,y,0) - right(i,y,0) + left(seamPos,y,1) - right(i,y,1) + left(seamPos,y,2) - right(i,y,2)));
  }
}


static void transferSeamsEnergy(Image8U const& left, Image32F const& seamsLeft, Image8U const& right, Image32F& seamsRight, int const& seamID, int& width)
{
  int height = left.height();
  
  Image32F energyGradient(width, height);
  Image32F energyRight(width, height);
  Image32F costWidthRight(width, height); 	// stores the minimum summed up energy values for each position
  Image32F predecessorsRight(width, height); 	// stores the x-position of the optimal predecessor for each position
  
  SeamCarvingImage::clearImage(seamsRight);
  SeamCarvingImage::clearImage(energyRight);
  
  SeamCarvingImage::computeEnergy(right, energyGradient, width);
  calculateTransferEnergyRight(left, seamsLeft, right, seamsRight, energyRight, seamID, width);
  
  for (int x = 0; x < width; x++) 
      for (int y = 0; y < height; y++)
	energyRight(x,y) = 3*energyGradient(x,y) + 1*energyRight(x,y);
  
  computeCostWidth(right, energyRight, costWidthRight, predecessorsRight, width);
  markSeamWidth(costWidthRight, energyRight, predecessorsRight, seamsRight, seamID, width);
      
  //printImage32F("/home/stud/kiess/Videos/3D_Stereo_Videos/energyRight.png", energyRight);
}
//############################ END

#if 0
static void transferSeamsPoints(Image8U& left, Image32F const& seamsLeft, Image8U& right, Image32F& seamsRight, int width)
{
  int height = left.height();
  int channels = left.channels();
  
  int minDiff = 100000;
  int minPos = width;
  int tmpValue = 0;
  
  SeamCarvingImage::clearImage(seamsRight);
  
  for (int y = 0; y < height; y++) 
    {
      for(int x = 0; x < width; x++)
          if(seamsLeft(x,y) > 0)
	    {
	      minDiff = 100000;
	      minPos = width;
              
	      for(int i = x; i < width; i++)
	      {
		tmpValue = 0;
		for(int c = 0; c < channels; c++)
		  tmpValue += abs(left(x,y,c) - right(i,y,c)); 
		
		if((tmpValue < minDiff) && (seamsRight(i,y) != -1))
		{
		  minDiff = tmpValue;
		  minPos = i;
		}
	      }
	      
	      for(int i = x; i >=0; i--)
	      {
		tmpValue = 0;
		for(int c = 0; c < channels; c++)
		  tmpValue += abs(left(x,y,c) - right(i,y,c)); 
		
		if((tmpValue < minDiff) && (seamsRight(i,y) != -1))
		{
		  minDiff = tmpValue;
		  minPos = i;
		}
	      }
	      
	      seamsRight(minPos,y) = 1;
	      
            }//if
    }//for y
    
}
#endif

static void calculateSeams(Image8U left, Image8U& resultLeft, Image8U right, Image8U& resultRight, Image32F& seamsLastFrame, Image8U const& prevLeftFrame, int const& t, int const& targetWidth)
{
  int width  = left.width();
  int height = left.height();
  int seamsWidth = abs(width - targetWidth); // Number of seams to be removed.
  int seamID = 0;
  
  Image32F energy(width, height); 		// stores the gradient-based energy values
  Image32F costWidth(width, height); 		// stores the minimum summed up energy values for each position
  Image32F predecessors(width, height); 	// stores the x-position of the optimal predecessor for each position
  Image32F seamsLeft(seamsWidth, height);
  Image32F seamsRight(seamsWidth, height); 
  Image32F tmpEnergy(width, height);
  
  SeamCarvingImage::clearImage(seamsLeft);
  SeamCarvingImage::clearImage(tmpEnergy);
  
  for(int x = width; x > targetWidth-1; x--)
    {
      SeamCarvingImage::computeEnergy(left, energy, x);
      //computeSaliency(left, energy, x);
      tmpEnergy = energy;
      
      if(t > 0)
	addTemporalMatchingCost(left, prevLeftFrame, energy, tmpEnergy, seamsLastFrame, seamID);
	
      SeamCarvingImage::computeCostWidth(left, tmpEnergy, costWidth, predecessors, x);
      markSeamWidth(costWidth, energy, predecessors, seamsLeft, seamID, x);
      
      transferSeamsEnergy(left, seamsLeft, right, seamsRight, seamID, x); 
  
      removeSeamsWidth(left, seamsLeft, seamID, x);
      removeSeamsWidth(right, seamsRight, seamID, x);
      seamID++;
    }// for
        
  //drawSeamsStereo(tmpImageLeft, seamsLeft, tmpImageRight, seamsRight, width);
  
  SeamCarvingImage::clearImage(seamsLastFrame);
  seamsLastFrame = seamsLeft;
  SeamCarvingImage::copyWidth(left, resultLeft, targetWidth);
  SeamCarvingImage::copyWidth(right, resultRight, targetWidth);
  
#if 0
  try 
    {
      std::cerr << "save images" << std::endl;        
      IO::saveImage("/home/stud/kiess/Videos/3D_Stereo_Videos/resultLeft.png", resultLeft);
      IO::saveImage("/home/stud/kiess/Videos/3D_Stereo_Videos/resultRight.png", resultRight);
    } 
  catch (MocaException e) 
    {
      std::cout << "save Image error: " << e.what() << std::endl;
      exit (-1);
    }  
#endif
}


static void combineLeftAndRightView(Image8U const& left, Image8U const& right, Image8U& resultFrame)
{
  Filter::copyImage(left, resultFrame, Rect(0, 0, left.width(),left.height()), Vector2D::create(0, 0));
  Filter::copyImage(right, resultFrame, Rect(0, 0, right.width(),right.height()), Vector2D::create(left.width(), 0)); 
}


static void saveVideo(deque<Image8U>& resultVideo, string const& destPath, int const& targetWidth)
{
  deque<Image8U>::iterator it = resultVideo.begin();  
  VideoWriter writer(destPath, targetWidth*2, it->height());
  writer.start();
      
  while (it != resultVideo.end())
  {
    writer.putImage(*it); 
    it++;
  }

  writer.stop();
}


void static processVideo(string const& srcPath, string const& destPath, double const retargetFactor)
{
  VideoReader reader(srcPath);
  reader.start();
  
  int fullWidth = reader.getImageWidth();
  int height = reader.getImageHeight();
  int channels = 3;
  int width = fullWidth/2;
  int targetWidth = (int)(width*retargetFactor);
  int seamsWidth = abs(width - targetWidth); // Number of seams to be removed.
  int t = 0;
  
  Image8U frame(fullWidth, height, channels);
  Image8U left(width, height, channels);
  Image8U right(width, height, channels);
  
  Image8U prevLeftFrame(width, height, channels); //the previous left frame
  Image32F seamsLastFrame(seamsWidth, height); //seams from the previous left frame
  SeamCarvingImage::clearImage(seamsLastFrame);
  
  Image8U resultFrame(targetWidth*2, height, channels);
  Image8U resultLeft(targetWidth, height, channels);
  Image8U resultRight(targetWidth, height, channels);
  deque<Image8U> resultVideo;
  
  cout << "Width: original = " << fullWidth << ", half = " << width <<", target size: " << targetWidth << "x" << height << endl;
  
  cout << "Processing"; 
  while(!reader.getEndOfVideo()) 
    {
      cout << " . " << t << endl;
      reader.getImage(frame); 
      extractViews(frame, left, right);
      calculateSeams(left, resultLeft, right, resultRight, seamsLastFrame, prevLeftFrame, t, targetWidth);
      combineLeftAndRightView(resultLeft, resultRight, resultFrame);
      resultVideo.push_back(resultFrame);
      prevLeftFrame = left;
      t++;
      
      //if(t>0) exit(0);
    }
    
  reader.stop();  
  saveVideo(resultVideo, destPath, targetWidth);
}



int main(int argc, char **argv)
{
  try 
    {
      Timing::start();
     
      string srcPath = "/home/stud/kiess/Videos/3D_Stereo_Videos/Testsequenzen/balloon_5.mp4";
      string destPath = "/home/stud/kiess/Videos/3D_Stereo_Videos/sc_balloon.avi";
      double retargetFactor = 0.75;
      
      processVideo(srcPath, destPath, retargetFactor);
      
      Timing::stopAndPrint();
    }
  catch(MocaException& e)
    {
      cerr << diagnostic_information(e);
    }
}

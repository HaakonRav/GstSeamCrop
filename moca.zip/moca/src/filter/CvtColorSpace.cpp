#include "filter/CvtColorSpace.h"

#include "types/MocaException.h"
#include "types/Image32F.h"
#include "types/Image8U.h"

std::map<uint64, int> CvtColorSpace::spaceMap;

#define CONV(src, dst) ((src)+(((uint64)dst)<<32))


void CvtColorSpace::initColorSpaceMap()
{
  if (spaceMap.size() > 0)
    return;
  spaceMap[CONV(COLOR_RGB, COLOR_Y)]   = CV_RGB2GRAY;
  spaceMap[CONV(COLOR_RGB, COLOR_BGR)] = CV_RGB2BGR;
  spaceMap[CONV(COLOR_RGB, COLOR_Luv)] = CV_RGB2Luv;
  spaceMap[CONV(COLOR_RGB, COLOR_HSV)] = CV_RGB2HSV;
  spaceMap[CONV(COLOR_RGB, COLOR_HLS)] = CV_RGB2HLS;

  spaceMap[CONV(COLOR_BGR, COLOR_Y)]   = CV_BGR2GRAY;
  spaceMap[CONV(COLOR_BGR, COLOR_RGB)] = CV_BGR2RGB;
  spaceMap[CONV(COLOR_BGR, COLOR_Luv)] = CV_BGR2Luv;
  spaceMap[CONV(COLOR_BGR, COLOR_HSV)] = CV_BGR2HSV;
  spaceMap[CONV(COLOR_BGR, COLOR_HLS)] = CV_BGR2HLS;

  spaceMap[CONV(COLOR_Y  , COLOR_BGR)] = CV_GRAY2BGR;
  spaceMap[CONV(COLOR_Luv, COLOR_BGR)] = CV_Luv2BGR;
  spaceMap[CONV(COLOR_HSV, COLOR_BGR)] = CV_HSV2BGR;
  spaceMap[CONV(COLOR_HLS, COLOR_BGR)] = CV_HLS2BGR;

  spaceMap[CONV(COLOR_BayerBG, COLOR_BGR)] = CV_BayerBG2BGR;
  spaceMap[CONV(COLOR_BayerRG, COLOR_BGR)] = CV_BayerRG2BGR;
  spaceMap[CONV(COLOR_BayerGB, COLOR_BGR)] = CV_BayerGB2BGR;
  spaceMap[CONV(COLOR_BayerGR, COLOR_BGR)] = CV_BayerGR2BGR;
}


void CvtColorSpace::convert(Image8U const& image, Image8U& result, ColorSpace srcMode, ColorSpace destMode)
{
  if (spaceMap.size() == 0)
    initColorSpaceMap();

  if (image.width() != result.width() || image.height() != result.height() || image.depth() != result.depth())
    BOOST_THROW_EXCEPTION(ArgumentException("Image parameters don't match.") << ErrImg1(image) << ErrImg2(result));
  int destChannels = (destMode == COLOR_Luv8 || destMode == COLOR_Y) ? 1 : 3;
  if (result.channels() != destChannels)
    BOOST_THROW_EXCEPTION(ArgumentException("Result channels don't match.") << ErrImg1(result));
 
  if (srcMode == COLOR_Luv && destMode == COLOR_Luv8)
    cvtLuv_Luv8(image, result);
  else if (srcMode == COLOR_Luv8 && destMode == COLOR_Luv)
    cvtLuv8_Luv(image, result);
  else if (srcMode == COLOR_BGR && destMode == COLOR_Yxy)
    cvtBGR_Yxy(image, result);
  else if (srcMode == COLOR_Yxy && destMode == COLOR_BGR)
    cvtYxy_BGR(image, result);
  else
  {
    if (spaceMap.find(CONV(srcMode, destMode)) == spaceMap.end())
      BOOST_THROW_EXCEPTION(ArgumentException("Conversion between these two modes not implemented.")
                            << ErrInt(srcMode) << ErrInt2(destMode));

    cvCvtColor(image.image, result.image, spaceMap[CONV(srcMode, destMode)]);
    
    if (srcMode == COLOR_BayerBG || srcMode == COLOR_BayerRG || srcMode == COLOR_BayerGB || srcMode == COLOR_BayerGR)
      fixBayerResult(result);
  }
}


void CvtColorSpace::cvtLuv_Luv8(Image8U const& image, Image8U& result)
{
  uint32 const width = image.width();
  uint32 const height = image.height();

  for (uint32 y=0; y<height; ++y)
    for (uint32 x=0; x<width; ++x)
      result(x, y) = (image(x, y, 0) >> 4) + ((image(x,y, 1) & 0xc0) >> 2) + (image(x, y, 2) & 0xc0);
}


void CvtColorSpace::cvtLuv8_Luv(Image8U const& image, Image8U& result)
{
  uint32 const width = image.width();
  uint32 const height = image.height();

  for (uint32 y=0; y<height; ++y)
    for (uint32 x=0; x<width; ++x)
      {
        result(x, y, 0) = ((image(x, y, 0) & 0x0f) << 4) + 8;
        result(x, y, 1) = ((image(x, y, 0) & 0x30) << 2) + 32;
        result(x, y, 2) = ((image(x, y, 0) & 0xc0)     ) + 32;  
      }
}


inline void rgb2YxyMat(double r, double g, double b, double& triY, double& chroX, double& chroY)
{
  double triX = 0.4887180*r + 0.3106803*g + 0.2006017*b;
         triY = 0.1762044*r + 0.8129847*g + 0.0108109*b;
  double triZ = 0.0000000*r + 0.0102048*g + 0.9897952*b;
  double sum = triX + triY + triZ;
  sum = std::max<double>(sum, 0.0001); // avoid divison by zero
  chroX = triX / sum * 255;
  chroY = triY / sum * 255;
}


void CvtColorSpace::cvtBGR_Yxy(Image8U const& image, Image8U& result)
{
  uint32 const width = image.width();
  uint32 const height = image.height();

  for (uint32 y=0; y<height; ++y)
    for (uint32 x=0; x<width; ++x)
      {
        double triY, chroX, chroY;
        rgb2YxyMat(image(x, y, 2), image(x, y, 1), image(x, y, 0), triY, chroX, chroY);
        result(x, y, 0) = (uint8)(triY + 0.5);
        result(x, y, 1) = (uint8)(chroX + 0.5);
        result(x, y, 2) = (uint8)(chroY + 0.5);
      }
}

// Image32F version of the above function
void CvtColorSpace::cvtBGR_Yxy(Image32F const& image, Image32F& result)
{
  uint32 const width = image.width();
  uint32 const height = image.height();

  for (uint32 y=0; y<height; ++y)
    for (uint32 x=0; x<width; ++x)
      {
        double triY, chroX, chroY;
        rgb2YxyMat(image(x, y, 2), image(x, y, 1), image(x, y, 0), triY, chroX, chroY);
        result(x, y, 0) = triY;  result(x, y, 1) = chroX;  result(x, y, 2) = chroY;
      }
}


inline void Yxy2rgbMat(double triY, double chroX, double chroY, double& r, double& g, double& b, bool scale)
{
  chroY = std::max<double>(chroY, 0.0001); // avoid division by zero
  double triX = triY * chroX / chroY;
  double triZ = triY * (255 - chroX - chroY) / chroY;
  // inverse of the above matrix
  r =  2.3706743*triX - 0.9000405*triY - 0.4706338*triZ;
  g = -0.5138850*triX + 1.4253036*triY + 0.0885814*triZ;
  b =  0.0052982*triX - 0.0146949*triY + 1.0093968*triZ;
  double max = std::max<double>(r, std::max<double>(g, b));
  if (scale && max > 255) // scale values down when saturated
    {
      max = 255 / max;
      r *= max; g *= max; b *= max;
    }
}


void CvtColorSpace::cvtYxy_BGR(Image8U const& image, Image8U& result)
{
  uint32 const width = image.width();
  uint32 const height = image.height();

  for (uint32 y=0; y<height; ++y)
    for (uint32 x=0; x<width; ++x)
      {
        double r, g, b;
        Yxy2rgbMat(image(x, y, 0), image(x, y, 1), image(x, y, 2), r, g, b, true);
        result(x, y, 0) = (uint8)b;  result(x, y, 1) = (uint8)g;  result(x, y, 2) = (uint8)r;
      }
}

// Image32F version of the above funtion
void CvtColorSpace::cvtYxy_BGR(Image32F const& image, Image32F& result)
{
  uint32 const width = image.width();
  uint32 const height = image.height();

  for (uint32 y=0; y<height; ++y)
    for (uint32 x=0; x<width; ++x)
      {
        double r, g, b;
        Yxy2rgbMat(image(x, y, 0), image(x, y, 1), image(x, y, 2), r, g, b, false);
        result(x, y, 0) = b;  result(x, y, 1) = g;  result(x, y, 2) = r;
      }
}


void CvtColorSpace::fixBayerResult(Image8U& result)
{
  uint32 const w = result.width();
  uint32 const h = result.height();
  int32 const c = result.channels();
  
  for(int32 chan = 0; chan < c; chan++)
  {
    for(uint32 x = 1; x < w-1; x++)
    {
      result(x,0,chan) = result(x,1,chan);
      result(x,h-1,chan) = result(x,h-2,chan);
    }
    
    for(uint32 y = 0; y < h; y++)
    {
      result(0,y,chan) = result(1,y,chan);
      result(w-1,y,chan) = result(w-2,y,chan);
    }
  }
}



#define BOOST_TEST_DYN_LINK
#include <boost/test/unit_test.hpp>
#include <vector>
#include <driver_types.h>
#include <cuda_runtime.h>
#include "cudaHDR/DeviceManager.h"
#include "cudaHDR/KernelFunctions.h"
#include "types/Image8U.h"
#include "types/MocaException.h"
#include "io/ImageFileReader.h"
#include "io/ImageFileWriter.h"
#include "testcases.h"

BOOST_AUTO_TEST_SUITE(DeviceManagerTest)

BOOST_AUTO_TEST_CASE(getNumberOfDevices)
{
	//Get number of devices
	int num = DeviceManager::getNumberOfDevices();
	BOOST_WARN(num == NUMBER_OF_DEVICES);
}

BOOST_AUTO_TEST_CASE(getMaxGFLOPSDeviceTest)
{
	//Select device mit maximum gflops
	int num = DeviceManager::getMaxGFLOPSDevice();
	BOOST_WARN(num == MAX_GFLOPS_DEVICE_INDEX);
}

BOOST_AUTO_TEST_CASE(deviceQueryTest)
{
	//Query for devices
	std::vector<cudaDeviceProp> devices;
	DeviceManager::deviceQuery(devices);
	BOOST_WARN(strcmp(devices[0].name, DEVICE_ZEROES_NAME) == 0);
}

BOOST_AUTO_TEST_SUITE_END()
#include "tools/NLinSolver.h"


#ifdef HAVE_LIBGSL

#include <gsl/gsl_multifit_nlin.h>


class NLinSolver::Impl
{
public:
  Impl(NLinSolver* solver, sizeType paramCnt, sizeType funcCnt);
  ~Impl();

  void solve(Vector& params);

private:
  static int32 f(gsl_vector const* x, void* params, gsl_vector* f);
  static int32 df(gsl_vector const* x, void* params, gsl_matrix* j);
  static int32 fdf(gsl_vector const* x, void* params, gsl_vector* f, gsl_matrix* j);

  static void vec2gsl(Vector const& vec1, gsl_vector* vec2);
  static void mat2gsl(Matrix const& mat1, gsl_matrix* mat2);
  static void gsl2vec(gsl_vector const* vec1, Vector& vec2);
  static void gsl2mat(gsl_matrix const* mat1, Matrix& mat2);

  gsl_multifit_function_fdf funcs;
  gsl_vector* x;
};


//==================== Impl implementation ====================

NLinSolver::Impl::Impl(NLinSolver* solver, sizeType paramCnt, sizeType funcCnt)
{
  sizeType const n = funcCnt;
  sizeType const p = paramCnt;
  x = gsl_vector_alloc(p);

  funcs.f      = f;
  funcs.df     = df;
  funcs.fdf    = fdf;
  funcs.n      = n;
  funcs.p      = p;
  funcs.params = solver;
}


NLinSolver::Impl::~Impl()
{
  gsl_vector_free(x);
}


void NLinSolver::Impl::solve(Vector& params)
{
  assert(x->size == params.size());
  vec2gsl(params, x);

  gsl_multifit_fdfsolver* multifit = gsl_multifit_fdfsolver_alloc(gsl_multifit_fdfsolver_lmder, funcs.n, funcs.p);
  gsl_multifit_fdfsolver_set(multifit, &funcs, x);

  for (indexType iter=0; iter<200; ++iter)
    gsl_multifit_fdfsolver_iterate(multifit);

  gsl2vec(multifit->x, params);
  gsl_multifit_fdfsolver_free(multifit);
}


int32 NLinSolver::Impl::f(gsl_vector const* x, void* params, gsl_vector* f)
{
  NLinSolver* solver = static_cast<NLinSolver*>(params);
  Vector position(x->size);
  gsl2vec(x, position);
  Vector values(f->size);
  solver->function(position, values);
  vec2gsl(values, f);
  return GSL_SUCCESS;
}


int32 NLinSolver::Impl::df(gsl_vector const* x, void* params, gsl_matrix* j)
{
  NLinSolver* solver = static_cast<NLinSolver*>(params);
  Vector position(x->size);
  gsl2vec(x, position);
  Matrix jacobi(j->size1, j->size2);
  solver->derivative(position, jacobi);
  mat2gsl(jacobi, j);
  return GSL_SUCCESS;
}


int32 NLinSolver::Impl::fdf(gsl_vector const* x, void* params, gsl_vector* f, gsl_matrix* j)
{
  NLinSolver* solver = static_cast<NLinSolver*>(params);
  Vector position(x->size);
  gsl2vec(x, position);
  Vector values(f->size);
  Matrix jacobi(j->size1, j->size2);
  solver->both(position, values, jacobi);
  vec2gsl(values, f);
  mat2gsl(jacobi, j);
  return GSL_SUCCESS;
}


void NLinSolver::Impl::vec2gsl(Vector const& vec1, gsl_vector* vec2)
{
  assert(vec1.size() == vec2->size);
  for (indexType i=0; i<vec1.size(); ++i)
    gsl_vector_set(vec2, i, vec1[i]);
}


void NLinSolver::Impl::mat2gsl(Matrix const& mat1, gsl_matrix* mat2)
{
  assert(mat1.size1() == mat2->size1);
  assert(mat1.size2() == mat2->size2);
  for (indexType i=0; i<mat1.size1(); ++i)
    for (indexType j=0; j<mat1.size2(); ++j)
      gsl_matrix_set(mat2, i, j, mat1(i,j));
}


void NLinSolver::Impl::gsl2vec(gsl_vector const* vec1, Vector& vec2)
{
  assert(vec2.size() == vec1->size);
  for (indexType i=0; i<vec2.size(); ++i)
    vec2[i] = gsl_vector_get(vec1, i);
}


void NLinSolver::Impl::gsl2mat(gsl_matrix const* mat1, Matrix& mat2)
{
  assert(mat2.size1() == mat1->size1);
  assert(mat2.size2() == mat1->size2);
  for (indexType i=0; i<mat2.size1(); ++i)
    for (indexType j=0; j<mat2.size2(); ++j)
      mat2(i,j) = gsl_matrix_get(mat1, i, j);
}


//==================== NLinSolver ====================

NLinSolver::NLinSolver(std::vector<Vector> const& modelPoints, std::vector<Vector> const& imagePoints, sizeType paramCnt, sizeType funcCnt)
  : modelPoints(modelPoints), imagePoints(imagePoints)  
{
  pImpl = boost::shared_ptr<Impl>(new Impl(this, paramCnt, funcCnt));
}


NLinSolver::~NLinSolver()
{
}


void NLinSolver::solve(Vector& params)
{
  pImpl->solve(params);
}


#endif // HAVE_LIBGSL


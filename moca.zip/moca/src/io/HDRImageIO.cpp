#include "io/HDRImageIO.h"

#include "filter/CvtColorSpace.h"
#include "types/MocaException.h"
#include <fstream>
#include <math.h>


void HDRImageIO::saveHDRImage(std::string const& fileName, Image32F const& _image, bool bgr)
{
  if (fileName.length() == 0)
    BOOST_THROW_EXCEPTION(ArgumentException("No file name given for loading."));
  if (_image.height() <= 0 || _image.width() <= 0)
    BOOST_THROW_EXCEPTION(ArgumentException("Not a valid image size."));
  if (_image.channels() != 3)
    BOOST_THROW_EXCEPTION(ArgumentException("Image must be color image."));
  
  boost::shared_ptr<Image32F> temp;
  if (!bgr)
    {
      temp = boost::shared_ptr<Image32F>(new Image32F(_image.width(), _image.height(), _image.channels()));
      CvtColorSpace::cvtYxy_BGR(_image, *temp);
    }
  Image32F const& image = bgr ? _image : *temp;

  uint8 rgbe[4];
  rgbe[0] = rgbe[1] = rgbe[2] = rgbe[3] = 0;
  std::ofstream pixelOut(fileName.c_str());
  pixelOut << "GAMMA = 1.0 \n" << "EXPOSURE = 1.0 \n" << "FORMAT = 32-bit_rgbe \n\n" << "-Y " << image.width() << " +X " << image.height() << "\n";   
  // value of GAMMA = 1.0 indicates that no gamma correction was used, value EXPOSURE = 1.0 corresponds to <exposure> watts/steradian/m^2
  for(uint32 y = 0; y < image.height(); ++y)
    for(uint32 x = 0; x < image.width(); ++x)
      {
        float v = std::max(image(x, y, 0), image(x, y, 1));
        v = std::max(image(x, y, 2), v);
        int e;
        v = frexp(v, &e) * 256.0f / v;
        rgbe[0] = (uint8) (image(x, y, 2) * v);
        rgbe[1] = (uint8) (image(x, y, 1) * v);
        rgbe[2] = (uint8) (image(x, y, 0) * v);
        rgbe[3] = (uint8) (e + 128);       
        if(pixelOut.fail())
          BOOST_THROW_EXCEPTION(ArgumentException("Error while writing to file"));
        pixelOut << rgbe[0] << rgbe[1] << rgbe[2] << rgbe[3];
      }
  pixelOut.close();
}


boost::shared_ptr<Image32F> HDRImageIO::loadHDRImage(std::string const& fileName, bool bgr)
{
  if (fileName.length() == 0)
    BOOST_THROW_EXCEPTION(ArgumentException("No file name given for loading."));
  
  int width = 1, height = 1;
  std::ifstream pixelIn(fileName.c_str());
  while (pixelIn.good())
    {
      std::string str;
      pixelIn >> str;
      if (str == "-Y")
        {
          pixelIn >> width >> str >> height;
          break;
        }
      if (pixelIn.eof() || width <= 0 || height <= 0)
        BOOST_THROW_EXCEPTION(ArgumentException("This is not a valid rgbe file."));
    }
  pixelIn.seekg((int)pixelIn.tellg() + 1); // skip over newline
  boost::shared_ptr<Image32F> image(new Image32F(width, height, 3));
  uint8 rgbe[4];
  rgbe[0] = rgbe[1] = rgbe[2] = rgbe[3] = 0;
  for(int y = 0; y < height; ++y)
    for(int x = 0; x < width; ++x)
      {
        if(pixelIn.fail())
          BOOST_THROW_EXCEPTION(ArgumentException("Error while reading from file"));
        for(int i = 0; i < 4; ++i)
          rgbe[i] = pixelIn.get();
        float f = ldexp(1.0, rgbe[3] - (int)(128 + 8));
        (*image)(x, y, 2) = rgbe[0] * f;
        (*image)(x, y, 1) = rgbe[1] * f;
        (*image)(x, y, 0) = rgbe[2] * f;
      }   
  pixelIn.close();
  if (!bgr)
    CvtColorSpace::cvtBGR_Yxy(*image, *image);
  return image;
}

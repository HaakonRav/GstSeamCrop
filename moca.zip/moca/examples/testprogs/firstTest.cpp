#include <iostream>
#include "types/Image8U.h"
#include "types/MocaException.h"
#include "types/Vector.h"
#include "types/Matrix.h"
#include "types/Rect.h"
#include "gui/FLTKHeaders.h"
#include "gui/DisplayWindow.h"


#ifdef HAVE_LIBFLTK


class FirstTest : public DisplayWindow
{
public:
  FirstTest()
    : DisplayWindow(Rect(0, 0, 1024, 1024), "First Test with the new MoCA")
  {
    for (uint32 y=0; y<image->height(); ++y)
      for (uint32 x=0; x<image->width(); ++x)
        (*image)(x, y) = 0;
  }

  void clickedRect(Rect rect)
  {
    for (int y=rect.y; y<rect.h+rect.y; ++y)
      for (int x=rect.x; x<rect.w+rect.x; ++x)
        (*image)(x, y) = 255;
  }

  void doStuff()
  {
    showImage(image);
  }
};


int main(int argc, char** argv)
{
  try {
    FirstTest firstTest;
    firstTest.mainLoop();
  } catch(MocaException& e)
    {
      std::cerr << diagnostic_information(e);
    }

  return 0;
}


#else // HAVE_LIBFLTK


int main(int argc, char** argv)
{
  std::cout << "this example requires FLTK." << std::endl;
  return 0;
}

#endif // HAVE_LIBFLTK


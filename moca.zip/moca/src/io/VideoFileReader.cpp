#include "io/VideoFileReader.h"

#include "types/MocaException.h"


// ==================== VideoFileReader ====================
 
VideoFileReader::VideoFileReader(std::string const& fileName)
  : fileName(fileName), width(0), height(0), frameCount(0)
{
  file = NULL;
}


VideoFileReader::~VideoFileReader()
{
  stop();
}
  

void VideoFileReader::start()
{
  file = cvCaptureFromFile(fileName.c_str());
  if(file == NULL)
    BOOST_THROW_EXCEPTION(IOException(std::string("Couldn't open video file '") + fileName + std::string("'.")));
    
  width = (sizeType)cvGetCaptureProperty(file, CV_CAP_PROP_FRAME_WIDTH);
  height = (sizeType)cvGetCaptureProperty(file, CV_CAP_PROP_FRAME_HEIGHT);
  frameCount = (sizeType)cvGetCaptureProperty(file, CV_CAP_PROP_FRAME_COUNT);

  IplImage* temp = cvQueryFrame(file);
  if(temp == NULL)
    BOOST_THROW_EXCEPTION(IOException(std::string("Couldn't read frame from video file '") + fileName + std::string("'.")));
  channels = temp->nChannels; // work around because there's no "number of channels"-property
  setCurrentFrame(0);
}


void VideoFileReader::stop()
{
  if(file != NULL)
  {
    cvReleaseCapture(&file);
    width = height = frameCount = 0;
    file = NULL;
  }
}


void VideoFileReader::getImage(Image8U& image)
{
  IplImage* frame = cvQueryFrame(file); // frame must not be freed by the user (us)!
  if(frame == NULL)
    BOOST_THROW_EXCEPTION(IOException(std::string("Couldn't read frame from video file '") + fileName + std::string("'.")));
  image.copyFrom(frame);
}
  

sizeType VideoFileReader::getImageWidth()
{
  return width;
}


sizeType VideoFileReader::getImageHeight()
{
  return height;
}


Rect VideoFileReader::getImageDimension()
{
  return Rect(0,0,width,height);
}
  

int32 VideoFileReader::getImageChannels()
{
  return channels;
}


sizeType VideoFileReader::getFrameCount()
{
  return frameCount;
}


indexType VideoFileReader::getCurrentFrame()
{
  return (indexType)cvGetCaptureProperty(file, CV_CAP_PROP_POS_FRAMES);
}


void VideoFileReader::setCurrentFrame(indexType frame)
{
  cvSetCaptureProperty(file, CV_CAP_PROP_POS_FRAMES, frame);
}


void VideoFileReader::loadVideo(std::string const& fileName)
{
  if(file != NULL)
    BOOST_THROW_EXCEPTION(RuntimeException("You have to stop the VideoFileReader before loading a new file."));

  this->fileName.assign(fileName);
}


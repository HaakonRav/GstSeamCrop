#include <iostream>
#include "io/IO.h"
#include "io/VideoReader.h"
#include "types/MocaException.h"
#include <string>
#include <sstream>

int main(int argc, char* argv[]){ 
  if (argc != 3) {
    std::cerr << "not enaugh arguements: \"Vid\" \"Destination Path\"" << std::endl;
    return 1;
  }
  VideoReader reader(argv[1]);
  reader.start();
  
  Image8U destBild = Image8U(reader.getImageWidth(), reader.getImageHeight(), 3);
  
  std::stringstream sstr;
  
  int x=0;
  while(!reader.getEndOfVideo()) {
    sstr << x << ".png";
    reader.getImage(destBild);  
      
    try {
      std::cout << "Frame: " << x << "\r" << std::flush;
      IO::saveImage(argv[2]+sstr.str(), destBild); 

    } catch (MocaException e) {
      std::cout << "save Image error: " << e.what() << std::endl;
      exit (-1);
    }  

    sstr.str("");
    sstr.clear();

    x++;
  }
  reader.stop();
}

#ifndef WINHDR_IMAGE_REGISTRATION_H
#define WINHDR_IMAGE_REGISTRATION_H

#include "feature/HistogramReg.h"
#include "feature/WardImageReg.h"
#include "Logic.h"
#include <vector>

#ifdef HAVE_CUDA
#include "cudaHDR/GPUHistogramReg.h"
#endif

class ExposureLoader;


class ImageRegistration
{
public:
  ImageRegistration();

  void registerFrame(HDRFrame& frame);
  void switchGroundTruth();
  void initFilter();

private:
  friend class GroundTruth;
  void registerImages(std::vector<Exposure>& expSet, HDRFrame* frame = 0);

  WardImageReg ward;
#ifndef HAVE_CUDA
  HistogramReg histReg;
#else
  GPUHistogramReg histReg;
#endif
};


class GroundTruth
{
public:
  GroundTruth(boost::shared_ptr<ExposureLoader> loader);

  void getGroundTruth(HDRFrame& frame);
  void load();
  void save();
  void init();
  void moveGT(int dx, int dy);
  void editGT(HDRFrame& frame);

private:
  boost::shared_ptr<ExposureLoader> loader;
  std::vector<std::vector<VectorI> > gTruth;
};


#endif

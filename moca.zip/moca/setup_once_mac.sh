#!/bin/bash
echo please use sudo to execute this script
ln -s /usr/bin/glibtoolize /usr/bin/libtoolize

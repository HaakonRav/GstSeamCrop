#include "gui/CamControl.h"

#ifdef HAVE_CAMERA
#ifdef HAVE_LIBFLTK

#include <iostream>
#include <sstream>
#include "io/CameraReader.h"
#include "gui/FeatureControl.h"


CamControl::CamControl(boost::shared_ptr<CameraReader> &reader, Rect wndSize)
  : Fl_Double_Window(wndSize.x, wndSize.y, wndSize.w, wndSize.h, "Camera Controls"), curPage(1)
{
  if((uint32)wndSize.w < FeatureControl::minWidth)
    wndSize.w = FeatureControl::minWidth;

  std::vector<CameraFeaturePtr> presentFeatures;
  for(indexType i = 0; i < CameraFeature::numFeatures; i++)
  {
    CameraFeaturePtr feature = reader->getFeature(i);
    if(feature->isPresent())
      presentFeatures.push_back(feature);
  }
  numFeatures = presentFeatures.size();

  if(numFeatures > featuresPerPage)
  {
    numPages = numFeatures / featuresPerPage;
    if(numFeatures % featuresPerPage != 0)
      numPages += 1;
   
    wndSize.h = FeatureControl::height*featuresPerPage + spacing*featuresPerPage + 2*borderSize + 24;
    size(wndSize.w, wndSize.h);

    Fl_Button *prevButton = new Fl_Button(borderSize, wndSize.h-(borderSize+24), 128, 24, "previous page");
    prevButton->callback(prevButtonCallback, this);

    pageLabel = new Fl_Output(136+borderSize, wndSize.h-(borderSize+24), 32, 24);
    pageLabel->box(FL_NO_BOX);

    Fl_Button *nextButton = new Fl_Button(176+borderSize, wndSize.h-(borderSize+24), 128, 24, "next page");
    nextButton->callback(nextButtonCallback, this);
  }
  else
  {
    numPages = 1;
    wndSize.h = FeatureControl::height*numFeatures + spacing*(numFeatures-1) + 2*borderSize;
    size(wndSize.w, wndSize.h);
  }

  wndSize.x = borderSize;
  wndSize.w -= 2*borderSize;
  wndSize.h = FeatureControl::height;
   
  for(indexType i = 0; i < numFeatures; i++)
  {
    wndSize.y = borderSize + (i%featuresPerPage)*(FeatureControl::height + spacing);
    FeatureControl *ctrl = new FeatureControl(presentFeatures[i], wndSize);
    controls.push_back(ctrl);
  }

  end();
 
  showPage(1);  
}


void CamControl::draw()
{
  Fl_Double_Window::draw();

  for(indexType i = 0; i < featuresPerPage; i++)
  {
    indexType index = i + featuresPerPage * (curPage-1);
    if(index < numFeatures)
    {
      controls[index]->show();
      controls[index]->update();
    }
  }
}


void CamControl::showPage(indexType pageNum)
{
  if(pageNum < 1)
    pageNum = 1;
  if(pageNum > numPages)
    pageNum = numPages;
  curPage = pageNum;  
  
  for(indexType i = 0; i < controls.size(); i++)
    controls[i]->hide();
    
  if(numPages != 1)
  {
    std::stringstream sstr("");
    sstr << curPage << " / " << numPages;
    pageLabel->value(sstr.str().c_str());
  }
  
  redraw();
}


void CamControl::prevButtonCallback(Fl_Widget *_widget, void *_window)
{
  CamControl *wnd = (CamControl *)_window;
  wnd->showPage(wnd->curPage - 1);
}


void CamControl::nextButtonCallback(Fl_Widget *_widget, void *_window)
{
  CamControl *wnd = (CamControl *)_window;
  wnd->showPage(wnd->curPage + 1);
}


#endif // HAVE_LIBFLTK
#endif // HAVE_CAMERA


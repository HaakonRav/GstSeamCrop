#include "StereoIO.h"

#include "filter/CvtColorSpace.h"
#include "filter/Filter.h"
#include "io/IO.h"

#include <boost/filesystem.hpp>


StereoIO::StereoIO()
  : left(1, 1, 1), right(1, 1, 1), disparity(1, 1, 1), frameIndex(0)
{
}


std::string StereoIO::makeFilename(std::string const& dir, std::string const& name,
                                   int index, int digits, std::string const& ext)
{
  std::ostringstream oss;
  oss << dir << name;
  for (int i=digits; i>1; --i)
    if (index < pow(10, i-1))
      oss << "0";
    else
      break;
  oss << index << ext;
  return oss.str();
}


void StereoIO::saveSBS(Image8U const& left, Image8U const& right, std::string const& dir, std::string const& name)
{
  Image8U outFrame(left.width()+right.width(), left.height(), left.channels());
  Filter::copyImage(left, outFrame, Rect(0, 0, left.width(), left.height()), Vector2D::create(0, 0));
  Filter::copyImage(right, outFrame, Rect(0, 0, right.width(), right.height()), Vector2D::create(left.width(), 0));
  IO::saveImage(makeFilename(dir, name, frameIndex, 4, ".png"), outFrame);
}


void StereoIO::saveDisparity(Image16S const& disp, std::string const& dir, std::string const& name)
{
  double min=MOCA_FLOAT_MAX, max=-MOCA_FLOAT_MAX;
  for (uint32 y=0; y<disp.height(); ++y)
    for (uint32 x=0; x<disp.width(); ++x) {
      int32 d = disp(x, y);
      min = d < min ? d : min;
      max = d > max ? d : max;
    }
  Image8U output(disp.width(), disp.height(), disp.channels());
  for (uint32 y=0; y<output.height(); ++y)
    for (uint32 x=0; x<output.width(); ++x)
      output(x, y) = (uint8)((disp(x, y)-min) / (max-min) * 255);
  IO::saveImage(makeFilename(dir, name, frameIndex, 4, ".png"), output);
}


void StereoIO::saveOcclusion(Image8U const& occlusion, std::string const& dir, std::string const& name)
{
  Image8U out(occlusion.width(), occlusion.height(), 1);
  Filter::set(out, 0);
  for (uint32 y=0; y<out.height(); ++y)
    for (uint32 x=0; x<out.width(); ++x)
      if (occlusion(x, y) > 0)
        out(x, y) = 255;
  IO::saveImage(makeFilename(dir, name, frameIndex, 4, ".png"), out);
}


void StereoIO::saveEnergy(Image32F const& energy, std::string const& dir, std::string const& name)
{
  double max = 0;
  for (uint32 y=0; y<energy.height(); ++y)
    for (uint32 x=0; x<energy.width(); ++x)
      if (energy(x, y) > max && energy(x, y) < MOCA_FLOAT_MAX)
        max = energy(x, y);

  Image8U visual(energy.width(), energy.height(), 3);
  for (uint32 y=0; y<energy.height(); ++y)
    for (uint32 x=0; x<energy.width(); ++x)
      if (energy(x, y) < MOCA_FLOAT_MAX)
        visual(x, y, 0) = visual(x, y, 1) = visual(x, y, 2) = energy(x, y)/max * 255;
      else {
        visual(x, y, 0) = visual(x, y, 1) = 0;
        visual(x, y, 2) = 255;
      }
  IO::saveImage(makeFilename(dir, name, frameIndex, 4, ".png"), visual);
}


uint32 StereoIO::getFrameIndex()
{
  return frameIndex;
}


Image8U StereoIO::getLeft()
{
  return left;
}


Image8U StereoIO::getRight()
{
  return right;
}


Image16S StereoIO::getDisparity()
{
  return disparity;
}


// ==================== SBSVideoIO ====================

SBSVideoIO::SBSVideoIO(std::string filename)
  : vr(filename), frame(1, 1, 1)
{
}


void SBSVideoIO::start()
{
  vr.start();
  frame = Image8U(vr.getImageWidth(), vr.getImageHeight(), vr.getImageChannels());
  frameIndex = 0;
}


void SBSVideoIO::stop()
{
  vr.stop();
}


void SBSVideoIO::loadNext()
{
  vr.getImage(frame);

  Image8U bwImg(frame.width(), frame.height(), 1);
  CvtColorSpace::convert(frame, bwImg, COLOR_BGR, COLOR_Y);
  left  = Image8U(frame.width()/2, frame.height(), 1);
  right = Image8U(frame.width()/2, frame.height(), 1);
  Filter::copyImage(bwImg, left, Rect(0, 0, left.width(), left.height()), Vector2D::create(0, 0));
  Filter::copyImage(bwImg, right, Rect(left.width(), 0, right.width(), right.height()), Vector2D::create(0, 0));

  // SGBM: realDisp = disparity/16
  // range realDisp: -1, ..., maxDisp (-1 means invalid)
  // rightPixel = leftPixel - realDisp
  // LeftX - Disparity = RightX
  disparity = Image16S(left.width(), left.height(), 1);
  Filter::findStereoCorrespondenceSGBM(left, right, disparity, 16);
  for (uint32 y=0; y<disparity.height(); ++y)
    for (uint32 x=0; x<disparity.width(); ++x)
      disparity(x, y) = (int)(disparity(x, y) / 16.0 + 0.5);

  ++frameIndex;
}


bool SBSVideoIO::hasMore()
{
  return vr.getCurrentFrameCount() < (vr.getTotalFrameCount()/1000)-1; // /1000 ist ein Hack!
}


// ==================== LRImagesIO ====================

LRImageIO::LRImageIO(std::string dir, std::string leftname, std::string rightname,
                     std::string dispname, int digits, std::string ext)
  : dir(dir), leftname(leftname), rightname(rightname), dispname(dispname), digits(digits), ext(ext)
{
}


void LRImageIO::start()
{
  frameIndex = 0;
}


void LRImageIO::stop()
{
}


void LRImageIO::loadNext()
{
  boost::shared_ptr<Image8U> leftCol (IO::loadImage(makeFilename(dir, leftname,  frameIndex+1, digits, ext)));
  boost::shared_ptr<Image8U> rightCol(IO::loadImage(makeFilename(dir, rightname, frameIndex+1, digits, ext)));
  left = *leftCol; //Image8U(leftCol->width(), leftCol->height(), 1);
  right = *rightCol; //Image8U(rightCol->width(), rightCol->height(), 1);
  //CvtColorSpace::convert(*leftCol, left, COLOR_BGR, COLOR_Y);
  //CvtColorSpace::convert(*rightCol, right, COLOR_BGR, COLOR_Y);

  boost::shared_ptr<Image8U> disp8U;
  disp8U = IO::loadImage(makeFilename(dir, dispname, frameIndex+1, digits, ext));
  disparity = Image16S(disp8U->width(), disp8U->height(), 1);
  for (uint32 y=0; y<disparity.height(); ++y)
    for (uint32 x=0; x<disparity.width(); ++x)
      disparity(x, y) = (int16)((*disp8U)(x, y)/4.0 + 0.5);

  ++frameIndex;
}


bool LRImageIO::hasMore()
{
  std::string filename(makeFilename(dir, leftname, frameIndex+2, digits, ext));
  return boost::filesystem::exists(filename);
}

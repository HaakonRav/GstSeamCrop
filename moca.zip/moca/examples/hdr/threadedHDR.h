#include "feature/WardImageReg.h"
#include "filter/HDR.h"
#include "gui/CameraWindow.h"
#include "tools/Thread.h"
#include "types/Exposure.h"
#include "types/BlockingQueue.h"

#include <boost/shared_ptr.hpp>
#include <boost/thread/mutex.hpp>


class HDRWindow;


// threading model: four threads exist: main thread, capture thread, image preperation thread, stitching thread
// capture thread: repeatedly captures new images (as long as "it's buffer" allows); puts the captured images into
// the queue of the image preperation thread
// image preperation: color conversion + image registration; puts the result into the stitching thread's queue
// stitchting thread: does stitching and tone mapping; the resulting images are put into the main thread's queue
// main thread: repeatedly looks for new results and shows them on the screen (also updates the shutter to be used
// for the next capture)

class CaptureThread : public Thread
{
public:
  CaptureThread(HDRWindow* wnd, uint32 bufferSize) : wnd(wnd), availableBuffers(bufferSize) {}
  
  void closeBuffer();
  void openBuffer();

protected:
  void doStuff();
  void cleanup();

private:
  HDRWindow* wnd;
  uint32 availableBuffers; // used for avoiding that the processing threads can't handle to load produced by the capture thread
  boost::mutex mutex;
};


class ImagePreperationThread : public Thread
{
public:
  ImagePreperationThread(HDRWindow* wnd) : wnd(wnd) {}

  BlockingQueue<std::vector<Exposure > > queue;
  
protected:
  void doStuff();
  void cleanup();
  
private:
  HDRWindow* wnd;
};


class StitchingThread : public Thread
{
public:
  StitchingThread(HDRWindow* wnd) : wnd(wnd) {}

  BlockingQueue<std::vector<Exposure> > queue;
  
protected:
  void doStuff();
  void cleanup();
  
private:
  HDRWindow* wnd;
};


struct Result
{
  boost::shared_ptr<Image32F> hdrImg;
  boost::shared_ptr<Image8U> ldrImg;
  float nextShutter;
};


class HDRWindow : public CameraWindow
{
  static int const imgWidth = 640;
  static int const imgHeight = 480;
  static CameraReader::ColorMode const colorMode = CameraReader::MODE_RAW8;

public:
  HDRWindow(bool sequenceMode = false);

  void doStuff();
  void cameraModeHDR();
  void cameraModeHDR_MT();
  void cameraModeLDR();
  float estimateNextShutter(double avg, uint32 darkest, uint32 brightest);
  void registerImages(std::vector<Exposure>& expSet);

  // stitches exposures in expSets[currentSet] which are either Yxy or gray
  // result will be in either colorImage or image
  double stitchHDR(std::vector<Exposure>& expSet, Result& result);
  double stitchHDR(std::vector<Exposure>& expSet);
  void print(std::vector<Exposure>& expSet);
  void createImages(uint32 width, uint32 height);

  // ==================== callbacks ====================
  static void printCB(DisplayWindow* dWnd);
  static void wardCB(DisplayWindow* dWnd);
  static void hdrCB(DisplayWindow* dWnd);
  static void ghostRemovalCB(DisplayWindow* dWnd);
  static void ghostSegmentCB(DisplayWindow* dWnd);
  
  // ==================== Attributes ====================
  // Logic
  HDR hdr;
  WardImageReg ward;

  // Data
  Exposure exposure;
  BlockingQueue<Result> hdrImages;
  boost::shared_ptr<Image8U> colorImage;
  boost::shared_ptr<Image32F> hdrImage, hdrImageCol;
  float minShutter, maxShutter;

  // State
  bool hdrSwitch, regSwitch, ghostRemovalSwitch, ghostSegmentSwitch, printSwitch;
  bool color, useMultiThreading, sequenceMode;
  
  // Threads
  boost::shared_ptr<CaptureThread> captThread;
  boost::shared_ptr<ImagePreperationThread> imgPrepThread;
  boost::shared_ptr<StitchingThread> stitchThread;
};


